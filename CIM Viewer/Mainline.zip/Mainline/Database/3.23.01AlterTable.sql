UPDATE ChangeType 
SET Name = 'Related CIRs changed'
WHERE Name = 'CIR Added'