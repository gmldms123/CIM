USE Pmanagement
DECLARE @ERR AS Int

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0

--------------------------------------------------------------------------------------------------

-- AlertReceiverRoleType	
	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Project Manager',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Execution Manager',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Platform Manager',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Case Creator',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Technical Specialist',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim