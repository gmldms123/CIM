USE Pmanagement
DECLARE @ERR AS Int

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0

--------------------------------------------------------------------------------------------------

-- StandardFolder	
	BEGIN	
        DELETE FROM StandardFolder
		WHERE Name = 'Superseded'
		SET @ERR = @@ERROR
	END

	BEGIN	
		DELETE FROM CaseRelation
		WHERE PhaseId Is Not NULL
		SET @ERR = @@ERROR
	END

	/* drop Folder2ProjectPlanDocument table */
	DROP TABLE Folder2ProjectPlanDocument
	SET @Err = @@ERROR 

	/* drop ProjectPlan table */
	DROP TABLE ProjectPlan 
	SET @Err = @@ERROR 

	/* Prepare delete documentBinary data with relation projectplanversion -> documenttemplate -> documentbinary */
	DECLARE @ids as nvarchar(4000)
	DECLARE @id AS BIGINT
	DECLARE @sqlstr as nvarchar(4000)

	SET @ids = ''

	DECLARE Documentbinary_cursor CURSOR FOR
	SELECT db.DocumentBinaryId 
	FROM ProjectPlanversion p 
		LEFT JOIN DocumentTemplate d on p.DocumentTemplateId = d.DocumentTemplateId 
		LEFT JOIN DocumentBinary db on db.DocumentBinaryId = d.DocumentBinaryId 

	OPEN DocumentBinary_Cursor

	FETCH NEXT FROM DocumentBinary_Cursor 
	INTO @id 
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		SET @ids = @ids + CONVERT(NVARCHAR(10), @Id) + ','
		
		FETCH NEXT FROM Documentbinary_cursor
		INTO @Id
	END
	CLOSE DocumentBinary_cursor
	DEALLOCATE DocumentBinary_Cursor

	/* Drop constraint, so it's possible to delete the projectplanversion */
	ALTER TABLE ProjectPlanVersion DROP CONSTRAINT FK_ProjectPlanVersion_DocumentTemplate
	ALTER TABLE ProjectPlanVersion DROP CONSTRAINT FK_ProjectPlanVersion_BusinessProcess
	ALTER TABLE Phase DROP CONSTRAINT FK_Phase_ProjectPlanVersion
	SET @Err = @@ERROR 

	/* Drop table projectplanversion */
	DROP TABLE ProjectPlanVersion 
	SET @Err = @@ERROR 

	/* Delete documentBinary data with relation projectplanversion -> documenttemplate -> documentbinary */
	SET @Ids = LEFT(@Ids, LEN(@Ids) - 1) + ')'	
	EXEC ('DELETE FROM DocumentBinary WHERE DocumentBinaryId IN (' + @ids)
	SET @Err = @@ERROR 

	/* Delete data from DocumentTemplate where title like project plan */
	DELETE FROM DocumentTemplate 
	WHERE Title LIKE '%Project Plan%'
	SET @Err = @@ERROR 

	/* Delete documentBinary data with relation to folder -> folder2document -> document -> documentbinary where foldertypeid = 7 */
	SET @ids = ''

	DECLARE Documentbinary_cursor CURSOR FOR
	SELECT db.DocumentBinaryId 
	FROM folder f
		LEFT JOIN folder2document f2d ON f.folderid = f2d.folderid  
		LEFT JOIN Document d ON f2d.DocumentId = d.DocumentId 
		LEFT JOIN DocumentBinary db ON db.DocumentBinaryId = d.DocumentBinaryId 
	WHERE foldertypeid = 7

	OPEN DocumentBinary_Cursor

	FETCH NEXT FROM DocumentBinary_Cursor 
	INTO @id 

	WHILE @@FETCH_STATUS = 0 
	BEGIN
		SET @ids = @ids + CONVERT(NVARCHAR(10), @Id) + ','
		
		IF LEN(@Ids) > 2000
		BEGIN 
			SET @Ids = LEFT(@Ids, LEN(@Ids) - 1) + ')'	
				EXEC ('DELETE FROM DocumentBinary WHERE DocumentBinaryId IN (' + @ids)
				SET @Err = @@Error
			
			SET @ids = ''
		END
		
		FETCH NEXT FROM Documentbinary_cursor
		INTO @Id
	END
	CLOSE DocumentBinary_cursor
	DEALLOCATE DocumentBinary_Cursor

	IF RIGHT(@Ids, 1) <> ')' AND LEN(@Ids) > 1
	BEGIN
		SET @Ids = LEFT(@Ids, LEN(@Ids) - 1) + ')'	
		EXEC ('DELETE FROM DocumentBinary WHERE DocumentBinaryId IN (' + @ids)
		SET @Err = @@ERROR
	END

	/* Delete documentversion with relation to folder -> folder2document -> document -> documentversion where foldertypeid = 7 */ 
	DELETE FROM DocumentVersion
	FROM folder f
		LEFT JOIN folder2document f2d on f.folderid = f2d.folderid  
		LEFT JOIN Document d on f2d.DocumentId = d.DocumentId 
		LEFT JOIN DocumentVersion dv on dv.DocumentId = d.DocumentId 
	WHERE foldertypeid = 7
	SET @Err = @@Error 

	/* Delete document with relation to folder -> folder2document -> document where foldertypeid = 7 */ 
	DELETE FROM Document
	FROM folder f
		LEFT JOIN folder2document f2d on f.folderid = f2d.folderid  
		LEFT JOIN Document d on f2d.DocumentId = d.DocumentId 
	WHERE foldertypeid = 7
	SET @ERr = @@Error

	/* Delete folder2document with relation to folder -> folder2document where foldertypeid = 7 */ 
	DELETE FROM Folder2Document 
	FROM folder2document f2d 
		JOIN folder f on f.folderid = f2d.folderid  
	WHERE foldertypeid = 7
	SET @Err = @@Error

	/* Delete superseeded data from folder */
	DELETE FROM Folder WHERE FolderTypeId = 7 AND Name LIKE '%Superseded%'
	SET @Err = @@Error

-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim