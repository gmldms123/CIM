USE Pmanagement
DECLARE @ERR AS Int

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0

--------------------------------------------------------------------------------------------------

-- Feature	
	BEGIN	
		UPDATE Feature
		SET Description = 'Various Relations'
		WHERE Description = 'Supplier Relations'
		SET @ERR = @@ERROR
	END

-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0

--------------------------------------------------------------------------------------------------

-- Feature	
	BEGIN	
		UPDATE AnyChanges 
		SET [Description] = 'VariousRelations' 
		WHERE AnyChangesId = 11
		SET @ERR = @@ERROR
	END

-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0

--------------------------------------------------------------------------------------------------

-- Feature	
	BEGIN	
		UPDATE CaseRelation 
		SET Name = 'Technical' 
		WHERE CaseRelationId = 1
		SET @ERR = @@ERROR
	END

-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim
