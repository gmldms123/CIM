USE [PManagement]
GO
/****** Object:  StoredProcedure [dbo].[CreateCaseStandards]    Script Date: 11/11/2010 12:45:59 ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CreateCaseStandards]
  @CaseId BIGINT
AS BEGIN
  DECLARE @Err BIGINT
  DECLARE @BrandId BIGINT
  DECLARE @ManagerId BIGINT
  DECLARE @FolderId AS BIGINT
  DECLARE @DocumentId AS BIGINT
  DECLARE @Timestamp AS DATETIME
  SET @Timestamp = GETUTCDATE()

  BEGIN TRANSACTION
  
  -- Get brand and manager
  SELECT @BrandId = BrandId, @ManagerId = ManagerId
  FROM [Case]
  WHERE CaseId = @CaseId
  SELECT @Err = @@ERROR
  
    -- Check for errors
  IF @Err = 0 BEGIN
  -- Insert phases
    INSERT INTO Case2Phase (CaseId, PhaseId, DeadlineDate)
    SELECT @CaseId, PhaseId, CONVERT(SMALLDATETIME, 'JAN 01 1900 00:00AM', 100)
    FROM Phase
    WHERE BrandId = @BrandId
    SELECT @Err = @@ERROR
  END

  -- Check for errors
  IF @Err = 0 BEGIN
    -- Declare variables to use for cursor fetches and logic handling
    DECLARE @StandardFolderId BIGINT

    -- Declare cursor to fetch standard folders
    DECLARE _Cursor CURSOR FOR
    SELECT StandardFolderId
    FROM StandardFolder
    WHERE StandardFolderId NOT IN (SELECT DISTINCT ParentStandardFolderId FROM StandardFolder WHERE ParentStandardFolderId IS NOT NULL AND BrandId = @BrandId)
      AND BrandId = @BrandId

    -- Loop through cursor fetches
    OPEN _Cursor
    FETCH NEXT FROM _Cursor INTO @StandardFolderId
    WHILE @@FETCH_STATUS = 0 BEGIN
      -- Insert standard folders (via recursive stored procedure)
      EXECUTE @Err = CreateFolder @CaseId, @StandardFolderId, -1
      IF @Err <> 0
         BREAK
      FETCH NEXT FROM _Cursor INTO @StandardFolderId
    END
    CLOSE _Cursor
    DEALLOCATE _Cursor
  END

  -- Check for errors
  IF @Err = 0 BEGIN
    -- Insert populationlist document template to approved folder for new case 
    -- Get folderid for the approved folder 
    SELECT @Folderid = FolderId 
    FROM Folder
    WHERE CaseId = @CaseId AND FolderTypeId = 6 AND [Name] = 'Approved'
    SELECT @Err = @@ERROR    
  END 
        
  -- Check for errors
  IF @Err = 0 BEGIN
    -- Get documenttemplateId for the populationlist template
    INSERT INTO Document (DocumentBinaryId, DocumentClassificationId, [FileName], FileSize, FileDate, Title, Thumbnail)
    SELECT dt.DocumentBinaryId, dt.DocumentClassificationId, dt.[FileName], dt.FileSize, @Timestamp, dt.Title, dt.Thumbnail
    FROM DocumentTemplate dt
    WHERE dt.Title = 'Populationlist'
      AND NOT EXISTS (SELECT 1
                      FROM Document d 
                      WHERE d.DocumentBinaryId=dt.DocumentBinaryId 
                        AND d.DocumentClassificationId=dt.DocumentClassificationId 
                        AND d.[FileName]=dt.[FileName] 
                        AND d.FileSize=dt.FileSize 
                        AND d.FileDate=@Timestamp 
                        AND d.Title=dt.Title)
    SELECT @DocumentId = SCOPE_IDENTITY()
    SELECT @Err = @@ERROR    
  END 
      
  -- Check for errors
  IF @Err = 0 BEGIN
    -- Insert reference in Folder2Document.
    INSERT INTO Folder2Document (FolderId, DocumentId, DocumentStatusId)
    SELECT @FolderId, @DocumentId, 1
    SELECT @Err = @@ERROR    
  END 

  DECLARE @popListId BIGINT
  -- Check for errors
  IF @Err = 0 BEGIN
     -- Insert default values into populationlist table for new populationlist
     INSERT INTO populationlist(version,stateid,comment,caseid,createdbyid,created,phaseid,statusid) values(1,1,'Draft',@CaseId,@ManagerId,GETDATE(),0,1)
     SET @popListId = SCOPE_IDENTITY()
	 SELECT @Err = @@ERROR
  END

  -- Check for errors
  IF @Err = 0 BEGIN
     INSERT INTO PopulationlistDocument(populationlistid,filename,filesize,filedate,locked,lockedbyid,DocumentClassificationId) values(@popListId,'populationlist.xls',38912,GETDATE(),null,null,null)
     SELECT @Err = @@ERROR
  END

  IF @Err = 0
    COMMIT
  ELSE
    ROLLBACK

  RETURN @Err
END