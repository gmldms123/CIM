USE [PManagement]
GO

/****** Object:  View [dbo].[vwCIM_Case]    Script Date: 11/22/2010 09:50:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vwCIM_CaseDataForProjectServer]
AS
SELECT DISTINCT c.CaseNo, c.Description
		, t.Turbine + '-' 
		+ CASE WHEN tnp.NominelPower IS NULL THEN '' ELSE convert(nvarchar(5), tnp.NominelPower) + 'kW-' END
		+ CASE WHEN tv.Voltage IS NULL THEN '' ELSE CONVERT(NVARCHAR(4), tv.Voltage) + 'V-' END
		+ CASE WHEN tf.Frequency IS NULL THEN '' ELSE CONVERT(NVARCHAR(3), tf.Frequency) + 'Hz-' END
		+ CASE WHEN tr.RotorDiameter IS NULL THEN '' ELSE CONVERT(NVARCHAR(8), tr.RotorDiameter) + 'M-' END
		+ CASE WHEN tsg.SmallGenerator IS NULL THEN '' ELSE CONVERT(NVARCHAR(4), tsg.SmallGenerator) + 'kW-' END
		+ CASE WHEN ttv.TemperatureVariant IS NULL THEN '' ELSE CONVERT(NVARCHAR(20), ttv.TemperatureVariant) + '-' END
		+ CASE WHEN tp.Placement IS NULL THEN '' ELSE CONVERT(NVARCHAR(20), tp.Placement) + '-' END
		+ CASE WHEN tma.Manufacturer IS NULL THEN '' ELSE CONVERT(NVARCHAR(100), tma.Manufacturer) END AS TurbineType,
		ph.PhaseId AS StageId,
		ph.Name AS Stage, 
		st.StandardTaskId AS PhaseId,
		st.Name AS Phase,
		pl.Name AS [Platform],		
		par.VestasInitials AS PlatformManager
FROM   [Case] c 
	   JOIN Participant p ON p.ParticipantId = c.ManagerId 
	   LEFT JOIN StandardTask st ON c.StandardTaskId = st.StandardTaskId 
	   LEFT JOIN Case2Phase c2p ON c2p.CaseId = c.CaseId 
	   LEFT JOIN Phase ph ON ph.PhaseId = c.PhaseId 
	   LEFT JOIN [Platform] pl ON c.[Platform] = pl.PlatformID 
	   LEFT JOIN Participant par ON pl.Coordinator = par.ParticipantId 
       LEFT JOIN Case2TurbineMatrix c2tm ON c.caseId = c2tm.CaseId 
       LEFT JOIN TurbineMatrix tm ON c2tm.TurbineMatrixId = tm.TurbineMatrixId 
       LEFT JOIN TurbineFrequency tf ON tm.TurbineFrequencyId = tf.TurbineFrequencyId 
       LEFT JOIN TurbineManufacturer tma ON tm.TurbineManufacturerId = tma.TurbineManufacturerId  
       LEFT JOIN TurbineNominelPower tnp ON tm.TurbineNominelPowerId = tnp.TurbineNominelPowerId 
       LEFT JOIN TurbinePlacement tp ON tm.TurbinePlacementId = tp.TurbinePlacementId 
       LEFT JOIN TurbinePowerRegulation tpr ON tm.TurbinePowerRegulationId = tpr.TurbinePowerRegulationId 
       LEFT JOIN TurbineRotorDiameter tr ON tm.TurbineRotorDiameterId = tr.TurbineRotorDiameterId 
       LEFT JOIN TurbineSmallGenerator tsg ON tm.TurbineSmallGeneratorId = tsg.TurbineSmallGeneratorId 
       LEFT JOIN TurbineTemperatureVariant ttv ON tm.TurbineTemperatureVariantId = ttv.TurbineTemperatureVariantId 
       LEFT JOIN TurbineVoltage tv ON tm.TurbineVoltageId = tv.TurbineVoltageId 
       LEFT JOIN Turbine t ON tm.TurbineId = t.TurbineId 
WHERE c.BrandId = 1 AND (c2tm.InitialFailed = 1 OR c2tm.caseid IS NULL)
GO


