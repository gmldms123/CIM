/****** Object:  Login [VESTAS\svc-dkrds-msprojadmi]    Script Date: 12/22/2010 12:48:36 ******/
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'VESTAS\svc-dkrds-msprojadmi')
BEGIN
	PRINT 'creating login'
	CREATE LOGIN [VESTAS\svc-dkrds-msprojadmi] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
END

USE [PManagement]
GO

/****** Object:  User [VESTAS\svc-dkrds-msprojadmi]    Script Date: 12/22/2010 12:49:18 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'VESTAS\svc-dkrds-msprojadmi')
BEGIN
	PRINT 'creating user'
	CREATE USER [VESTAS\svc-dkrds-msprojadmi] FOR LOGIN [VESTAS\svc-dkrds-msprojadmi] WITH DEFAULT_SCHEMA=[dbo]
	GRANT SELECT ON [vwCIM_CaseDataForProjectServer] TO [VESTAS\svc-dkrds-msprojadmi]
END

