-- create Role table
CREATE TABLE [dbo].[Role](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](400) NULL,
	[GrantToProjectManager] [bit] NOT NULL,
	[GrantToTechnicalSpecialist] [bit] NOT NULL,
	[GrantToExecutionManager] [bit] NOT NULL,
	[GrantToCaseCreator] [bit] NOT NULL,
	[GrantToPlatformManager] [bit] NOT NULL,
	[GrantToProjectParticipant] [bit] NOT NULL,
	[GrantToEveryone] [bit] NOT NULL,
	[Created] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](10) NOT NULL,
	[Updated] [datetime] NULL,
	[UpdatedBy] [nvarchar](10) NULL,
	[Deleted] [datetime] NULL,
	[DeletedBy] [nvarchar](10) NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [DF_Role_GrantToProjectManager]  DEFAULT ((0)) FOR [GrantToProjectManager]
GO

ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [DF_Role_GrantToTechnicalSpecialist]  DEFAULT ((0)) FOR [GrantToTechnicalSpecialist]
GO

ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [DF_Role_GrantToExecutionManager]  DEFAULT ((0)) FOR [GrantToExecutionManager]
GO

ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [DF_Role_GrantToCaseCreator]  DEFAULT ((0)) FOR [GrantToCaseCreator]
GO

ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [DF_Role_GrantToPlatformManager]  DEFAULT ((0)) FOR [GrantToPlatformManager]
GO

ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [DF_Role_GrantToProjectParticipant]  DEFAULT ((0)) FOR [GrantToProjectParticipant]
GO

ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [DF_Role_GrantToEveryone]  DEFAULT ((0)) FOR [GrantToEveryone]
GO

-- create mapping table between Role and Participant
CREATE TABLE [dbo].[Participant2Role](
	[Participant2RoleId] [int] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [bigint] NOT NULL,
	[RoleId] [int] NOT NULL,
 CONSTRAINT [PK_Participant2Role] PRIMARY KEY CLUSTERED 
(
	[Participant2RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Participant2Role]  WITH CHECK ADD  CONSTRAINT [FK_Participant2Role_Participant] FOREIGN KEY([ParticipantId])
REFERENCES [dbo].[Participant] ([ParticipantId])
GO

ALTER TABLE [dbo].[Participant2Role] CHECK CONSTRAINT [FK_Participant2Role_Participant]
GO

ALTER TABLE [dbo].[Participant2Role]  WITH CHECK ADD  CONSTRAINT [FK_Participant2Role_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([RoleId])
GO

ALTER TABLE [dbo].[Participant2Role] CHECK CONSTRAINT [FK_Participant2Role_Role]
GO

-- create Permission table
CREATE TABLE [dbo].[Permission](
	[PermissionId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](80) NOT NULL,
	[Description] [nvarchar](400) NULL,
	[Deleted] [datetime] NULL,
	[DeletedBy] [nvarchar](10) NULL,
 CONSTRAINT [PK_Permission] PRIMARY KEY CLUSTERED 
(
	[PermissionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- create mapping table between Role and Permission
CREATE TABLE [dbo].[Role2Permission](
	[Role2PermissionId] [int] IDENTITY(1,1) NOT NULL,
	[RoleId] [int] NOT NULL,
	[PermissionId] [int] NOT NULL,
 CONSTRAINT [PK_Role2Permission] PRIMARY KEY CLUSTERED 
(
	[Role2PermissionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Role2Permission]  WITH CHECK ADD  CONSTRAINT [FK_Role2Permission_Permission] FOREIGN KEY([PermissionId])
REFERENCES [dbo].[Permission] ([PermissionId])
GO

ALTER TABLE [dbo].[Role2Permission] CHECK CONSTRAINT [FK_Role2Permission_Permission]
GO

ALTER TABLE [dbo].[Role2Permission]  WITH CHECK ADD  CONSTRAINT [FK_Role2Permission_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([RoleId])
GO

ALTER TABLE [dbo].[Role2Permission] CHECK CONSTRAINT [FK_Role2Permission_Role]
GO




