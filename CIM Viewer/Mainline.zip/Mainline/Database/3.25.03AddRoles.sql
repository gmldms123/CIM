-- #### all roles ####
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Administrator', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Case Manager', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Customer Service', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Everyone', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Execution Manager', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Executive Management', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Finance', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM HSE', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Project Participant', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Purchase', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM QSE', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM R&D Technology', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM Sales', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM SBU Technical Support', 'Migrated from AzMan', GETUTCDATE(), 'kenja')
INSERT INTO [Role] (Name, [Description], Created, CreatedBy) VALUES ('CIM VP', 'Migrated from AzMan', GETUTCDATE(), 'kenja')

-- #### define dynamic roles ####
UPDATE [Role] SET GrantToProjectManager = 1 WHERE Name = 'CIM Case Manager'
UPDATE [Role] SET GrantToExecutionManager = 1 WHERE Name = 'CIM Execution Manager'
UPDATE [Role] SET GrantToProjectParticipant = 1 WHERE Name = 'CIM Project Participant'
UPDATE [Role] SET GrantToEveryone = 1 WHERE Name = 'CIM Everyone'
