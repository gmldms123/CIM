-- #### all role operations ####
DECLARE @RoleId INT

-- start CIM Administrator
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Administrator'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Admin_MayDownloadSBUPopulationlist'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClosedForInvoicing'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeExecutionManager'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeManager'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePlatform'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Casefacts_ChangeTechnicalSpecialist'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_EditRCA'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Reopen'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CIR_Read'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_DeletePermanently'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_EditPopulationList'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_EditProjectPlan'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3FinancialDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3TechnicalDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_MoveFromInBoxToFolder'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_UndoAllCheckouts'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Main_Administration'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToProject'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToReview'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromProject'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromReview'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ProjectPortal_ChangeKPI'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ProjectPortal_ChangePortfolio'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Timeline_ViewFullTimeline'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Administrator'
END
-- end CIM Administrator

-- start CIM Case Manager
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Case Manager'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Admin_MayDownloadSBUPopulationlist'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClosedForInvoicing'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeExecutionManager'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeManager'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePlatform'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Casefacts_ChangeTechnicalSpecialist'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Reopen'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_DeletePermanently'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_EditPopulationList'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_EditProjectPlan'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3FinancialDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3TechnicalDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_MoveFromInBoxToFolder'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToProject'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToReview'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromProject'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromReview'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ProjectPortal_ChangeKPI'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ProjectPortal_ChangePortfolio'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Case Manager'
END
-- end CIM Case Manager

-- start CIM Customer Service
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Customer Service'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Customer Service'
END
-- end CIM Customer Service

-- start CIM Everyone
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Everyone'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Everyone'
END
-- end CIM Everyone

-- start CIM Execution Manager
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Execution Manager'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Admin_MayDownloadSBUPopulationlist'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeExecutionManager'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeManager'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePlatform'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Casefacts_ChangeTechnicalSpecialist'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Reopen'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CIR_Read'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_DeletePermanently'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_EditPopulationList'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_EditProjectPlan'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3FinancialDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3TechnicalDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_MoveFromInBoxToFolder'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_UndoAllCheckouts'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Main_Administration'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToProject'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToReview'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromProject'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromReview'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ProjectPortal_ChangeKPI'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ProjectPortal_ChangePortfolio'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Timeline_ViewFullTimeline'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Execution Manager'
END
-- end CIM Execution Manager

-- start CIM Executive Management
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Executive Management'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Executive Management'
END
-- end CIM Executive Management

-- start CIM Finance
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Finance'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClosedForInvoicing'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_EditPopulationList'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3FinancialDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3TechnicalDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_MoveFromInBoxToFolder'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_UndoAllCheckouts'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Finance'
END
-- end CIM Finance

-- start CIM HSE
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM HSE'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ProjectPortal_ChangeKPI'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM HSE'
END
-- end CIM HSE

-- start CIM Project Participant
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Project Participant'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass3TechnicalDocuments'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Project Participant'
END
-- end CIM Project Participant

-- start CIM Purchase
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Purchase'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Purchase'
END
-- end CIM Purchase

-- start CIM QSE
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM QSE'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM QSE'
END
-- end CIM QSE

-- start CIM R&D Technology
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM R&D Technology'
END
-- end CIM R&D Technology

-- start CIM Sales
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM Sales'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM Sales'
END
-- end CIM Sales

-- start CIM SBU Technical Support
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_AlarmLogNumbers_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeConfirmedBySupplier'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhaseBudget'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeRootItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSalesOption'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeDependent'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ChangeKnowledge'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseRelations_ViewDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ComponentType_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Discussions_Reply'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass1Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Documents_HandleClass2Documents'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Edit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Milestones_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_News_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_AddToKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Participants_RemoveFromKnowHow'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_AddTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_RemoveTubineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_ServiceCodes_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Add'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_ChangeItemCategories'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_SupplierRelations_Remove'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimResponsiblePBU'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeClaimStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeDescription'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedItem'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeFailedTurbineUnit'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangePhase'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeSBURelations'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_ChangeStatus'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_CaseFacts_Create'))
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Editor_RelevantTurbines_EditAmountUsed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM SBU Technical Support'
END
-- end CIM SBU Technical Support

-- start CIM VP
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM VP'
IF @RoleId IS NOT NULL
BEGIN
   INSERT INTO Role2Permission (RoleId, PermissionId) VALUES (@RoleId, (SELECT PermissionId FROM Permission WHERE Name = 'Viewer_Startup_AccessAllowed'))
END
ELSE
BEGIN
   PRINT 'Missing role: CIM VP'
END
-- end CIM VP
