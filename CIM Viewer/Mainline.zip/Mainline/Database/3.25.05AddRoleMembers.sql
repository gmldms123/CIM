-- #### role member mappings ####
DECLARE @ParticipantId BIGINT

-- start gdh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gdh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end gdh@vestas.net

-- start razkn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'razkn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end razkn@vestas.net

-- start hmn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hmn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end hmn@vestas.net

-- start akje@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'akje'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end akje@vestas.net

-- start ago@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ago'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end ago@vestas.net

-- start annt@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'annt'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end annt@vestas.net

-- start an@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'an'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end an@vestas.net

-- start crm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'crm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end crm@vestas.net

-- start dab@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dab'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end dab@vestas.net

-- start dbc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dbc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end dbc@vestas.net

-- start hpu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hpu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end hpu@vestas.net

-- start hbe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hbe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end hbe@vestas.net

-- start jvl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jvl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jvl@vestas.net

-- start jabl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jabl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end jabl@vestas.net

-- start jns@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jns'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jns@vestas.net

-- start kehen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kehen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end kehen@vestas.net

-- start kpg@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kpg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kpg@vestas.net

-- start kifu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kifu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end kifu@vestas.net

-- start lfn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lfn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end lfn@vestas.net

-- start lajp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lajp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end lajp@vestas.net

-- start lsoe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lsoe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end lsoe@vestas.net

-- start lbs@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lbs'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end lbs@vestas.net

-- start mkjh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mkjh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end mkjh@vestas.net

-- start mbd@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mbd'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end mbd@vestas.net

-- start mki@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mki'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end mki@vestas.net

-- start moja@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'moja'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end moja@vestas.net

-- start pwar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pwar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end pwar@vestas.net

-- start pego@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pego'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end pego@vestas.net

-- start remi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'remi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end remi@vestas.net

-- start skm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'skm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end skm@vestas.net

-- start sokma@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sokma'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end sokma@vestas.net

-- start tb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end tb@vestas.net

-- start toje@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'toje'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Execution Manager'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end toje@vestas.net

-- start vvj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vvj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end vvj@vestas.net

-- start slb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'slb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end slb@vestas.net

-- start ttfje@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ttfje'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end ttfje@vestas.net

-- start inand@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'inand'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end inand@vestas.net

-- start MAZIL@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mazil'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end MAZIL@vestas.net

-- start FRQUE@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'frque'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end FRQUE@vestas.net

-- start nebj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nebj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end nebj@vestas.net

-- start mgb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mgb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end mgb@vestas.net

-- start morni@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'morni'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end morni@vestas.net

-- start riksr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'riksr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end riksr@vestas.net

-- start cmbc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cmbc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end cmbc@vestas.net

-- start kbpe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kbpe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end kbpe@vestas.net

-- start jajkj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jajkj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jajkj@vestas.net

-- start MOBKR@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mobkr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end MOBKR@vestas.net

-- start heaar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'heaar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end heaar@vestas.net

-- start bobbo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bobbo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end bobbo@vestas.net

-- start rrnvk@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rrnvk'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end rrnvk@vestas.net

-- start chale@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chale'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end chale@vestas.net

-- start jksie@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jksie'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jksie@vestas.net

-- start jbrha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jbrha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jbrha@vestas.net

-- start kelth@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kelth'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end kelth@vestas.net

-- start ankni@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ankni'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end ankni@vestas.net

-- start peliv@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'peliv'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end peliv@vestas.net

-- start willa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'willa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Case Manager'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Everyone'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end willa@vestas.net

-- start sapur@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sapur'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end sapur@vestas.net

-- start kaflo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kaflo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end kaflo@vestas.net

-- start krlys@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'krlys'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end krlys@vestas.net

-- start nimpe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nimpe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end nimpe@vestas.net

-- start perh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'perh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end perh@vestas.net

-- start bbaha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bbaha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end bbaha@vestas.net

-- start hblan@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hblan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end hblan@vestas.net

-- start mifth@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mifth'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end mifth@vestas.net

-- start ksbri@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ksbri'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end ksbri@vestas.net

-- start marki@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'marki'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end marki@vestas.net

-- start jjess@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jjess'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jjess@vestas.net

-- start harva@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'harva'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end harva@vestas.net

-- start nakro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nakro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end nakro@vestas.net

-- start jksor@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jksor'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jksor@vestas.net

-- start kenja@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kenja'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end kenja@vestas.net

-- start msims@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'msims'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end msims@Vestas.net

-- start dhaug@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dhaug'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dhaug@Vestas.net

-- start minop@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'minop'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end minop@vestas.net

-- start kavin@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kavin'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end kavin@vestas.net

-- start helpo@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'helpo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end helpo@Vestas.net

-- start VEKAN@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vekan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end VEKAN@Vestas.net

-- start sbkri@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sbkri'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end sbkri@Vestas.net

-- start joege@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'joege'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end joege@Vestas.net

-- start jbold@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jbold'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jbold@Vestas.net

-- start mabal@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mabal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end mabal@Vestas.net

-- start clahn@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'clahn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end clahn@Vestas.net

-- start usoki@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'usoki'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end usoki@Vestas.net

-- start pthar@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pthar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end pthar@Vestas.net

-- start pelch@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pelch'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end pelch@Vestas.net

-- start jucat@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jucat'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end jucat@Vestas.net

-- start jalka@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jalka'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end jalka@Vestas.net

-- start dathe@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dathe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end dathe@Vestas.net

-- start flaen@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'flaen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Administrator'))
END
-- end flaen@Vestas.net

-- start mabeg@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mabeg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Case Manager'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mabeg@vestas.net

-- start pelun@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pelun'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Case Manager'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Everyone'))
END
-- end pelun@vestas.net

-- start stetk@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'stetk'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Case Manager'))
END
-- end stetk@vestas.net

-- start pel@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pel'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end pel@vestas.net

-- start zhsji@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zhsji'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end zhsji@vestas.net

-- start asth@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'asth'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end asth@vestas.net

-- start jtj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jtj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jtj@vestas.net

-- start kmac@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kmac'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kmac@vestas.net

-- start lam@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lam'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end lam@vestas.net

-- start ltj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ltj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end ltj@vestas.net

-- start zyp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zyp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end zyp@vestas.net

-- start trber@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'trber'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end trber@vestas.net

-- start antor@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'antor'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end antor@vestas.net

-- start pahan@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pahan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end pahan@vestas.net

-- start esm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'esm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end esm@vestas.net

-- start lblk@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lblk'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end lblk@vestas.net

-- start locon@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'locon'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end locon@vestas.net

-- start zhequ@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zhequ'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end zhequ@vestas.net

-- start anmac@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'anmac'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end anmac@vestas.net

-- start mimch@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mimch'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end mimch@vestas.net

-- start rbrad@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rbrad'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end rbrad@vestas.net

-- start crmcm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'crmcm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end crmcm@vestas.net

-- start kehug@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kehug'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end kehug@vestas.net

-- start cbros@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cbros'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end cbros@vestas.net

-- start ivrob@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ivrob'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end ivrob@vestas.net

-- start jabrs@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jabrs'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jabrs@vestas.net

-- start jahen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jahen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jahen@vestas.net

-- start kebur@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kebur'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end kebur@vestas.net

-- start lapto@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lapto'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end lapto@vestas.net

-- start mzehr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mzehr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end mzehr@vestas.net

-- start mbela@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mbela'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end mbela@vestas.net

-- start mimac@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mimac'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end mimac@vestas.net

-- start nemaf@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nemaf'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end nemaf@vestas.net

-- start rofen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rofen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end rofen@vestas.net

-- start roden@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'roden'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end roden@vestas.net

-- start stoeh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'stoeh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end stoeh@vestas.net

-- start SGray@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sgray'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end SGray@vestas.net

-- start tlef@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tlef'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end tlef@vestas.net

-- start torol@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'torol'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end torol@vestas.net

-- start ereme@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ereme'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end ereme@vestas.net

-- start maurg@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'maurg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end maurg@vestas.net

-- start jaafr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jaafr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jaafr@vestas.net

-- start naseg@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'naseg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end naseg@vestas.net

-- start rawil@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rawil'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end rawil@vestas.net

-- start marau@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'marau'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end marau@vestas.net

-- start majas@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'majas'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end majas@vestas.net

-- start shaba@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'shaba'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end shaba@vestas.net

-- start jalee@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jalee'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jalee@vestas.net

-- start gespa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gespa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end gespa@vestas.net

-- start dahar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dahar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end dahar@vestas.net

-- start slsuc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'slsuc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end slsuc@vestas.net

-- start masv@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'masv'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end masv@vestas.net

-- start allwi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'allwi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end allwi@vestas.net

-- start jehun@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jehun'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jehun@vestas.net

-- start jhend@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jhend'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jhend@vestas.net

-- start aukar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'aukar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end aukar@vestas.net

-- start anbpi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'anbpi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end anbpi@vestas.net

-- start kagna@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kagna'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end kagna@vestas.net

-- start mukba@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mukba'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end mukba@vestas.net

-- start ramve@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ramve'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end ramve@vestas.net

-- start nabha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nabha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end nabha@vestas.net

-- start saper@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'saper'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end saper@vestas.net

-- start sunve@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sunve'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end sunve@vestas.net

-- start jhill@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jhill'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jhill@vestas.net

-- start dorah@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dorah'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dorah@vestas.net

-- start larpe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'larpe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end larpe@vestas.net

-- start seaj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'seaj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end seaj@vestas.net

-- start dduda@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dduda'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end dduda@vestas.net

-- start chris@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chris'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end chris@vestas.net

-- start deper@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'deper'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end deper@vestas.net

-- start micdu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'micdu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end micdu@vestas.net

-- start wedav@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'wedav'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end wedav@vestas.net

-- start mapen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mapen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end mapen@vestas.net

-- start tokro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tokro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end tokro@vestas.net

-- start ronat@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ronat'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end ronat@vestas.net

-- start stdor@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'stdor'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end stdor@vestas.net

-- start matpe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'matpe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end matpe@vestas.net

-- start dacal@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dacal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end dacal@vestas.net

-- start grrod@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'grrod'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end grrod@vestas.net

-- start jepod@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jepod'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jepod@vestas.net

-- start jacne@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jacne'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jacne@vestas.net

-- start jabee@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jabee'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jabee@vestas.net

-- start jemon@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jemon'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jemon@vestas.net

-- start chmcb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chmcb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end chmcb@vestas.net

-- start danes@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'danes'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end danes@vestas.net

-- start darub@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'darub'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end darub@vestas.net

-- start naraz@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'naraz'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end naraz@vestas.net

-- start demil@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'demil'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end demil@vestas.net

-- start ryfab@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ryfab'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end ryfab@vestas.net

-- start sejen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sejen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end sejen@vestas.net

-- start anzim@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'anzim'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end anzim@vestas.net

-- start guban@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'guban'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end guban@vestas.net

-- start haada@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'haada'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end haada@vestas.net

-- start cynew@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cynew'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end cynew@vestas.net

-- start kimkj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kimkj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end kimkj@vestas.net

-- start lynal@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lynal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end lynal@vestas.net

-- start rokas@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rokas'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end rokas@vestas.net

-- start rilou@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rilou'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rilou@vestas.net

-- start lusco@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lusco'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end lusco@vestas.net

-- start JSTEI@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jstei'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end JSTEI@vestas.net

-- start SAPEN@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sapen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end SAPEN@vestas.net

-- start petno@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'petno'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end petno@vestas.net

-- start DAEAS@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'daeas'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end DAEAS@vestas.net

-- start GOGAL@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gogal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end GOGAL@vestas.net

-- start PACHE@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pache'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end PACHE@vestas.net

-- start rschu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rschu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end rschu@vestas.net

-- start JOLAM@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jolam'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end JOLAM@vestas.net

-- start JEHEL@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jehel'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end JEHEL@vestas.net

-- start pehal@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pehal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end pehal@vestas.net

-- start lhped@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lhped'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end lhped@vestas.net

-- start ROPAZ@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ropaz'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end ROPAZ@vestas.net

-- start damay@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'damay'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end damay@Vestas.net

-- start helkj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'helkj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end helkj@vestas.net

-- start jyikr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jyikr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end jyikr@vestas.net

-- start henhs@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'henhs'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end henhs@Vestas.net

-- start aawya@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'aawya'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end aawya@Vestas.net

-- start cuhal@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cuhal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end cuhal@Vestas.net

-- start nejam@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nejam'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end nejam@Vestas.net

-- start crkar@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'crkar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end crkar@Vestas.net

-- start prgre@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'prgre'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end prgre@Vestas.net

-- start seheg@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'seheg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end seheg@Vestas.net

-- start shkir@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'shkir'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end shkir@Vestas.net

-- start magan@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'magan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
END
-- end magan@Vestas.net

-- start fregr@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'fregr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Customer Service'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end fregr@Vestas.net

-- start hkj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hkj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Executive Management'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end hkj@vestas.net

-- start eljoh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'eljoh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Executive Management'))
END
-- end eljoh@vestas.net

-- start jkc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jkc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end jkc@vestas.net

-- start lfm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lfm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end lfm@vestas.net

-- start chpuk@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chpuk'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end chpuk@vestas.net

-- start iwnie@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'iwnie'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end iwnie@vestas.net

-- start gosha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gosha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end gosha@vestas.net

-- start thots@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'thots'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end thots@vestas.net

-- start dhish@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dhish'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end dhish@vestas.net

-- start krifr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'krifr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end krifr@vestas.net

-- start nagro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nagro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
END
-- end nagro@vestas.net

-- start kanas@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kanas'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Finance'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end kanas@Vestas.net

-- start doman@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'doman'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end doman@vestas.net

-- start laod@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'laod'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end laod@vestas.net

-- start chkri@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chkri'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end chkri@vestas.net

-- start IJOBM@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ijobm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end IJOBM@vestas.net

-- start flepe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'flepe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end flepe@vestas.net

-- start makja@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'makja'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end makja@vestas.net

-- start perhm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'perhm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end perhm@vestas.net

-- start mramk@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mramk'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end mramk@vestas.net

-- start larmo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'larmo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end larmo@vestas.net

-- start kecon@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kecon'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
END
-- end kecon@vestas.net

-- start ppapa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ppapa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end ppapa@vestas.net

-- start kssat@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kssat'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end kssat@vestas.net

-- start pagan@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pagan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM HSE'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end pagan@vestas.net

-- start hje@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hje'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end hje@vestas.net

-- start chgae@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chgae'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end chgae@vestas.net

-- start loach@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'loach'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end loach@vestas.net

-- start vitni@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vitni'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end vitni@vestas.net

-- start mdani@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mdani'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end mdani@vestas.net

-- start KEKRA@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kekra'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end KEKRA@vestas.net

-- start reoma@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'reoma'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end reoma@vestas.net

-- start cavch@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cavch'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM Purchase'))
END
-- end cavch@vestas.net

-- start ceh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ceh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end ceh@vestas.net

-- start jobyw@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jobyw'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end jobyw@vestas.net

-- start jkd@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jkd'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end jkd@vestas.net

-- start nbo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nbo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end nbo@vestas.net

-- start chh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end chh@vestas.net

-- start kelra@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kelra'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kelra@vestas.net

-- start pprad@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pprad'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end pprad@vestas.net

-- start edweh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'edweh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end edweh@vestas.net

-- start clo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'clo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end clo@vestas.net

-- start lilym@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lilym'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end lilym@vestas.net

-- start shzho@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'shzho'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end shzho@vestas.net

-- start uldoh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'uldoh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end uldoh@vestas.net

-- start volau@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'volau'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end volau@vestas.net

-- start sisak@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sisak'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end sisak@vestas.net

-- start stpli@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'stpli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end stpli@vestas.net

-- start jankp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jankp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end jankp@vestas.net

-- start anhor@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'anhor'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end anhor@vestas.net

-- start sehwa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sehwa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end sehwa@vestas.net

-- start klrat@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'klrat'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end klrat@vestas.net

-- start chpol@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chpol'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM QSE'))
END
-- end chpol@vestas.net

-- start llm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'llm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end llm@vestas.net

-- start PSM@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'psm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end PSM@vestas.net

-- start zhgao@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zhgao'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end zhgao@vestas.net

-- start evn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'evn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end evn@vestas.net

-- start hhpn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hhpn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end hhpn@vestas.net

-- start joje@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'joje'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end joje@vestas.net

-- start kmh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kmh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end kmh@vestas.net

-- start ptl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ptl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end ptl@vestas.net

-- start pbc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pbc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end pbc@vestas.net

-- start recve@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'recve'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end recve@vestas.net

-- start zhtli@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zhtli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end zhtli@vestas.net

-- start rarku@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rarku'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end rarku@vestas.net

-- start thumu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'thumu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end thumu@vestas.net

-- start vpdc-user@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vpdc-user'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end vpdc-user@vestas.net

-- start sipye@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sipye'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end sipye@vestas.net

-- start kwnie@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kwnie'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end kwnie@vestas.net

-- start lahaf@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lahaf'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end lahaf@vestas.net

-- start gbje@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gbje'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end gbje@vestas.net

-- start abjos@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'abjos'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end abjos@vestas.net

-- start rejam@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rejam'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end rejam@vestas.net

-- start kpeli@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kpeli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end kpeli@vestas.net

-- start gilop@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gilop'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end gilop@vestas.net

-- start dragu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dragu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end dragu@vestas.net

-- start gopsu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gopsu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end gopsu@vestas.net

-- start phoeb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'phoeb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end phoeb@vestas.net

-- start gnana@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gnana'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end gnana@vestas.net

-- start marir@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'marir'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end marir@vestas.net

-- start ymzha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ymzha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end ymzha@vestas.net

-- start mictu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mictu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end mictu@vestas.net

-- start luxuw@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'luxuw'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end luxuw@vestas.net

-- start chnde@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chnde'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end chnde@vestas.net

-- start sjapp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sjapp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end sjapp@vestas.net

-- start wache@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'wache'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end wache@vestas.net

-- start thmkh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'thmkh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end thmkh@vestas.net

-- start sukga@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sukga'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end sukga@vestas.net

-- start danbr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'danbr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end danbr@vestas.net

-- start karaa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'karaa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end karaa@vestas.net

-- start chych@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chych'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end chych@vestas.net

-- start jiyho@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jiyho'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end jiyho@vestas.net

-- start jikon@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jikon'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end jikon@vestas.net

-- start mfbms@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mfbms'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end mfbms@vestas.net

-- start yuzhu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'yuzhu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end yuzhu@vestas.net

-- start jhuch@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jhuch'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end jhuch@vestas.net

-- start kkrna@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kkrna'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end kkrna@vestas.net

-- start sepnp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sepnp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sepnp@vestas.net

-- start bensk@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bensk'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end bensk@vestas.net

-- start cnliu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cnliu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end cnliu@vestas.net

-- start vivba@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vivba'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end vivba@vestas.net

-- start yukar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'yukar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end yukar@vestas.net

-- start tzylo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tzylo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end tzylo@vestas.net

-- start GCLAN@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gclan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end GCLAN@vestas.net

-- start mecko@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mecko'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end mecko@vestas.net

-- start jssom@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jssom'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end jssom@vestas.net

-- start pauho@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pauho'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end pauho@vestas.net

-- start jkrp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jkrp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end jkrp@vestas.net

-- start hacla@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hacla'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end hacla@vestas.net

-- start halsi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'halsi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end halsi@vestas.net

-- start llili@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'llili'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end llili@vestas.net

-- start rnara@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rnara'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end rnara@vestas.net

-- start badhe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'badhe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end badhe@vestas.net

-- start alhuo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'alhuo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end alhuo@vestas.net

-- start hawng@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hawng'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end hawng@vestas.net

-- start cws@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cws'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end cws@vestas.net

-- start flebj@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'flebj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end flebj@Vestas.net

-- start IJUNS@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ijuns'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end IJUNS@Vestas.net

-- start SOWAN@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sowan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end SOWAN@Vestas.net

-- start krgre@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'krgre'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end krgre@Vestas.net

-- start zhuol@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zhuol'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end zhuol@Vestas.net

-- start weqis@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'weqis'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end weqis@Vestas.net

-- start kkrog@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kkrog'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end kkrog@Vestas.net

-- start antwa@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'antwa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end antwa@Vestas.net

-- start atmar@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'atmar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end atmar@Vestas.net

-- start toene@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'toene'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end toene@Vestas.net

-- start rasak@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rasak'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end rasak@Vestas.net

-- start srram@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'srram'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end srram@Vestas.net

-- start jusli@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jusli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM R&D Technology'))
END
-- end jusli@Vestas.net

-- start FJU@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'fju'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end FJU@vestas.net

-- start GIS@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gis'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end GIS@vestas.net

-- start demad@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'demad'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end demad@vestas.net

-- start gdc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gdc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end gdc@vestas.net

-- start gin@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gin'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end gin@vestas.net

-- start mho@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mho'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mho@vestas.net

-- start peken@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'peken'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end peken@vestas.net

-- start FKCH@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'fkch'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end FKCH@vestas.net

-- start ROMAR@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'romar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ROMAR@vestas.net

-- start mivin@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mivin'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mivin@vestas.net

-- start TOCHR@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tochr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end TOCHR@vestas.net

-- start heskr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'heskr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end heskr@vestas.net

-- start modch@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'modch'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end modch@vestas.net

-- start asi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'asi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end asi@vestas.net

-- start abi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'abi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end abi@vestas.net

-- start delao@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'delao'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end delao@vestas.net

-- start nimol@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nimol'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end nimol@vestas.net

-- start bhc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bhc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end bhc@vestas.net

-- start bc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end bc@vestas.net

-- start bmbsm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bmbsm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end bmbsm@vestas.net

-- start bo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end bo@vestas.net

-- start chm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'chm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end chm@vestas.net

-- start ch@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ch'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ch@vestas.net

-- start dan@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dan@vestas.net

-- start dew@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dew'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dew@vestas.net

-- start flha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'flha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end flha@vestas.net

-- start frha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'frha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end frha@vestas.net

-- start gkc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gkc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end gkc@vestas.net

-- start hli@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hli@vestas.net

-- start hoshi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hoshi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hoshi@vestas.net

-- start jkl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jkl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jkl@vestas.net

-- start jalu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jalu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jalu@vestas.net

-- start jep@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jep'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jep@vestas.net

-- start jikat@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jikat'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jikat@vestas.net

-- start jhhe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jhhe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jhhe@vestas.net

-- start jubr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jubr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jubr@vestas.net

-- start jnc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jnc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jnc@vestas.net

-- start kbe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kbe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kbe@vestas.net

-- start kel@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kel'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kel@vestas.net

-- start ksve@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ksve'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ksve@vestas.net

-- start kerm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kerm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kerm@vestas.net

-- start krlo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'krlo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end krlo@vestas.net

-- start ljen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ljen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ljen@vestas.net

-- start lgh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lgh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end lgh@vestas.net

-- start mah@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mah'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mah@vestas.net

-- start mabll@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mabll'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mabll@vestas.net

-- start mdj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mdj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mdj@vestas.net

-- start nks@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nks'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end nks@vestas.net

-- start phe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'phe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end phe@vestas.net

-- start pno@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pno'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pno@vestas.net

-- start pet@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pet'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pet@vestas.net

-- start pnli@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pnli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pnli@vestas.net

-- start pgm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pgm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pgm@vestas.net

-- start rcf@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rcf'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rcf@vestas.net

-- start sfb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sfb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sfb@vestas.net

-- start sfo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sfo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sfo@vestas.net

-- start sh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sh@vestas.net

-- start SOSCL@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'soscl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end SOSCL@vestas.net

-- start tiv@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tiv'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tiv@vestas.net

-- start togru@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'togru'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end togru@vestas.net

-- start vedi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vedi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end vedi@vestas.net

-- start vke@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vke'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end vke@vestas.net

-- start JCV@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jcv'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end JCV@vestas.net

-- start thbfr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'thbfr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end thbfr@vestas.net

-- start michs@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'michs'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end michs@vestas.net

-- start jeher@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jeher'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jeher@vestas.net

-- start mkra@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mkra'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mkra@vestas.net

-- start kistn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kistn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kistn@vestas.net

-- start kwwju@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kwwju'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kwwju@vestas.net

-- start rcbal@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rcbal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rcbal@vestas.net

-- start samay@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'samay'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end samay@vestas.net

-- start thspe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'thspe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end thspe@vestas.net

-- start cabll@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cabll'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end cabll@vestas.net

-- start esmlo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'esmlo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end esmlo@vestas.net

-- start lfe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lfe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end lfe@vestas.net

-- start oscdu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'oscdu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end oscdu@vestas.net

-- start kivei@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kivei'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kivei@vestas.net

-- start rkb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rkb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rkb@vestas.net

-- start rpkum@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rpkum'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rpkum@vestas.net

-- start brlar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'brlar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end brlar@vestas.net

-- start DOCAN@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'docan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end DOCAN@vestas.net

-- start gicat@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gicat'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end gicat@vestas.net

-- start miana@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'miana'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end miana@vestas.net

-- start pabr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pabr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pabr@vestas.net

-- start doiur@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'doiur'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end doiur@vestas.net

-- start jeom@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jeom'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jeom@vestas.net

-- start gebkr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gebkr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end gebkr@vestas.net

-- start jejuu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jejuu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jejuu@vestas.net

-- start amehm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'amehm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end amehm@vestas.net

-- start bofra@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bofra'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end bofra@vestas.net

-- start dak@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dak'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dak@vestas.net

-- start glee@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'glee'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end glee@vestas.net

-- start hogu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hogu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hogu@vestas.net

-- start jbv@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jbv'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jbv@vestas.net

-- start jcar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jcar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jcar@vestas.net

-- start mbp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mbp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mbp@vestas.net

-- start mpmaf@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mpmaf'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mpmaf@vestas.net

-- start mitro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mitro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mitro@vestas.net

-- start apt@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'apt'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end apt@vestas.net

-- start dagro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dagro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dagro@vestas.net

-- start jokno@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jokno'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jokno@vestas.net

-- start ancof@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ancof'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ancof@vestas.net

-- start iscro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'iscro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end iscro@vestas.net

-- start jaspe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jaspe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jaspe@vestas.net

-- start matbu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'matbu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end matbu@vestas.net

-- start zocro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zocro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end zocro@vestas.net

-- start spaa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'spaa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end spaa@vestas.net

-- start pimsi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pimsi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pimsi@vestas.net

-- start ajdrm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ajdrm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ajdrm@vestas.net

-- start anhla@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'anhla'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end anhla@vestas.net

-- start tvj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tvj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tvj@vestas.net

-- start kakr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kakr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kakr@vestas.net

-- start makje@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'makje'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end makje@vestas.net

-- start shrpr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'shrpr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end shrpr@vestas.net

-- start pirou@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pirou'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pirou@vestas.net

-- start shamm@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'shamm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end shamm@vestas.net

-- start brbev@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'brbev'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end brbev@vestas.net

-- start dfrie@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dfrie'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dfrie@vestas.net

-- start linev@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'linev'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end linev@vestas.net

-- start jebo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jebo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jebo@vestas.net

-- start marg@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'marg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end marg@vestas.net

-- start miken@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'miken'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end miken@vestas.net

-- start mob@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mob'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mob@vestas.net

-- start rsmi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rsmi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rsmi@vestas.net

-- start sayl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sayl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sayl@vestas.net

-- start thmi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'thmi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end thmi@vestas.net

-- start tpas@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tpas'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tpas@vestas.net

-- start pekil@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pekil'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pekil@vestas.net

-- start kebra@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kebra'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kebra@vestas.net

-- start zakuz@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zakuz'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end zakuz@vestas.net

-- start tomck@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tomck'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tomck@vestas.net

-- start dgros@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dgros'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dgros@vestas.net

-- start crmun@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'crmun'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end crmun@vestas.net

-- start gdslo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gdslo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end gdslo@vestas.net

-- start mahlo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mahlo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mahlo@vestas.net

-- start manto@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'manto'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end manto@vestas.net

-- start gucal@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'gucal'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end gucal@vestas.net

-- start sfa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sfa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sfa@vestas.net

-- start maven@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'maven'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end maven@vestas.net

-- start xiagu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'xiagu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end xiagu@vestas.net

-- start mauds@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mauds'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mauds@vestas.net

-- start kelej@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kelej'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kelej@vestas.net

-- start dedym@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dedym'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dedym@vestas.net

-- start stsen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'stsen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end stsen@vestas.net

-- start rshan@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rshan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rshan@vestas.net

-- start shila@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'shila'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end shila@vestas.net

-- start ragun@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ragun'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ragun@vestas.net

-- start Danba@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'danba'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end Danba@vestas.net

-- start faleo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'faleo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end faleo@vestas.net

-- start brajo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'brajo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end brajo@vestas.net

-- start marza@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'marza'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end marza@vestas.net

-- start iogle@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'iogle'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end iogle@vestas.net

-- start nibou@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'nibou'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end nibou@vestas.net

-- start ioako@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ioako'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ioako@vestas.net

-- start jlars@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jlars'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jlars@vestas.net

-- start macve@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'macve'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end macve@vestas.net

-- start jvg@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jvg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jvg@vestas.net

-- start tocl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tocl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tocl@vestas.net

-- start jetno@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jetno'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jetno@vestas.net

-- start sempa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sempa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sempa@vestas.net

-- start vecha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'vecha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end vecha@vestas.net

-- start rajay@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'rajay'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end rajay@vestas.net

-- start prgur@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'prgur'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end prgur@vestas.net

-- start shasu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'shasu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end shasu@vestas.net

-- start ganag@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ganag'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ganag@vestas.net

-- start barba@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'barba'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end barba@vestas.net

-- start ninis@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ninis'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ninis@vestas.net

-- start josp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'josp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end josp@vestas.net

-- start tors@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tors'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tors@vestas.net

-- start beha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'beha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end beha@vestas.net

-- start woszy@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'woszy'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end woszy@vestas.net

-- start ardyc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ardyc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ardyc@vestas.net

-- start berus@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'berus'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end berus@vestas.net

-- start johkn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'johkn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end johkn@vestas.net

-- start yohar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'yohar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end yohar@vestas.net

-- start miear@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'miear'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end miear@vestas.net

-- start jmdue@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jmdue'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jmdue@vestas.net

-- start lagru@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lagru'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end lagru@vestas.net

-- start crhar@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'crhar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end crhar@vestas.net

-- start bricl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bricl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end bricl@vestas.net

-- start adlem@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'adlem'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end adlem@vestas.net

-- start joegg@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'joegg'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end joegg@vestas.net

-- start evasc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'evasc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end evasc@vestas.net

-- start sowei@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sowei'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sowei@vestas.net

-- start anfka@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'anfka'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end anfka@vestas.net

-- start jocpb@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jocpb'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jocpb@vestas.net

-- start karoe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'karoe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end karoe@vestas.net

-- start frnan@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'frnan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end frnan@vestas.net

-- start flbot@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'flbot'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end flbot@vestas.net

-- start buabe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'buabe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end buabe@vestas.net

-- start olter@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'olter'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end olter@vestas.net

-- start yizho@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'yizho'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end yizho@vestas.net

-- start toyam@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'toyam'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end toyam@vestas.net

-- start mahan@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mahan'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mahan@vestas.net

-- start hcth@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hcth'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hcth@vestas.net

-- start mechr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mechr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mechr@vestas.net

-- start stst@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'stst'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end stst@vestas.net

-- start jalni@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jalni'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jalni@vestas.net

-- start lecun@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lecun'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end lecun@vestas.net

-- start jmose@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jmose'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jmose@vestas.net

-- start piejl@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'piejl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end piejl@vestas.net

-- start lti@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lti'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end lti@vestas.net

-- start hersv@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hersv'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hersv@vestas.net

-- start bomka@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bomka'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end bomka@vestas.net

-- start yohbo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'yohbo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end yohbo@vestas.net

-- start masig@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'masig'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end masig@vestas.net

-- start celc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'celc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end celc@vestas.net

-- start maxco@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'maxco'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end maxco@vestas.net

-- start fjmfe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'fjmfe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end fjmfe@vestas.net

-- start zegir@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'zegir'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end zegir@vestas.net

-- start alepe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'alepe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end alepe@vestas.net

-- start heesp@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'heesp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end heesp@vestas.net

-- start loken@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'loken'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end loken@vestas.net

-- start stchr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'stchr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end stchr@vestas.net

-- start tcla@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tcla'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tcla@vestas.net

-- start sefas@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sefas'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sefas@vestas.net

-- start strod@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'strod'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end strod@vestas.net

-- start trtay@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'trtay'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end trtay@vestas.net

-- start dogut@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dogut'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dogut@vestas.net

-- start jasha@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jasha'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jasha@vestas.net

-- start kamaj@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kamaj'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kamaj@vestas.net

-- start degre@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'degre'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end degre@vestas.net

-- start pedej@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pedej'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pedej@vestas.net

-- start leoba@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'leoba'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end leoba@vestas.net

-- start tr@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'tr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end tr@vestas.net

-- start yossi@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'yossi'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end yossi@vestas.net

-- start jaron@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jaron'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jaron@vestas.net

-- start magec@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'magec'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end magec@vestas.net

-- start lcash@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'lcash'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end lcash@vestas.net

-- start keiwa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'keiwa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end keiwa@vestas.net

-- start ryann@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ryann'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ryann@vestas.net

-- start thmla@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'thmla'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end thmla@vestas.net

-- start dahuf@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dahuf'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dahuf@vestas.net

-- start KEMUR@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kemur'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end KEMUR@vestas.net

-- start yujdu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'yujdu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end yujdu@vestas.net

-- start brfyh@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'brfyh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end brfyh@vestas.net

-- start keli@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'keli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end keli@vestas.net

-- start CYBUR@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cybur'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end CYBUR@vestas.net

-- start hethe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hethe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hethe@vestas.net

-- start jeoly@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jeoly'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jeoly@vestas.net

-- start poeva@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'poeva'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end poeva@vestas.net

-- start cagia@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cagia'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end cagia@vestas.net

-- start segpo@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'segpo'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end segpo@vestas.net

-- start pegsc@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pegsc'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pegsc@vestas.net

-- start kaeri@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kaeri'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kaeri@vestas.net

-- start danve@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'danve'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end danve@vestas.net

-- start steyn@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'steyn'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end steyn@vestas.net

-- start mihpa@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mihpa'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mihpa@vestas.net

-- start dalee@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'dalee'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end dalee@vestas.net

-- start COCOL@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cocol'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end COCOL@vestas.net

-- start pauro@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'pauro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end pauro@vestas.net

-- start jivko@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jivko'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jivko@vestas.net

-- start jekli@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jekli'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jekli@vestas.net

-- start mcjen@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mcjen'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mcjen@vestas.net

-- start RECLA@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'recla'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end RECLA@vestas.net

-- start MAVAT@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mavat'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end MAVAT@vestas.net

-- start CLBRO@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'clbro'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end CLBRO@vestas.net

-- start RALFK@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ralfk'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end RALFK@vestas.net

-- start togwu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'togwu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end togwu@vestas.net

-- start kalhu@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'kalhu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end kalhu@vestas.net

-- start judbr@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'judbr'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end judbr@Vestas.net

-- start jathw@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jathw'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jathw@vestas.net

-- start GREAC@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'greac'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end GREAC@vestas.net

-- start jepe@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jepe'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jepe@vestas.net

-- start cklco@vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'cklco'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end cklco@vestas.net

-- start HAHYL@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hahyl'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end HAHYL@Vestas.net

-- start BOSMA@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'bosma'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end BOSMA@Vestas.net

-- start balud@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'balud'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end balud@Vestas.net

-- start mcley@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'mcley'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end mcley@Vestas.net

-- start peasp@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'peasp'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end peasp@Vestas.net

-- start sth@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'sth'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end sth@Vestas.net

-- start abohm@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'abohm'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end abohm@Vestas.net

-- start ianbu@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'ianbu'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end ianbu@Vestas.net

-- start berng@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'berng'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end berng@Vestas.net

-- start hezul@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hezul'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hezul@Vestas.net

-- start hjuoh@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'hjuoh'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end hjuoh@Vestas.net

-- start jobus@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'jobus'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end jobus@Vestas.net

-- start phfar@Vestas.net
SELECT @ParticipantId = ParticipantId FROM Participant WHERE VestasInitials = 'phfar'
IF @ParticipantId IS NOT NULL
BEGIN
   INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, (SELECT RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'))
END
-- end phfar@Vestas.net
