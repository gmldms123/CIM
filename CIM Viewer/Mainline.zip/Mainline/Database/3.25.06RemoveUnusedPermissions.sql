/*
Delete permissions:
	Editor_CaseRelations_ChangeBundle 
	Editor_CIR_Read
	Editor_Documents_ViewAllPopulationLists 
	Editor_Items_Add 
	Editor_Items_Remove 
	Editor_Main_ImpersonateUser 
	Editor_ProjectPortal_CloseTimeRegistration 
	SharePoint_CIR_Change_Workflow 
	Test_No_Access 
	
	Viewer_Documents_HandleClass1Documents 
	Viewer_Documents_HandleClass2Documents 
	Viewer_Documents_HandleClass3FinancialDocuments 
	Editor_CaseFacts_CloseCase 
	Editor_CaseFacts_ChangeParentCase 

*/

BEGIN TRANSACTION PermissionTransaction

DECLARE @PermissionId INT;
DECLARE PermissionCursor CURSOR FOR
	SELECT PermissionId FROM Permission WHERE Name IN (
	'Editor_CaseRelations_ChangeBundle',
	'Editor_CIR_Read',
	'Editor_Documents_ViewAllPopulationLists',
	'Editor_Items_Add',
	'Editor_Items_Remove',
	'Editor_Main_ImpersonateUser',
	'Editor_ProjectPortal_CloseTimeRegistration',
	'SharePoint_CIR_Change_Workflow',
	'Test_No_Access',

	'Viewer_Documents_HandleClass1Documents',
	'Viewer_Documents_HandleClass2Documents',
	'Viewer_Documents_HandleClass3FinancialDocuments',
	'Editor_CaseFacts_CloseCase',
	'Editor_CaseFacts_ChangeParentCase' 	
	)
OPEN PermissionCursor

FETCH NEXT FROM PermissionCursor 
INTO @PermissionId

WHILE @@FETCH_STATUS = 0
BEGIN

	DELETE FROM Role2Permission WHERE PermissionId = @PermissionId
	DELETE FROM Permission WHERE PermissionId = @PermissionId

	FETCH NEXT FROM PermissionCursor 
	INTO @PermissionId

END
CLOSE PermissionCursor
DEALLOCATE PermissionCursor

COMMIT TRANSACTION PermissionTransaction
