/* The script remove all duplicated permission in roles in the role2permission table */
USE PManagement
CREATE TABLE #tmp (
	RName NVARCHAR(50) NOT NULL,
	PName NVARCHAR(50) NOT NULL)

INSERT INTO #tmp (RName, PName)
SELECT r.name AS RName, p.name AS PName 
FROM role2permission r2p 
	JOIN permission p ON r2p.permissionid = p.permissionid 
	JOIN role r ON r2p.roleid = r.roleid 
GROUP BY r.name, p.name 
HAVING COUNT(*) > 1 
ORDER BY r.name, p.name

WHILE (SELECT COUNT(*) FROM #tmp) > 0
BEGIN
	DELETE FROM #tmp

	INSERT INTO #tmp (RName, PName)
	SELECT r.name AS RName, p.name AS PName 
	FROM role2permission r2p 
		JOIN permission p ON r2p.permissionid = p.permissionid 
		JOIN role r ON r2p.roleid = r.roleid 
	GROUP BY r.name, p.name 
	HAVING COUNT(*) > 1 
	ORDER BY r.name, p.name

	DECLARE @sql AS NVARCHAR(4000)
	DECLARE permission_cursor CURSOR FOR
	SELECT N'DELETE FROM Role2Permission WHERE Role2PermissionId = (SELECT MAX(Role2PermissionId) AS Role2PermissionId ' + 
		   'FROM Role2Permission ' + 
		   'WHERE RoleId = (SELECT RoleId FROM Role WHERE Name = ''' + RName + ''') AND PermissionId = (SELECT PermissionId FROM Permission WHERE Name = ''' + PName + '''))'
	FROM #tmp

	OPEN permission_cursor;

	FETCH NEXT FROM permission_cursor INTO @sql;

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC sp_executeSQL @sql    
		FETCH NEXT FROM permission_cursor INTO @sql;
	END

	CLOSE permission_cursor;
	DEALLOCATE permission_cursor;
END
