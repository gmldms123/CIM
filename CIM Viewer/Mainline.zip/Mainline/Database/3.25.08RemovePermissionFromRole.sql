/* The script removes permission in roles in the role2permission table */
USE PManagement
DELETE FROM Role2Permission WHERE RoleId = (SELECT RoleId FROM [Role] WHERE Name = 'CIM Execution Manager') AND PermissionId = (SELECT PermissionId FROM Permission WHERE Name = 'Editor_Main_Administration')