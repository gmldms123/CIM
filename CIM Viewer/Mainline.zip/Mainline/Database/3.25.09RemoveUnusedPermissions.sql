/*
Delete permissions:

Editor_CaseRelations_ChangeDependent
Editor_CaseRelations_ChangeKnowledge
Editor_CaseRelations_ViewDescription
*/

BEGIN TRANSACTION PermissionTransaction

DECLARE @PermissionId INT;
DECLARE PermissionCursor CURSOR FOR
	SELECT PermissionId FROM Permission WHERE Name IN (
	'Editor_CaseRelations_ChangeDependent',
	'Editor_CaseRelations_ChangeKnowledge',
	'Editor_CaseRelations_ViewDescription'
	)
OPEN PermissionCursor

FETCH NEXT FROM PermissionCursor 
INTO @PermissionId

WHILE @@FETCH_STATUS = 0
BEGIN

	DELETE FROM Role2Permission WHERE PermissionId = @PermissionId
	DELETE FROM Permission WHERE PermissionId = @PermissionId

	FETCH NEXT FROM PermissionCursor 
	INTO @PermissionId

END
CLOSE PermissionCursor
DEALLOCATE PermissionCursor

COMMIT TRANSACTION PermissionTransaction
