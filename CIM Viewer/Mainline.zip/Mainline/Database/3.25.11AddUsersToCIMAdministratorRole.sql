USE PManagement

TRUNCATE TABLE Participant2Role

DECLARE @ParticipantId AS BIGINT
DECLARE @RoleId AS BIGINT

-- Find participantId for user akje
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'akje' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User akje added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user andvi
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'andvi' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User andvi added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ago
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ago' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ago added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ankni
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ankni' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ankni added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user annt
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'annt' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User annt added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user an
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'an' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User an added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user badhe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'badhe' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User badhe added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user benru
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'benru' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User benru added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user bsm
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'bsm' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User bsm added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user bbaha
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'bbaha' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User bbaha added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user crm
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'crm' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User crm added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user cmbc
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'cmbc' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User cmbc added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user chale
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'chale' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User chale added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user clahn
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'clahn' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User clahn added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user dab
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'dab' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User dab added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user dhaug
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'dhaug' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User dhaug added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user dathe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'dathe' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User dathe added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user dbc
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'dbc' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User dbc added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user evn
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'evn' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User evn added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user flaen
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'flaen' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User flaen added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user frque
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'frque' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User frque added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user gdh
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'gdh' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User gdh added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user hpu
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'hpu' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User hpu added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user harva
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'harva' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User harva added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user hbe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'hbe' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User hbe added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user heaar
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'heaar' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User heaar added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user helpo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'helpo' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User helpo added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user hmn
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'hmn' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User hmn added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user inand
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'inand' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User inand added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jalka
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jalka' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jalka added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jbold
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jbold' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jbold added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jvl
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jvl' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jvl added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jajkj
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jajkj' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jajkj added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jabl
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jabl' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jabl added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jksie
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jksie' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jksie added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jjess
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jjess' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jjess added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jksor
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jksor' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jksor added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jqliu
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jqliu' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jqliu added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jusli
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jusli' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jusli added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jbrha
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jbrha' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jbrha added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jns
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jns' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jns added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user joege
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'joege' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User joege added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kbpe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kbpe' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kbpe added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kaflo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kaflo' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kaflo added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kkrog
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kkrog' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kkrog added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kavin
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kavin' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kavin added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kehen
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kehen' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kehen added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kelth
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kelth' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kelth added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kenja
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kenja' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kenja added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kpg
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kpg' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kpg added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ksbri
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ksbri' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ksbri added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kifu
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kifu' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kifu added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user krlys
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'krlys' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User krlys added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lfn
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lfn' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lfn added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lajp
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lajp' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lajp added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lsoe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lsoe' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lsoe added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user llili
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'llili' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User llili added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lbs
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lbs' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lbs added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mkjh
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mkjh' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mkjh added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mabal
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mabal' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mabal added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mbd
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mbd' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mbd added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mki
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mki' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mki added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user marki
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'marki' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User marki added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mazil
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mazil' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mazil added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user minop
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'minop' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User minop added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user msims
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'msims' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User msims added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mifth
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mifth' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mifth added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mgb
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mgb' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mgb added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mobkr
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mobkr' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mobkr added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mmkri
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mmkri' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mmkri added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user morni
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'morni' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User morni added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user moja
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'moja' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User moja added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user nakro
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'nakro' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User nakro added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user nimpe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'nimpe' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User nimpe added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user nebj
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'nebj' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User nebj added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user pwar
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'pwar' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User pwar added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user pego
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'pego' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User pego added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user pelch
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'pelch' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User pelch added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user pthar
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'pthar' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User pthar added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ptl
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ptl' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ptl added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user rrnvk
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'rrnvk' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User rrnvk added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user razkn
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'razkn' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User razkn added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user remi
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'remi' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User remi added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user sapur
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'sapur' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User sapur added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user skm
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'skm' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User skm added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user sbkri
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'sbkri' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User sbkri added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user sokma
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'sokma' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User sokma added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user slb
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'slb' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User slb added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ttfje
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ttfje' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ttfje added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user tb
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'tb' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User tb added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user toje
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'toje' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User toje added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user usoki
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'usoki' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User usoki added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user up
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'up' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User up added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user vekan
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'vekan' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User vekan added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user vvj
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'vvj' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User vvj added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user wvili
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'wvili' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User wvili added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user weqis
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'weqis' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User weqis added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user willa
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'willa' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User willa added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ymzha
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ymzha' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ymzha added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user zhgao
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'zhgao' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User zhgao added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user zhuol
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'zhuol' 

-- Find roleId for role CIM Administrator
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Administrator' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User zhuol added to role CIM Administrator'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 
