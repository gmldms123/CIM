USE PManagement
DECLARE @ParticipantId AS BIGINT
DECLARE @RoleId AS BIGINT

-- Find participantId for user toje
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'toje' 

-- Find roleId for role CIM Execution Manager
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Execution Manager' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User toje added to role CIM Execution Manager'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 
