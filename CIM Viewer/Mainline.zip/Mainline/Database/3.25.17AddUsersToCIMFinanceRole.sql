USE PManagement
DECLARE @ParticipantId AS BIGINT
DECLARE @RoleId AS BIGINT

-- Find participantId for user jkc
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jkc' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jkc added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lfm
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lfm' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lfm added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user inand
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'inand' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User inand added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user chpuk
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'chpuk' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User chpuk added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user iwnie
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'iwnie' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User iwnie added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user gosha
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'gosha' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User gosha added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user thots
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'thots' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User thots added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user dhish
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'dhish' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User dhish added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user krifr
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'krifr' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User krifr added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user nagro
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'nagro' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User nagro added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kanas
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kanas' 

-- Find roleId for role CIM Finance
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Finance' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kanas added to role CIM Finance'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 








































