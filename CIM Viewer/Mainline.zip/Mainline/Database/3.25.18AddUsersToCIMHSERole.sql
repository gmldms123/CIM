USE PManagement
DECLARE @ParticipantId AS BIGINT
DECLARE @RoleId AS BIGINT

-- Find participantId for user doman
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'doman' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User doman added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jabl
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jabl' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jabl added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user laod
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'laod' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User laod added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user chkri
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'chkri' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User chkri added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ijobm
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ijobm' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ijobm added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user flepe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'flepe' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User flepe added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user makja
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'makja' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User makja added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user rrnvk
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'rrnvk' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User rrnvk added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user perhm
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'perhm' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User perhm added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mramk
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mramk' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mramk added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user larmo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'larmo' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User larmo added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kecon
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kecon' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kecon added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ppapa
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ppapa' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ppapa added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kssat
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kssat' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kssat added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user pagan
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'pagan' 

-- Find roleId for role CIM HSE
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM HSE' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User pagan added to role CIM HSE'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 
