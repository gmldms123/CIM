USE PManagement
DECLARE @ParticipantId AS BIGINT
DECLARE @RoleId AS BIGINT

-- Find participantId for user hje
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'hje' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User hje added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user chgae
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'chgae' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User chgae added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user loach
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'loach' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User loach added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user vitni
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'vitni' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User vitni added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mdani
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mdani' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mdani added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kekra
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kekra' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kekra added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user tobak
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'tobak' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User tobak added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user reoma
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'reoma' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User reoma added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user cavch
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'cavch' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User cavch added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user hethe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'hethe' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User hethe added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kipra
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kipra' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kipra added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user adcas
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'adcas' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User adcas added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user annho
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'annho' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User annho added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user arnkl
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'arnkl' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User arnkl added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user armul
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'armul' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User armul added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user besve
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'besve' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User besve added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user bebey
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'bebey' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User bebey added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user bhk
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'bhk' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User bhk added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user brope
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'brope' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User brope added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user chaas
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'chaas' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User chaas added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user frhma
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'frhma' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User frhma added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jem
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jem' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jem added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jagan
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jagan' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jagan added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jumko
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jumko' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jumko added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lalkn
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lalkn' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lalkn added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user marbh
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'marbh' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User marbh added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user melmo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'melmo' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User melmo added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user peand
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'peand' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User peand added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user rombl
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'rombl' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User rombl added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ipede
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ipede' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ipede added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jopas
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jopas' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jopas added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kschm
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kschm' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kschm added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lasea
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lasea' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lasea added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user olsol
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'olsol' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User olsol added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user prpou
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'prpou' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User prpou added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user pibeh
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'pibeh' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User pibeh added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user rilys
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'rilys' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User rilys added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user thbor
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'thbor' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User thbor added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user tomog
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'tomog' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User tomog added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user brpou
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'brpou' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User brpou added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kraar
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kraar' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kraar added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mifrb
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mifrb' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mifrb added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jetmo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jetmo' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jetmo added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user loach
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'loach' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User loach added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ankua
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ankua' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ankua added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user berah
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'berah' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User berah added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mibru
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mibru' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mibru added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user henar
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'henar' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User henar added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user xjvs
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'xjvs' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User xjvs added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jetmo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jetmo' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jetmo added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jdach
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jdach' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jdach added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lauam
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lauam' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lauam added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user leeby
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'leeby' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User leeby added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user peaas
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'peaas' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User peaas added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ruson
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ruson' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ruson added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user adrwi
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'adrwi' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User adrwi added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user besve
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'besve' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User besve added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user suleh
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'suleh' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User suleh added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user hahov
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'hahov' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User hahov added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jimar
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jimar' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jimar added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jbh
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jbh' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jbh added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kasie
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kasie' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kasie added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ktnor
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ktnor' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ktnor added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user kipra
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'kipra' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User kipra added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lgeru
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lgeru' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lgeru added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user laove
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'laove' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User laove added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lejol
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lejol' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lejol added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user lemaa
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'lemaa' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User lemaa added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user liann
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'liann' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User liann added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user linor
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'linor' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User linor added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user jilji
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'jilji' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User jilji added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user majo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'majo' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User majo added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user metra
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'metra' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User metra added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mibru
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mibru' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mibru added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user mdo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'mdo' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User mdo added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user moweg
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'moweg' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User moweg added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user nasch
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'nasch' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User nasch added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user nehau
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'nehau' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User nehau added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user panve
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'panve' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User panve added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user rehel
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'rehel' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User rehel added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ricde
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ricde' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ricde added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user scdan
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'scdan' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User scdan added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user stuwo
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'stuwo' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User stuwo added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user suleh
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'suleh' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User suleh added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user soreb
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'soreb' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User soreb added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user thhof
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'thhof' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User thhof added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user tirya
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'tirya' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User tirya added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user tonys
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'tonys' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User tonys added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user vikpe
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'vikpe' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User vikpe added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user ansli
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'ansli' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User ansli added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user arluk
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'arluk' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User arluk added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 

-- Find participantId for user knmad
SELECT @ParticipantId = participantId 
FROM Participant 
WHERE HasLeft = 0 AND VestasInitials = 'knmad' 

-- Find roleId for role CIM Purchase
SELECT @RoleId = RoleId 
FROM Role 
WHERE Name = 'CIM Purchase' 

-- Join participant to role if participant does not exist in role
IF @ParticipantId IS NOT NULL AND @RoleId IS NOT NULL
BEGIN 
    IF (SELECT COUNT(*) FROM Participant2Role WHERE ParticipantId = @ParticipantId AND RoleId = @RoleId) = 0 
    BEGIN 
        PRINT 'User knmad added to role CIM Purchase'
        INSERT INTO Participant2Role (ParticipantId, RoleId) VALUES (@ParticipantId, @RoleId)
    END 
END 
