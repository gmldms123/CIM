/*
Delete permissions:

Editor_CaseFacts_ChangeClaimStatus
Editor_CaseFacts_ChangeStatus
Editor_CaseFacts_Create
*/

BEGIN TRANSACTION PermissionTransaction

DECLARE @PermissionId INT;
DECLARE PermissionCursor CURSOR FOR
	SELECT PermissionId FROM Permission WHERE Name IN (
		'Editor_CaseFacts_ChangeClaimStatus',
		'Editor_CaseFacts_ChangeStatus',
		'Editor_CaseFacts_Create'
		)
OPEN PermissionCursor

FETCH NEXT FROM PermissionCursor 
INTO @PermissionId

DECLARE @RoleId INT;
SELECT @RoleId = RoleId FROM [Role] WHERE Name = 'CIM SBU Technical Support'

WHILE @@FETCH_STATUS = 0
BEGIN

	DELETE FROM Role2Permission WHERE PermissionId = @PermissionId AND RoleId = @RoleId

	FETCH NEXT FROM PermissionCursor 
	INTO @PermissionId

END
CLOSE PermissionCursor
DEALLOCATE PermissionCursor

COMMIT TRANSACTION PermissionTransaction
