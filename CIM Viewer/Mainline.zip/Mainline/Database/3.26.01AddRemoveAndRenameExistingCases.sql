use pmanagement
/*
	For all existing cases
	- create folders 
		- CIM Project Log 
	- rename and move folders
		- Gate Deliverables List -> List of Deliveries
	- rename folders
		- FR Presentation and FR Decision Log -> FR Presentation
	- delete folders 
		- Project Resource Plan 
		- Project Scope Log
		- Case Closure
*/
		
DECLARE @CreatedBy AS BIGINT
DECLARE @CaseDocumentsId AS BIGINT
DECLARE @GateDeliverablesSort AS BIGINT
DECLARE @ListOfDeliverablesSort AS BIGINT
DECLARE @CIMProjectLogSort AS BIGINT
DECLARE @CaseId AS BIGINT

DECLARE folder_cursor CURSOR FOR
SELECT DISTINCT CaseId FROM Folder 

OPEN folder_cursor;
FETCH NEXT FROM folder_cursor INTO @CaseId

WHILE @@FETCH_STATUS = 0
BEGIN
	
	SELECT @CreatedBy = CreatedBy
	FROM Folder
	WHERE CaseId = @CaseId AND FolderTypeId = 0

	-- Get Sort of CIM Project Log 
	SELECT @CIMProjectLogSort = MAX(Sort) + 1
	FROM Folder 
	WHERE CaseId = @CaseId AND Name < 'CIM Project Log' AND ParentFolderId IS NULL AND Name NOT LIKE 'Case Documents' AND FolderTypeId = 3
	
	-- Make room for Cim Project Log 
	UPDATE Folder 
	SET Sort = Sort + 1
	FROM Folder
	WHERE CaseId = @CaseId AND ParentFolderId IS NULL AND FolderTypeId NOT IN (0, 2) AND Sort >= @CIMProjectLogSort 

	-- Insert CIM Project Log
	INSERT INTO Folder (CaseId, FolderTypeId, Name, ParentFolderId, Sort, Created, CreatedBy)
	VALUES (@CaseId, 3, 'CIM Project Log', NULL, @CIMProjectLogSort, GetDate(), @CreatedBy)

	-- Get Sort of List of Deliverables
	SELECT @ListOfDeliverablesSort = MAX(Sort) + 1
	FROM Folder 
	WHERE CaseId = @CaseId AND Name < 'List of Deliverables' AND Name NOT LIKE 'Case Documents' AND ParentFolderId IS NULL AND FolderTypeId = 3

	-- Get Sort of Gate Deliverables 
	SELECT @GateDeliverablesSort = Sort
	FROM Folder 
	WHERE CaseId = @CaseId AND Name = 'Gate Deliverables List' AND ParentFolderId = @CaseDocumentsId 

	-- Make room for List of Deliverables
	UPDATE Folder 
	SET Sort = Sort + 1
	FROM Folder
	WHERE CaseId = @CaseId AND ParentFolderId IS NULL AND FolderTypeId NOT IN (0, 2) AND Sort >= @ListOfDeliverablesSort 

	-- Move and rename Gate Deliverables List
	UPDATE Folder 
	SET ParentFolderId = NULL, Name = 'List of Deliverables', Sort = @ListOfDeliverablesSort
	WHERE CaseId = @CaseId AND Name = 'Gate Deliverables List'

	-- Get CaseDocuments Id
	SELECT @CaseDocumentsId = FolderId 
	FROM Folder
	WHERE CaseId = @CaseId AND Name = 'Case Documents'

	-- Move sort in Case Documents.
	UPDATE Folder 
	SET Sort = Sort - 1
	WHERE CaseId = @CaseId AND ParentFolderId = @CaseDocumentsId AND Sort > @GateDeliverablesSort 

	-- Rename FR Presentation and FR Decision Log
	UPDATE Folder 
	SET Name = 'FR Presentation'
	FROM Folder
	WHERE CaseId = @CaseId AND Name = 'FR Presentation and FR Decision Log'

    FETCH NEXT FROM folder_cursor INTO @CaseId
END

CLOSE folder_cursor;
DEALLOCATE folder_cursor;

