use pmanagement
/*
	For all future cases
	- create folders 
		- CIM Project Log 
	- rename and move folders
		- Gate Deliverables List -> List of Deliveries
	- rename folders
		- FR Presentation and FR Decision Log -> FR Presentation
	- delete folders 
		- Project Resource Plan 
		- Project Scope Log
		- Case Closure
*/
	
DECLARE @CreatedBy AS BIGINT
DECLARE @CaseDocumentsId AS BIGINT
DECLARE @GateDeliverablesSort AS BIGINT
DECLARE @ListOfDeliverablesSort AS BIGINT
DECLARE @CIMProjectLogSort AS BIGINT
DECLARE @CaseId AS BIGINT
DECLARE @CaseClosureId AS BIGINT
DECLARE @ProjectResourcePlanId AS BIGINT
DECLARE @ProjectResourcePlanSort AS BIGINT
DECLARE @ProjectScopeLogID AS BIGINT

-- Get Sort of CIM Project Log 
SELECT @CIMProjectLogSort = MAX(Sort) + 1
FROM StandardFolder 
WHERE BrandId = 1 AND Name < 'CIM Project Log' AND ParentStandardFolderId IS NULL AND Name NOT LIKE 'Case Documents' AND FolderTypeId = 3

-- Make room for Cim Project Log 
UPDATE StandardFolder 
SET Sort = Sort + 1
FROM StandardFolder
WHERE brandId = 1 AND ParentStandardFolderId IS NULL AND FolderTypeId NOT IN (0, 2) AND Sort >= @CIMProjectLogSort 

-- Insert CIM Project Log
INSERT INTO StandardFolder (BrandId, FolderTypeId, Name, ParentStandardFolderId, Sort)
VALUES (1, 3, 'CIM Project Log', NULL, @CIMProjectLogSort)

-- Get Sort of List of Deliverables
SELECT @ListOfDeliverablesSort = MAX(Sort) + 1
FROM StandardFolder 
WHERE BrandId = 1 AND Name < 'List of Deliverables' AND Name NOT LIKE 'Case Documents' AND ParentStandardFolderId IS NULL AND FolderTypeId = 3

-- Get CaseDocuments Id
SELECT @CaseDocumentsId = StandardFolderId 
FROM StandardFolder
WHERE brandId = 1 AND Name = 'Case Documents'

-- Get Sort of Gate Deliverables 
SELECT @GateDeliverablesSort = Sort
FROM StandardFolder 
WHERE BrandId = 1 AND Name = 'Gate Deliverables List' AND ParentStandardFolderId = @CaseDocumentsId 

-- Make room for List of Deliverables
UPDATE StandardFolder 
SET Sort = Sort + 1
FROM StandardFolder
WHERE BrandId = 1 AND ParentStandardFolderId IS NULL AND FolderTypeId NOT IN (0, 2) AND Sort >= @ListOfDeliverablesSort 

-- Move and rename Gate Deliverables List
UPDATE StandardFolder 
SET ParentStandardFolderId = NULL, Name = 'List of Deliverables', Sort = @ListOfDeliverablesSort
WHERE brandId = 1 AND Name = 'Gate Deliverables List'

-- Rename FR Presentation and FR Decision Log
UPDATE StandardFolder 
SET Name = 'FR Presentation'
FROM StandardFolder
WHERE brandId = 1 AND Name = 'FR Presentation and FR Decision Log'

-- Get Sort of Gate Deliverables 
SELECT @ProjectResourcePlanSort = Sort
FROM StandardFolder 
WHERE BrandId = 1 AND Name = 'Project Resource Plan' AND ParentStandardFolderId IS NULL

-- Delete Project Resource Plan and Project Scope Log
DELETE FROM StandardFolder 
WHERE BrandId = 1 AND Name IN ('Project Resource Plan', 'Project Scope Log') AND ParentStandardFolderId IS NULL

-- Move sort in root.
UPDATE StandardFolder 
SET Sort = Sort - 2 
WHERE BrandId = 1 AND ParentStandardFolderId IS NULL AND Sort > @ProjectResourcePlanSort 

-- Delete Case Closure
DELETE FROM StandardFolder 
WHERE brandId = 1 AND Name in ('Case Closure', 'Project Risk Assessment') AND ParentStandardFolderId = @CaseDocumentsId 

-- Move sort in Case Documents.
UPDATE StandardFolder 
SET Sort = Sort - 2 
WHERE brandId = 1 AND ParentStandardFolderId = @CaseDocumentsId AND Sort > @GateDeliverablesSort 

