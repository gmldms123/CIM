USE PManagement 

/* Merge Improvement Verification to Improvement Development StandardTask */
DECLARE @VerificationId AS BIGINT
DECLARE @DevelopmentId AS BIGINT
SELECT @VerificationId = StandardTaskId FROM standardtask WHERE name = 'Improvement Verification' 
SELECT @DevelopmentId = StandardTaskId FROM standardtask WHERE name = 'Improvement Development' 

UPDATE [Case] SET StandardTaskId = @DevelopmentId WHERE StandardTaskId = @VerificationId 
UPDATE Task SET StandardTaskId = @DevelopmentId WHERE StandardTaskId = @VerificationId 
UPDATE StandardTask SET DeletedById = 11581, Deleted = GETDATE() WHERE StandardTaskId = @VerificationId 
DELETE FROM StandardTask2Status WHERE StandardTaskId = @VerificationId 
UPDATE StandardTask SET Name = 'Improvement Development and Verification' WHERE StandardTaskId = @DevelopmentId 
