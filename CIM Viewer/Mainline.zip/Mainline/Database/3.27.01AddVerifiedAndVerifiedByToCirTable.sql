-- Add Verified and VerifiedBy to the CIR table
USE [Pmanagement]

ALTER TABLE dbo.CIR ADD
	Verified datetime NULL,
	VerifiedBy bigint NULL
GO
ALTER TABLE dbo.CIR ADD CONSTRAINT
	FK_CIR_Participant FOREIGN KEY
	(
	VerifiedBy
	) REFERENCES dbo.Participant
	(
	ParticipantId
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
