-- Add Rejected and RejectedBy to the CIR table
USE [Pmanagement]

ALTER TABLE dbo.CIR ADD
	Rejected datetime NULL,
	RejectedBy bigint NULL
GO
ALTER TABLE dbo.CIR ADD CONSTRAINT
	FK_CIR_Participant1 FOREIGN KEY
	(
	RejectedBy
	) REFERENCES dbo.Participant
	(
	ParticipantId
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
