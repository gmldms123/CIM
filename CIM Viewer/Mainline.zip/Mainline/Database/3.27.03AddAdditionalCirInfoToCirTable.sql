-- Add DateOfInspection, DateOfFailure, SiteName and ServiceReportNumber to the CIR and CIR_ImportStaging tables
USE [Pmanagement]

ALTER TABLE dbo.CIR_ImportStaging ADD
	DateOfInspection datetime NULL,
	DateOfFailure datetime NULL,
	SiteName nvarchar(200) NULL,
	ServiceReportNumber nvarchar(200) NOT NULL CONSTRAINT DF_CIR_ImportStaging_ServiceReportNumber DEFAULT N''
GO

ALTER TABLE dbo.CIR ADD
	DateOfInspection datetime NULL,
	DateOfFailure datetime NULL,
	SiteName nvarchar(200) NULL,
	ServiceReportNumber nvarchar(200) NOT NULL CONSTRAINT DF_CIR_ServiceReportNumber DEFAULT (N'')
GO
