USE [Pmanagement]

BEGIN
	
  IF NOT EXISTS(SELECT 1 FROM [dbo].[Platform] WHERE Name='Service Platform I')
  BEGIN
	INSERT INTO dbo.Platform VALUES ('Service Platform I', (SELECT TOP 1 ParticipantId FROM dbo.Participant WHERE VestasInitials = 'CLLOC'));
  END
  IF NOT EXISTS(SELECT 1 FROM [dbo].[Platform] WHERE Name='Service Platform II')
  BEGIN
	INSERT INTO dbo.Platform VALUES ('Service Platform II', (SELECT TOP 1 ParticipantId FROM dbo.Participant WHERE VestasInitials = 'JVL'));
  END
  
 END