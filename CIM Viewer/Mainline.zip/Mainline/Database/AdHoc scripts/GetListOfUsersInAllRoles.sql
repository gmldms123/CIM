/* Get list of users in all roles */
USE PManagement 
SELECT r.Name, VestasInitials
FROM Participant2Role p2r 
	JOIN Participant p ON p2r.ParticipantId = p.ParticipantId 
	JOIN Role r ON p2r.RoleId = r.RoleId
ORDER BY r.Name, VestasInitials 
