USE Pmanagement
DECLARE @ERR AS Int

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0
	
-- StandardTask VIS Sort Update
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 0
		WHERE StandardTaskId = 40
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 1
		WHERE StandardTaskId = 42
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 3
		WHERE StandardTaskId = 45
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 4
		WHERE StandardTaskId = 47
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 5
		WHERE StandardTaskId = 48
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 6
		WHERE StandardTaskId = 50
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 7
		WHERE StandardTaskId = 52
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 8
		WHERE StandardTaskId = 54
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 9
		WHERE StandardTaskId = 56
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET VISSort = 10
		WHERE StandardTaskId = 58
		SET @ERR = @@ERROR
	END
	
--------------------------------------------------------------------------------------------------

-- StandardTask Sort Update
	BEGIN
		UPDATE StandardTask 
		SET Sort = 0
		WHERE StandardTaskId = 40
		SET @ERR = @@ERROR
	END

	BEGIN
		UPDATE StandardTask 
		SET Sort = 1
		WHERE StandardTaskId = 41
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 2
		WHERE StandardTaskId = 42
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 3
		WHERE StandardTaskId = 43
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 4
		WHERE StandardTaskId = 44
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 5
		WHERE StandardTaskId = 45
		SET @ERR = @@ERROR
	END

	BEGIN
		UPDATE StandardTask 
		SET Sort = 6
		WHERE StandardTaskId = 46
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 7
		WHERE StandardTaskId = 47
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 8
		WHERE StandardTaskId = 48
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 9
		WHERE StandardTaskId = 49
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 10
		WHERE StandardTaskId = 50
		SET @ERR = @@ERROR
	END

	BEGIN
		UPDATE StandardTask 
		SET Sort = 11
		WHERE StandardTaskId = 51
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 12
		WHERE StandardTaskId = 52
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 13
		WHERE StandardTaskId = 53
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 14
		WHERE StandardTaskId = 54
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 15
		WHERE StandardTaskId = 55
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 16
		WHERE StandardTaskId = 56
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 17
		WHERE StandardTaskId = 57
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 18
		WHERE StandardTaskId = 58
		SET @ERR = @@ERROR
	END
	
	BEGIN
		UPDATE StandardTask 
		SET Sort = 19
		WHERE StandardTaskId = 59
		SET @ERR = @@ERROR
	END
	
--------------------------------------------------------------------------------------------------

-- Phase VIS Update
	BEGIN
		UPDATE Phase
		SET VISSort = 0
		WHERE PhaseId = 25
		SET @ERR = @@ERROR
	END

	BEGIN
		UPDATE Phase
		SET VISSort = 1
		WHERE PhaseId = 26
		SET @ERR = @@ERROR
	END

	BEGIN
		UPDATE Phase
		SET VISSort = 2
		WHERE PhaseId = 27
		SET @ERR = @@ERROR
	END

	BEGIN
		UPDATE Phase
		SET VISSort = 3
		WHERE PhaseId = 28
		SET @ERR = @@ERROR
	END
		
--------------------------------------------------------------------------------------------------

-- ChangeType
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Phase changed',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Status changed',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
	
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Invoice changed',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
	
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('KPI changed',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO ChangeType
		VALUES ('KPI deleted',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
	
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('KPI created',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
	
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Case closed',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Case reopened',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
	
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Case Created',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
	
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Project Manager changed',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
	
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Execution Manager changed',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

--------------------------------------------------------------------------------------------------

-- AlertServiceSettings
	BEGIN
		INSERT INTO AlertServiceSettings 
		VALUES (NULL,28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
		
--------------------------------------------------------------------------------------------------
-- AlertFrequency
	BEGIN
		INSERT INTO AlertFrequency
		VALUES ('Immediate',NULL,180,NULL,28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO AlertFrequency
		VALUES ('Weekly','Monday',180,NULL,28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
--------------------------------------------------------------------------------------------------
-- AlertCategory		
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('By CIM Case',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('Platform',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('By CIM Project Manager',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('By Execution Manager',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('Status',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('Phase',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('All existing cases',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AlertCategory
		VALUES ('New Cases',28524,GETDATE(),NULL,NULL)			
		SET @ERR = @@ERROR
	END

-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim