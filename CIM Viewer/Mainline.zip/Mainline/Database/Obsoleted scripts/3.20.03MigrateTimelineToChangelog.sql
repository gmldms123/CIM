use PManagement
/* Create change types - uncomment then deploying to production*/
/*
INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('Phase changed', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('Status changed', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('Invoice changed', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('KPI created', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('KPI changed', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('KPI deleted', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('Case created', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('Case closed', 28524, GetDate())

INSERT INTO ChangeType (Name, CreatedById, Created)
VALUES ('Case reopened', 28524, GetDate())

*/
/* Variables */
DECLARE @Text AS NVARCHAR(1000)
DECLARE @AdditionalInfo AS NVARCHAR(1000)
DECLARE @BeforeValue AS NVARCHAR(400)
DECLARE @AfterValue AS NVARCHAR(400)
DECLARE @ChangeType AS BIGINT
DECLARE @KPIId AS BIGINT
DECLARE @Sort AS INT
DECLARE @TimelineId AS BIGINT
DECLARE @CaseId AS BIGINT
DECLARE @OldCaseId AS BIGINT


/* Case Created */
/* Find ChangeType for Case created */
SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'Case created%'

INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, CreatedById, Created)
SELECT caseid, '', 1, @ChangeType, changedby, Changed 
FROM Timeline 
WHERE [Text] = 'Case Created'


/* Case Re-opened */
/* Find ChangeType for Case reopened */
SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'Case reopened%'

INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, CreatedById, Created)
SELECT caseid, 6, 3, @ChangeType, changedby, Changed 
FROM Timeline 
WHERE [Text] = 'Case Re-Opened'


/* KPI x changed from y to z */
DECLARE kpi_cursor CURSOR FOR
SELECT TimeLineID, [Text] FROM TimeLine
WHERE [Text] LIKE 'KPI %' AND [Text] LIKE '%changed%'
ORDER BY timelineID

OPEN kpi_cursor

FETCH NEXT FROM kpi_cursor
INTO @TimelineId, @Text

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Get AdditionalInfo for KPIs */
	SET @AdditionalInfo = RIGHT(LEFT(@Text,CHARINDEX(''' changed', @Text) - 1), CHARINDEX(''' changed', @Text) - (CHARINDEX('KPI ''', @Text) + 5))

	/* Insert new hidden kpi if it does not exist */
	IF (SELECT COUNT(*) FROM KPI WHERE Name = @AdditionalInfo) = 0
	BEGIN
		SELECT @Sort = MAX(Sort) + 1 FROM KPI WHERE KPIGroupId = 1
	 
		INSERT INTO KPI (KPIGroupID, Name, Sort, Hidden, Calculated)
		VALUES (1, @AdditionalInfo, @Sort, 1, 0) 	
	END

	SELECT @KPIId = KPIId 
	FROM KPI 
	WHERE Name = @AdditionalInfo 

	/* Get beforevalue for KPIs */
	SET @BeforeValue = RIGHT(@Text, LEN(@Text) - CHARINDEX('changed from (', @Text)-13)
	
	/* Changed from is not in the string anymore */
	IF (CHARINDEX('changed from', @BeforeValue) = 0)  
	BEGIN
		SET @BeforeValue = LEFT(@BeforeValue, CHARINDEX(')', @BeforeValue)-1)
	END
	ELSE
	BEGIN
		/* Changed from is still in the string */
		SET @BeforeValue = RIGHT(@beforevalue,LEN(@beforevalue) - CHARINDEX('changed from', @beforevalue)-12)
		SET @BeforeValue = RIGHT(@beforevalue,LEN(@beforevalue) - CHARINDEX('(', @beforevalue)+1)

		/* Some still have ( as No. 1 character */
		IF (LEFT(@BeforeValue, 1) = '(')
		BEGIN
			SET @BeforeValue = RIGHT(@BeforeValue, LEN(@beforevalue) - 1)
		END
	
		/* Get the end ) of beforevalue */
		SET @BeforeValue = LEFT(@Beforevalue, CHARINDEX(')', @Beforevalue)-1)
	END   
   
	SELECT @BeforeValue = Value
	FROM KPIRating 
	WHERE Name = @BeforeValue AND KPIId = @KPIId

	/* Set BeforeValue to 0 if it is not found in KPIRating table */
	IF (ISNUMERIC(@Beforevalue) = 0)
		SET @BeforeValue = 0

	/* Get afterValue for KPIs */
	SET @AfterValue = RIGHT(@text, LEN(@text) - CHARINDEX(' to ', @Text) - 6)
	SET @AfterValue = LEFT(@aftervalue, len(@aftervalue) - 1)
	SET @AfterValue = LEFT(@aftervalue, len(@aftervalue) - CHARINDEX('...', @aftervalue)- 2)
   
	/* Find KPIRatingID for AfterValue */
	SELECT @AfterValue = Value
	FROM KPIRating 
	WHERE Name like '%' + @afterValue + '%' AND KPIId = @KPIId 
   
	/* Set AfterValue to 0 if it is not found in KPIRating table */
	IF (ISNUMERIC(@Aftervalue) = 0)
		SET @AfterValue = 0

	/* Find ChangeType for KPI changed */
	SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'KPI changed%'

	/* Insert KPI changed into ChangeLog */
	INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
	SELECT caseid, @BeforeValue, @AfterValue, @ChangeType, @KPIId, ChangedBy, Changed 
	FROM Timeline 
	WHERE TimeLineId = @TimelineId

   FETCH NEXT FROM kpi_cursor
   INTO @TimelineId, @Text
END

CLOSE kpi_cursor
DEALLOCATE kpi_cursor


/* KPI x has been deleted */
DECLARE kpi_cursor CURSOR FOR
SELECT TimeLineId, [Text] FROM TimeLine
WHERE [Text] LIKE 'KPI %' AND [Text] LIKE '%has been deleted%'
ORDER BY timelineID

OPEN kpi_cursor

FETCH NEXT FROM kpi_cursor
INTO @TimelineId, @Text

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Get AdditionalInfo for KPIs */
	SET @AdditionalInfo = RIGHT(LEFT(@Text,CHARINDEX(''' has been deleted', @Text) - 1), CHARINDEX(''' has been deleted', @Text) - (CHARINDEX('KPI ''', @Text) + 5))

	/* Insert new hidden kpi if it does not exist */
	IF (SELECT COUNT(*) FROM KPI WHERE Name = @AdditionalInfo) = 0
	BEGIN
		SELECT @Sort = MAX(Sort) + 1 FROM KPI WHERE KPIGroupId = 1
	 
		INSERT INTO KPI (KPIGroupID, Name, Sort, Hidden, Calculated)
		VALUES (1, @AdditionalInfo, @Sort, 1, 0) 	
	END

	SELECT @KPIId = KPIId 
	FROM KPI 
	WHERE Name = @AdditionalInfo

	/* Find ChangeType for KPI changed */
	SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'KPI deleted%'

	INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
	SELECT caseid, '', '', @ChangeType, @KPIId, ChangedBy, Changed 
	FROM Timeline 
	WHERE TimeLineId = @TimelineId

   FETCH NEXT FROM kpi_cursor
   INTO @TimelineId, @Text
END

CLOSE kpi_cursor
DEALLOCATE kpi_cursor


/* KPI x created */

DECLARE kpi_cursor CURSOR FOR
SELECT TimeLineId, [Text] FROM TimeLine
WHERE [Text] LIKE 'KPI %' AND [Text] LIKE '%created with value%'
ORDER BY timelineID

OPEN kpi_cursor

FETCH NEXT FROM kpi_cursor
INTO @TimelineId, @Text

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Get AdditionalInfo for KPIs */
	SET @AdditionalInfo = RIGHT(LEFT(@Text,CHARINDEX(''' created with value', @Text) - 1), CHARINDEX(''' created with value', @Text) - (CHARINDEX('KPI ''', @Text) + 5))

	/* Insert new hidden kpi if it does not exist */
	IF (SELECT COUNT(*) FROM KPI WHERE Name = @AdditionalInfo) = 0
	BEGIN
		SELECT @Sort = MAX(Sort) + 1 FROM KPI WHERE KPIGroupId = 1
	 
		INSERT INTO KPI (KPIGroupID, Name, Sort, Hidden, Calculated)
		VALUES (1, @AdditionalInfo, @Sort, 1, 0) 	
	END

	SELECT @KPIId = KPIId 
	FROM KPI 
	WHERE Name = @AdditionalInfo

	/* Get afterValue for KPIs */
	SET @AfterValue = RIGHT(@text, LEN(@text) - CHARINDEX(' created with value ', @Text) - 18)
	SET @AfterValue = RTRIM(LTRIM(LEFT(@aftervalue, CHARINDEX('(', @aftervalue)-1)))
   
	/* Find KPIRatingID for AfterValue */
	SELECT @AfterValue = KPIRatingId 
	FROM KPIRating 
	WHERE value = @afterValue AND KPIId = @KPIId 
   
	/* Set AfterValue to 0 if it is not found in KPIRating table */
	IF (ISNUMERIC(@Aftervalue) = 0)
		SET @AfterValue = 0

	/* Find ChangeType for KPI changed */
	SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'KPI created%'

	INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
	SELECT caseid, '', @aftervalue, @ChangeType, @KPIId, ChangedBy, Changed 
	FROM Timeline 
	WHERE TimeLineId = @TimelineId

   FETCH NEXT FROM kpi_cursor
   INTO @TimelineId, @Text
END

CLOSE kpi_cursor
DEALLOCATE kpi_cursor


/* Phase changed from x to y*/
DECLARE phase_cursor CURSOR FOR
SELECT TimelineId, [Text] FROM TimeLine
WHERE [Text] LIKE 'Phase changed%' 
		AND [Text] NOT LIKE '%00%' 
		AND [Text] NOT LIKE '%01%' 
		AND [Text] NOT LIKE '%02%' 
		AND [Text] NOT LIKE '%03%' 
		AND [Text] NOT LIKE '%04%' 
		AND [Text] NOT LIKE '%05%' 		
		AND [Text] NOT LIKE '%06%' 
		AND [Text] NOT LIKE '%07%' 
		AND [Text] NOT LIKE '%08%' 
		AND [Text] NOT LIKE '%09%' 
		AND [Text] NOT LIKE '%10%' 
ORDER BY timelineID

OPEN phase_cursor

FETCH NEXT FROM phase_cursor
INTO @TimelineId, @Text

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Get beforeValue for Phase */	
	SET @BeforeValue = RIGHT(@Text,LEN(@text) - 20)
	SET @BeforeValue = LEFT(@BeforeValue, CHARINDEX('"', @BeforeValue)-1)

	/* Find PhaseID for BeforeValue */
	SELECT @BeforeValue = StandardTaskId
	FROM StandardTask 
	WHERE Name LIKE @BeforeValue 
	
	IF (ISNUMERIC(@BeforeValue) = 0)
		SET @BeforeValue = ''
		
	SET @AfterValue = RIGHT(@Text,LEN(@text) - CHARINDEX(' to "', @Text)-4)
	SET @AfterValue = LEFT(@AfterValue, CHARINDEX('"', @AfterValue)-1)
		
	/* Find PhaseID for AfterValue */
	SELECT @AfterValue = StandardTaskId
	FROM StandardTask 
	WHERE Name LIKE @AfterValue 
	
	IF (ISNUMERIC(@AfterValue) = 0)
		SET @AfterValue = ''

	/* Find ChangeType for KPI changed */
	SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'Phase changed%'

	INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
	SELECT caseid, @BeforeValue, @Aftervalue, @ChangeType, @KPIId, ChangedBy, Changed 
	FROM Timeline 
	WHERE TimeLineId = @TimelineId

   FETCH NEXT FROM phase_cursor
   INTO @TimelineId, @Text
END

CLOSE phase_cursor
DEALLOCATE phase_cursor


/* Phase converted to x*/
DECLARE phase_cursor CURSOR FOR
SELECT TimeLineId, [Text] FROM TimeLine
WHERE [Text] LIKE 'Phase converted%' 
ORDER BY timelineID

OPEN phase_cursor

FETCH NEXT FROM phase_cursor
INTO @TimelineId, @Text

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Find PhaseID for AfterValue */
	SET @AfterValue = RIGHT(@Text,LEN(@text) - CHARINDEX(' to "', @Text)-4)
	SET @AfterValue = LEFT(@AfterValue, CHARINDEX('"', @AfterValue)-1)
		
	/* Find PhaseID for AfterValue */
	SELECT @AfterValue = StandardTaskId
	FROM StandardTask 
	WHERE Name LIKE @AfterValue 
	
	IF (ISNUMERIC(@AfterValue) = 0)
		SET @AfterValue = ''

	/* Find ChangeType for Phase converted */
	SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'Phase changed%'

	INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
	SELECT caseid, '', @Aftervalue, @ChangeType, @KPIId, ChangedBy, Changed 
	FROM Timeline 
	WHERE TimeLineId = @TimelineId

	FETCH NEXT FROM phase_cursor
	INTO @TimelineId, @Text
END

CLOSE phase_cursor
DEALLOCATE phase_cursor


/* Project changed from*/
DECLARE project_cursor CURSOR FOR
SELECT TimelineId, REPLACE([Text], 'Projcet', 'Project') AS [Text] FROM TimeLine
WHERE [Text] LIKE 'Projcet changed from%' OR [Text] LIKE 'Project changed from%'
ORDER BY timelineID

OPEN project_cursor

FETCH NEXT FROM project_cursor
INTO @TimelineId, @Text

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Get beforeValue for Phase */	
	SET @BeforeValue = RIGHT(@Text,LEN(@text) - 22)
	SET @BeforeValue = LEFT(@BeforeValue, CHARINDEX('"', @BeforeValue)-1)

	/* Find PhaseID for BeforeValue */
	SELECT @BeforeValue = PhaseId
	FROM Phase 
	WHERE Name LIKE @BeforeValue 
	
	IF (ISNUMERIC(@BeforeValue) = 0)
		SET @BeforeValue = ''

	/* Find PhaseID for AfterValue */
	SET @AfterValue = RIGHT(@Text,LEN(@text) - CHARINDEX(' to "', @Text)-4)
	SET @AfterValue = LEFT(@AfterValue, CHARINDEX('"', @AfterValue)-1)
		
	/* Find PhaseID for AfterValue */
	SELECT @AfterValue = PhaseId
	FROM Phase 
	WHERE Name LIKE @AfterValue 
	
	IF (ISNUMERIC(@AfterValue) = 0)
		SET @AfterValue = ''

	/* Find ChangeType for KPI changed */
	SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'Phase changed%'

	INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
	SELECT caseid, '', @Aftervalue, @ChangeType, @KPIId, ChangedBy, Changed 
	FROM Timeline 
	WHERE TimeLineId = @TimelineId

   FETCH NEXT FROM project_cursor
   INTO @TimelineId, @Text
END

CLOSE project_cursor
DEALLOCATE project_cursor


/* Status changed from */
DECLARE Status_cursor CURSOR FOR
SELECT TimeLineId, [Text] FROM TimeLine
WHERE [Text] LIKE 'Status changed from%' 
ORDER BY timelineID

OPEN status_cursor

FETCH NEXT FROM status_cursor
INTO @TimelineId, @Text

WHILE @@FETCH_STATUS = 0
BEGIN
	/* Get beforeValue for Status changed from */	
	SET @BeforeValue = RIGHT(@Text, LEN(@text) - 21)
	SET @BeforeValue = LEFT(@BeforeValue, CHARINDEX('"', @BeforeValue)-1)

	/* Find StatusID for BeforeValue */
	SELECT @BeforeValue = StatusId
	FROM Status 
	WHERE Name LIKE @beforeValue 
	
	IF (ISNUMERIC(@BeforeValue) = 0)
		SET @BeforeValue = ''

	/* Get afterValue for Status changed from */	
	SET @AfterValue = RIGHT(@Text,LEN(@text) - CHARINDEX(' to "', @Text)-4)
	SET @AfterValue = LEFT(@AfterValue, CHARINDEX('"', @AfterValue)-1)
		
	/* Find Status ID for AfterValue */
	SELECT @AfterValue = StatusId
	FROM Status 
	WHERE Name LIKE @AfterValue 
	
	IF (ISNUMERIC(@AfterValue) = 0)
		SET @AfterValue = ''

	/* Find ChangeType for Status changed from */
	SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'Status changed%'

	INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
	SELECT caseid, @BeforeValue, @AfterValue, @ChangeType, @KPIId, ChangedBy, Changed 
	FROM Timeline 
	WHERE TimeLineId = @TimelineId

   FETCH NEXT FROM status_cursor
   INTO @TimelineId, @Text
END

CLOSE status_cursor
DEALLOCATE status_cursor


/* Set to */
/*DECLARE Status_cursor CURSOR FOR
SELECT TimeLineId, [Text], CaseID FROM TimeLine
WHERE [Text] LIKE 'Set to%' 
ORDER BY CaseID, Changed 

SET @BeforeValue = ''
SET @OldCaseId = 0

OPEN status_cursor

FETCH NEXT FROM status_cursor
INTO @TimelineId, @Text, @CaseId

WHILE @@FETCH_STATUS = 0
BEGIN*/
	/* Find ChangeType for status changed */
	/*SELECT @ChangeType = ChangetypeID FROM ChangeType WHERE Name LIKE 'Status changed'

	SET @AfterValue  = RIGHT(@Text, LEN(@Text) - 7)
	
	SELECT @AfterValue = StatusID 
	FROM [Status] 
	WHERE [Name] LIKE '%' + @AfterValue + '%'
	
	IF (ISNUMERIC(@AfterValue) = 0)
		SET @AfterValue = ''
		
	IF (@CaseId = @OldCaseId)	
	BEGIN		
		INSERT INTO ChangeLog (CaseId, BeforeValue, AfterValue, ChangeTypeId, AdditionalInfo, CreatedById, Created)
		SELECT caseid, @BeforeValue, @AfterValue, @ChangeType, Null, ChangedBy, Changed 
		FROM Timeline 
		WHERE TimeLineId = @TimelineId
		
		SET @BeforeValue = @AfterValue 
	END
	ELSE
	BEGIN
		SET @BeforeValue = ''
	END
	SET @OldCaseId = @CaseId 			

	FETCH NEXT FROM status_cursor
	INTO @TimelineId, @Text, @CaseId
END

CLOSE status_cursor
DEALLOCATE status_cursor
*/