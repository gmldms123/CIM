USE Pmanagement
DECLARE @ERR AS Int

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0
--------------------------------------------------------------------------------------------------

-- AlertCategory	
	BEGIN
		UPDATE [PManagement].[dbo].[AlertCategory]
		SET [Name] = 'By Platform'
		WHERE [Name] = 'Platform'
		SET @ERR = @@ERROR
	END
--------------------------------------------------------------------------------------------------

-- ChangeType
	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Populationlist Created',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO ChangeType
		VALUES ('News Added',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO ChangeType
		VALUES ('Any Changes',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO ChangeType 
		VALUES ('CIR Added', 28524, GETDATE(), NULL, NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO ChangeType 
		VALUES ('Project changed', 28524, GETDATE(), NULL, NULL)
		SET @ERR = @@ERROR
	END

--------------------------------------------------------------------------------------------------

-- Frequency
	BEGIN
		INSERT INTO AlertFrequency
		VALUES ('Monthly','1',0,NULL,28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR

		UPDATE AlertFrequency
		SET HandleTime = 6
		WHERE Name = 'Weekly'
		SET @ERR = @@ERROR

		UPDATE AlertFrequency
		SET HandleTime = 6
		WHERE Name = 'Monthly'
		SET @ERR = @@ERROR
	END

--------------------------------------------------------------------------------------------------

-- AlertReceiverType
	BEGIN
		INSERT INTO AlertReceiverType
		VALUES ('Myself',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR

		INSERT INTO AlertReceiverType
		VALUES ('Other',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR

		INSERT INTO AlertReceiverType
		VALUES ('Roles',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

--------------------------------------------------------------------------------------------------

-- AlertServiceSettings
	BEGIN
		INSERT INTO AlertServiceSettings 
		VALUES (NULL,28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END
		
--------------------------------------------------------------------------------------------------

-- AnyChanges
	BEGIN 
		CREATE TABLE AnyChanges 
		(
			AnyChangesId BIGINT IDENTITY (1,1),
			WindowNo BIGINT,
			Description NVARCHAR(50)
		)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (1, 'Documents')
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (2, 'RelevantTurbines')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (3, 'RCO')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (4, 'AlarmLogNumbers')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (5, 'ServiceCodes')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (6, 'Discussions')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (7, 'News')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (8, 'Bundling')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (9, 'Milestones')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (10, 'Participants')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (11, 'SupplierRelations')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (12, 'CaseImplementedInMKVersion')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (13, 'KeyPriorityIndicators')
		SET @ERR = @@ERROR
	END
	
	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (14, 'Alert')
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO AnyChanges (WindowNo, Description)
		VALUES (15, 'CaseFacts')
		SET @ERR = @@ERROR
	END
-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim