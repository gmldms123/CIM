ALTER TABLE dbo.AlertReceiver ALTER COLUMN VPPersonId NVARCHAR(50)

EXEC SP_RENAME 'AlertReceiver.VPPersonId', 'Value', 'COLUMN'

--Adds default value to be "Myself" as all values in PROD now only can be "Myself"
ALTER TABLE dbo.AlertReceiver
ADD AlertReceiverTypeId BIGINT NOT NULL DEFAULT(1)  

ALTER TABLE [dbo].[AlertReceiver] ADD
CONSTRAINT [FK_AlertReceiver_AlertReceiverType] FOREIGN KEY ([AlertReceiverTypeId]) REFERENCES [dbo].[AlertReceiverType] ([AlertReceiverTypeId])

--GO