ALTER PROCEDURE [dbo].[GetDocumentsForCase]
	@CaseId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT 
		f.FolderId, f.FolderTypeId, f.parentfolderId, d.DocumentClassificationId,
		d.DocumentId, d.Title, d.FileName, d.FileSize, d.LinkNo, d.Created, d.FileDate, d.Deleted, 
		ds.Name AS StatusName, 
		p.VestasInitials AS CreatedBy 
	FROM Document d WITH(NOLOCK) 
		JOIN Folder2Document f2d WITH(NOLOCK) ON f2d.DocumentId = d.DocumentId 
		JOIN Folder f WITH(NOLOCK) ON f.FolderId = f2d.FolderId 
		JOIN [Case] c WITH(NOLOCK) ON c.CaseId = f.CaseId 
		JOIN DocumentStatus ds WITH(NOLOCK) ON ds.DocumentStatusId = f2d.DocumentStatusId 
		LEFT OUTER JOIN Participant p WITH(NOLOCK) ON d.CreatedById = p.ParticipantId 
	WHERE c.CaseId = @CaseId
	AND NOT (
		d.Created IS NULL AND d.Deleted = 1
	)	
END
