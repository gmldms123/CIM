CREATE TABLE dbo.PerformanceAction
	(
	[PerformanceActionId] BIGINT NOT NULL IDENTITY (1, 1),
	[Name] nvarchar(50) NOT NULL,
	[Description] nvarchar(256) NOT NULL,
	[Enabled] bit NOT NULL,
	[CreatedDateTime] datetime NOT NULL,
	[CreatedInitials] nvarchar(50) NOT NULL,
	[DeletedDateTime] datetime NULL,
	[DeletedInitials] nvarchar(50) NULL

	CONSTRAINT pk_performanceAction_aid PRIMARY KEY(PerformanceActionId)

	)  ON [PRIMARY]

--GO

CREATE TABLE dbo.PerformanceData
	(
	[PerformanceDataId] BIGINT NOT NULL IDENTITY (1, 1),
	[PerformanceActionId] BIGINT NOT NULL,
	[Duration] BIGINT NOT NULL,
	[ComputerName] nvarchar(50) NULL,
	[IpAdress] nvarchar(50) NULL,
	[ConnectionType] nvarchar(50) NULL,
	[ProcessId] BIGINT NULL,
	[MemoryUsage] BIGINT NULL,
	[AvailableMemory] BIGINT NULL,
	[TotalMemory] BIGINT NULL,
	[CaseId] BIGINT NULL,
	[RunningProcesses] nvarchar(4000) NOT NULL,
	[AdditionalInfo] nvarchar(4000) NULL,
	[CreatedDateTime] datetime NOT NULL,
	[CreatedInitials] nvarchar(50) NULL
	
	CONSTRAINT pk_performanceData_pid PRIMARY KEY(PerformanceDataId)

	)  ON [PRIMARY]

--GO

ALTER TABLE [PManagement].[dbo].[PerformanceData]
ADD CONSTRAINT FK_PerformanceData FOREIGN KEY (PerformanceActionId)
REFERENCES [PManagement].[dbo].[PerformanceAction]

--GO

CREATE TABLE dbo.PerformanceUtilitySetting
	(
	[PerformanceUtilitySettingId] int NOT NULL IDENTITY (1, 1),
	[Name] nvarchar(256) NOT NULL,
	[Value] nvarchar(4000) NOT NULL,
	[CreatedDateTime] datetime NOT NULL,
	[CreatedInitials] nvarchar(50) NOT NULL,
	[DeletedDateTime] datetime NULL,
	[DeletedInitials] nvarchar(50) NULL

	CONSTRAINT pk_performanceUtilitySetting_pusid PRIMARY KEY(PerformanceUtilitySettingId)

	)  ON [PRIMARY]

--GO

CREATE TABLE [dbo].[AlertReceiverRoleType]
	(
	[AlertReceiverRoleTypeId] [bigint] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[CreatedById] [bigint] NOT NULL,
	[Created] [datetime] NOT NULL,
	[DeletedById] [bigint] NULL,
	[Deleted] [datetime] NULL,
 
	CONSTRAINT [PK_AlertReceiverRoleType] PRIMARY KEY CLUSTERED([AlertReceiverRoleTypeId] ASC) 
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]) ON [PRIMARY]

--GO