ALTER TABLE dbo.AlertReceiver ADD IsGroup bit NOT NULL
ALTER TABLE dbo.[AlertReceiver] ADD  CONSTRAINT [DF_AlertReceiver_IsGroup]  DEFAULT ((0)) FOR [IsGroup]
ALTER TABLE dbo.PerformanceData ALTER COLUMN RunningProcesses text NOT NULL
ALTER TABLE dbo.PerformanceAction ALTER COLUMN Description nvarchar(500) NOT NULL