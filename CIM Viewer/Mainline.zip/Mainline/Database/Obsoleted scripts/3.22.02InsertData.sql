USE Pmanagement
DECLARE @ERR AS Int

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0
--------------------------------------------------------------------------------------------------

-- AlertCategory

	BEGIN
		UPDATE AlertCategory
		SET Name = 'By Platform' 
		WHERE Name = 'Platform'
		SET @ERR = @@ERROR
	END

--------------------------------------------------------------------------------------------------

-- AlertReceiverRoleType	
	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Project Manager',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Execution Manager',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Platform Manager',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Case Creator',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN	
		INSERT INTO AlertReceiverRoleType
		VALUES ('Technical Specialist',28524,GETDATE(),NULL,NULL)
		SET @ERR = @@ERROR
	END

--------------------------------------------------------------------------------------------------

--PerformanceUtilitySetting

	BEGIN
		INSERT INTO PerformanceUtilitySetting
		VALUES ('Enabled','True',GETUTCDATE(),'TTHOL',NULL,NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceUtilitySetting
		VALUES ('Users','PTL;TTHOL;MORNI;MIFTH',GETUTCDATE(),'TTHOL',NULL,NULL)
		SET @ERR = @@ERROR
	END

--------------------------------------------------------------------------------------------------

-- PerformanceAction
	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Unit test',
		'Test',
		0,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Download CIM Editor',
		'The time it takes to download 20 MB. (20 MB is approximately the size of CIM Editor Click Once installation).',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'CIM Editor startup',
		'The time from where the CIM Editor starts executing to the time where it is ready for user interaction. Downloading/installing CIM Editor is not part of this action.',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Open a case in CIM Editor',
		'The time it takes to open a CIM case using the "Enter Case Number" field in the upper left corner in the main window of CIM Editor.',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Save documents',
		'The time it takes to save documents (Save in Document window). The PerfomanceData.AdditionalInfo field will for this action contain data about filenames and file sizes of the saved documents. E.g. "CIM Project Plan.mpp (190KB)".',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Advanced Search in CIM Viewer',
		'The time it takes to open a CIM Viewer. The PerformanceData.AdditionalInfo field will for this action contain data about what filter was used and how many cases was found. E.g. "Search fileter: Phase = RCA and Turbine Type = M100; Search result = 19".',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Reactivate case in CIM Editor',
		'The time it takes to reopen a closed case (Reactivate in Case Facts window)',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Save case in CIM Editor',
		'The time it takes to save a case (Save in Case Facts window)',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Open document for editing',
		'The time it takes for open a document (Edit in Document window). The time to start 3rd party programs (e.g MS Office Project Professional) is not part of this action. The PerformanceData.AdditionalInfo field will for this action contain data about filenames and file sizes of the document. E.g. "CIM Project Plan.mpp (190 KB)"',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END

	BEGIN
		INSERT INTO PerformanceAction
		VALUES (
		'Save bundling',
		'The time it takes to save a bundle (Save on Bundling window). The PerformanceData.AdditionalInfo field will for this action contain data about which cases the bundle consist of. E.g. "2001;2004;2002"',
		1,
		GETUTCDATE(),
		'TTHOL',
		NULL,
		NULL)
		SET @ERR = @@ERROR
	END



-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim