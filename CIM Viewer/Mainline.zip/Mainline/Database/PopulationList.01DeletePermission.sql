USE PManagement
DECLARE @ERR AS Int

BEGIN TRAN cim
	SET @ERR = 0	
	IF @ERR = 0

-- Delete permission from roles	
	BEGIN	
		DELETE FROM Role2Permission 
		WHERE PermissionId = (SELECT PermissionId 
							  FROM Permission 
							  WHERE Name = 'Editor_Documents_EditPopulationList')
		SET @ERR = @@ERROR
	END
-- Delete permission
	BEGIN	
		DELETE FROM Permission 
		WHERE Name = 'Editor_Documents_EditPopulationList'
	END
	
-- Commit if no errors found otherwise rollback.
IF @ERR = 0 
	COMMIT TRAN cim
ELSE
	ROLLBACK TRAN cim