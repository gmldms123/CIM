Use PManagement 

-- Mark all Superseeded Folder to be deleted
update Folder SET deleted = 1 
WHERE FolderTypeId = 6 AND Name = 'Superseeded'

-- Mark all Approved Folder to be deleted
update Folder SET deleted = 1 
WHERE FolderTypeId = 6 AND Name = 'Approved'

-- Rename Populationlist folder to Population List accessible through SAP
UPDATE Folder 
SET Name = 'Population List accessible through SAP' 
WHERE FolderTypeId = 6