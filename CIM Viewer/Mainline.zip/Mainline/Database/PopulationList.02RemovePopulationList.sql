use PManagement
-- Remove documentbinary data related to populationlist
DELETE FROM DocumentBinary 
FROM folder f 
	JOIN folder2document f2d ON f.folderId = f2d.folderid 
	JOIN Document d ON f2d.DocumentId = d.DocumentId 
	JOIN DocumentBinary db ON d.DocumentBinaryId = db.DocumentBinaryId 
WHERE FileName like 'populationlist%' AND FolderTypeId = 6

-- Remove Document data related to populationlist
DELETE FROM Document
FROM folder f 
	JOIN folder2document f2d ON f.folderId = f2d.folderid 
	JOIN Document d ON f2d.DocumentId = d.DocumentId 
WHERE FileName like 'populationlist%' AND FolderTypeId = 6

-- Remove superseeded folders 
DELETE FROM Folder 
WHERE FolderTypeId = 6 AND Name = 'Superseeded'

-- Remove approved folders
DELETE FROM Folder 
WHERE FolderTypeId = 6 AND Name = 'Approved'

-- Remove ItemStatus Constraints
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ItemStatus_Payee]') AND parent_object_id = OBJECT_ID(N'[dbo].[ItemStatus]'))
ALTER TABLE [dbo].[ItemStatus] DROP CONSTRAINT [FK_ItemStatus_Payee]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ItemStatus_PopulationlistItem]') AND parent_object_id = OBJECT_ID(N'[dbo].[ItemStatus]'))
ALTER TABLE [dbo].[ItemStatus] DROP CONSTRAINT [FK_ItemStatus_PopulationlistItem]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ItemStatus_Servicetype]') AND parent_object_id = OBJECT_ID(N'[dbo].[ItemStatus]'))
ALTER TABLE [dbo].[ItemStatus] DROP CONSTRAINT [FK_ItemStatus_Servicetype]
GO

-- Drop ServiceType table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ServiceType]') AND type in (N'U'))
DROP TABLE [dbo].[ServiceType]
GO

-- Drop Payee table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Payee]') AND type in (N'U'))
DROP TABLE [dbo].[Payee]
GO

-- Drop ItemStatus table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ItemStatus]') AND type in (N'U'))
DROP TABLE [dbo].[ItemStatus]
GO

-- Remove PopulationlistDocument Constraints
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PopulationlistDocument_DocumentClassification]') AND parent_object_id = OBJECT_ID(N'[dbo].[PopulationlistDocument]'))
ALTER TABLE [dbo].[PopulationlistDocument] DROP CONSTRAINT [FK_PopulationlistDocument_DocumentClassification]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PopulationlistDocument_Participant]') AND parent_object_id = OBJECT_ID(N'[dbo].[PopulationlistDocument]'))
ALTER TABLE [dbo].[PopulationlistDocument] DROP CONSTRAINT [FK_PopulationlistDocument_Participant]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PopulationlistDocument_Populationlist]') AND parent_object_id = OBJECT_ID(N'[dbo].[PopulationlistDocument]'))
ALTER TABLE [dbo].[PopulationlistDocument] DROP CONSTRAINT [FK_PopulationlistDocument_Populationlist]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_PopulationlistDocument_FileName]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PopulationlistDocument] DROP CONSTRAINT [DF_PopulationlistDocument_FileName]
END

-- Drop PopulationlistDocument table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PopulationlistDocument]') AND type in (N'U'))
DROP TABLE [dbo].[PopulationlistDocument]
GO

-- Remove Populationlist Constraints
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Populationlist_Case]') AND parent_object_id = OBJECT_ID(N'[dbo].[Populationlist]'))
ALTER TABLE [dbo].[Populationlist] DROP CONSTRAINT [FK_Populationlist_Case]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Populationlist_Participant]') AND parent_object_id = OBJECT_ID(N'[dbo].[Populationlist]'))
ALTER TABLE [dbo].[Populationlist] DROP CONSTRAINT [FK_Populationlist_Participant]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Populationlist_Phase]') AND parent_object_id = OBJECT_ID(N'[dbo].[Populationlist]'))
ALTER TABLE [dbo].[Populationlist] DROP CONSTRAINT [FK_Populationlist_Phase]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Populationlist_State]') AND parent_object_id = OBJECT_ID(N'[dbo].[Populationlist]'))
ALTER TABLE [dbo].[Populationlist] DROP CONSTRAINT [FK_Populationlist_State]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Populationlist_Status]') AND parent_object_id = OBJECT_ID(N'[dbo].[Populationlist]'))
ALTER TABLE [dbo].[Populationlist] DROP CONSTRAINT [FK_Populationlist_Status]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Populationlist_Version]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Populationlist] DROP CONSTRAINT [DF_Populationlist_Version]
END

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Populationlist_Created]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Populationlist] DROP CONSTRAINT [DF_Populationlist_Created]
END

-- Remove PopulationListItem Constraints
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PopulationlistItem_Populationlist]') AND parent_object_id = OBJECT_ID(N'[dbo].[PopulationlistItem]'))
ALTER TABLE [dbo].[PopulationlistItem] DROP CONSTRAINT [FK_PopulationlistItem_Populationlist]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_PopulationlistItem_ItemWTG]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PopulationlistItem] DROP CONSTRAINT [DF_PopulationlistItem_ItemWTG]
END

-- Remove CustomColumnsName Constraints
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CustomColumnsName_Populationlist]') AND parent_object_id = OBJECT_ID(N'[dbo].[CustomColumnsName]'))
ALTER TABLE [dbo].[CustomColumnsName] DROP CONSTRAINT [FK_CustomColumnsName_Populationlist]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_CustomColumnsName_Order]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CustomColumnsName] DROP CONSTRAINT [DF_CustomColumnsName_Order]
END

-- Remove CustomColumnsValue Constraints
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CustomColumnsValue_CustomColumnsName]') AND parent_object_id = OBJECT_ID(N'[dbo].[CustomColumnsValue]'))
ALTER TABLE [dbo].[CustomColumnsValue] DROP CONSTRAINT [FK_CustomColumnsValue_CustomColumnsName]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CustomColumnsValue_PopulationlistItem]') AND parent_object_id = OBJECT_ID(N'[dbo].[CustomColumnsValue]'))
ALTER TABLE [dbo].[CustomColumnsValue] DROP CONSTRAINT [FK_CustomColumnsValue_PopulationlistItem]
GO

-- Drop CustomColumnsValue table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomColumnsValue]') AND type in (N'U'))
DROP TABLE [dbo].[CustomColumnsValue]
GO

-- Drop CustomColumnsName table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomColumnsName]') AND type in (N'U'))
DROP TABLE [dbo].[CustomColumnsName]
GO

-- Drop PopulationList table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Populationlist]') AND type in (N'U'))
DROP TABLE [dbo].[Populationlist]
GO

-- Drop PopulationListItem table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PopulationlistItem]') AND type in (N'U'))
DROP TABLE [dbo].[PopulationlistItem]
GO

-- Drop State table
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[State]') AND type in (N'U'))
DROP TABLE [dbo].[State]
GO

-- Rename Populationlist folder to Population List accessible through SAP
UPDATE Folder 
SET Name = 'Population List accessible through SAP' 
WHERE FolderTypeId = 6