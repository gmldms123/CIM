Imports System.Net.Mail

Module Module1
  Private _Environment As Business.Environment = New Business.Environment()
  Private _Controller As Business.News.ServiceController = New Business.News.ServiceController(_Environment)

  Sub Main()
    'Setup environment
    _Environment.IsNetworkDeployed = My.Application.IsNetworkDeployed
    _Environment.SetupEnvironment(Business.Environment.Platforms.Windows)

    'Load the participants on news who should be alerted
    Dim alertOnThisNews As List(Of Business.News.News) = _Controller.AlertOnNews()

    'Send the alerts
    If Not alertOnThisNews Is Nothing Then
      For Each alertNews As Business.News.News In alertOnThisNews
        Dim recipients As String = String.Empty
        If Not alertNews.AlertParticipants Is Nothing AndAlso alertNews.AlertParticipants.Count > 0 Then
          For Each alertParticpant As Business.Participant.Participant In alertNews.AlertParticipants
            recipients = recipients + alertParticpant.EMail + ";"
          Next
          SendMail(alertNews, recipients)
        End If
      Next
    End If

    System.Console.WriteLine("Finished.")
    System.Console.ReadKey()
  End Sub

  ''' <summary>
  ''' Sends the mail.
  ''' </summary>
  ''' <param name="alertNews">The alert news.</param>
  ''' <param name="recipientEMail">The recipient E mail.</param>
  Public Sub SendMail(ByRef alertNews As Business.News.News, ByVal recipientEMail As String)
    Try
      Using mm As New MailMessage()

        ' Recipients
        Dim Recipients As String() = recipientEMail.Split(CChar(";"))
        mm.From = New Net.Mail.MailAddress(String.Format("{0}@vestas.com", "projportnews"))
        For Each Recp As String In Recipients
          Try
            If Recp.Trim <> "" Then mm.To.Add(Recp)
          Catch ex As Exception
          End Try
        Next

        ' Body
        mm.Body = "Description: " + alertNews.Description + vbCrLf + "Link to case viewer: " + _Environment.ProjectPortal_URL + alertNews.CaseId.ToString()
        mm.IsBodyHtml = False

        ' Subject
        mm.Subject = "News: " + alertNews.Name + ". Created: " + alertNews.Created + " on CaseNo: " + _Controller.CaseNo(alertNews.CaseId).ToString()

        Dim smtp As New Net.Mail.SmtpClient

        ' UseDefaultCredentials tells the mail client to use the 
        ' Windows credentials of the account (i.e. user account) 
        ' being used to run the application
        smtp.UseDefaultCredentials = True
        smtp.Host = "smtp.vestas.net"

        'Don't actually send
        'smtp.Send(mm)
      End Using
    Catch ex As Exception

    Finally
      'Update
      _Controller.ParticipantsIsAlertedOnNews(alertNews.Id)
    End Try
  End Sub

End Module
