Imports System.Web.Configuration
Imports PManagement.Framework
Imports PManagement.Framework.Interfaces

''' <summary>
''' Cached version of Access Control
''' </summary>
''' <remarks></remarks>
	Public NotInheritable Class AccessControl
	Implements IAccessControl
	Private ReadOnly _accessControlWithoutCache As AccessControlWithoutCache
	Private _environment As Environment
	Private _Context As PmanContext = Nothing

    Private ReadOnly _cacheOfOperationIsLegal As New Hashtable()

	Private _caseId As Long? = - 1

	Public Sub New()
		_accessControlWithoutCache = New AccessControlWithoutCache()
	End Sub

	Public ReadOnly Property Initialized() As Boolean
		Get
			Return _accessControlWithoutCache.Initialized
		End Get
	End Property

	Public Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
	                      ByRef syncobject As ISynchronizeInvoke, ByRef userWindowsIdentity As WindowsIdentity)
		PmanTrace.WriteInfo("AccessControl", "Initialize (with windows identity)")
		_environment = environment
		_Context = context
		_accessControlWithoutCache.Initialize(environment, context, syncobject, userWindowsIdentity)
	End Sub

	Public ReadOnly Property Roles() As String()
		Get
			Return _accessControlWithoutCache.Roles
		End Get
	End Property

	Public Function OperationIsLegal(ByVal operation As Permissions) As Boolean Implements IAccessControl.OperationIsLegal
		' this ensures that permissions are reloaded for each case. if this is removed, make sure to change the way 
		' permissions are loaded in AccessControlWithoutCache, otherwise there is no benefit from removing this
		' (currently permissions are loaded in AccessControlWithoutCache on context change if the case has changed)
		If (_caseId.Equals(_Context.CaseId) = False) Then
			_cacheOfOperationIsLegal.Clear()
			_caseId = _Context.CaseId
		End If

        '' Removing JV condition from here bcoz it was working while validating the documents also hence taking lot of time
        ''Joint Venture user should not have access
        'Dim adr As New ActiveDirectoryRequestor()
        'Dim jvADGroup As String = WebConfigurationManager.AppSettings("JVADGroup")
        'Dim result As Boolean = adr.Validate("Vestas", jvADGroup, _Context.User.ToLower().Replace("vestas\", String.Empty))
        'If result = True Then ' USer part of JV AD group
        '    Return False
        'End If

		Dim caseId As Long = Nothing
		If _Context.CaseId.HasValue Then caseId = _Context.CaseId.Value

		' Check if response is cached - and get response + cache it if not currently in cache
		Dim cacheKey As String = GetCacheKey(operation, _environment, caseId)
		If (IsKeyCached(cacheKey)) Then
			PmanTrace.WriteVerbose("AccessControl - cached", "OperationIsLegal", "Cache hit for " + operation.ToString)
		Else
			PmanTrace.WriteVerbose("AccessControl - cached", "OperationIsLegal", "Cache NOT hit for " + operation.ToString)

			' This is know to cause problems in obscure racing conditions - exception is most likely to occur here.
			AddCacheKey(operation, cacheKey)
		End If

		' If we get this far, return value (and thus exit
		Return CType(_cacheOfOperationIsLegal(cacheKey), Boolean)
	End Function

	Public Sub AddCacheKey(ByVal operation As Permissions, ByVal cacheKey As String)
		Dim res As Boolean = _accessControlWithoutCache.OperationIsLegal(operation)
		_cacheOfOperationIsLegal.Add(cacheKey, res)
	End Sub

	Public Function IsKeyCached(ByVal cacheKey As String) As Boolean
		Return _cacheOfOperationIsLegal.ContainsKey(cacheKey)
	End Function

	Private Function GetCacheKey(ByVal Operation As Permissions, ByVal environment As Environment, ByVal caseId As Long) _
		As String
		Dim res As New StringBuilder()
		res.Append(_Context.User)
		res.Append("_")
		res.Append(Operation.ToString())
		res.Append("_")
		res.Append(environment.Environment.ToString())
		res.Append("_")
		res.Append(caseId)

		Return res.ToString()
	End Function
End Class
