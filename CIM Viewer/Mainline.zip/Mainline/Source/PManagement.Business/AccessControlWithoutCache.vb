Imports PManagement.Framework
Imports PManagement.ModelLayer.RolesAndPermissions
Imports PManagement.ServiceLayer.Services.Interfaces.RolesAndPermissions
Imports StructureMap

''' <summary>
''' Manage access control to the application
''' </summary>
''' <remarks></remarks>
	Public NotInheritable Class AccessControlWithoutCache
	Private _Initialized As Boolean = False
	Private _Environment As Environment = Nothing
	Private _Context As PmanContext = Nothing

	Private _UserWindowsIdentity As WindowsIdentity = Nothing

	Private _CaseId As Nullable(Of Long) = - 1
	Private _SyncObject As ISynchronizeInvoke = Nothing

	Private _Permissions As New SortedList(Of Permissions, Boolean)
	Private ReadOnly _UserRoles As New RoleList()

	Private Delegate Function OperationIsLegalDelegate(ByVal Operation As Permissions) As Boolean

	Private Delegate Function OperationsAreLegalDelegate() As SortedList(Of Permissions, Boolean)

	''' <summary>
	''' Is instance initialized using Sub Initialize
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property Initialized() As Boolean
		Get
			Return _Initialized
		End Get
	End Property

	''' <summary>
	''' Finalize
	''' </summary>
	''' <remarks></remarks>
	Protected Overrides Sub Finalize()
		If Initialized Then
			RemoveHandler _Environment.EnvironmentChanged, AddressOf EnvironmentChanged
			RemoveHandler _Context.ContextChanged, AddressOf ContextChanged
			_Environment = Nothing
			_Context = Nothing
		End If

		MyBase.Finalize()
	End Sub

	''' <summary>
	''' Initialize
	''' </summary>
	''' <param name="environment"></param>
	''' <param name="context"></param>
	''' <param name="syncobject"></param>
	''' <param name="userWindowsIdentity"></param>
	''' <remarks></remarks>
	Public Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
	                      ByRef syncobject As ISynchronizeInvoke, ByRef userWindowsIdentity As WindowsIdentity)
		PmanTrace.WriteInfo("AccessControl", "Initialize (with windows identity)")

		_UserWindowsIdentity = userWindowsIdentity

		_Environment = environment
		_Context = context
		_SyncObject = syncobject
		AddHandler _Environment.EnvironmentChanged, AddressOf EnvironmentChanged
		AddHandler _Context.ContextChanged, AddressOf ContextChanged

		For Each operation As String In [Enum].GetNames(GetType(Permissions))
			_Permissions.Add(DirectCast([Enum].Parse(GetType(Permissions), operation), Permissions), False)
		Next
		_Initialized = True
		EnvironmentChanged()
		ContextChanged()
	End Sub

	''' <summary>
	''' 
	''' </summary>
	''' <remarks></remarks>
	Private Sub EnvironmentChanged()
		If _Environment.Environment = Environment.Environments.UnitTest Then
			Return
		End If
		PmanTrace.WriteInfo("AccessControl", "EnvironmentChanged")
	End Sub

	''' <summary>
	''' Get current user context
	''' </summary>
	''' <remarks></remarks>
	Private Sub ContextChanged()
		PmanTrace.WriteInfo("AccessControl", "ContextChanged")

		If _Initialized Then
			'Refresh Permissions
			If _Permissions.Keys.Count > 0 Then OperationsAreLegal()
		Else
			Throw New ApplicationException("Access Control class not initialized")
		End If
	End Sub

	''' <summary>
	''' Roles
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property Roles() As String()
		Get
			If (_UserRoles.Count = 0) Then
				' get all user roles from service layer
				Dim rolesService As IRoleService = ObjectFactory.GetInstance (Of IRoleService)()
				_UserRoles.AddRange(
					rolesService.GetUserRoles(
						UserInitials,
						_Context.IsCaseManager.HasValue AndAlso _Context.IsCaseManager.Value,
						_Context.IsTechnicalSpecialist.HasValue AndAlso _Context.IsTechnicalSpecialist.Value,
						_Context.IsExecutionManager.HasValue AndAlso _Context.IsExecutionManager.Value,
						_Context.IsCaseCreator.HasValue AndAlso _Context.IsCaseCreator.Value,
						_Context.IsPlatformManager.HasValue AndAlso _Context.IsPlatformManager.Value,
						_Context.IsProjectParticipant.HasValue AndAlso _Context.IsProjectParticipant.Value
						)
					)
			End If

			Return (From r In _UserRoles Select r.Name).ToArray()
		End Get
	End Property

	''' <summary>
	''' Check if the current user can access a given operation
	''' </summary>
	''' <param name="Operation"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Function OperationIsLegal(ByVal Operation As Permissions) As Boolean
		'    If (System.Environment.UserName.ToLower() = "anjul") Then
		'      Return True
		'    End If
		If _SyncObject IsNot Nothing AndAlso _SyncObject.InvokeRequired Then
			PmanTrace.WriteInfo("AccessControl", "OperationIsLegal1")
			Return _
				DirectCast(_SyncObject.Invoke(New OperationIsLegalDelegate(AddressOf OperationIsLegal), New Object() {Operation}),
				           Boolean)
		Else
			PmanTrace.WriteInfo("AccessControl", "OperationIsLegal2")

			If _Initialized Then
				Dim retVal As Boolean
				If _Permissions.ContainsKey(Operation) Then retVal = _Permissions(Operation)
				Dim message As String = String.Format("Operation ""{0}"" has evaluated to {1}", Operation, retVal)
				PmanTrace.WriteVerbose("AccessControl", "OperationIsLegal", message)
				Return retVal
			Else
				Throw New ApplicationException("Access Control class not initialized")
			End If
		End If
	End Function

	''' <summary>
	''' Check if the current user can access given operations
	''' </summary>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Function OperationsAreLegal() As SortedList(Of Permissions, Boolean)
		If _SyncObject IsNot Nothing AndAlso _SyncObject.InvokeRequired Then
			Return _
				DirectCast(_SyncObject.Invoke(New OperationsAreLegalDelegate(AddressOf OperationsAreLegal), New Object() {}),
				           SortedList(Of Permissions, Boolean))
		Else
			PmanTrace.WriteInfo("AccessControl", "OperationsAreLegal")

			If _Initialized Then
				' reload all permissions if the case has changed (to ensure that all dynamic roles are loaded correctly)
				If _Permissions.Count > 0 AndAlso (_CaseId.Equals(_Context.CaseId) = False) AndAlso UserInitials.Length > 0 Then _
' AndAlso (_LastAccessWasCaseManager.Equals(_Context.IsCaseManager) = False Or _LastAccessWasExectionManager.Equals(_Context.IsExecutionManager) = False) Then
					_Permissions = ReloadAllPermissions()
					' store state for next time
					_CaseId = _Context.CaseId

					'PmanTrace.WriteVerbose("AccessControl", "OperationsAreLegal", sb.ToString())
				End If
				Return _Permissions
			Else
				Throw New ApplicationException("Access Control class not initialized")
			End If
		End If
	End Function

	Public Function ReloadAllPermissions() As SortedList(Of Permissions, Boolean)

		' Reset roles cache (lazy load in the Roles property)
		_UserRoles.Clear()

		' Reset all permissions
		For Each p As Permissions In [Enum].GetValues(GetType(Permissions))
			If (_Permissions.ContainsKey(p)) Then
				_Permissions(p) = False
			End If
		Next

		' Reload all permissions
		Dim userPermissions As PermissionList = Nothing
		Try
			Dim permissionService As IPermissionService = ObjectFactory.GetInstance (Of IPermissionService)()
			userPermissions = permissionService.GetUserPermission(
				UserInitials,
				_Context.IsCaseManager.HasValue AndAlso _Context.IsCaseManager.Value,
				_Context.IsTechnicalSpecialist.HasValue AndAlso _Context.IsTechnicalSpecialist.Value,
				_Context.IsExecutionManager.HasValue AndAlso _Context.IsExecutionManager.Value,
				_Context.IsCaseCreator.HasValue AndAlso _Context.IsCaseCreator.Value,
				_Context.IsPlatformManager.HasValue AndAlso _Context.IsPlatformManager.Value,
				_Context.IsProjectParticipant.HasValue AndAlso _Context.IsProjectParticipant.Value
				)


		Catch ex As StructureMapException
			' We get this exception when system is being initialize. And we just ignore that. The method wil be called very soon again and this time no exception will be raised.
		End Try

		Dim sb As New StringBuilder()

		' Map all allowed permissions to the allPermissions collection
		If userPermissions IsNot Nothing Then
			For Each permission As Permission In userPermissions
				If (_Permissions.ContainsKey(permission.PermissionEnum)) Then
					sb.AppendFormat("{0}{1}Operation ""{2}"" has evaluated to True", System.Environment.NewLine, Space(20),
					                permission.PermissionEnum)
					_Permissions(permission.PermissionEnum) = True
				End If
			Next
		End If
		Return _Permissions
	End Function

	Private ReadOnly Property UserInitials As String
		Get
			If _Context.UserParticipant IsNot Nothing Then
                Dim initials As String = String.Empty
                Try
                    initials = _Context.UserParticipant.VestasInitials
                Catch ex As Exception
                    Throw New Exception("Exception while gettings initials + Exception:" + ex.InnerException.ToString())
                End Try
                
                Return initials
            ElseIf _UserWindowsIdentity IsNot Nothing Then
                Return _UserWindowsIdentity.Name.ToLowerInvariant.Replace("vestas\", "")
			End If
			Return String.Empty
		End Get
	End Property
End Class
