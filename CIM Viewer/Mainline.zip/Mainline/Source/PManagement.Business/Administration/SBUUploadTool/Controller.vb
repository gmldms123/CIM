Imports Aspose.Cells
Imports PManagement.ModelLayer

Namespace Administration.SBUUploadTool
  Public Class Controller
    Protected _Environment As Environment
    Protected _accessControl As AccessControl
    Protected _eI As ExcelImport
    Protected _context As PmanContext
    Protected _eV As ExcelValidator
    Protected _ds As StatusReportDS
    Protected _eE As ExcelExport
    Protected _SBUList As List(Of SBU)

#Region "Methods"

    Public Sub New(ByVal environment As Environment, ByVal context As PmanContext, ByVal accessControl As AccessControl)
      _Environment = environment
      _context = context
      _accessControl = accessControl
      _eI = New ExcelImport()
      _eE = New ExcelExport(_Environment, _context, _accessControl)
      _SBUList = GetSBUList()

      ' Activate Aspose.Cells license for MS Excel integration
            ' Dim AsposeTasksLicense As New License()
            'AsposeTasksLicense.SetLicense(New MemoryStream(My.Resources.Aspose_Cells))

    End Sub

    Public Function Validate(ByVal fileName As String, ByVal template As ExcelValidator.Template, ByVal pw As iprogressindicator) As StringBuilder
      _eV = New ExcelValidator(_Environment, _context, _accessControl, pw)
      Return _eV.Validate(fileName)
    End Function

    Public Function GetErrors() As Integer
      Return _eV.GetErrors()
    End Function

    Public Function GetNotifications() As Integer
      Return _eV.GetNotifications()
    End Function

    Public Function GetPlannedUpgradeDateNotifications() As Integer
      Return _eV.GetPlannedUpgradeDateNotifications()
    End Function

    Public Function SaveExcelFile(ByVal fileName As String, ByVal template As ExcelExport.Templates) As String
      Return _eE.SaveExcelFile(fileName, template)
    End Function

    Public Sub Save()
      For Each r As StatusReportDS.StatusReportRow In _eV.GetValidatedDS.StatusReport.Rows
        SaveToDB(r.UnitID, CType(r.SAPTaskId, Long), r.CaseNo, r.PlannedUpgradeDate, r.ActualUpgradeDate)
      Next
    End Sub

    Public Function GetSBUList() As List(Of SBU)
      Dim list As New List(Of SBU)()

      Dim daa As DataAccessAdapter = New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
      Dim ec As New EntityCollection(Of SbucloneEntity)()

      Try
        daa.FetchEntityCollection(ec, Nothing)

        For Each sbuclone As SbucloneEntity In ec
          list.Add(New SBU(sbuclone.Sbuid, sbuclone.ShortName))
        Next
      Catch ex As Exception
      Finally
        daa.CloseConnection()
      End Try

      Return list
    End Function

    Public ReadOnly Property SBUList() As List(Of SBU)
      Get
        Return _SBUList
      End Get
    End Property

    Public Function GetSBUShortNameById(ByVal SBUId As Integer) As String
      Dim sbu As SBU = _SBUList.SingleOrDefault(Function(e) e.SbuID = SBUId)
      Return sbu.SbuShortName
    End Function

    Public Function GetApprovedItemStatusBySAPTaskIdAndCaseNo(ByVal daa As DataAccessAdapter, ByVal unitId As Long, ByVal SAPTaskId As Long, ByVal caseNo As Long) As ItemStatusEntity
      Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()

      fb.PredicateExpression.AddWithOr( _
                                        PopulationlistItemFields.UnitId = unitId And _
                                        ItemStatusFields.SaptaskId = SAPTaskId And _
                                        CaseFields.CaseNo = caseNo And _
                                        PopulationlistFields.StateId = 1)

      Dim ec As New EntityCollection(Of ItemStatusEntity)()
      fb.Relations.Add(ItemStatusEntity.Relations.PopulationlistItemEntityUsingPopulationListItemId)
      fb.Relations.Add(PopulationlistItemEntity.Relations.PopulationlistEntityUsingPopulationlistId)
      fb.Relations.Add(PopulationlistEntity.Relations.CaseEntityUsingCaseId)
      Dim pp As New PrefetchPath2(CInt(EntityType.ItemStatusEntity))
      pp.Add(ItemStatusEntity.PrefetchPathPopulationlistItem).SubPath.Add( _
                                                                            PopulationlistItemEntity. _
                                                                             PrefetchPathPopulationlist).SubPath.Add( _
                                                                                                                      PopulationlistEntity _
                                                                                                                       . _
                                                                                                                       PrefetchPathCase)
      daa.FetchEntityCollection(ec, fb, pp)

      Return ec(0)
    End Function

    Public Sub SaveToDB(ByVal UnitID As Long, ByVal SAPTaskID As Long, ByVal CaseNo As Long, ByVal Planned As String, _
                         ByVal Actual As String)

      Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)

        Dim entity As ItemStatusEntity = GetApprovedItemStatusBySAPTaskIdAndCaseNo(daa, UnitID, SAPTaskID, CaseNo)

        If entity IsNot Nothing Then
          If Not String.IsNullOrEmpty(Planned) Then
            entity.Planned = Convert.ToDateTime(Planned)
          End If
          If Not String.IsNullOrEmpty(Actual) Then
            entity.Done = Convert.ToDateTime(Actual)
          End If
        Else
        End If

        daa.SaveEntity(entity, False, False)
      End Using
    End Sub

#End Region
  End Class
End Namespace
