Imports PManagement.Business.BaseClasses

Namespace AlarmLogNumber
	''' <summary>
	''' Alarm Log Number
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class AlarmLogNumber
		Inherits BaseObject

#Region "Variables"

		Private ReadOnly _myId As Long
		Private ReadOnly _CtrlTypeId As Short
		Private ReadOnly _Release As Integer
		Private ReadOnly _LogNo As Short
		Private ReadOnly _CtrlTypeText As String = [String].Empty
		Private ReadOnly _Description As String = [String].Empty

#End Region

#Region "Methods"

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As LogInfoEntity)
			If entity.Case2LogInfo.Count = 1 Then _Id = entity.Case2LogInfo(0).Case2LogInfoId
			_myId = entity.LogInfoId
			_CtrlTypeId = entity.CtrlTypeId
			_Release = entity.Release
			_LogNo = entity.LogNo
			If entity.LogTxtCollectionViaLogInfo2LogTxt.Count = 1 Then
				_CtrlTypeText = entity.LogTxtCollectionViaLogInfo2LogTxt(0).CtrlTypeText
				_Description = entity.LogTxtCollectionViaLogInfo2LogTxt(0).Text
			End If
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Relation Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property RelationId() As Long
			Get
				Return _Id
			End Get
			Set(ByVal value As Long)
				_Id = value
			End Set
		End Property

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' CtrlTypeId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property CtrlTypeId() As Short
			Get
				Return _CtrlTypeId
			End Get
		End Property

		''' <summary>
		''' Release
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Release() As Integer
			Get
				Return _Release
			End Get
		End Property

		''' <summary>
		''' LogNo
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property LogNo() As Short
			Get
				Return _LogNo
			End Get
		End Property

		''' <summary>
		''' CtrlTypeText
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property CtrlTypeText() As String
			Get
				Return _CtrlTypeText
			End Get
		End Property

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Description() As String
			Get
				Return _Description
			End Get
		End Property

#End Region
	End Class
End Namespace
