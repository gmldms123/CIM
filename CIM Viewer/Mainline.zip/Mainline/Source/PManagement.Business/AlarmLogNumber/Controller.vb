Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace AlarmLogNumber
	''' <summary>
	''' Manage all interaction with case facts data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

#Region "Variables"

		Private _Model As Model
		Private _changeLogService As IChangeLogService

#End Region

#Region "Methods"

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As AlarmLogNumber)
			If _Model.Exists(item) Then
				If item.IsNew Then
					_Model.Remove(item)
				Else
					_Model.Delete(item)
				End If
			End If
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Dim ecDelete As New EntityCollection(Of Case2LogInfoEntity)(New Case2LogInfoEntityFactory())
			For Each item As AlarmLogNumber In _Model.DeletedAlarmLogNumbers
				ecDelete.Add(New Case2LogInfoEntity(item.RelationId))
			Next

			Dim ecSave As New EntityCollection(Of Case2LogInfoEntity)(New Case2LogInfoEntityFactory())
			For Each item As AlarmLogNumber In _Model.NewAlarmLogNumbers
				Dim ec As New Case2LogInfoEntity()
				ec.CaseId = _Context.CaseId.Value
				ec.LogInfoId = item.Id
				ecSave.Add(ec)
			Next

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					daa.StartTransaction(IsolationLevel.Serializable, "AlarmLogNumberSaveTransaction")
					daa.DeleteEntityCollection(ecDelete)
					daa.SaveEntityCollection(ecSave, True, False)
					Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                _Context.UserParticipant.ParticipantId,
					                                                                ChangeTypeEnum.AnyChanges, String.Empty,
					                                                                String.Empty,
					                                                                [Enum].Format(GetType(AnyChangesEnum),
					                                                                              AnyChangesEnum.AlarmLogNumbers, "d").
					                                                               	ToString)
					If (vs.GetErrors.Count > 0) Then
						daa.Rollback()
					Else
						daa.Commit()
					End If
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Catch ex As Exception
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()

					Dim deletedAlarmLogNumbers(_Model.DeletedAlarmLogNumbers.Count - 1) As AlarmLogNumber
					_Model.DeletedAlarmLogNumbers.CopyTo(deletedAlarmLogNumbers)
					For Each item As AlarmLogNumber In deletedAlarmLogNumbers
						_Model.Remove(item)
					Next

					Dim newAlarmLogNumbers(_Model.NewAlarmLogNumbers.Count - 1) As AlarmLogNumber
					_Model.NewAlarmLogNumbers.CopyTo(newAlarmLogNumbers)
					For Each item As AlarmLogNumber In newAlarmLogNumbers
						_Model.UpdateRelation(item,
						                      ecSave(
						                      	ecSave.FindMatches(
						                      		Case2LogInfoFields.CaseId = _Context.CaseId And Case2LogInfoFields.LogInfoId = item.Id)(0)) _
						                     	.Case2LogInfoId)
					Next
				End Try
			End Using
			Return New ValidationSummary()
		End Function

		''' <summary>
		''' Find reason codes from input criteria
		''' </summary>
		''' <param name="CtrlTypeText"></param>
		''' <param name="Release"></param>
		''' <param name="LogNo"></param>
		''' <param name="MaximumNumberOfItems"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function FindAlarmLogNumbers(ByVal CtrlTypeText As String, ByVal Release As String, ByVal LogNo As String,
		                                    ByVal MaximumNumberOfItems As Integer) As List(Of AlarmLogNumber)
			Dim liItems As New List(Of AlarmLogNumber)
			Dim ec As New EntityCollection(Of LogInfoEntity)(New LogInfoEntityFactory())

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				daa.CommandTimeOut = 120
				Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
				fb.PredicateExpression.Add(LogInfoFields.Deleted = DBNull.Value)
				If CtrlTypeText <> String.Empty Then
					fb.Relations.Add(LogInfoEntity.Relations.LogInfo2LogTxtEntityUsingLogInfoId, JoinHint.Right)
					fb.Relations.Add(LogInfo2LogTxtEntity.Relations.LogTxtEntityUsingLogTxtId)
					Dim fb2 As IRelationPredicateBucket = New RelationPredicateBucket()
					fb2.PredicateExpression.AddWithOr(LogInfoFields.CtrlTypeId Mod String.Format("%{0}%", CtrlTypeText))
					fb2.PredicateExpression.AddWithOr(LogTxtFields.CtrlTypeText Mod String.Format("%{0}%", CtrlTypeText))
					fb.PredicateExpression.AddWithAnd(fb2.PredicateExpression)
				End If
				If Release <> String.Empty Then
					fb.PredicateExpression.AddWithAnd(LogInfoFields.Release Mod String.Format("%{0}%", Release))
				End If
				If LogNo <> String.Empty Then
					fb.PredicateExpression.AddWithAnd(LogInfoFields.LogNo Mod String.Format("%{0}%", LogNo))
				End If
				Dim pp As IPrefetchPath2 = New PrefetchPath2(CInt(EntityType.LogInfoEntity))
				pp.Add(LogInfoEntity.PrefetchPathCase2LogInfo, 0,
				       New PredicateExpression(Case2LogInfoFields.CaseId = _Context.CaseId))
				pp.Add(LogInfoEntity.PrefetchPathLogTxtCollectionViaLogInfo2LogTxt, 0,
				       New PredicateExpression(LogTxtFields.Deleted = DBNull.Value))
				Try
					daa.FetchEntityCollection(ec, fb, MaximumNumberOfItems, Nothing, pp)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try
			End Using

			For i As Integer = 0 To ec.Count - 1
				liItems.Add(New AlarmLogNumber(ec(i)))
			Next

			Return liItems
		End Function

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As AlarmLogNumber)
			_Model.Add(item)
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Reason Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property AlarmLogNumbers() As List(Of AlarmLogNumber)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Dim ec As New EntityCollection(Of LogInfoEntity)(New LogInfoEntityFactory())
					Dim fb As New RelationPredicateBucket()
					fb.Relations.Add(LogInfoEntity.Relations.Case2LogInfoEntityUsingLogInfoId)
					fb.PredicateExpression.Add(LogInfoFields.Deleted = DBNull.Value)
					fb.PredicateExpression.Add(Case2LogInfoFields.CaseId = _Context.CaseId)
					Dim pp As New PrefetchPath2(CInt(EntityType.LogInfoEntity))
					pp.Add(LogInfoEntity.PrefetchPathCase2LogInfo, 0,
					       New PredicateExpression(Case2LogInfoFields.CaseId = _Context.CaseId))
					pp.Add(LogInfoEntity.PrefetchPathLogTxtCollectionViaLogInfo2LogTxt, 0,
					       New PredicateExpression(LogTxtFields.Deleted = DBNull.Value))
					Try
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.AlarmLogNumbers
			End Get
		End Property

		''' <summary>
		''' May Add Alarm Log Nmber
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddAlarmLogNumber() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_AlarmLogNumbers_Add)
			End Get
		End Property

		''' <summary>
		''' May Remove Alarm Log Nmber
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveAlarmLogNumber() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_AlarmLogNumbers_Remove)
			End Get
		End Property

#End Region
	End Class
End Namespace
