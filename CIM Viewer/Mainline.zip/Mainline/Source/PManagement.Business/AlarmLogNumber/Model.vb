Imports PManagement.Business.Genericed

Namespace AlarmLogNumber
	''' <summary>
	''' Model
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Model
		Inherits BaseClasses.Model

#Region "Variables"

		Private ReadOnly _slItem As New SortedList(Of Long, AlarmLogNumber)

#End Region

#Region "Methods"

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_slItem.Clear()
			OnDataChanged()
		End Sub

		''' <summary>
		''' Inject
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of LogInfoEntity))
			Dim dataChanged As Boolean = False

			'Insert new
			For i As Integer = 0 To ec.Count - 1
				If Not _slItem.ContainsKey(ec(i).LogInfoId) Then
					Dim item As New AlarmLogNumber(ec(i))
					_slItem.Add(item.Id, item)
					dataChanged = True
				Else
					Dim item As AlarmLogNumber = _slItem(ec(i).LogInfoId)
					If item.IsNew And ec(i).Case2LogInfo.Count = 1 Then
						item.RelationId = ec(i).Case2LogInfo(0).Case2LogInfoId
						dataChanged = True
					End If
				End If
			Next

			'Remove deleted
			Dim liKeys As List(Of Long) =
			    	(From item In _slItem.Values
			    	Where ec.FindMatches(LogInfoFields.LogInfoId = item.Id).Count = 0 And Not item.IsNew Select item.Id).ToList()
			If liKeys.Count > 0 Then
				For Each key As Long In liKeys
					_slItem.Remove(key)
				Next
				dataChanged = True
			End If

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Delete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As AlarmLogNumber)
			If Not item.Deleted Then
				item.Deleted = True
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Undelete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Undelete(ByVal item As AlarmLogNumber)
			If item.Deleted Then
				item.Deleted = False
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Remove(ByVal item As AlarmLogNumber)
			If _slItem.ContainsKey(item.Id) Then
				_slItem.Remove(item.Id)
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As AlarmLogNumber)
			If Exists(item) Then
				Undelete(_slItem(item.Id))
			Else
				_slItem.Add(item.Id, item)
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Update Relation Id
		''' </summary>
		''' <param name="item"></param>
		''' <param name="RelationId"></param>
		''' <remarks></remarks>
		Public Sub UpdateRelation(ByVal item As AlarmLogNumber, ByVal RelationId As Long)
			If _slItem.ContainsKey(item.Id) Then
				item.RelationId = RelationId
				OnDataChanged()
			End If
		End Sub

#End Region

#Region "Properties"

		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Dim _IsDirty As Boolean = False
				For Each item As AlarmLogNumber In _slItem.Values
					_IsDirty = _IsDirty Or item.IsDirty
					If _IsDirty Then Exit For
				Next
				Return _IsDirty
			End Get
		End Property

		''' <summary>
		''' Alarm Log Numbers
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property AlarmLogNumbers() As List(Of AlarmLogNumber)
			Get
				Dim liItem As New List(Of AlarmLogNumber)
				For i As Integer = 0 To _slItem.Values.Count - 1
					If Not _slItem.Values(i).Deleted Then
						liItem.Add(_slItem.Values(i))
					End If
				Next
				Return liItem
			End Get
		End Property

		''' <summary>
		''' Deleted Alarm Log Numbers
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedAlarmLogNumbers() As List(Of AlarmLogNumber)
			Get
				'Items from sortedlist to generic list
				Dim _lItem As List(Of AlarmLogNumber) = _slItem.Values.ToList()
				Return _lItem.FindAll(Predicate (Of AlarmLogNumber).Deleted)
			End Get
		End Property

		''' <summary>
		''' New Alarm Log Numbers
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NewAlarmLogNumbers() As List(Of AlarmLogNumber)
			Get
				'Items from sortedlist to generic list
				Dim _lItem As List(Of AlarmLogNumber) = New List(Of AlarmLogNumber)
				For Each item As AlarmLogNumber In _slItem.Values
					_lItem.Add(item)
				Next
				Return _lItem.FindAll(Predicate (Of AlarmLogNumber).IsNew)
			End Get
		End Property

		''' <summary>
		''' Exists
		''' </summary>
		''' <param name="item"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Exists(ByVal item As AlarmLogNumber) As Boolean
			Get
				Return _slItem.ContainsKey(item.Id)
			End Get
		End Property

#End Region
	End Class
End Namespace
