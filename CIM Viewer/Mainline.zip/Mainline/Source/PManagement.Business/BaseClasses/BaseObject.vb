Imports PManagement.DataLayer.Interfaces

Namespace BaseClasses
	''' <summary>
	''' Base Object
	''' </summary>
	''' <remarks></remarks>
		Public MustInherit Class BaseObject
		Implements IBaseObject

		''' <summary>
		''' The id that determines if the object is new (typically RelationId, but not always)
		''' </summary>
		''' <remarks></remarks>
		Protected _Id As Long = - 1

		''' <summary>
		''' Boolean that determines if the object is marked deleted
		''' </summary>
		''' <remarks></remarks>
		Protected _Deleted As Boolean

		''' <summary>
		''' Gets a value indicating whether this instance is new.
		''' </summary>
		''' <value><c>true</c> if this instance is new; otherwise, <c>false</c>.</value>
		Public Overridable ReadOnly Property IsNew() As Boolean Implements IBaseObject.IsNew
			Get
				Return _Id = - 1
			End Get
		End Property

		''' <summary>
		''' Gets a value indicating whether this instance is dirty.
		''' </summary>
		''' <value><c>true</c> if this instance is dirty; otherwise, <c>false</c>.</value>
		Public Overridable ReadOnly Property IsDirty() As Boolean Implements IBaseObject.IsDirty
			Get
				Return _Deleted Or IsNew
			End Get
		End Property

		''' <summary>
		''' Gets or sets a value indicating whether this <see cref="BaseObject" /> is deleted.
		''' </summary>
		''' <value><c>true</c> if deleted; otherwise, <c>false</c>.</value>
		Public Overridable Property Deleted() As Boolean Implements IBaseObject.Deleted
			Get
				Return _Deleted
			End Get
			Set(ByVal value As Boolean)
				_Deleted = value
			End Set
		End Property
	End Class
End Namespace
