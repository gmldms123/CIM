
Imports PManagement.Framework
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults

Namespace BaseClasses
	''' <summary>
	''' Base class for all controllers
	''' </summary>
	''' <remarks></remarks>
		Public MustInherit Class Controller
		Implements Interfaces.Controller
		Implements IDisposable

		Protected _Initialized As Boolean
		Protected _Environment As Environment
		Protected _Context As PmanContext
		Protected _AccessControl As AccessControl

		''' <summary>
		''' Is instance initialized using Sub Initialize
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Initialized() As Boolean Implements Interfaces.Controller.Initialized
			Get
				Return _Initialized
			End Get
		End Property

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public MustOverride ReadOnly Property IsDirty() As Boolean Implements Interfaces.Controller.IsDirty

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesctrl"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overridable Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                  ByRef accesctrl As AccessControl, ByVal model As Interfaces.Model) _
			Implements Interfaces.Controller.Initialize
			PmanTrace.WriteInfo("Base Controller", "Initialize")

			_Environment = environment
			_Context = context
			_AccessControl = accesctrl

			AddHandler _Context.ContextChanged, AddressOf ContextChanged

			_Initialized = True
		End Sub

		''' <summary>
		''' PmanContext Changed
		''' </summary>
		''' <remarks></remarks>
		Protected Overridable Sub ContextChanged()
			PmanTrace.WriteInfo("Base Controller", "ContextChanged")

			Clear()
		End Sub

		''' <summary>
		''' Clear model
		''' </summary>
		''' <remarks></remarks>
		Public MustOverride Sub Clear() Implements Interfaces.Controller.Clear

		''' <summary>
		''' Save model
		''' </summary>
		''' <remarks></remarks>
		Public MustOverride Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                                  Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary _
			Implements Interfaces.Controller.Save

		Private disposedValue As Boolean = False
		' To detect redundant calls

		' IDisposables
		Protected Overridable Sub Dispose(ByVal disposing As Boolean)
			PmanTrace.WriteInfo("Base Controller", "Dispose")

			If Not disposedValue Then
				If disposing Then
					If _Initialized Then
						RemoveHandler _Context.ContextChanged, AddressOf ContextChanged
						_Environment = Nothing
						_Context = Nothing
						_AccessControl = Nothing
						_Initialized = False
					End If
				End If
				PmanTrace.WriteVerbose("Base Controller", "Dispose", "Disposed")
			End If
			disposedValue = True
		End Sub

#Region " IDisposable Support "

		' This code added by Visual Basic to correctly implement the disposable pattern.
		Public Sub Dispose() Implements IDisposable.Dispose, Interfaces.Controller.Dispose
			' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
			Dispose(True)
			GC.SuppressFinalize(Me)
		End Sub

#End Region
	End Class
End Namespace
