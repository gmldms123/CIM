Imports PManagement.Framework

Namespace BaseClasses
	Public MustInherit Class Model
		Implements Interfaces.Model
		Implements IDisposable

		Protected _Initialized As Boolean = False
		Protected _Environment As Environment
		Protected _Context As PmanContext

		Public Event DataChanged() Implements Interfaces.Model.DataChanged

		''' <summary>
		''' Is instance initialized using Sub Initialize
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Initialized() As Boolean Implements Interfaces.Model.Initialized
			Get
				Return _Initialized
			End Get
		End Property

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <remarks></remarks>
		Public Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext) _
			Implements Interfaces.Model.Initialize
			PmanTrace.WriteInfo("Base Model", "Initialize")

			_Environment = environment
			_Context = context
			_Initialized = True
		End Sub

		''' <summary>
		''' Raise DataChanged event
		''' </summary>
		''' <remarks></remarks>
		Protected Sub OnDataChanged() Implements Interfaces.Model.OnDataChanged
			PmanTrace.WriteInfo("Base Model", "OnDataChanged")

			RaiseEvent DataChanged()
		End Sub

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <remarks></remarks>
		Public MustOverride ReadOnly Property IsDirty() As Boolean Implements Interfaces.Model.IsDirty

		''' <summary>
		''' Clear model
		''' </summary>
		''' <remarks></remarks>
		Public MustOverride Sub Clear() Implements Interfaces.Model.Clear

		Private disposedValue As Boolean = False
		' To detect redundant calls

		' IDisposable
		Protected Overridable Sub Dispose(ByVal disposing As Boolean)
			PmanTrace.WriteInfo("Base Model", "Dispose")

			If Not disposedValue Then
				If disposing Then
					If _Initialized Then
						_Environment = Nothing
						_Context = Nothing
						_Initialized = False
					End If
				End If
				PmanTrace.WriteVerbose("Base Model", "Dispose", "Disposed")
			End If
			disposedValue = True
		End Sub

#Region " IDisposable Support "

		' This code added by Visual Basic to correctly implement the disposable pattern.
		Public Sub Dispose() Implements IDisposable.Dispose, Interfaces.Model.Dispose
			' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
			Dispose(True)
			GC.SuppressFinalize(Me)
		End Sub

#End Region
	End Class
End Namespace
