﻿Imports PManagement.ModelLayer
Imports PManagement.DataLayer
Imports PManagement.BusinessLayer
Imports PManagement.ServiceLayer
Imports StructureMap

Public Class BootStrapper
	Public Shared Sub ConfigureStructureMap()
		ObjectFactory.Initialize(AddressOf RegistryAdder)
		Debug.WriteLine(ObjectFactory.WhatDoIHave())
	End Sub

	Private Shared Sub RegistryAdder(ByVal x As IInitializationExpression)
		x.AddRegistry(New BusinessRegistry())
		x.AddRegistry(New BusinessLayerRegistry())
		x.AddRegistry(New DataLayerRegistry())
		x.AddRegistry(New ServiceLayerRegistry())
		x.AddRegistry(New ModelLayerRegistry())
	End Sub
End Class
