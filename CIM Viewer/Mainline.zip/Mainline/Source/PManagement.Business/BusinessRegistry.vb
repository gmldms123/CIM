﻿Imports PManagement.DataLayer.Factories
Imports PManagement.Business.Document
Imports StructureMap.Configuration.DSL

Public Class BusinessRegistry
	Inherits Registry

	Public Sub New()
		ForRequestedType (Of IDocumentPathFactory)().TheDefaultIsConcreteType (Of DocumentPathFactory)().AsSingletons()
	End Sub
End Class