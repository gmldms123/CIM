﻿Namespace Caching
	Public Enum TimeToLive
		Low
		High
	End Enum

	''' <summary>
	''' Interface for all caching implementations
	''' </summary>
	''' <remarks></remarks>
		Public Interface ICache
		''' <summary>
		''' Whether the cache contains a specific item
		''' </summary>
		''' <param name="key">The key of the item to find</param>
		''' <returns>True if the item exists in the cache</returns>
		''' <remarks></remarks>
		Function ContainsItem(ByVal key As String) As Boolean

		''' <summary>
		''' Retrieves an item from the cache
		''' </summary>
		''' <typeparam name="T">The expected type of the cache</typeparam>
		''' <param name="key">The key of the item to get</param>
		''' <returns>The item to get, or null if the item does not exist in cache</returns>
		''' <remarks></remarks>
		Function GetItem (Of T)(ByVal key As String) As T

		''' <summary>
		''' Adds an item to the cache
		''' </summary>
		''' <param name="key">The item key</param>
		''' <param name="value">The item value</param>
		''' <param name="ttl">The time to live for this item</param>
		''' <remarks></remarks>
		Sub SetItem(ByVal key As String, ByVal value As Object, Optional ByVal ttl As TimeToLive = TimeToLive.Low)

		''' <summary>
		''' Removes an item from the cache
		''' </summary>
		''' <param name="key">The item key</param>
		''' <remarks></remarks>
		Sub RemoveItem(ByVal key As String)

		''' <summary>
		''' The target platform for a cache implementation
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		ReadOnly Property TargetPlatform() As Environment.Platforms

		''' <summary>
		''' Removes all items from the cache
		''' </summary>
		Sub Clear()
	End Interface
End Namespace
