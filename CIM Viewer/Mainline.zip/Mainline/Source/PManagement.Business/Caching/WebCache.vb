﻿Imports System.Web
Imports System.Web.Caching

Namespace Caching
	' cross request web cache
	Public Class WebCache
		Implements ICache

		Private Const CacheItemTTL As Integer = 60

		Public Sub Clear() Implements ICache.Clear
			For Each de As DictionaryEntry In HttpContext.Current.Cache
				HttpContext.Current.Cache.Remove(DirectCast(de.Key, String))
			Next
		End Sub

		Public Function ContainsItem(ByVal key As String) As Boolean Implements ICache.ContainsItem
			Dim context As HttpContext = HttpContext.Current
			If context.Cache(key) IsNot Nothing Then
				Return True
			ElseIf context.Items.Contains(key) Then
				Return True
			End If
			Return False
		End Function

		Public Function GetItem (Of T)(ByVal key As String) As T Implements ICache.GetItem
			Dim context As HttpContext = HttpContext.Current
			Dim value As Object = Nothing
			If context.Cache(key) IsNot Nothing Then
				value = context.Cache(key)
			ElseIf context.Items.Contains(key) Then
				value = context.Items(key)
			End If
			If value IsNot Nothing Then
				Return DirectCast(value, T)
			End If
			Return Nothing
		End Function

		Public Sub SetItem(ByVal key As String, ByVal value As Object, Optional ByVal ttl As TimeToLive = TimeToLive.Low) _
			Implements ICache.SetItem
			If ttl = TimeToLive.High Then
				' use the built in ASP.NET cache for high TTL (= cross request)
				HttpContext.Current.Cache.Insert(key, value, Nothing, DateTime.UtcNow.AddMinutes(CacheItemTTL),
				                                 Cache.NoSlidingExpiration)
			Else
				HttpContext.Current.Items(key) = value
			End If
		End Sub

		Public Sub RemoveItem(ByVal key As String) Implements ICache.RemoveItem
			If HttpContext.Current.Cache(key) IsNot Nothing Then
				HttpContext.Current.Cache.Remove(key)
			ElseIf HttpContext.Current.Items.Contains(key) Then
				HttpContext.Current.Items.Remove(key)
			End If
		End Sub

		Public ReadOnly Property TargetPlatform() As Environment.Platforms Implements ICache.TargetPlatform
			Get
				Return Environment.Platforms.Web
			End Get
		End Property
	End Class

	' per request web cache
	'Public Class WebCache
	'  Implements ICache

	'  Public Function ContainsItem(ByVal key As String) As Boolean Implements ICache.ContainsItem
	'    Return System.Web.HttpContext.Current.Items.Contains(key)
	'  End Function

	'  Public Function GetItem(Of T)(ByVal key As String) As T Implements ICache.GetItem
	'    If ContainsItem(key) Then
	'      Return DirectCast(System.Web.HttpContext.Current.Items(key), T)
	'    End If
	'    Return Nothing
	'  End Function

	'  Public Sub SetItem(ByVal key As String, ByVal value As Object) Implements ICache.SetItem
	'    System.Web.HttpContext.Current.Items(key) = value
	'  End Sub

	'  Public ReadOnly Property TargetPlatform() As Environment.Platforms Implements ICache.TargetPlatform
	'    Get
	'      Return Environment.Platforms.Web
	'    End Get
	'  End Property
	'End Class
End Namespace