﻿Namespace Caching
	Public Class WinCache
		Implements ICache

		Private ReadOnly _Items As New Dictionary(Of String, Object)
		Private ReadOnly _SyncLock As Object = New Object()

		Public Sub Clear() Implements ICache.Clear
			SyncLock _SyncLock
				_Items.Clear()
			End SyncLock
		End Sub

		Public Function ContainsItem(ByVal key As String) As Boolean Implements ICache.ContainsItem
			Dim contains As Boolean
			SyncLock _SyncLock
				contains = _Items.ContainsKey(key)
			End SyncLock
			Return contains
		End Function

		Public Function GetItem (Of T)(ByVal key As String) As T Implements ICache.GetItem
			Dim value As Object = Nothing

			If _Items.ContainsKey(key) Then
				SyncLock _SyncLock
					' double check after sync locking
					If _Items.ContainsKey(key) Then
						value = _Items(key)
					End If
				End SyncLock
			End If

			Return DirectCast(value, T)
		End Function

		Public Sub SetItem(ByVal key As String, ByVal value As Object, Optional ByVal ttl As TimeToLive = TimeToLive.Low) _
			Implements ICache.SetItem
			' TODO: TTL?
			SyncLock _SyncLock
				_Items(key) = value
			End SyncLock
		End Sub

		Public Sub RemoveItem(ByVal key As String) Implements ICache.RemoveItem
			If _Items.ContainsKey(key) Then
				SyncLock _SyncLock
					_Items.Remove(key)
				End SyncLock
			End If
		End Sub

		Public ReadOnly Property TargetPlatform() As Environment.Platforms Implements ICache.TargetPlatform
			Get
				Return Environment.Platforms.Windows
			End Get
		End Property
	End Class
End Namespace