Namespace CaseFacts
	Public NotInheritable Class BusinessProcess
		Private _Id As Long

		Public Sub New(ByVal entity As BusinessProcessEntity)
			_Id = entity.BusinessProcessId
		End Sub

		Public Property Id() As Long
			Get
				Return _Id
			End Get
			Set(ByVal value As Long)
				_Id = value
			End Set
		End Property
	End Class
End NameSpace