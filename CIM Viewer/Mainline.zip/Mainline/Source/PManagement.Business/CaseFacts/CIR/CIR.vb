Namespace CaseFacts.CIR
	''' <summary>
	''' CIR
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class CIR
		Private ReadOnly _Id As Long
		Private ReadOnly _ComponentFailureReportId As Long
		Private ReadOnly _TurbineNo As String
		Private ReadOnly _ProcessedDate As Nullable(Of Date)
		Private ReadOnly _NewCIR As Short
		Private ReadOnly _ReportTypeId As Nullable(Of Long)
		Private ReadOnly _ReportTypeName As String
		Private ReadOnly _CaseNo As Long
		Private ReadOnly _VerifiedDate As Nullable(Of Date)
		Private ReadOnly _VerifiedBy As Participant.Participant
		Private ReadOnly _RejectedDate As Nullable(Of Date)
		Private ReadOnly _DateOfInspection As Nullable(Of Date)
		Private ReadOnly _DateOfFailure As Nullable(Of Date)
		Private ReadOnly _SiteName As String
		Private ReadOnly _ServiceReportNumber As String

		'add a controller to a CIR. By HEMOM
		Private _Controller As Controller


		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As CirEntity, ByRef _Ctrl As Controller)
			Controller = _Ctrl
			_Id = entity.Cirid
			_ComponentFailureReportId = entity.ComponentFailureReportId
			_TurbineNo = entity.TurbineNo
			_ProcessedDate = entity.ProcessedDate
			_NewCIR = entity.NewCir
			_ReportTypeId = entity.ReportTypeId
			_ReportTypeName = "-"
			' entity
			_CaseNo = entity.Case.CaseNo
			_DateOfFailure = entity.DateOfFailure
			_DateOfInspection = entity.DateOfInspection
			_SiteName = entity.SiteName
			_ServiceReportNumber = entity.ServiceReportNumber

			If (entity.VerifiedByParticipant IsNot Nothing AndAlso entity.Verified IsNot Nothing) Then
				_VerifiedDate = entity.Verified
				_VerifiedBy = New Participant.Participant(entity.VerifiedByParticipant)
			End If

			If (entity.Rejected isnot nothing) Then
				_RejectedDate = entity.Rejected
			End If

			If _ReportTypeId IsNot Nothing Then
				Select Case _ReportTypeId
					Case 1 : _ReportTypeName = "Inspection"
					Case 2 : _ReportTypeName = "Failure"
					Case 3 : _ReportTypeName = "Repair"
					Case 4 : _ReportTypeName = "Replacement"
					Case 5 : _ReportTypeName = "Retrofit"
					Case 6 : _ReportTypeName = "CMS Inspection"
				End Select
			End If
		End Sub

		''' <summary>
		''' Gets the controller. Since CIR data is dependent on the controller, the controller reference has been associated with a CIR. 
		''' </summary>
		''' <value>The controller.</value>
		Public Property Controller() As Controller
			Get
				Return _Controller
			End Get
			Set(ByVal value As Controller)
				_Controller = value
			End Set
		End Property


		''' <summary>
		''' Gets the id.
		''' </summary>
		''' <value>The id.</value>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property


		''' <summary>
		''' Gets Report type.
		''' </summary>
		''' <value>The report type.</value>
		Public ReadOnly Property ReportTypeId() As Nullable(Of Long)
			Get
				Return _ReportTypeId
			End Get
		End Property

		''' <summary>
		''' Gets Report type name.
		''' </summary>
		''' <value>The report type name.</value>
		Public ReadOnly Property ReportTypeName() As String
			Get
				Return _ReportTypeName
			End Get
		End Property

		''' <summary>
		''' Gets the component failure report id.
		''' </summary>
		''' <value>The component failure report id.</value>
		Public ReadOnly Property ComponentFailureReportId() As Long
			Get
				Return _ComponentFailureReportId
			End Get
		End Property

		''' <summary>
		''' Gets the turbine no.
		''' </summary>
		''' <value>The turbine no.</value>
		Public ReadOnly Property TurbineNo() As String
			Get
				Return _TurbineNo
			End Get
		End Property

		''' <summary>
		''' Gets the processed date.
		''' </summary>
		''' <value>The processed date.</value>
		Public ReadOnly Property ProcessedDate() As Nullable(Of Date)
			Get
				Return _ProcessedDate
			End Get
		End Property

		''' <summary>
		''' Gets whether the CIR is from the the very old, the old or the new CIR system
		''' </summary>
		''' <value>-1 is very old, 0 is old, and 1 is new</value>
		Public ReadOnly Property NewCIR() As Short
			Get
				Return _NewCIR
			End Get
		End Property

		''' <summary>
		''' Gets the case number of the CIM that this CIR belongs to 
		''' </summary>
		''' <returns>Case number of the CIM case that this CIR belongs to</returns>
		Public ReadOnly Property CaseNo() As Long
			Get
				Return _CaseNo
			End Get
		End Property

		''' <summary>
		''' Gets the person that verified this CIR (if it is verified)
		''' </summary>
		''' <value></value>
		''' <returns>The person that has verified this CIR (null if not verified)</returns>
		Public ReadOnly Property VerifiedBy As Participant.Participant
			Get
				Return _VerifiedBy
			End Get
		End Property

		''' <summary>
		''' Gets the date of the CIR verification (if it is verified)
		''' </summary>
		''' <value></value>
		''' <returns>The date of the CIR verification (null if not verified)</returns>
		Public ReadOnly Property VerifiedDate As Date?
			Get
				Return _VerifiedDate
			End Get
		End Property

		''' <summary>
		''' Gets whether or not this CIR has been rejected from this CIM case
		''' </summary>
		''' <value></value>
		''' <returns>True if the CIR has been rejected, false otherwise</returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsRejected As Boolean
			Get
				Return _RejectedDate.HasValue
			End Get
		End Property

		Public ReadOnly Property DateOfInspection As Date?
			Get
				Return _DateOfInspection
			End Get
		End Property

		Public ReadOnly Property DateOfFailure As Date?
			Get
				Return _DateOfFailure
			End Get
		End Property

		Public ReadOnly Property SiteName as String
			Get
				return _SiteName
			End Get
		End Property

		Public ReadOnly Property ServiceReportNumber as String
			Get
				return _ServiceReportNumber
			End Get
		End Property
	End Class
End Namespace
