Imports System.Net
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports PManagement.Business.RejectCir

Namespace CaseFacts.CIR
	Public Class Controller
		Inherits BaseClasses.Controller

#Region "Overrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return False
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Return New ValidationSummary()
		End Function

#End Region


#Region "Methods"


		'Public ReadOnly Environment
		''' <summary>
		''' Gets the environment. Since CIR data is dependent on the controller environment, the environment reference has been made readable. 
		''' </summary>
		''' <value>The environment.</value>
		Public Property Environment() As Environment
			Get
				Return _Environment
			End Get
			Set(ByVal value As Environment)
				_Environment = Environment
			End Set
		End Property

		Public Shadows Sub Initialize(ByRef env As Environment, ByRef context As PmanContext, ByRef accesctrl As AccessControl,
		                              ByVal model As Interfaces.Model)
			'Public Shadows Sub Initialize(ByRef environment As Environment, ByRef PmanContext As PmanContext, ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Environment = env
			MyBase.Initialize(env, context, accesctrl, model)
		End Sub

		''' <summary>
		''' Load CIRs.
		''' </summary>
		''' <param name="CaseID">The case ID.</param>
		''' <returns></returns>
		Public Function CIRs(ByVal CaseID As Nullable(Of Long)) As List(Of CIR)
			Dim tempCIRs As List(Of CIR) = New List(Of CIR)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Dim ec As New EntityCollection(Of CirEntity)(New CirEntityFactory())
				Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
				filter.PredicateExpression.AddWithAnd(CirFields.CaseId = CaseID)
				filter.PredicateExpression.AddWithAnd(CirFields.Deleted = DBNull.Value)
				Dim prefetchPath As New PrefetchPath2(CInt(EntityType.CirEntity))
				prefetchPath.Add(CirEntity.PrefetchPathCase)
				prefetchPath.Add(CirEntity.PrefetchPathVerifiedByParticipant)
				Try
					daa.FetchEntityCollection(ec, filter, prefetchPath)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try

				If ec IsNot Nothing Then
					For Each entity As CirEntity In ec
						Dim _Cir As CIR
						'_Cir.Controller = Me 'change! A reference to this controller is stored in every CIR (child)!
						_Cir = New CIR(entity, Me)
						tempCIRs.Add(_Cir)
					Next
				End If
			End Using

			Return tempCIRs
		End Function

		Public Sub RejectCir(ByRef cir As CIR)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString)
				Dim entity As New CirEntity(cir.Id)
				If (daa.FetchEntity(entity)) Then
					If entity.NewCir = 1 Then
						' delete new CIR immediately
						entity.Deleted = Now
						entity.DeletedBy = _Context.UserParticipant.VestasInitials
					Else
						' mark old CIR as "being rejceted"
						entity.Rejected = DateTime.Now
						entity.RejectedBy = _Context.UserParticipant.ParticipantId
					End If
					daa.SaveEntity(entity)
				End If
			End Using
		End Sub

		Public Function VerifyCir(ByVal cirToVerify As List(Of CIR)) As Integer
			Dim affectedCir As Integer = 0
			cirToVerify.RemoveAll(Function(c) c.VerifiedBy IsNot Nothing AndAlso c.VerifiedDate IsNot Nothing)
			If (cirToVerify.Count > 0) Then
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString)
					For Each cir As CIR In cirToVerify
						Dim entity As New CirEntity(cir.Id)
						If (daa.FetchEntity(entity)) Then
							entity.VerifiedBy = _Context.UserParticipant.ParticipantId
							entity.Verified = DateTime.Now
							daa.SaveEntity(entity)
							affectedCir += 1
						End If
					Next
				End Using
			End If
			Return affectedCir
		End Function


		''' <summary>
		''' Reject CIR from CIR2010
		''' </summary>
		Public Function RejectNewCir(ByRef cir As CIR, ByVal comment As String) As RejectOutcome
			' use the "RejectCir" WS from CIR2010
			Dim reject As New RejectCir.RejectCir
			'Set the WebService URL, based on the current environment
			reject.Url = _Environment.RejectCir_WebService_URL
			reject.PreAuthenticate = True
			reject.Credentials = CredentialCache.DefaultCredentials
			Dim cirId As Long = cir.ComponentFailureReportId
			Dim result As RejectOutcome = reject.RejectCirToInbox(cirId, comment, _Context.UserParticipant.VestasInitials)

			' immediately reject the CIR in the CIM system if the WS call was a success
			If (result = RejectOutcome.Success) Then
				RejectCir(cir)
			End If
			Return result
		End Function

		Public Function UndoRejection(ByVal cirToUndo As List(Of CIR)) As Integer
			Dim affectedCir As Integer = 0
			cirToUndo.RemoveAll(Function(c) c.IsRejected = False Or c.NewCIR = 1)
			If (cirToUndo.Count > 0) Then
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString)
					For Each cir As CIR In cirToUndo
						Dim entity As New CirEntity(cir.Id)
						If (daa.FetchEntity(entity)) Then
							entity.RejectedBy = Nothing
							entity.Rejected = Nothing
							daa.SaveEntity(entity)
							affectedCir += 1
						End If
					Next
				End Using
			End If
			Return affectedCir
		End Function

		Public Function CanRejectCir() As Boolean
			Dim isCaseManager As Boolean = False
			If _Context.IsCaseManager.HasValue Then isCaseManager = _Context.IsCaseManager.Value
			Dim IsExecutionManager As Boolean = False
			If _Context.IsExecutionManager.HasValue Then IsExecutionManager = _Context.IsExecutionManager.Value

			Return _
				isCaseManager OrElse IsExecutionManager OrElse
				_AccessControl.OperationIsLegal(Permissions.Editor_Main_Administration)
		End Function

		Public Function CanUndoRejection() As Boolean
			Return _AccessControl.OperationIsLegal(Permissions.Editor_Main_Administration)
		End Function

#End Region
	End Class
End Namespace
