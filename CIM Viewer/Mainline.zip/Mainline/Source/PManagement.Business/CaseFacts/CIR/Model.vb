Namespace CaseFacts.CIR
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

#Region "Overrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return False
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			'OnDataChanged()
		End Sub

#End Region
	End Class
End Namespace
