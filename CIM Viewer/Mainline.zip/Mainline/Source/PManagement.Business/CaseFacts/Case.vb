
Imports PManagement.DataLayer.Factories
Imports PManagement.DataLayer.CaseFacts
Imports PManagement.BusinessLayer.Services.Interfaces
Imports PManagement.BusinessLayer.Factories.Interfaces
Imports PManagement.DataLayer.DbBasedModel.CaseFacts
Imports PManagement.ModelLayer.CaseFacts
Imports PManagement.DataLayer.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate
Imports StructureMap

Namespace CaseFacts
	Public NotInheritable Class [Case]
		Implements ICase

		Private ReadOnly _Id As Long = - 1
		Private ReadOnly _CreatedBy As IParticipant
		Private ReadOnly _Number As Nullable(Of Long)
		Private _Manager As IParticipant
		Private _ManagerIsDirty As Boolean
		Private _ParentCase As [ICase]
		Private _ParentCaseIsDirty As Boolean
		Private ReadOnly _ChildCase As New List(Of [ICase])
		Private _Description As String = String.Empty
		Private _DescriptionIsDirty As Boolean
		Private _Phase As IPhase
		Private _PhaseIsDirty As Boolean
		Private ReadOnly _PhaseBudget As New List(Of IPhaseBudget)
		Private _ClaimStatus As IClaimStatus
		Private _ClaimStatusIsDirty As Boolean
		Private _Status As ICaseFactsStatus
		Private _StatusIsDirty As Boolean
		Private _PBU As IPBU
		Private _PBUIsDirty As Boolean
		Private ReadOnly _SBU As New List(Of ISBU)
		Private _SBUIsDirty As Boolean
		Private _ConfirmedBySupplier As Boolean
		Private _ConfirmedBySupplierIsDirty As Boolean
		Private _SalesOption As Boolean
		Private _SalesOptionIsDirty As Boolean
		Private ReadOnly _ProjectPortalId As Integer
		Private _Platform As DataLayer.Interfaces.IPlatform
		Private _PlatformIsDirty As Boolean
		Private _Portfolio As IPortfolio
		Private _PortfolioIsDirty As Boolean
		Private _TechnicalSpecialist As IParticipant
		Private _TechnicalSpecialistIsDirty As Boolean
		Private _ExecutionManager As IParticipant
		Private _ExecutionManagerIsDirty As Boolean
		Private _ClosedForInvoicing As Boolean
		Private _ClosedForInvoicingIsDirty As Boolean
		Private caseToFind As [Case]
		Private phaseBudgetToFind As IPhaseBudget
		Private phaseBudgetCollection As EntityCollection(Of Case2PhaseEntity)
		Private sbuToFind As ISBU
		Private sbuCollection As EntityCollection(Of Case2SbuEntity)
		Private _businessProcessId As Long
		Private _BusinessProcessIsDirty As Boolean
		Private _standardTask As StandardTask
		Private _StandardTaskIsDirty As Boolean
		Private ReadOnly _HasProcessedMSProjectPlan As Boolean
		Private _CaseCategory As ICaseCategory
		Private _Component As IComponent
        Private _PersonalSafety As IPersonalSafety
        ' PKB CO 74840 PS
        Private _ProjectScope As IProjectScope

		Public ReadOnly Property HasProcessedMsProjectPlan() As Boolean Implements ICaseSimple.HasProcessedMSProjectPlan
			Get
				Return _HasProcessedMSProjectPlan
			End Get
		End Property

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New(ByVal phase As IPhase, ByVal standardtask As StandardTask, ByVal claimStatus As IClaimStatus,
		               ByVal status As ICaseFactsStatus, ByVal participant As IParticipant, ByVal portfolio As IPortfolio,
		               ByVal businessProcessId As Long)
			_CreatedBy = participant
			_Manager = participant
			_Phase = phase
			_standardTask = standardtask
			_ClaimStatus = claimStatus
			_Status = status
			_ClosedForInvoicing = True
			_businessProcessId = businessProcessId
			If portfolio IsNot Nothing Then _Portfolio = portfolio
		End Sub

		'''' <summary>
		'''' New
		'''' </summary>
		'''' <param name="entity">The entity.</param>
		'''' <remarks></remarks>
		'Public Sub New(ByVal entity As CaseEntity)
		'  _Id = entity.CaseId
		'  _Number = entity.CaseNo
		'  _Description = entity.Description
		'End Sub

		''' <summary>
		''' Initializes a new instance of the <see cref="[Case]" /> class.
		''' </summary>
		''' <param name="entity">The entity.</param>
		''' <param name="relatedCase">if set to <c>true</c> [related case].</param>
		Public Sub New(ByVal entity As CaseEntity, ByVal relatedCase As Boolean)
			_Id = entity.CaseId
			_CreatedBy = New Participant.Participant(entity.CreatedByParticipant)
			_Number = entity.CaseNo
			_Manager = New Participant.Participant(entity.ManagerParticipant)
			If Not relatedCase Then
				If entity.ParentCase IsNot Nothing Then _ParentCase = New [Case](entity.ParentCase, True)
				For i As Integer = 0 To entity.ChildCase.Count - 1
					_ChildCase.Add(New [Case](entity.ChildCase(i), True))
				Next
			End If
			_Description = entity.Description
			_Phase = New Phase(entity.Phase)

			_businessProcessId = entity.BusinessProcessId

			Dim _BusinessProcessLogicFactory As IBusinessProcessLogicFactory =
			    	ObjectFactory.GetInstance (Of IBusinessProcessLogicFactory)()
			Dim businessProcessLogicService As IBusinessProcessLogicService =
			    	_BusinessProcessLogicFactory.GetBusinessProcessLogicByBusinessProcessId(BusinessProcessid)
			If (entity.StandardTask IsNot Nothing) Then
				_standardTask = businessProcessLogicService.GetAllStandardTasks().GetById(entity.StandardTaskId)
			End If


			_ClosedForInvoicing = entity.ClosedForInvoicing
			For i As Integer = 0 To entity.Case2Phase.Count - 1
				_PhaseBudget.Add(New PhaseBudget(entity.Case2Phase(i)))
			Next

			_ClaimStatus = New ClaimStatus(entity.ClaimStatus)
			_Status = New CaseFactsStatus(entity.Status)
			_PBU = New PBU(entity.Pbu)
			For Each sbuEntity As Case2SbuEntity In entity.Case2Sbu
				_SBU.Add(New SBU(sbuEntity.Sbu))
			Next
			_ConfirmedBySupplier = entity.ConfirmedBySupplier
			_SalesOption = entity.SalesOption
			_ProjectPortalId = entity.ProjectPortalId
            _HasProcessedMSProjectPlan = entity.HasProcessedMsprojectPlan

            Bleeding = entity.Bleeding
            SafetyAlert = entity.SafetyAlert
            EcoNumber = entity.Econumber
            Dmsdocument = entity.Dmsdocument

			If entity.Platform_ IsNot Nothing Then
				_Platform = New Platform(entity.Platform_)
			End If

			If entity.TechnicalSpecialistId IsNot Nothing Then
				_TechnicalSpecialist = New Participant.Participant(entity.TechnicalSpecialistParticipant)
			End If

			If entity.ExecutionManagerId IsNot Nothing Then
				_ExecutionManager = New Participant.Participant(entity.ExecutionManagerParticipant)
			End If

			If entity.Portfolio IsNot Nothing Then
				_Portfolio = New Portfolio(entity.Portfolio)
			End If

			If entity.Category IsNot Nothing Then
				_CaseCategory = New CaseCategory(entity.Category)
			End If
			If entity.Component IsNot Nothing Then
				_Component = New Component(entity.Component)
            End If
            ' PKB 74840 PS
            If entity.ProjectScope IsNot Nothing Then
                _ProjectScope = New ProjectScope(entity.ProjectScope)
            End If
			If entity.PersonalSafety IsNot Nothing Then
				_PersonalSafety = New PersonalSafety(entity.PersonalSafety)
			End If
        End Sub

		''' <summary>
		''' Initializes a new instance of the <see cref="[Case]" /> class.
		''' </summary>
		''' <param name="entity">The entity.</param>
		Public Sub New(ByVal entity As CaseEntity)
			Me.New(entity, False)
			'If project IsNot Nothing Then _Portfolio = project.Portfolio
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As CaseEntity) As Boolean Implements ICase.Update
			'Public Function Update(ByVal entity As CaseEntity, ByVal project As wsProjectPortal.Project) As Boolean
			Dim dataChanged As Boolean

			'Manager
			If Not _ManagerIsDirty AndAlso _Manager.Id <> entity.ManagerId Then
				_Manager = New Participant.Participant(entity.ManagerParticipant)
				dataChanged = True
			End If

			'Technical Specialist
			If Not _TechnicalSpecialistIsDirty AndAlso Not _TechnicalSpecialist Is Nothing Then
				If entity.TechnicalSpecialistId IsNot Nothing Then
					_TechnicalSpecialist = New Participant.Participant(entity.TechnicalSpecialistParticipant)
					dataChanged = True
				End If
			End If

			'Execution Manager
			If Not _ExecutionManagerIsDirty AndAlso Not _ExecutionManager Is Nothing Then
				If entity.ExecutionManagerId IsNot Nothing Then
					_ExecutionManager = New Participant.Participant(entity.ExecutionManagerParticipant)
					dataChanged = True
				End If
			End If

			'Platform
			If Not _PlatformIsDirty AndAlso Not _Platform Is Nothing Then
				'If _Platform.Id.Equals(entity.Platform) Then
				If entity.Platform_ IsNot Nothing Then
					_Platform = New Platform(entity.Platform_)
					dataChanged = True
				End If
				'End If
			End If

			'Portfolio
			Dim portfolio As Portfolio = Nothing
			If (entity.Portfolio IsNot Nothing) Then
				portfolio = New Portfolio(entity.Portfolio)
			End If

			If Not _PortfolioIsDirty And (
			   	(_Portfolio IsNot Nothing AndAlso portfolio IsNot Nothing AndAlso _Portfolio.Id <> portfolio.Id) OrElse
			   	(_Portfolio Is Nothing AndAlso portfolio IsNot Nothing) OrElse
			   	(_Portfolio IsNot Nothing AndAlso portfolio Is Nothing)
			   	) Then
				'(_Portfolio Is Nothing And portfolio IsNot Nothing) OrElse _
				' (_Portfolio IsNot Nothing Or Project IsNot Nothing AndAlso Project.Portfolio IsNot Nothing) AndAlso _
				' (_Portfolio Is Nothing And Project IsNot Nothing AndAlso Project.Portfolio IsNot Nothing OrElse _
				' _Portfolio IsNot Nothing And Project IsNot Nothing OrElse Project.Portfolio Is Nothing OrElse _
				' Project IsNot Nothing AndAlso _Portfolio.GetId <> Project.Portfolio.GetId) Then
				If portfolio IsNot Nothing Then
					_Portfolio = portfolio
				Else
					_Portfolio = Nothing
				End If
				dataChanged = True
			End If

			'Parent Case
			If Not _ParentCaseIsDirty And
			   (_ParentCase IsNot Nothing Or entity.ParentCase IsNot Nothing) AndAlso
			   (_ParentCase Is Nothing And entity.ParentCase IsNot Nothing OrElse
			    _ParentCase IsNot Nothing And entity.ParentCase Is Nothing OrElse
			    _ParentCase.Id <> entity.ParentCase.CaseId) Then
				_ParentCase = New [Case](entity.ParentCase, True)
				dataChanged = True
			End If

			'Child Cases
			For i As Integer = 0 To entity.ChildCase.Count - 1
				caseToFind = New [Case](entity.ChildCase(i), True)
				Dim myCase As [ICase] = _ChildCase.Find(New Predicate(Of [ICase])(AddressOf FindCase))
				If myCase Is Nothing Then
					_ChildCase.Add(caseToFind)
					dataChanged = True
				End If
			Next
			'Why doesn't this work? Sometimes the Child collection is blank...
			'dataChanged = dataChanged Or _ChildCase.RemoveAll(New Predicate(Of [Case])(AddressOf FindCasesToRemove)) > 0

			'Description
			If Not _DescriptionIsDirty AndAlso _Description <> entity.Description Then
				_Description = entity.Description
				dataChanged = True
			End If

			'BusinessProcessId
			If _businessProcessId <> entity.BusinessProcessId Then
				_businessProcessId = entity.BusinessProcessId
				dataChanged = True
			End If


			'Phase
			If Not _PhaseIsDirty AndAlso _Phase.Id <> entity.PhaseId Then
				_Phase = New Phase(entity.Phase)
				dataChanged = True
			End If

			'StandardTask
			If Not _StandardTaskIsDirty Then
				If (_standardTask IsNot Nothing) Then
					If _standardTask.Id <> entity.StandardTaskId Then
						_standardTask = StandardTaskFactory.CreateStandardTask(entity.StandardTask)
						dataChanged = True
					End If
				End If
			End If

			'Phase Budget
			For i As Integer = 0 To entity.Case2Phase.Count - 1
				phaseBudgetToFind = New PhaseBudget(entity.Case2Phase(i))
				Dim myPhaseBudget As IPhaseBudget = _PhaseBudget.Find(New Predicate(Of IPhaseBudget)(AddressOf FindPhaseBudget))
				If myPhaseBudget Is Nothing Then
					_PhaseBudget.Add(phaseBudgetToFind)
					dataChanged = True
				End If
			Next
			phaseBudgetCollection = entity.Case2Phase
			dataChanged = dataChanged Or
			              _PhaseBudget.RemoveAll(New Predicate(Of IPhaseBudget)(AddressOf FindPhaseBudgetsToRemove)) > 0

			'Claim CaseFactsStatus
			If Not _ClaimStatusIsDirty AndAlso _ClaimStatus.Id <> entity.ClaimStatusId Then
				_ClaimStatus = New ClaimStatus(entity.ClaimStatus)
				dataChanged = True
			End If

			'CaseFactsStatus
			If Not _StatusIsDirty AndAlso _Status.Id <> entity.StatusId Then
				_Status = New CaseFactsStatus(entity.Status)
				dataChanged = True
			End If

			'PBU
			If Not _PBUIsDirty AndAlso _PBU.Id <> entity.Pbuid Then
				_PBU = New PBU(entity.Pbu)
				dataChanged = True
			End If

			'SBU
			If Not _SBUIsDirty Then
				For Each sbuEntity As Case2SbuEntity In entity.Case2Sbu
					dataChanged = dataChanged Or AddSBU(New SBU(sbuEntity.Sbu))
				Next
				sbuCollection = entity.Case2Sbu
				dataChanged = dataChanged Or _SBU.RemoveAll(New Predicate(Of ISBU)(AddressOf FindSBUsToRemove)) > 0
			End If


			'Confirmed By Supplier
			If Not _ConfirmedBySupplierIsDirty AndAlso _ConfirmedBySupplier <> entity.ConfirmedBySupplier Then
				_ConfirmedBySupplier = entity.ConfirmedBySupplier
				dataChanged = True
			End If

			'Sales Option
			If Not _SalesOptionIsDirty AndAlso _SalesOption <> entity.SalesOption Then
				_SalesOption = entity.SalesOption
				dataChanged = True
			End If

			' Closed for invoicing
			If Not _ClosedForInvoicingIsDirty AndAlso _ClosedForInvoicing <> entity.ClosedForInvoicing Then
				_ClosedForInvoicing = entity.ClosedForInvoicing
				_ClosedForInvoicingIsDirty = True
			End If

			Return dataChanged
		End Function

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long Implements ICase.Id
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Created By
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property CreatedBy() As IParticipant 'Implements ICase.CreatedBy
			Get
				Return _CreatedBy
			End Get
		End Property

		''' <summary>
		''' Number
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Number() As Nullable(Of Long) Implements ICase.Number
			Get
				Return _Number
			End Get
		End Property

		Public ReadOnly Property CaseNo() As Long Implements ICaseSimple.CaseNo
			Get
				Return Number.Value
			End Get
		End Property

		Public ReadOnly Property ExecutionManagerId() As Long Implements ICaseSimple.ExecutionManagerId
			Get
				Return _ExecutionManager.Id
			End Get
		End Property

		Public ReadOnly Property TechnicalSpecialistId() As Long Implements ICaseSimple.TechnicalSpecialistId
			Get
				Return _TechnicalSpecialist.Id
			End Get
		End Property

		Public ReadOnly Property ManagerId() As Long Implements ICaseSimple.ManagerId
			Get
				Return _Manager.Id
			End Get
		End Property

		Public ReadOnly Property StatusChangedDate() As Date? Implements ICaseSimple.StatusChangedDate
			Get
				Throw New NotImplementedException()
			End Get
		End Property

		''' <summary>
		''' Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Manager() As IParticipant Implements ICase.Manager
			Get
				Return _Manager
			End Get
			Set(ByVal value As IParticipant)
				If _Manager.Id <> value.Id Then
					_Manager = value
					_ManagerIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Technical Specialist
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property TechnicalSpecialist() As IParticipant Implements ICase.TechnicalSpecialist
			Get
				Return _TechnicalSpecialist
			End Get
			Set(ByVal value As IParticipant)
				If Not Equals(_TechnicalSpecialist, value) Then
					_TechnicalSpecialist = value
					_TechnicalSpecialistIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Execution Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ExecutionManager() As IParticipant Implements ICase.ExecutionManager
			Get
				Return _ExecutionManager
			End Get
			Set(ByVal value As IParticipant)
				If Not Equals(_ExecutionManager, value) Then
					_ExecutionManager = value
					_ExecutionManagerIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Platform
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Platform() As DataLayer.Interfaces.IPlatform Implements ICase.Platform
			Get
				Return _Platform
			End Get
			Set(ByVal value As DataLayer.Interfaces.IPlatform)
				If Not Equals(_Platform, value) Then
					_Platform = value
					_PlatformIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Description() As String Implements ICase.Description
			Get
				Return _Description
			End Get
			Set(ByVal value As String)
				If _Description <> value Then
					_Description = value
					_DescriptionIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Cleans the Description for VbCrLf's.
		''' </summary>
		''' <value></value>
		''' <returns>The carriage- and linefeed-free description.</returns>
		''' <remarks></remarks>
		Public ReadOnly Property CarriageFreeDescription() As String
			Get
				Try
					Return Description.Replace(vbCrLf, " ")
				Catch ex As NullReferenceException
					Return Description
				End Try
			End Get
		End Property

		Public Property Phase() As IPhase Implements ICase.Phase
			Get
				Return _Phase
			End Get
			Set(ByVal value As IPhase)
				If Not Equals(_Phase, value) Then
					_Phase = value
					_PhaseIsDirty = True
				End If
			End Set
		End Property

		Public ReadOnly Property PhaseBudgets() As List(Of IPhaseBudget) Implements ICase.PhaseBudgets
			Get
				Return _PhaseBudget
			End Get
		End Property

		''' <summary>
		''' Add PhaseBudget
		''' </summary>
		''' <param name="phaseBudget"></param>
		''' <remarks></remarks>
		Public Sub AddPhaseBudget(ByVal phaseBudget As IPhaseBudget) Implements ICase.AddPhaseBudget
			_PhaseBudget.Add(phaseBudget)
		End Sub

		''' <summary>
		''' Claim CaseFactsStatus
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ClaimStatus() As IClaimStatus Implements ICase.ClaimStatus
			Get
				Return _ClaimStatus
			End Get
			Set(ByVal value As IClaimStatus)
				If Not Equals(_ClaimStatus, value) Then
					_ClaimStatus = value
					_ClaimStatusIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' CaseFactsStatus
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Status() As ICaseFactsStatus Implements ICase.Status
			Get
				Return _Status
			End Get
			Set(ByVal value As ICaseFactsStatus)
				If Not Equals(_Status, value) Then
					_Status = value
					_StatusIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' PBU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property PBU() As IPBU Implements ICase.PBU
			Get
				Return _PBU
			End Get
			Set(ByVal value As IPBU)
				If Not Equals(_PBU, value) Then
					_PBU = value
					_PBUIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Portfolio
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Portfolio() As IPortfolio Implements ICase.Portfolio
			Get
				Return _Portfolio
			End Get
			Set(ByVal value As IPortfolio)
				If Not Equals(_Portfolio, value) Then
					_Portfolio = value
					_PortfolioIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' SBU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SBU() As List(Of ISBU) Implements ICase.SBU
			Get
				Return _SBU
			End Get
		End Property

		''' <summary>
		''' Add SBU
		''' </summary>
		''' <param name="sbu"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function AddSBU(ByVal sbu As ISBU) As Boolean Implements ICase.AddSBU
			sbuToFind = sbu
			Dim mySBU As ISBU = _SBU.Find(New Predicate(Of ISBU)(AddressOf FindSBU))
			If mySBU Is Nothing Then
				_SBU.Add(sbu)
				_SBUIsDirty = True
			End If
			Return mySBU Is Nothing
		End Function

        ''' <summary>
        ''' Remove SBU
        ''' </summary>
        ''' <param name="sbu"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function RemoveSBU(ByVal sbu As ISBU) As Boolean Implements ICase.RemoveSBU
            sbuToFind = sbu
            Dim mySBU As ISBU = _SBU.Find(New Predicate(Of ISBU)(AddressOf FindSBU))
            If mySBU IsNot Nothing Then
                _SBU.Remove(mySBU)
                _SBUIsDirty = True
            End If
            Return mySBU IsNot Nothing
        End Function

        ''' <summary>
        ''' Find SBU
        ''' </summary>
        ''' <param name="sbu"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function FindSBU(ByVal sbu As ISBU) As Boolean
            Return sbuToFind.Id = sbu.Id And sbuToFind.Name = sbu.Name
        End Function

        ''' <summary>
        ''' Find SBUs To Remove
        ''' </summary>
        ''' <param name="sbu"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function FindSBUsToRemove(ByVal sbu As ISBU) As Boolean
            Return sbuCollection.FindMatches(Case2SbuFields.Sbuid = sbu.Id).Count = 0
        End Function

        ''' <summary>
        ''' Find Phase Budget
        ''' </summary>
        ''' <param name="phaseBudget"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function FindPhaseBudget(ByVal phaseBudget As IPhaseBudget) As Boolean
            Return phaseBudgetToFind.Id = phaseBudget.Id
        End Function

        ''' <summary>
        ''' Find Phase Budgets To Remove
        ''' </summary>
        ''' <param name="phaseBudget"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function FindPhaseBudgetsToRemove(ByVal phaseBudget As IPhaseBudget) As Boolean
            Return phaseBudgetCollection.FindMatches(Case2PhaseFields.Case2PhaseId = phaseBudget.Id).Count = 0
        End Function

        ''' <summary>
        ''' Find Case
        ''' </summary>
        ''' <param name="case"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function FindCase(ByVal [case] As [ICase]) As Boolean
            Return caseToFind.Id = [case].Id
        End Function

        ''' <summary>
        ''' IsNew
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property IsNew() As Boolean
            Get
                Return _Id = -1
            End Get
        End Property

        ''' <summary>
        ''' Confirmed By Supplier
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ConfirmedBySupplier() As Boolean Implements ICase.ConfirmedBySupplier
            Get
                Return _ConfirmedBySupplier
            End Get
            Set(ByVal value As Boolean)
                If _ConfirmedBySupplier <> value Then
                    _ConfirmedBySupplier = value
                    _ConfirmedBySupplierIsDirty = True
                End If
            End Set
        End Property

        ''' <summary>
        ''' Sales Option
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SalesOption() As Boolean Implements ICase.SalesOption
            Get
                Return _SalesOption
            End Get
            Set(ByVal value As Boolean)
                If _SalesOption <> value Then
                    _SalesOption = value
                    _SalesOptionIsDirty = True
                End If
            End Set
        End Property

        ''' <summary>
        ''' Closed for invoicing
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ClosedForInvoicing() As Boolean Implements ICase.ClosedForInvoicing
            Get
                Return _ClosedForInvoicing
            End Get
            Set(ByVal value As Boolean)
                If _ClosedForInvoicing <> value Then
                    _ClosedForInvoicing = value
                    _ClosedForInvoicingIsDirty = True
                End If
            End Set
        End Property

        ''' <summary>
        ''' ProjectPortalId
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property ProjectPortalId() As Integer Implements ICase.ProjectPortalId
            Get
                Return _ProjectPortalId
            End Get
        End Property

        ''' <summary>
        ''' IsDirty
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property IsDirty() As Boolean Implements ICase.IsDirty
            Get
                Dim _PhaseBudgetIsDirty As Boolean
                For Each phaseBudget As PhaseBudget In _PhaseBudget
                    _PhaseBudgetIsDirty = _PhaseBudgetIsDirty Or phaseBudget.IsDirty
                Next
                Return _ManagerIsDirty Or
                       _TechnicalSpecialistIsDirty Or
                       _ExecutionManagerIsDirty Or
                       _ParentCaseIsDirty Or
                       _DescriptionIsDirty Or
                       _PhaseIsDirty Or
                       _StandardTaskIsDirty Or
                       _PhaseBudgetIsDirty Or
                       _ClaimStatusIsDirty Or
                       _StatusIsDirty Or
                       _PBUIsDirty Or
                       _SBUIsDirty Or
                       _ConfirmedBySupplierIsDirty Or
                       _SalesOptionIsDirty Or
                       _ClosedForInvoicingIsDirty Or
                       _PlatformIsDirty Or
                       _PortfolioIsDirty Or
                       _BusinessProcessIsDirty Or
                       IsNew
            End Get
        End Property

        Public Property BusinessProcessid() As Long Implements ICase.BusinessProcessid
            Get
                Return _businessProcessId
            End Get
            Set(ByVal value As Long)
                If _businessProcessId <> value Then
                    _businessProcessId = value
                    _BusinessProcessIsDirty = True
                End If
            End Set
        End Property

        Public Property StandardTask() As StandardTask Implements ICase.StandardTask
            Get
                Return _standardTask
            End Get
            Set(ByVal value As StandardTask)
                If Not Equals(_standardTask, value) Then
                    _standardTask = value
                    _StandardTaskIsDirty = True
                End If
            End Set
        End Property

        ''' <summary>
        ''' Case Category
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CaseCategory() As ICaseCategory Implements ICase.CaseCategory
            Get
                Return _CaseCategory
            End Get
            Set(ByVal value As ICaseCategory)
                If Not Equals(_CaseCategory, value) Then
                    _CaseCategory = value
                End If
            End Set
        End Property

        ''' <summary>
        ''' Component
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Component() As IComponent Implements ICase.Component
            Get
                Return _Component
            End Get
            Set(ByVal value As IComponent)
                If Not Equals(_Component, value) Then
                    _Component = value
                End If
            End Set
        End Property

        ''' <summary> PKB CO 74840 PS
        ''' Project Scope
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ProjectScope() As IProjectScope Implements ICase.ProjectScope
            Get
                Return _ProjectScope
            End Get
            Set(ByVal value As IProjectScope)
                If Not Equals(_ProjectScope, value) Then
                    _ProjectScope = value
                End If
            End Set
        End Property

        ''' <summary>
        ''' Personal Safety
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PersonalSafety() As IPersonalSafety Implements ICase.PersonalSafety
            Get
                Return _PersonalSafety
            End Get
            Set(ByVal value As IPersonalSafety)
                If Not Equals(_PersonalSafety, value) Then
                    _PersonalSafety = value
                End If
            End Set
        End Property

        Public Property SafetyAlert() As String Implements ICase.SafetyAlert
        Public Property Bleeding() As String Implements ICase.Bleeding
        Public Property EcoNumber() As String Implements ICase.ECONumber
        Public Property Dmsdocument() As String Implements ICase.Dmsdocument
	End Class
End Namespace
