﻿Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
	Public NotInheritable Class CaseCategory
		Implements ICaseCategory

		Private ReadOnly _CategoryId As Integer
		Private ReadOnly _Name As String
		Private ReadOnly _CreatedById As Long
		Private ReadOnly _Created As DateTime
		Private ReadOnly _DeletedById As Nullable(Of Long)
		Private ReadOnly _Deleted As Nullable(Of DateTime)

		Public Sub New(ByVal entity As CategoryEntity)
			_CategoryId = entity.CategoryId
			_Name = entity.Name
			_CreatedById = entity.CreatedById
			_Created = entity.Created
			_DeletedById = entity.DeletedById
			_Deleted = entity.Deleted
		End Sub


		Public ReadOnly Property CategoryId() As Integer Implements ICaseCategory.CategoryId
			Get
				Return _CategoryId
			End Get
		End Property

		Public ReadOnly Property Name() As String Implements ICaseCategory.Name
			Get
				Return _Name
			End Get
		End Property

		Public ReadOnly Property CreatedById() As Long Implements ICaseCategory.CreatedById
			Get
				Return _CreatedById
			End Get
		End Property

		Public ReadOnly Property Created() As Date Implements ICaseCategory.Created
			Get
				Return _Created
			End Get
		End Property

		Public ReadOnly Property DeletedById() As Nullable(Of Long) Implements ICaseCategory.DeletedById
			Get
				Return _DeletedById
			End Get
		End Property

		Public ReadOnly Property Deleted() As Nullable(Of DateTime) Implements ICaseCategory.Deleted
			Get
				Return _Deleted
			End Get
		End Property
	End Class
End Namespace
