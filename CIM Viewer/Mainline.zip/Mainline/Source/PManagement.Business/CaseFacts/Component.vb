﻿Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
	Public NotInheritable Class Component
		Implements IComponent

		Private ReadOnly _ComponentId As Long
		Private ReadOnly _Name As String
		Private ReadOnly _CreatedById As Long
		Private ReadOnly _Created As DateTime
		Private ReadOnly _DeletedById As Nullable(Of Long)
        Private ReadOnly _Deleted As Nullable(Of DateTime)
        ' PKB 74840 CO
        'Private ReadOnly _ComponentOwnerId As Nullable(Of Long)


		Public Sub New(ByVal entity As ComponentEntity)
			_ComponentId = entity.ComponentId
			_Name = entity.Name
			_CreatedById = entity.CreatedById
			_Created = entity.Created
			_DeletedById = entity.DeletedById
            _Deleted = entity.Deleted
            ' PKB 74840 CO
            '_ComponentOwnerId = entity.ComponentOwnerId
		End Sub


		Public ReadOnly Property ComponentId() As Long Implements IComponent.ComponentId
			Get
				Return _ComponentId
			End Get
		End Property

		Public ReadOnly Property Name() As String Implements IComponent.Name
			Get
				Return _Name
			End Get
		End Property

		Public ReadOnly Property CreatedById() As Long Implements IComponent.CreatedById
			Get
				Return _CreatedById
			End Get
		End Property

		Public ReadOnly Property Created() As Date Implements IComponent.Created
			Get
				Return _Created
			End Get
		End Property

		Public ReadOnly Property DeletedById() As Nullable(Of Long) Implements IComponent.DeletedById
			Get
				Return _DeletedById
			End Get
		End Property

		Public ReadOnly Property Deleted() As Nullable(Of DateTime) Implements IComponent.Deleted
			Get
				Return _Deleted
			End Get
        End Property

        '' PKB 74840 CO
        'Public ReadOnly Property ComponentOwnerId() As Nullable(Of Long) Implements IComponent.ComponentOwnerId
        '    Get
        '        Return _ComponentOwnerId
        '    End Get
        'End Property

	End Class
End Namespace
