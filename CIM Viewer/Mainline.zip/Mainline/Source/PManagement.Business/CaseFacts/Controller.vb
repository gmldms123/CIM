Imports PManagement.Business.Document
Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.Business.Caching
Imports PManagement.DataLayer
Imports PManagement.ModelLayer.Performance.Enums
Imports PManagement.DataLayer.CaseFacts
Imports PManagement.DataLayer.DbBasedModel.CaseFacts
Imports PManagement.DataLayer.Interfaces
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.ServiceLayer.Services.Implementations.Performance
Imports PManagement.BusinessLayer.Services.Interfaces
Imports PManagement.BusinessLayer.Factories.Interfaces
Imports PManagement.ServiceLayer.Services.Interfaces.Visits
Imports PManagement.DataLayer.ProjectPlanTemplate
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace CaseFacts
	''' <summary>
	''' Manage all interaction with relation data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model

		Private _DocController As Document.Controller
		Private _RTController As RelevantTurbine.Controller

		Private _FindName As String

		Private ReadOnly _CasePrefetchPath As New PrefetchPath2(DirectCast(EntityType.CaseEntity, Integer))
		Private ReadOnly _BusinessProcessLogicFactory As IBusinessProcessLogicFactory
		Private ReadOnly _BusinessLogicService As IBusinessLogicService
		Private ReadOnly _PerformanceGeneralService As PerformanceGeneralService

		'Alert
		Private _changeLogService As IChangeLogService

		'Visits
		Private _visitsService As IVisitsService

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Dim IsRTModelDirty As Boolean = False

				If _RTController IsNot Nothing Then
					IsRTModelDirty = _RTController.IsDirty
				End If

				Return IsRTModelDirty Or _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Shadows Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                              ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model,
		                              ByRef documentController As Document.Controller,
		                              ByRef relevantTurbineController As RelevantTurbine.Controller)
			_Model = DirectCast(model, Model)

			_DocController = documentController
			_RTController = relevantTurbineController

			'Alert
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
			ObjectFactory.GetInstance (Of IChangeTypeService)()

			_visitsService = ObjectFactory.GetInstance (Of IVisitsService)()
			MyBase.Initialize(environment, context, accesscontrol, model)

			' force a load of projects, phases and statuses (necessary e.g. for creating a new case)
			'      Dim count As Integer
			'      count = Phases.Count
			'      count = StandardTasks.Count
			'      count = Statuses.Count

			AddHandler _Environment.EnvironmentChanged, AddressOf EnvironmentChanged
			EnvironmentChanged()
		End Sub

		''' <summary>
		''' Environment Changed
		''' </summary>
		''' <remarks></remarks>
		Private Sub EnvironmentChanged()
			'      _ProjectWebService = New wsProjectPortal.ProjectWebService(_Environment.ProjectPortal_WebService_URL)
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New()
			_BusinessProcessLogicFactory = ObjectFactory.GetInstance (Of IBusinessProcessLogicFactory)()
			_BusinessLogicService = ObjectFactory.GetInstance (Of IBusinessLogicService)()
			_PerformanceGeneralService = ObjectFactory.GetInstance (Of PerformanceGeneralService)()
			ObjectFactory.GetInstance (Of PerformanceDataService)()
			ObjectFactory.GetInstance (Of PerformanceActionService)()

			_CasePrefetchPath.Add(CaseEntity.PrefetchPathManagerParticipant)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathTechnicalSpecialistParticipant)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathExecutionManagerParticipant)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathPhase)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathStandardTask)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathCase2Phase).SubPath.Add(Case2PhaseEntity.PrefetchPathPhase)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathClaimStatus)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathStatus)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathTimeline).SubPath.Add(
				TimelineEntity.
			                                                                  	PrefetchPathChangedByParticipant)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathPbu)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathCase2Sbu).SubPath.Add(Case2SbuEntity.PrefetchPathSbu)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathPlatform_).SubPath.Add(PlatformEntity.PrefetchPathParticipant)

			_CasePrefetchPath.Add(CaseEntity.PrefetchPathCreatedByParticipant)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathPortfolio)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathCategory)
            _CasePrefetchPath.Add(CaseEntity.PrefetchPathComponent)
            ' PKB 74840 PS
            _CasePrefetchPath.Add(CaseEntity.PrefetchPathProjectScope)
			_CasePrefetchPath.Add(CaseEntity.PrefetchPathPersonalSafety)

			'Parent Case
			Dim _
				ppeParent As PrefetchPathElement2 =
					DirectCast(_CasePrefetchPath.Add(CaseEntity.PrefetchPathParentCase), PrefetchPathElement2)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathManagerParticipant)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathTechnicalSpecialistParticipant)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathExecutionManagerParticipant)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathPhase)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathStandardTask)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathClaimStatus)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathStatus)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathPbu)
			ppeParent.SubPath.Add(CaseEntity.PrefetchPathCreatedByParticipant)

			'Child Cases
			Dim _
				ppeChild As PrefetchPathElement2 =
					DirectCast(_CasePrefetchPath.Add(CaseEntity.PrefetchPathChildCase), PrefetchPathElement2)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathManagerParticipant)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathTechnicalSpecialistParticipant)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathExecutionManagerParticipant)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathPhase)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathStandardTask)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathClaimStatus)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathStatus)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathPbu)
			ppeChild.SubPath.Add(CaseEntity.PrefetchPathCreatedByParticipant)
		End Sub

		''' <summary>
		''' Create New Case
		''' </summary>
		''' <remarks></remarks>
		Public Sub CreateNewCase()
			Dim portfolio As Portfolio = Nothing
			If _Context.InitialPortfolioId.HasValue Then _
				portfolio = Portfolios.FirstOrDefault(Function(p As Portfolio) (p.Id = _Context.InitialPortfolioId.Value))

			Dim businessProcessId As Integer = _BusinessLogicService.GetIdOfBusinessProcessToUseForNewCases()
			Dim businessProcessLogicService As IBusinessProcessLogicService =
			    	_BusinessProcessLogicFactory.GetBusinessProcessLogicByBusinessProcessId(businessProcessId)

			_Model.Inject(businessProcessLogicService.GetAllPhases())
			_Model.Inject(businessProcessLogicService.GetAllStandardTasks())

			Dim initialPhase As IPhase = businessProcessLogicService.GetInitialPhaseForNewCase()
			Dim initialStandardTask As StandardTask = businessProcessLogicService.GetInitialStandardTaskForNewCase()
			Dim initialStatus As ICaseFactsStatus = businessProcessLogicService.GetInitialStatusForNewCase()

			_Model.CreateNewCase(portfolio, initialPhase, initialStandardTask, initialStatus, businessProcessId)
			'Dim portfolio As wsProjectPortal.Portfolio = Nothing
			'If _Context.InitialPortfolioId.HasValue Then portfolio = ProjectWebService.GetPortfolio(Integer.Parse(_Context.InitialPortfolioId.Value.ToString()))
			'_Model.CreateNewCase(portfolio)
		End Sub

		''' <summary>
		''' Reopen Case
		''' </summary>
		''' <remarks></remarks>
		Public Sub ReopenCase()
			_PerformanceGeneralService.ShouldPerformanceBeLogged(PerformanceActionEnum.ReactivateCaseInCIMEditor,
			                                                     _Context.UserParticipant.VestasInitials)
			Dim businessProcessId As Long = _Model.Case.BusinessProcessid
			Dim businessProcessLogicService As IBusinessProcessLogicService =
			    	_BusinessProcessLogicFactory.GetBusinessProcessLogicByBusinessProcessId(businessProcessId)
			Dim existingStateBeforeReopen As CaseProcessProgressState = New CaseProcessProgressState(_Model.Phase,
			                                                                                         _Model.StandardTask,
			                                                                                         _Model.Status)

			Dim caseProcessProgressStateAfterReopen As CaseProcessProgressState =
			    	businessProcessLogicService.GetReopenedCaseProcessProgressState(existingStateBeforeReopen)

			_Model.Phase = caseProcessProgressStateAfterReopen.Phase
			_Model.StandardTask = caseProcessProgressStateAfterReopen.StandardTask
			_Model.Status = caseProcessProgressStateAfterReopen.CaseFactsStatus

			Save()
		End Sub

		Public Function GetBusinessProcessLogic(ByVal BusinessProcessId As Long) As IBusinessProcessLogicService
			Dim res As IBusinessProcessLogicService =
			    	_BusinessProcessLogicFactory.GetBusinessProcessLogicByBusinessProcessId(BusinessProcessId)
			Return res
		End Function

		Public Function Phases(ByVal businessProcessId As Long) As IPhaseList
			If Not _Context.CaseId.HasValue Then
				Return New PhaseList()
			End If

			Return GetBusinessProcessLogic(businessProcessId).GetAllPhases()
		End Function

		Public ReadOnly Property BusinessProcessId() As Long
			Get
				Return _Model.BusinessProcessId
			End Get
		End Property

		Public Function GetStandardTasks(ByVal businessProcessId As Long) As StandardTaskList
			If _Model.StandardTasks Is Nothing OrElse _Model.StandardTasks.Count = 0 Then
				_Model.StandardTasks = GetBusinessProcessLogic(businessProcessId).GetAllStandardTasks()
			End If

			Return _Model.StandardTasks
		End Function

		''' <summary>
		''' Claim Statuses
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ClaimStatuses() As List(Of ClaimStatus)
			Get
				Dim li As New List(Of ClaimStatus)

				If _Context.Cache.ContainsItem("CaseFacts.ClaimStatuses") Then
					li.AddRange(_Context.Cache.GetItem (Of List(Of ClaimStatus))("CaseFacts.ClaimStatuses"))
				Else
					Dim ec As New EntityCollection(Of ClaimStatusEntity)(New ClaimStatusEntityFactory())
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)

						Try
							daa.FetchEntityCollection(ec, Nothing)
							_Model.InjectClaimStatus(ec)
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using

					For i As Integer = 0 To ec.Count - 1
						li.Add(New ClaimStatus(ec(i)))
					Next

					If li.Count > 0 Then
						' ClaimStatuses are not likely to change, use high TTL on cache
						_Context.Cache.SetItem("CaseFacts.ClaimStatuses", li, TimeToLive.High)
					End If
				End If

				Return li
			End Get
		End Property

		''' <summary>
		''' Statuses
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Statuses() As List(Of ICaseFactsStatus)
			Get
				If _Model.Statuses Is Nothing OrElse _Model.Statuses.Count = 0 Then
					Dim ec As New EntityCollection(Of StatusEntity)(New StatusEntityFactory())
					Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
					filter.PredicateExpression.Add(StatusFields.Deleted = DBNull.Value)
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Try
							daa.FetchEntityCollection(ec, filter)
							_Model.Inject(ec)
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using
				End If

				Return _Model.Statuses
			End Get
		End Property

		Public ReadOnly Property ApplicableStatuses() As List(Of ICaseFactsStatus)
			Get
				If Not _Context.CaseId.HasValue Then
					Return New List(Of ICaseFactsStatus)
				End If
				If Phase IsNot Nothing Then
					Return Statuses
					'Return Phases.Find (Function(p As Phase) (p.Id = Phase.Id)).ApplicableStatuses
				End If
				Return New List(Of ICaseFactsStatus)
			End Get
		End Property

		''' <summary>
		''' PBUs
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PBUs() As List(Of IPBU)
			Get
				Dim li As New List(Of IPBU)

				If _Context.Cache.ContainsItem("CaseFacts.PBUs") Then
					li.AddRange(_Context.Cache.GetItem (Of List(Of IPBU))("CaseFacts.PBUs"))
				Else
					Dim ec As New EntityCollection(Of PbuEntity)(New PbuEntityFactory())
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Try
							daa.FetchEntityCollection(ec, New RelationPredicateBucket(PbuFields.Deleted = DBNull.Value))
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using

					For i As Integer = 0 To ec.Count - 1
						li.Add(New PBU(ec(i)))
					Next

					If li.Count > 0 Then
						' PBU's are not likely to change, use high TTL on cache
						_Context.Cache.SetItem("CaseFacts.PBUs", li, TimeToLive.High)
					End If

				End If

				Return li
			End Get
		End Property

		''' <summary>
		''' SBUs
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SBUs() As List(Of SBU)
			Get
				Dim li As New List(Of SBU)

				If _Context.Cache.ContainsItem("CaseFacts.SBUs") Then
					li.AddRange(_Context.Cache.GetItem (Of List(Of SBU))("CaseFacts.SBUs"))
				Else
					Dim ec As New EntityCollection(Of SbuEntity)(New SbuEntityFactory())
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Try
							daa.FetchEntityCollection(ec, New RelationPredicateBucket(SbuFields.Deleted = DBNull.Value))
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using

					For i As Integer = 0 To ec.Count - 1
						li.Add(New SBU(ec(i)))
					Next

					If li.Count > 0 Then
						' SBU's are not likely to change, use high TTL on cache
						_Context.Cache.SetItem("CaseFacts.SBUs", li, TimeToLive.High)
					End If
				End If

				Return li
			End Get
		End Property

		Public Function GetCase() As ICase
			If _Context.CaseId.HasValue Then

				Dim entity As CaseEntity
				'Dim project As wsProjectPortal.Project = Nothing

				If _Context.Cache.ContainsItem("CaseFacts.Case." + _Context.CaseId.ToString()) Then
					entity = _Context.Cache.GetItem (Of CaseEntity)("CaseFacts.Case." + _Context.CaseId.ToString())
				Else
					entity = New CaseEntity(_Context.CaseId.Value)
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Try
							'Cut away unwanted timeline entries
							If Not _AccessControl.OperationIsLegal(Permissions.Viewer_Timeline_ViewFullTimeline) Then
								'Find prefetchpath for Timeline
                                Dim ppe As IPrefetchPathElement2 = Nothing
								For Each ppe In _CasePrefetchPath
									If ppe.PropertyName = "Timeline" Then
										Exit For
									End If
								Next

                                If ppe IsNot Nothing Then
                                    'Find entries that indicates that the case has been reopened and closed within 24 hours
                                    Dim fields As New ResultsetFields(3)
                                    fields.DefineField(TimelineFields.TimelineId, 0, TimelineFields.TimelineId.Name)
                                    fields.DefineField(TimelineFields.Changed, 1, TimelineFields.Changed.Name)
                                    fields.DefineField(TimelineFields.Changed, 2, "Changed2", "Timeline2")
                                    Dim filter As New RelationPredicateBucket()
                                    filter.Relations.Add(TimelineEntity.Relations.CaseEntityUsingCaseId)
                                    filter.PredicateExpression.AddWithOr(CaseFields.CaseId = _Context.CaseId.Value)
                                    filter.Relations.Add(CaseEntity.Relations.TimelineEntityUsingCaseId, "Timeline2")
                                    Dim subFilter As New RelationPredicateBucket()
                                    subFilter.PredicateExpression.Add(
                                     TimelineFields.Text Mod "Status changed from ""%"" to ""Closed""" And
                                     TimelineFields.Text.SetObjectAlias("Timeline2") Mod
                                     "Status changed from ""Closed"" to ""%""" And
                                     TimelineFields.Changed >=
                                     TimelineFields.Changed.SetObjectAlias("Timeline2"))
                                    subFilter.PredicateExpression.AddWithOr(
                                     TimelineFields.Text.SetObjectAlias("Timeline2") Mod
                                     "Status changed from ""%"" to ""Closed""" And
                                     TimelineFields.Text Mod
                                     "Status changed from ""Closed"" to ""%""" And
                                     TimelineFields.Changed.SetObjectAlias("Timeline2") >=
                                     TimelineFields.Changed)
                                    filter.PredicateExpression.Add(subFilter.PredicateExpression)
                                    Dim dynamicList As New DataTable()
                                    daa.FetchTypedList(fields, dynamicList, filter, 0, Nothing, False)

                                    Dim arrIds As New ArrayList()
                                    Dim arrDates As New ArrayList()
                                    For Each row As DataRow In dynamicList.Rows
                                        Dim changed1 As Date = DirectCast(row.Item(TimelineFields.Changed.Name), Date)
                                        Dim changed2 As Date = DirectCast(row.Item("Changed2"), Date)
                                        If _
                                         (changed1 <= changed2 AndAlso changed2 - changed1 <= New TimeSpan(1, 0, 0, 0)) Or
                                         (changed2 < changed1 AndAlso changed1 - changed2 <= New TimeSpan(1, 0, 0, 0)) Then
                                            arrIds.Add(row.Item(TimelineFields.TimelineId.Name))
                                            arrDates.Add(changed1)
                                        End If
                                    Next

                                    If Not arrIds.Count = 0 And Not arrDates.Count = 0 Then
                                        ppe.Filter.Add(
                                         TimelineFields.TimelineId <> arrIds And
                                         Not _
                                         (TimelineFields.Text Mod "Phase changed from ""%" And
                                          TimelineFields.Changed = arrDates))
                                    End If
                                End If
							End If

							daa.FetchEntity(entity, _CasePrefetchPath)
							_Context.Cache.SetItem("CaseFacts.Case." + _Context.CaseId.ToString(), entity)

							Select Case _Environment.Platform.ToString()
								Case "Windows"
									_visitsService.HandleVisits(daa, _Context.CaseId.Value, _Context.UserParticipant.ParticipantId, "editor")
								Case "Web"
									_visitsService.HandleVisits(daa, _Context.CaseId.Value, _Context.UserParticipant.ParticipantId, "viewer")
							End Select

						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Catch ex As Exception
							Console.WriteLine("")

						Finally
							daa.CloseConnection()
						End Try
					End Using
				End If
				If entity IsNot Nothing Then
					_Model.Inject(entity)
				End If
			End If
			Return _Model.Case
		End Function

		''' <summary>
		''' May Create Case
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayCreateCase() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_Create)
			End Get
		End Property

		''' <summary>
		''' May Reopen Case
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayReopenCase() As Boolean
			Get
				Return _Model.Case() IsNot Nothing AndAlso
				       IsClosed(Status) AndAlso
				       IsDirty = False AndAlso
				       _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_Reopen)
			End Get
		End Property

		''' <summary>
		''' May Change Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeManager() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeManager)
			End Get
		End Property

		''' <summary>
		''' May Change Technical Specialist
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeTechnicalSpecialist() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Casefacts_ChangeTechnicalSpecialist)
			End Get
		End Property

		''' <summary>
		''' May Remove Technical Specialist
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveTechnicalSpecialist() As Boolean
			Get
				If _Context.CaseId.HasValue Then
					Return IsPhase0(Phase)
				End If
				Return False
			End Get
		End Property

		Public ReadOnly Property MayChangeExecutionManager() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeExecutionManager)
			End Get
		End Property

		''' <summary>
		''' May Remove Execution Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveExecutionManager() As Boolean
			Get
				If _Context.CaseId.HasValue Then
					Return (IsStatusActive(Status) = False)
				End If
				Return False
			End Get
		End Property

		''' <summary>
		''' User May Change Platform
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangePlatform() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangePlatform)
			End Get
		End Property

		''' <summary>
		''' User May Change Portfolio
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangePortFolio() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_ProjectPortal_ChangePortfolio)
			End Get
		End Property

		''' <summary>
		''' May Change Description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeDescription() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeDescription)
			End Get
		End Property

		''' <summary>
		''' May Change Phase
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangePhase() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangePhase)
			End Get
		End Property

		''' <summary>
		''' May Change Phase Budget
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangePhaseBudget() As Boolean
			Get
				Return Not _Context.MSProjectIntegration AndAlso
				       _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangePhaseBudget)
			End Get
		End Property

		''' <summary>
		''' May Change Closed for invoicing
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeClosedForInvoicing() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeClosedForInvoicing)
			End Get
		End Property

		''' <summary>
		''' May Change Claim CaseFactsStatus
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeClaimStatus() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeClaimStatus)
			End Get
		End Property

		''' <summary>
		''' May Change CaseFactsStatus
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeStatus() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeStatus)
			End Get
		End Property

		''' <summary>
		''' May Change Claim Responsible PBU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeClaimResponsiblePBU() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeClaimResponsiblePBU)
			End Get
		End Property

		''' <summary>
		''' May Change SBU Relations
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeSBURelations() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeSBURelations)
			End Get
		End Property

		''' <summary>
		''' May Change Failed Turbine
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeFailedTurbine() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeFailedTurbineUnit)
			End Get
		End Property

		''' <summary>
		''' May Change Failed Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeFailedItem() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeFailedItem) AndAlso
				       _RTController.Turbines.Count > 0
			End Get
		End Property

		''' <summary>
		''' May Change Root Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeRootItem() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeRootItem)
			End Get
		End Property

		''' <summary>
		''' May Change Confirmed By Supplier
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeConfirmedBySupplier() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeConfirmedBySupplier)
			End Get
		End Property

		''' <summary>
		''' May Change Sales Option
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeSalesOption() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_CaseFacts_ChangeSalesOption)
			End Get
		End Property

		''' <summary>
		''' Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Manager() As IParticipant
			Get
				Return _Model.Manager
			End Get
			Set(ByVal value As IParticipant)
				_Model.Manager = value
			End Set
		End Property

		''' <summary>
		''' Technical Specialist
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property TechnicalSpecialist() As IParticipant
			Get
				Return _Model.TechnicalSpecialist
			End Get
			Set(ByVal value As IParticipant)
				_Model.TechnicalSpecialist = value
			End Set
		End Property

		''' <summary>
		''' Execution Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ExecutionManager() As IParticipant
			Get
				Return _Model.ExecutionManager
			End Get
			Set(ByVal value As IParticipant)
				_Model.ExecutionManager = value
			End Set
		End Property

		' ''' <summary>
		' ''' Parent Case
		' ''' </summary>
		' ''' <value></value>
		' ''' <returns></returns>
		' ''' <remarks></remarks>
		'Public ReadOnly Property ParentCase() As [ICase]
		'	Get
		'		Return _Model.ParentCase
		'	End Get
		'End Property

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <remarks></remarks>
		Public WriteOnly Property Description() As String
			Set(ByVal value As String)
				_Model.Description = value
			End Set
		End Property

		''' <summary>
		''' Find CaseFactsStatus By Name
		''' </summary>
		''' <param name="status"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function FindStatusByName(ByVal status As ICaseFactsStatus) As Boolean
			Return status.Name = _FindName
		End Function

		''' <summary>
		''' Phase
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Phase() As IPhase
			Get
				Return _Model.Phase
			End Get
			Set(ByVal value As IPhase)

				'        If IsPhase0(value) = False Then
				'          If _Model.Case.TechnicalSpecialist Is Nothing Then
				'            Throw New InvalidCaseConfigurationException(InvalidCaseConfiguration.MissingTechnicalSpecialist)
				'          End If
				'
				'        End If

				'        If ApplicableStatuses.Count = 0 Then
				'          Throw New ApplicationException("No applicable statuses found in phase " + value.ToString())
				'        End If
				'
				'        ' always set the CaseFactsStatus of the case to the first applicable CaseFactsStatus for the phase
				'        Status = ApplicableStatuses(0)
				'If (value.ApplicableStatuses.Find(Function(s As CaseFactsStatus) (s.Id = CaseFactsStatus.Id)) Is Nothing) Then
				'  _Model.CaseFactsStatus = value.ApplicableStatuses(0)
				'End If

				' must set closed for invoicing to false when leaving phase 1
				If value.Sort > 1 AndAlso _Model.Phase.Sort <= 1 Then
					ClosedForInvoicing = False
				End If
				'If IsPhase0(value) = False AndAlso IsPhase0(_Model.Phase) Then
				'  ClosedForInvoicing = False
				'End If

				_Model.Phase = value
			End Set
		End Property

		Private Function IsPhase0(ByVal phase As IPhase) As Boolean
			Return (phase.Sort = 0)
		End Function

		Public Property StandardTask() As StandardTask
			Get
				Return _Model.StandardTask
			End Get
			Set(ByVal value As StandardTask)
				_Model.StandardTask = value
			End Set
		End Property

		''' <summary>
		''' Claim CaseFactsStatus
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ClaimStatus() As IClaimStatus
			Get
				Return _Model.ClaimStatus
			End Get
			Set(ByVal value As IClaimStatus)
				_Model.ClaimStatus = value
			End Set
		End Property

		''' <summary>
		''' Find Phase By Name
		''' </summary>
		''' <param name="phase"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function FindPhaseByName(ByVal phase As IPhase) As Boolean
			Return phase.Name = _FindName
		End Function

		''' <summary>
		''' CaseFactsStatus
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Status() As ICaseFactsStatus
			Get
				Return _Model.Status
			End Get
			Set(ByVal value As ICaseFactsStatus)
				_Model.Status = value
			End Set
		End Property

		Friend Shared Function IsClosed(ByVal status As ICaseFactsStatus) As Boolean
			If IsStatusClosed(status) OrElse IsStatusSolved(status) Then
				Return True
			End If
			Return False
		End Function

		Private Shared Function IsStatusActive(ByVal status As ICaseFactsStatus) As Boolean
			Return (status.Name.ToLower() = "active")
		End Function

		Private Shared Function IsStatusClosed(ByVal status As ICaseFactsStatus) As Boolean
			Return (status.Name.ToLower() = "closed")
		End Function

		Private Shared Function IsStatusSolved(ByVal status As ICaseFactsStatus) As Boolean
			Return (status.Name.ToLower() = "solved")
		End Function

		'    Private Shared Function IsStatusStandby(ByVal status As ICaseFactsStatus) As Boolean
		'      Return (status.Name.ToLower() = "standby")
		'    End Function

		''' <summary>
		''' PBU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property PBU() As IPBU
			Get
				Return _Model.PBU
			End Get
			Set(ByVal value As IPBU)
				_Model.PBU = value
			End Set
		End Property

		''' <summary>
		''' Platform
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Platform() As IPlatform
			Get
				Return _Model.Platform
			End Get
			Set(ByVal value As IPlatform)
				_Model.Platform = value
			End Set
		End Property

		Public Property Portfolio() As IPortfolio
			Get
				Return _Model.Portfolio
			End Get
			Set(ByVal value As IPortfolio)
				_Model.Portfolio = value
			End Set
		End Property

		''' <summary>
		''' SBU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SBU() As List(Of ISBU)
			Get
				Return _Model.SBU
			End Get
		End Property

		''' <summary>
		''' Add SBU
		''' </summary>
		''' <param name="sbu"></param>
		''' <remarks></remarks>
		Public Sub AddSBU(ByVal sbu As ISBU)
			_Model.AddSBU(sbu)
		End Sub

		''' <summary>
		''' Remove SBU
		''' </summary>
		''' <param name="sbu"></param>
		''' <remarks></remarks>
		Public Sub RemoveSBU(ByVal sbu As ISBU)
			_Model.RemoveSBU(sbu)
		End Sub

		''' <summary>
		''' Update PHase Budget
		''' </summary>
		''' <param name="phaseBudget"></param>
		''' <param name="newPhaseBudget"></param>
		''' <remarks></remarks>
		Public Sub UpdatePhaseBudget(ByVal phaseBudget As IPhaseBudget, ByVal newPhaseBudget As IPhaseBudget)
			_Model.UpdatePhaseBudget(phaseBudget, newPhaseBudget)
		End Sub

		''' <summary>
		''' Confirmed By Supplier
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ConfirmedBySupplier() As Boolean
			Get
				Return _Model.ConfirmedBySupplier
			End Get
			Set(ByVal value As Boolean)
				_Model.ConfirmedBySupplier = value
			End Set
		End Property

		''' <summary>
		''' Sales Option
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property SalesOption() As Boolean
			Get
				Return _Model.SalesOption
			End Get
			Set(ByVal value As Boolean)
				_Model.SalesOption = value
			End Set
		End Property

		''' <summary>
		''' Closed for invoicing
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ClosedForInvoicing() As Boolean
			Get
				Return _Model.ClosedForInvoicing
			End Get
			Set(ByVal value As Boolean)
				_Model.ClosedForInvoicing = value
			End Set
		End Property

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			'Persist to database
			Dim validationSummary As New ValidationSummary
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					If Not IsDirty Then
						Return validationSummary
					End If
					Dim sbErrors As StringBuilder = CheckInput()
					If sbErrors.Length > 0 Then Throw New ApplicationException(sbErrors.ToString())

					'Date to be used below as changed date
					Dim _Now As Date = Date.UtcNow


					''Get Uplink (parent case)
					'Dim uplink As Integer = 0
					'If _Model.Case.ParentCase IsNot Nothing Then
					'	uplink = _Model.Case.ParentCase.ProjectPortalId
					'End If

					'Project Portal project
					'Dim wsProject As wsProjectPortal.Project = Nothing

					daa.StartTransaction(IsolationLevel.Serializable, "CaseFactsTransaction")

					Dim entity As CaseEntity

					If _Context.CreatingNewCase Then
						entity = SaveNewCimCase(daa, _Now)

					Else
						'Update existing case

						'Fetch case information
						entity = New CaseEntity(_Context.CaseId.Value)
						daa.FetchEntity(entity, _CasePrefetchPath)

						'Fill in standard fields from case
						UpdateEntity(entity, _Now)

						'Fetch Project Portal project
						'wsProject = ProjectWebService.ReadProject(entity.ProjectPortalId)

						'ProjectManager changed
						If (_Model.OriginalProjectManager Is Nothing AndAlso _Model.Case.Manager IsNot Nothing) Or
						   (_Model.OriginalProjectManager IsNot Nothing AndAlso _Model.Case.Manager Is Nothing) Or
						   (_Model.OriginalProjectManager IsNot Nothing AndAlso _Model.Case.Manager IsNot Nothing AndAlso
						    _Model.OriginalProjectManager.Id <> _Model.Case.Manager.Id) Then

							'ChangeLog for ProjectManager
							Dim beforeValue As String = String.Empty
							If _Model.OriginalExecutionManager IsNot Nothing Then
								beforeValue = _Model.OriginalProjectManager.Id.ToString()
							End If
							Dim afterValue As String = String.Empty
							If _Model.Case.Manager IsNot Nothing Then
								afterValue = _Model.Case.Manager.Id.ToString()
							End If
							Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
							                                                                _Context.UserParticipant.ParticipantId,
							                                                                ChangeTypeEnum.ProjectManagerChange, beforeValue,
							                                                                afterValue, Nothing)
							validationSummary.AddValidationSummary(vs)
						End If

						'ExecutionManager changed
						If (_Model.OriginalExecutionManager Is Nothing AndAlso _Model.Case.ExecutionManager IsNot Nothing) Or
						   (_Model.OriginalExecutionManager IsNot Nothing AndAlso _Model.Case.ExecutionManager Is Nothing) Or
						   (_Model.OriginalExecutionManager IsNot Nothing AndAlso _Model.Case.ExecutionManager IsNot Nothing AndAlso
						    _Model.OriginalExecutionManager.Id <> _Model.Case.ExecutionManager.Id) Then

							'ChangeLog for ProjectManager
							Dim beforeValue As String = String.Empty
							If _Model.OriginalExecutionManager IsNot Nothing Then
								beforeValue = _Model.OriginalExecutionManager.Id.ToString()
							End If
							Dim afterValue As String = String.Empty
							If _Model.Case.ExecutionManager IsNot Nothing Then
								afterValue = _Model.Case.ExecutionManager.Id.ToString()
							End If
							Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
							                                                                _Context.UserParticipant.ParticipantId,
							                                                                ChangeTypeEnum.ExecutionManagerChange,
							                                                                beforeValue, afterValue, Nothing)
							validationSummary.AddValidationSummary(vs)
						End If

						'CaseFactsStatus changed
						If _Model.OriginalStatus.Id <> _Model.Case.Status.Id Then

							'ChangeLog for Status
							Dim beforeValue As String = _Model.OriginalStatus.Id.ToString()
							Dim afterValue As String = _Model.Case.Status.Id.ToString()
							Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
							                                                                _Context.UserParticipant.ParticipantId,
							                                                                ChangeTypeEnum.StatusChange, beforeValue,
							                                                                afterValue, Nothing)
							validationSummary.AddValidationSummary(vs)

							'Update StateChangedDate
							entity.StateChangedDate = _Now

							'spnpNewsChannel = PostNewsAboutUpdatingExistingCimCase(spnpController, spnpNewsChannel)

							'Update Project Portal project
							'wsProject.ProjectStatus = Array.Find(Of wsProjectPortal.ProjectStatus)(ProjectWebService.GetProjectStatusList(), New System.Predicate(Of wsProjectPortal.ProjectStatus)(AddressOf FindStatus))

							'Post news
						End If

						'Phase changed

						Dim secondlevelChanged As Boolean = False
						secondlevelChanged = secondlevelChanged OrElse
						                     ((_Model.OriginalSecondLevelTask Is Nothing) And (_Model.Case.StandardTask IsNot Nothing))
						secondlevelChanged = secondlevelChanged OrElse
						                     ((_Model.OriginalSecondLevelTask IsNot Nothing) And (_Model.Case.StandardTask Is Nothing))
						secondlevelChanged = secondlevelChanged OrElse (_Model.OriginalSecondLevelTask.Id <> _Model.Case.StandardTask.Id)

						If secondlevelChanged Then
							'ChangeLog for Phase
							Dim beforeValue As String
							Dim afterValue As String

							If _Model.OriginalSecondLevelTask Is Nothing Then
								beforeValue = String.Empty
							Else
								beforeValue = _Model.OriginalSecondLevelTask.Id.ToString()
							End If

							afterValue = _Model.Case.StandardTask.Id.ToString()
							Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
							                                                                _Context.UserParticipant.ParticipantId,
							                                                                ChangeTypeEnum.PhaseChange, beforeValue,
							                                                                afterValue, Nothing)
							validationSummary.AddValidationSummary(vs)

							'Update Project Portal project
							'wsProject.NextGate = DirectCast(gatelist.GetValue(gatelistindex), wsProjectPortal.ProjectGate)

							'Post news
							'spnpNewsChannel = PostNewsAboutChangingSecondLevelTaskOnExistingCimCase(spnpController, spnpNewsChannel)
						End If

						'First Level Task changed
						If _Model.OriginalFirstLevelTask.Id <> _Model.Case.Phase.Id Then

							'Whenever af CIM case go into Project Implementation 
							If _Model.Phase.Id = 4 Then

								'spnpController.AddNewsPosting(spnpNewsChannel, headline, message, String.Concat(_Environment.ProjectPortal_URL, _Model.Case.Id))
							End If

							Dim projectBeforeValue As String = _Model.OriginalFirstLevelTask.Id.ToString
							Dim projectAfterValue As String = _Model.Case.Phase.Id.ToString

							Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
							                                                                _Context.UserParticipant.ParticipantId,
							                                                                ChangeTypeEnum.ProjectChange, projectBeforeValue,
							                                                                projectAfterValue, Nothing)
							validationSummary.AddValidationSummary(vs)

							''Post news
							'Select Case _Context.BrandId.Value
							'  Case 1 'CIM
							'    If _Model.Case.Phase.Id = 1 And _Model.OriginalSecondLevelTask.Id = 0 Then
							'      spnpController.AddNewsPosting(spnpNewsChannel, String.Format("{0} Case {1} is approved and moved to phase 01.", _Context.BrandName, _Model.Case.Number), String.Format("The phase has been changed by {0} - {1}", _Context.UserParticipant.VestasInitials, _Context.UserParticipant.FormattedName), String.Concat(_Environment.ProjectPortal_URL, _Model.Case.Id))
							'    End If
							'    If _Model.Case.Phase.Id = 8 And _Model.OriginalSecondLevelTask.Id < 8 Then
							'      spnpController.AddNewsPosting(spnpNewsChannel, String.Format("{0} Case {1} has begun upgrade.", _Context.BrandName, _Model.Case.Number), String.Format("The phase has been changed from '{0}' to '{1}' by {2} - {3}", _Model.OriginalSecondLevelTask.Name, _Model.Case.Phase.Name, _Context.UserParticipant.VestasInitials, _Context.UserParticipant.FormattedName), String.Concat(_Environment.ProjectPortal_URL, _Model.Case.Id))
							'    End If
							'  Case Else
							'    'Do nothing
							'End Select
						End If

						'Delete related SBU's from database
						daa.DeleteEntitiesDirectly(GetType(Case2SbuEntity),
						                           New RelationPredicateBucket(Case2SbuFields.CaseId = _Context.CaseId.Value))
					End If


					''Update and save Project Portal project
					'wsProject.Description = _Model.Case.Description
					'wsProject.Manager = ProjectWebService.GetPersonById(Integer.Parse(_Model.Case.Manager.VPId.ToString()))
					'wsProject.UpLink = uplink
					'wsProject.LastEditUser = ProjectWebService.GetPersonById(_Context.UserParticipant.VppersonId)
					'wsProject.LastEditDate = _Now
					'If _Model.Portfolio IsNot Nothing Then
					'  wsProject.Portfolio = _Model.Portfolio
					'End If
					'ProjectWebService.UpdateProject(wsProject)

					' update system cache
					'_Context.Cache.SetItem("CaseFacts.Case." + _Context.CaseId.ToString() + ".Project", wsProject)

					'Save news postings
					'spnpController.Save(entity.CaseId)

					'Last Edited
					entity.LastEdited = _Now
					entity.LastEditedById = _Context.UserParticipant.ParticipantId

					'ChangeLog for Invoicing
					Dim currentInvoice As Boolean = entity.ClosedForInvoicing
					If currentInvoice <> ClosedForInvoicing Then
						Dim beforeValue As String = "0"
						Dim afterValue As String = "0"

						If currentInvoice = True Then beforeValue = "1"
						If ClosedForInvoicing = True Then afterValue = "1"

						Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
						                                                                _Context.UserParticipant.ParticipantId,
						                                                                ChangeTypeEnum.InvoiceChange, beforeValue,
						                                                                afterValue, Nothing)
						validationSummary.AddValidationSummary(vs)
					End If

					entity.ClosedForInvoicing = ClosedForInvoicing

					' update portfolio
					If (Portfolio IsNot Nothing) Then
						entity.PortfolioId = Portfolio.Id
					Else
						entity.PortfolioId = Nothing
					End If

					'Save
					daa.SaveEntity(entity, True, True)
					If _Context.CaseId.HasValue Then
						Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
						                                                                _Context.UserParticipant.ParticipantId,
						                                                                ChangeTypeEnum.AnyChanges, String.Empty,
						                                                                String.Empty,
						                                                                [Enum].Format(GetType(AnyChangesEnum),
						                                                                              AnyChangesEnum.CaseFacts, "d").
						                                                               	ToString)
						validationSummary.AddValidationSummary(vs)
						If (vs.GetErrors.Count > 0) Then
							Throw New Exception(vs.ToString())
						End If
					End If

					Dim RTControllerSaved As Boolean
					If _RTController.IsDirty Then
						_RTController.Save(daa, entity.CaseId)
						RTControllerSaved = True
					End If

					If validationSummary.GetErrors.Count > 0 Then
						daa.Rollback()
						Throw New ApplicationException(validationSummary.ToString)
					Else
						daa.Commit()

						ForceCaseReload()

						If _Context.CreatingNewCase Then
							_Context.CreatingNewCase = False
							_Context.CaseId = entity.CaseId
						Else
							If RTControllerSaved Then _RTController.Clear()
							Clear()
						End If
					End If
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Finally
					daa.CloseConnection()
				End Try
			End Using
			Return validationSummary
		End Function

		Private Function SaveNewCimCase(ByVal daa As DataAccessAdapter, ByVal _Now As Date) As CaseEntity
			Dim entity As CaseEntity

			'Create new case

			'Dim initialPortfolio As Long = Long.Parse(_Context.InitialPortfolioId.ToString())
			'If _Model.Case.Portfolio IsNot Nothing AndAlso _Model.Case.Portfolio.Id <> initialPortfolio Then initialPortfolio = _Model.Case.Portfolio.Id

			''Initialize new Project Portal project
			'wsProject = ProjectWebService.InitializeSaveProject("Default", _Model.Case.Description, ProjectWebService.GetPortfolio(initialPortfolio), Array.Find(Of wsProjectPortal.ProjectStatus)(ProjectWebService.GetProjectStatusList(), New System.Predicate(Of wsProjectPortal.ProjectStatus)(AddressOf FindStatus)), DirectCast(gatelist.GetValue(gatelistindex), wsProjectPortal.ProjectGate), uplink, ProjectWebService.GetPersonById(Integer.Parse(_Model.Case.Manager.VPId.ToString())), ProjectWebService.GetPersonByInitials(_Context.UserParticipant.VestasInitials), _Now, False, False)

			'Get new case number for the current brand
			Dim CaseNo As Long = - 1
			Dim CaseId As Long = - 1
			ActionProcedures.NewCaseId(_Context.BrandId.Value, CaseNo, CaseId, daa)

			'Create a new case
			entity = New CaseEntity()
			entity.BrandId = _Context.BrandId.Value
			entity.CaseNo = CaseNo
			entity.ProjectPortalId = - 1
			'entity.ProjectPortalId = wsProject.GetId
			entity.Created = _Now
			entity.CreatedById = _Context.UserParticipant.ParticipantId
			entity.LastEdited = _Now
			entity.LastEditedById = _Context.UserParticipant.ParticipantId

			UpdateEntity(entity, _Now)
			daa.SaveEntity(entity, True, True)

			'Create standard database setup for the new case
			Dim err As Integer = - 1
			_BusinessLogicService.GetIdOfBusinessProcessToUseForNewCases()
			ActionProcedures.CreateCaseStandards(entity.CaseId, err, daa)

			''Update Project Portal project
			'wsProject.Name = String.Format("{0} Case {1}", _Context.BrandName, CaseNo)
			'wsProject.CIMCaseNo = Integer.Parse(CaseNo.ToString())

			'Add 'Case Created' to ChangeLog
			Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, CaseId, _Context.UserParticipant.ParticipantId,
			                                                                ChangeTypeEnum.CaseCreated, String.Empty,
			                                                                String.Empty, Nothing)
			If (vs.GetErrors.Count > 0) Then
				' todo: How should we handle this? Use transaction?! Perhaps this method should return a ValidationSummery object??
			End If


			Return entity
		End Function

		''' <summary>
		''' Update Case Entity with model information
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Private Sub UpdateEntity(ByRef entity As CaseEntity, ByVal _Now As Date)
			entity.BusinessProcessId = _Model.BusinessProcessId

			If _Context.CreatingNewCase OrElse entity.ManagerId <> _Model.Case.Manager.Id Then _
				entity.ManagerId = _Model.Case.Manager.Id
			'If _
			'  _Context.CreatingNewCase AndAlso _Model.Case.ParentCase IsNot Nothing OrElse _
			'  (_Model.ParentCase IsNot Nothing AndAlso Not entity.Uplink.Equals(_Model.Case.ParentCase.Id)) Then _
			'  entity.Uplink = _Model.Case.ParentCase.Id

			If _Context.CreatingNewCase OrElse entity.Description <> _Model.Case.Description Then _
				entity.Description = _Model.Case.Description

			If _Context.CreatingNewCase OrElse entity.PhaseId <> _Model.Case.Phase.Id Then _
				entity.PhaseId = _Model.Case.Phase.Id

			If _Context.CreatingNewCase OrElse (entity.StandardTaskId <> _Model.Case.StandardTask.Id) Then _
				entity.StandardTaskId = _Model.Case.StandardTask.Id

			If _Context.CreatingNewCase OrElse entity.ClaimStatusId <> _Model.Case.ClaimStatus.Id Then _
				entity.ClaimStatusId = _Model.Case.ClaimStatus.Id

			If Not _Context.CreatingNewCase Then
				''ClosureDate and ReopenDate.
				If _
					IsStatusClosed(_Model.Case.Status) AndAlso IsStatusClosed(_Model.OriginalStatus) = False AndAlso
					Not entity.ReopenDate.HasValue Then
					'if CaseFactsStatus is set to closed, and reopendate=empty, then update the closuredate
					entity.ClosureDate = _Now
				ElseIf IsStatusClosed(_Model.Case.Status) = False AndAlso IsStatusClosed(_Model.OriginalStatus) Then
					'if CaseFactsStatus is set to open(or less?), from closed, then the reopendate is updated
					entity.ReopenDate = _Now
				ElseIf _
					IsStatusClosed(_Model.Case.Status) AndAlso entity.ReopenDate.HasValue AndAlso
					DateDiff(DateInterval.Hour, entity.ReopenDate.GetValueOrDefault(), _Now) < 24 Then
					'if CaseFactsStatus is set to closed, and reopendate is set, and the reopendate occurred less than 24h from now, the reopendate is cleared, and the closuredate is left untouched
					entity.ReopenDate = Nothing
				ElseIf _
					IsStatusClosed(_Model.Case.Status) AndAlso entity.ReopenDate.HasValue AndAlso
					DateDiff(DateInterval.Hour, _Now, entity.ReopenDate.GetValueOrDefault()) > 24 Then
					'if CaseFactsStatus is set to closed, and reopendate is set, and the reopendate occurred more than 24h from now, the reopendate is cleared, and the closuredate is updated
					entity.ReopenDate = Nothing
					entity.ClosureDate = _Now
				End If

				' ''ClosureDate and ReopenDate.
				'If _Model.Case.CaseFactsStatus.Id = 4 AndAlso _Model.OriginalStatus.Id <> 4 AndAlso Not entity.ReopenDate.HasValue Then
				'  'if CaseFactsStatus is set to closed, and reopendate=empty, then update the closuredate
				'  entity.ClosureDate = _Now
				'ElseIf _Model.Case.CaseFactsStatus.Id < 4 AndAlso _Model.OriginalStatus.Id = 4 Then
				'  'if CaseFactsStatus is set to open(or less?), from closed, then the reopendate is updated
				'  entity.ReopenDate = _Now
				'ElseIf _Model.Case.CaseFactsStatus.Id = 4 AndAlso entity.ReopenDate.HasValue AndAlso DateDiff(DateInterval.Hour, entity.ReopenDate.GetValueOrDefault(), _Now) < 24 Then
				'  'if CaseFactsStatus is set to closed, and reopendate is set, and the reopendate occurred less than 24h from now, the reopendate is cleared, and the closuredate is left untouched
				'  entity.ReopenDate = Nothing
				'ElseIf _Model.Case.CaseFactsStatus.Id = 4 AndAlso entity.ReopenDate.HasValue AndAlso DateDiff(DateInterval.Hour, _Now, entity.ReopenDate.GetValueOrDefault()) > 24 Then
				'  'if CaseFactsStatus is set to closed, and reopendate is set, and the reopendate occurred more than 24h from now, the reopendate is cleared, and the closuredate is updated
				'  entity.ReopenDate = Nothing
				'  entity.ClosureDate = _Now
				'End If
			End If

			If _Context.CreatingNewCase OrElse entity.StatusId <> _Model.Case.Status.Id Then _
				entity.StatusId = Byte.Parse(_Model.Case.Status.Id.ToString())
			If _Context.CreatingNewCase OrElse entity.Pbuid <> _Model.Case.PBU.Id Then entity.Pbuid = _Model.Case.PBU.Id

			If entity.TechnicalSpecialistId.HasValue Then
				If _Model.Case.TechnicalSpecialist Is Nothing Then
					entity.TechnicalSpecialistId = Nothing
				Else
					If Not entity.TechnicalSpecialistId.Equals(_Model.Case.TechnicalSpecialist.Id) Then _
						entity.TechnicalSpecialistId = _Model.Case.TechnicalSpecialist.Id
				End If
			Else
				If _Model.Case.TechnicalSpecialist IsNot Nothing Then _
					entity.TechnicalSpecialistId = _Model.Case.TechnicalSpecialist.Id
			End If

			If entity.ExecutionManagerId.HasValue Then
				If _Model.Case.ExecutionManager Is Nothing Then
					entity.ExecutionManagerId = Nothing
				Else
					If Not entity.ExecutionManagerId.Equals(_Model.Case.ExecutionManager.Id) Then _
						entity.ExecutionManagerId = _Model.Case.ExecutionManager.Id
				End If
			Else
				If _Model.Case.ExecutionManager IsNot Nothing Then entity.ExecutionManagerId = _Model.Case.ExecutionManager.Id
			End If

			If _Context.CreatingNewCase OrElse _Model.Case.Platform IsNot Nothing Then
				If entity.Platform.HasValue Then
					If Not entity.Platform.Equals(_Model.Case.Platform.Id) Then entity.Platform = _Model.Case.Platform.Id
				Else
					If _Model.Case.Platform IsNot Nothing Then entity.Platform = _Model.Case.Platform.Id
				End If
			End If

			entity.Case2Sbu.Clear()
			For Each sbu As SBU In _Model.Case.SBU
				Dim sbuEntity As Case2SbuEntity = entity.Case2Sbu.AddNew()
				sbuEntity.Sbuid = sbu.Id
			Next
			If _Context.CreatingNewCase OrElse entity.ConfirmedBySupplier <> _Model.Case.ConfirmedBySupplier Then _
				entity.ConfirmedBySupplier = _Model.Case.ConfirmedBySupplier
			If _Context.CreatingNewCase OrElse entity.SalesOption <> _Model.Case.SalesOption Then _
				entity.SalesOption = _Model.Case.SalesOption
		End Sub

		''' <summary>
		''' Check Close Case
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function CheckCloseCase() As Boolean
			Return _
				_Model.OriginalStatus IsNot Nothing AndAlso _Model.Case.Status.Id <> _Model.OriginalStatus.Id And
				IsClosed(_Model.Case.Status)
		End Function

		''' <summary>
		''' Check screen input for invalid data
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function CheckInput() As StringBuilder
			Dim sbErrors As New StringBuilder()

			'If you're an administrator, you do not have to obey the rules about required fields for incomplete old cases
			If Not _AccessControl.OperationIsLegal(Permissions.Editor_Main_Administration) OrElse _Context.CreatingNewCase _
				Then
				If _Model.Case.Description.Length = 0 Then sbErrors.AppendLine("You must enter a description")
				If _Model.Case.Phase Is Nothing Then sbErrors.AppendLine("You must select a phase")
				If _Model.Case.ClaimStatus Is Nothing Then sbErrors.AppendLine("You must select a claim CaseFactsStatus")
				If _Model.Case.Status Is Nothing Then sbErrors.AppendLine("You must select a CaseFactsStatus")
				If _Model.Case.PBU Is Nothing Then sbErrors.AppendLine("You must select a claim responsible PBU")
				If _Model.Case.SBU.Count = 0 Then sbErrors.AppendLine("You must select at least one SBU")
				If _RTController.FailedTurbines.Count = 0 Then sbErrors.AppendLine("You must select a failed turbine")
				If _RTController.FailedItem Is Nothing Then sbErrors.AppendLine("You must select a failed item")
			End If

			'As an everyone user I want every CIM case to contain Service code + Service Group
			'Existing CIM cases are not to be changed for now.
			'      If _Context.CaseId.HasValue Then
			'        Dim case2ServiceCodeService As ICase2ServiceCodeService = ObjectFactory.GetInstance(Of ICase2ServiceCodeService)()
			'        Dim listOfCase2ServiceCodes As List(Of Case2ServiceCode) = case2ServiceCodeService.GetCase2ServiceCodesByCaseId(_Context.CaseId.Value)
			'
			'        If listOfCase2ServiceCodes.Count = 0 Then
			'          Dim infoToUser As String = "You need to add 'Service Code' and 'Service Group' before saving!" + System.Environment.NewLine + "This can be found under View -> Service Codes"
			'          sbErrors.AppendLine(infoToUser)
			'        End If
			'      End If

			'It must not be possible to close a case while documents are being edited on the case
			'HACK: StatusId (4 = 'Closed') hardcoded
			If _
				Not _Context.CreatingNewCase AndAlso
				(_Model.OriginalStatus.Id <> _Model.Case.Status.Id And _Model.Case.Status.Id = 4) Then
				Dim liFolders As List(Of Folder) = _DocController.Folders
				Dim liDocs As List(Of Document.Document) = _DocController.LockedDocuments
				Dim sbDocErrors As New StringBuilder()

				For i As Integer = 0 To liDocs.Count - 1
					Dim sbFolder As New StringBuilder()
					Dim doc As Document.Document = liDocs(i)
					Dim folder As Folder = doc.Folders(0)

					sbFolder.Append(folder.Name)
					While folder.Parent IsNot Nothing
						folder = liFolders.Find(Function(f) f.Id = folder.Parent.Id)
						sbFolder.Insert(0, [String].Format("{0}{1}", folder.Name, Path.DirectorySeparatorChar))
					End While
					sbDocErrors.AppendFormat("{0}{4}{1} (locked by ""{2}""){3}", sbFolder.ToString(), doc.Title,
					                         doc.LockedByParticipant.VestasInitials, System.Environment.NewLine,
					                         Path.DirectorySeparatorChar)
				Next

				If sbDocErrors.Length > 0 Then
					sbErrors.AppendFormat(
						"You can not close the case as the following documents are still being edited:{0}{0}{1}",
						System.Environment.NewLine, sbDocErrors.ToString())
				End If
			End If

			Return sbErrors
		End Function

		''' <summary>
		''' Case Category
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property CaseCategory() As ICaseCategory
			Get
				Return _Model.CaseCategory
			End Get
			Set(ByVal value As ICaseCategory)
				_Model.CaseCategory = value
			End Set
		End Property

		''' <summary>
		''' Component
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Component() As IComponent
			Get
				Return _Model.Component
			End Get
			Set(ByVal value As IComponent)
				_Model.Component = value
			End Set
        End Property

        ''' <summary> PKB 74840 PS
        ''' Project Scope
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ProjectScope() As IProjectScope
            Get
                Return _Model.ProjectScope
            End Get
            Set(ByVal value As IProjectScope)
                _Model.ProjectScope = value
            End Set
        End Property

		''' <summary>
		''' Personal Safety
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property PersonalSafety() As IPersonalSafety
			Get
				Return _Model.PersonalSafety
			End Get
			Set(ByVal value As IPersonalSafety)
				_Model.PersonalSafety = value
			End Set
		End Property

#Region "Add Case Window"

		Public Function FindCases(ByVal caseNo As String, ByVal description As String, ByVal createdBy As String,
		                          ByVal manager As String, ByVal technicalSpecialist As String,
		                          ByVal executionManager As String, ByVal phase As Phase, ByVal claimStatus As ClaimStatus,
		                          ByVal status As CaseFactsStatus, ByVal MaximumNumberOfItems As Integer) As List(Of [Case])
			Dim collectionToFill As New EntityCollection(Of CaseEntity)(New CaseEntityFactory())

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				daa.CommandTimeOut = 120
				Try
					Dim filterBucket As New RelationPredicateBucket()

					filterBucket.PredicateExpression.AddWithAnd(CaseFields.BrandId = _Context.BrandId)

					If caseNo.Length > 0 Then _
						filterBucket.PredicateExpression.AddWithAnd(CaseFields.CaseNo Mod String.Concat("%", caseNo, "%"))

					If description.Length > 0 Then _
						filterBucket.PredicateExpression.AddWithAnd(
							CaseFields.Description Mod
							String.Concat("%", description, "%"))

					If createdBy.Length > 0 Then
						filterBucket.Relations.Add(CaseEntity.Relations.ParticipantEntityUsingCreatedById, "CreatedByParticipant")
						filterBucket.PredicateExpression.AddWithAnd(
							ParticipantFields.VestasInitials.SetObjectAlias(
								"CreatedByParticipant") Mod
							String.Concat("%", createdBy.ToLower(), "%") Or
							ParticipantFields.FormattedName.SetObjectAlias(
								"CreatedByParticipant") Mod
							String.Concat("%", createdBy.ToLower(), "%"))
					End If

					If manager.Length > 0 Then
						filterBucket.Relations.Add(CaseEntity.Relations.ParticipantEntityUsingManagerId, "ManagerParticipant")
						filterBucket.PredicateExpression.AddWithAnd(
							ParticipantFields.VestasInitials.SetObjectAlias(
								"ManagerParticipant") Mod
							String.Concat("%", manager.ToLower(), "%") Or
							ParticipantFields.FormattedName.SetObjectAlias(
								"ManagerParticipant") Mod
							String.Concat("%", manager.ToLower(), "%"))
					End If

					If technicalSpecialist.Length > 0 Then
						filterBucket.Relations.Add(CaseEntity.Relations.ParticipantEntityUsingTechnicalSpecialistId,
						                           "TechnicalSpecialistParticipant")
						filterBucket.PredicateExpression.AddWithAnd(
							ParticipantFields.VestasInitials.SetObjectAlias(
								"TechnicalSpecialistParticipant") Mod
							String.Concat("%", technicalSpecialist.ToLower(), "%") Or
							ParticipantFields.FormattedName.SetObjectAlias(
								"TechnicalSpecialistParticipant") Mod
							String.Concat("%", technicalSpecialist.ToLower(), "%"))
					End If

					If executionManager.Length > 0 Then
						filterBucket.Relations.Add(CaseEntity.Relations.ParticipantEntityUsingExecutionManagerId,
						                           "ExecutionManagerParticipant")
						filterBucket.PredicateExpression.AddWithAnd(
							ParticipantFields.VestasInitials.SetObjectAlias(
								"ExecutionManagerParticipant") Mod
							String.Concat("%", executionManager.ToLower(), "%") Or
							ParticipantFields.FormattedName.SetObjectAlias(
								"ExecutionManagerParticipant") Mod
							String.Concat("%", executionManager.ToLower(), "%"))
					End If

					If phase IsNot Nothing Then filterBucket.PredicateExpression.AddWithAnd(CaseFields.PhaseId = phase.Id)

					If status IsNot Nothing Then filterBucket.PredicateExpression.AddWithAnd(CaseFields.StatusId = status.Id)

					If claimStatus IsNot Nothing Then _
						filterBucket.PredicateExpression.AddWithAnd(CaseFields.ClaimStatusId = claimStatus.Id)

					daa.FetchEntityCollection(collectionToFill, filterBucket, MaximumNumberOfItems, Nothing, _CasePrefetchPath)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Finally
					daa.CloseConnection()
				End Try
			End Using

			Dim li As New List(Of [Case])
			For i As Integer = 0 To collectionToFill.Count - 1
				li.Add(New [Case](collectionToFill(i), False))
			Next
			Return li
		End Function

#End Region

#Region "SetTypeCoordinator Window"

		''' <summary>
		''' Platforms
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Platforms() As List(Of Platform)
			Get
				Dim li As New List(Of Platform)
				If _Context.Cache.ContainsItem("CaseFacts.Platforms") Then
					li.AddRange(_Context.Cache.GetItem (Of List(Of Platform))("CaseFacts.Platforms"))
				Else
					Dim ec As New EntityCollection(Of PlatformEntity)(New PlatformEntityFactory())
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Try
							Dim pp As New PrefetchPath2(DirectCast(EntityType.PlatformEntity, Integer))
							pp.Add(PlatformEntity.PrefetchPathParticipant)
							daa.FetchEntityCollection(ec, Nothing, pp)
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using

					For i As Integer = 0 To ec.Count - 1
						li.Add(New Platform(ec(i)))
					Next
					If li.Count > 0 Then
						' Platforms are not likely to change, use high TTL on cache
						_Context.Cache.SetItem("CaseFacts.Platforms", New List(Of Platform)(li), TimeToLive.High)
					End If
				End If

				Return li
			End Get
		End Property


		''' <summary>
		''' Portfolios
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Portfolios() As List(Of Portfolio)
			Get
				Dim li As New List(Of Portfolio)
				If _Context.Cache.ContainsItem("CaseFacts.Portfolios") Then
					li.AddRange(_Context.Cache.GetItem (Of List(Of Portfolio))("CaseFacts.Portfolios"))
				Else
					Dim ec As New EntityCollection(Of PortfolioEntity)(New PortfolioEntityFactory())
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Try
							daa.FetchEntityCollection(ec, Nothing)
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using

					For i As Integer = 0 To ec.Count - 1
						li.Add(New Portfolio(ec(i)))
					Next
					If li.Count > 0 Then
						' Portfolios are not likely to change, use high TTL on cache
						_Context.Cache.SetItem("CaseFacts.Portfolios", New List(Of Portfolio)(li), TimeToLive.High)
					End If
				End If

				Return li
			End Get
		End Property

#End Region

		Public Sub ForceCaseReload()
			' clear casefacts from system cache (force reload)
			'_Context.Cache.RemoveItem("CaseFacts.Case." + _Context.CaseId.ToString())
			_Context.Cache.Clear()
			' Remove ALL to ensure that the CIM Case (including relations) are reloaded.
			_Context.FlushCaseFacts()
		End Sub
	End Class
End Namespace
