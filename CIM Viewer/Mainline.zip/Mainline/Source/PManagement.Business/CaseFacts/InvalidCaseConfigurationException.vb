﻿Namespace CaseFacts
	Public Enum InvalidCaseConfiguration
		MissingTechnicalSpecialist
		MissingExecutionManager
		InvalidStatus
	End Enum

	Public Class InvalidCaseConfigurationException
		Inherits Exception

		Public ReadOnly ErrorType As InvalidCaseConfiguration

		Public Sub New(ByVal errorType As InvalidCaseConfiguration)
			MyBase.New("Invalid or missing case configuration (" + errorType.ToString() + ")")
			Me.ErrorType = errorType
		End Sub
	End Class
End Namespace
