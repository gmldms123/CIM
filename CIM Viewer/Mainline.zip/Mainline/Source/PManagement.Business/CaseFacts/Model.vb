Imports PManagement.DataLayer.CaseFacts
Imports PManagement.DataLayer.DbBasedModel.CaseFacts
Imports PManagement.DataLayer.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate

Namespace CaseFacts
	Public NotInheritable Class Model
		Inherits BaseClasses.Model
		Implements ICaseFactsModel

		Private _CurrentCaseId As Nullable(Of Long)

		Private _Case As [ICase] = Nothing

		Private _Phases As IPhaseList = New PhaseList()
		Private _StandardTasks As New StandardTaskList

		Private ReadOnly _Statuses As New List(Of ICaseFactsStatus)

		Private _OriginalStatus As ICaseFactsStatus
		Private _originalFirstLevelTask As IPhase
		Private _originalSecondLevelTask As StandardTask
		Private _originalProjectManager As IParticipant
		Private _originalExecutionManager As IParticipant

		Private _initialClaimStatus As IClaimStatus

		Private _idToFind As Long
		Private statusCollection As EntityCollection(Of StatusEntity)

		Public Sub New()
		End Sub

		Public Sub New(ByVal context As PmanContext)
			Me.New()
			_Context = context
		End Sub

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Dim dirty As Boolean = False
				If _Case IsNot Nothing Then dirty = _Case.IsDirty
				Return dirty
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If Not _Context.CreatingNewCase Then _Case = Nothing
			_CurrentCaseId = _Context.CaseId
			OnDataChanged()
		End Sub

		''' <summary>
		''' Create New Case
		''' </summary>
		''' <remarks></remarks>
		Public Sub CreateNewCase(ByVal portfolio As IPortfolio, ByVal initialPhase As IPhase,
		                         ByVal initialStandardTask As StandardTask, ByVal initialCaseFactsStatus As ICaseFactsStatus,
		                         ByVal businessProcessId As Long)
			_Case = New [Case](initialPhase, initialStandardTask, _initialClaimStatus, initialCaseFactsStatus,
			                   New Participant.Participant(_Context.UserParticipant), portfolio, businessProcessId)

			For i As Integer = 0 To _Phases.Count - 1
				_Case.AddPhaseBudget(New PhaseBudget(_Phases(i)))
			Next
			_Context.CreatingNewCase = True
			OnDataChanged()
		End Sub

		''' <summary>
		''' Case
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property [Case]() As [ICase] Implements ICaseFactsModel.Case
			Get
				Return _Case
			End Get
		End Property


		Public Property StandardTasks() As StandardTaskList
			Get
				Return _StandardTasks
			End Get
			Set(ByVal value As StandardTaskList)
				_StandardTasks = value
			End Set
		End Property

		''' <summary>
		''' Statuses
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Statuses() As List(Of ICaseFactsStatus)
			Get
				Return _Statuses
			End Get
		End Property

		''' <summary>
		''' Inject initial claim status
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub InjectClaimStatus(ByVal ec As EntityCollection(Of ClaimStatusEntity))
			If Not _CurrentCaseId.Equals(_Context.CaseId) Then Clear()

			If _initialClaimStatus Is Nothing OrElse _initialClaimStatus.Id <> ec(0).ClaimStatusId Then
				_initialClaimStatus = New ClaimStatus(ec(0))
			End If
		End Sub

		''' <summary>
		''' Inject Statuses
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of StatusEntity))
			If Not _CurrentCaseId.Equals(_Context.CaseId) Then Clear()

			Dim dataChanged As Boolean = False

			For i As Integer = 0 To ec.Count - 1
				_idToFind = ec(i).StatusId
				Dim existingStatus As ICaseFactsStatus = _Statuses.Find(New Predicate(Of ICaseFactsStatus)(AddressOf FindStatusById))
				If existingStatus Is Nothing Then
					'Add
					_Statuses.Add(New CaseFactsStatus(ec(i)))
					dataChanged = True
				Else
					'Update
					dataChanged = existingStatus.Update(ec(i))
				End If
			Next

			statusCollection = ec
			dataChanged = dataChanged Or
			              _Statuses.RemoveAll(New Predicate(Of ICaseFactsStatus)(AddressOf FindStatusesToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Inject
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal entity As CaseEntity)
			'Public Sub Inject(ByVal entity As CaseEntity, ByVal project As wsProjectPortal.Project)
			If Not _CurrentCaseId.Equals(_Context.CaseId) Then Clear()

			Dim dataChanged As Boolean

			If _Case Is Nothing OrElse entity.CaseId <> _Case.Id Then
				'Replace with new object
				_Case = New [Case](entity)
				_OriginalStatus = _Case.Status
				_originalFirstLevelTask = _Case.Phase
				_originalSecondLevelTask = _Case.StandardTask
				_originalProjectManager = _Case.Manager
				_originalExecutionManager = _Case.ExecutionManager
				dataChanged = True
			Else
				'Update existing case
				dataChanged = _Case.Update(entity)
			End If

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Manager() As IParticipant
			Get
				Return _Case.Manager
			End Get
			Set(ByVal value As IParticipant)
				If _Case.Manager.Id <> value.Id Then
					_Case.Manager = value
					OnDataChanged()
				End If
			End Set
		End Property

		''' <summary>
		''' Technical Specialist
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property TechnicalSpecialist() As IParticipant
			Get
				Return _Case.TechnicalSpecialist
			End Get
			Set(ByVal value As IParticipant)
				If _Case IsNot Nothing Then
					_Case.TechnicalSpecialist = value
					OnDataChanged()
				End If
			End Set
		End Property

		''' <summary>
		''' Execution Manager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ExecutionManager() As IParticipant
			Get
				Return _Case.ExecutionManager
			End Get
			Set(ByVal value As IParticipant)
				If _Case IsNot Nothing Then
					_Case.ExecutionManager = value
					OnDataChanged()
				End If
			End Set
		End Property

		''' <summary>
		''' Platform
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Platform() As IPlatform
			Get
				Return _Case.Platform
			End Get
			Set(ByVal value As IPlatform)
				If _Case IsNot Nothing AndAlso (_Case.Platform Is Nothing OrElse _Case.Platform.Id <> value.Id) Then
					_Case.Platform = value
					OnDataChanged()
				End If
			End Set
		End Property

		' ''' <summary>
		' ''' Parent Case
		' ''' </summary>
		' ''' <value></value>
		' ''' <returns></returns>
		' ''' <remarks></remarks>
		'Public ReadOnly Property ParentCase() As [ICase]
		'  Get
		'    Return _Case.ParentCase
		'  End Get
		'End Property

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <remarks></remarks>
		Public WriteOnly Property Description() As String
			Set(ByVal value As String)
				If _Case IsNot Nothing AndAlso _Case.Description <> value Then
					_Case.Description = value
				End If
			End Set
		End Property

		''' <summary>
		''' Phase
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Phase() As IPhase
			Get
				Return _Case.Phase
			End Get
			Set(ByVal value As IPhase)
				If _Case IsNot Nothing AndAlso (_Case.Phase Is Nothing OrElse _Case.Phase.Id <> value.Id) Then

					'' must set closed for invoicing to false when leaving phase 0
					'If _Case.Phase.Name = Controller.CimPhase00Name Then
					'  _Case.ClosedForInvoicing = False
					'End If

					_Case.Phase = value
					OnDataChanged()
				End If
			End Set
		End Property

		''' <summary>
		''' Portfolio
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Portfolio() As IPortfolio
			Get
				Return _Case.Portfolio
			End Get
			Set(ByVal value As IPortfolio)
				If _Case IsNot Nothing AndAlso Not Equals(_Case.Portfolio, value) Then
					_Case.Portfolio = value
					OnDataChanged()
				End If
			End Set
		End Property


		''' <summary>
		''' Original Phase
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OriginalSecondLevelTask() As StandardTask
			Get
'        ' Handle the case where StandardTask is not yet selected in database.
'        ' Should only happen right after converting in connection with the reopened 499.40.
'        If (_originalSecondLevelTask Is Nothing) Then
'          _originalSecondLevelTask = _StandardTasks(0)
'        End If
'
				Return _originalSecondLevelTask
			End Get
		End Property

		''' <summary>
		''' Original Project
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OriginalFirstLevelTask() As IPhase
			Get
'        ' Handle the case where Phase is not yet selected in database.
'        ' Should only happen right after converting in connection with the reopened 499.40.
'        If (_originalFirstLevelTask Is Nothing) Then
'          _originalFirstLevelTask = _Phases(0)
'        End If
				Return _originalFirstLevelTask
			End Get
		End Property

		''' <summary>
		''' Original ProjectManager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OriginalProjectManager() As IParticipant
			Get
				Return _originalProjectManager
			End Get
		End Property

		''' <summary>
		''' Original ProjectManager
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OriginalExecutionManager() As IParticipant
			Get
				Return _originalExecutionManager
			End Get
		End Property

		''' <summary>
		''' Claim Status
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ClaimStatus() As IClaimStatus
			Get
				Return _Case.ClaimStatus
			End Get
			Set(ByVal value As IClaimStatus)
				If _Case IsNot Nothing AndAlso (_Case.ClaimStatus Is Nothing OrElse _Case.ClaimStatus.Id <> value.Id) Then
					_Case.ClaimStatus = value
				End If
			End Set
		End Property

		''' <summary>
		''' Status
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Status() As ICaseFactsStatus Implements ICaseFactsModel.Status
			Get
				Return _Case.Status
			End Get
			Set(ByVal value As ICaseFactsStatus)
				If _Case IsNot Nothing AndAlso (_Case.Status Is Nothing OrElse _Case.Status.Id <> value.Id) Then
					_Case.Status = value
					OnDataChanged()
				End If
			End Set
		End Property

		''' <summary>
		''' Original Status
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OriginalStatus() As ICaseFactsStatus
			Get
				Return _OriginalStatus
			End Get
		End Property

		''' <summary>
		''' PBU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property PBU() As IPBU 'Implements ICaseFactsModel .
			Get
				Return _Case.PBU
			End Get
			Set(ByVal value As IPBU)
				If _Case IsNot Nothing AndAlso (_Case.PBU Is Nothing OrElse _Case.PBU.Id <> value.Id) Then
					_Case.PBU = value
				End If
			End Set
		End Property

		''' <summary>
		''' SBU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SBU() As List(Of ISBU)
			Get
				Return _Case.SBU
			End Get
		End Property

		''' <summary>
		''' Add SBU
		''' </summary>
		''' <param name="sbu"></param>
		''' <remarks></remarks>
		Public Sub AddSBU(ByVal sbu As ISBU)
			_Case.AddSBU(sbu)
		End Sub

		''' <summary>
		''' Remove SBU
		''' </summary>
		''' <param name="sbu"></param>
		''' <remarks></remarks>
		Public Sub RemoveSBU(ByVal sbu As ISBU)
			_Case.RemoveSBU(sbu)
		End Sub

		''' <summary>
		''' Update Phase Budget
		''' </summary>
		''' <param name="phaseBudget"></param>
		''' <param name="newPhaseBudget"></param>
		''' <remarks></remarks>
		Public Sub UpdatePhaseBudget(ByVal phaseBudget As IPhaseBudget, ByVal newPhaseBudget As IPhaseBudget)
			Dim dataChanged As Boolean
			If phaseBudget.Relevant <> newPhaseBudget.Relevant Then
				phaseBudget.Relevant = newPhaseBudget.Relevant
				dataChanged = True
			End If
			If phaseBudget.Budget <> newPhaseBudget.Budget Then
				phaseBudget.Budget = newPhaseBudget.Budget
				dataChanged = True
			End If
			If phaseBudget.Realised <> newPhaseBudget.Realised Then
				phaseBudget.Realised = newPhaseBudget.Realised
				dataChanged = True
			End If
			If phaseBudget.Deadline <> newPhaseBudget.Deadline Then
				phaseBudget.Deadline = newPhaseBudget.Deadline
				dataChanged = True
			End If
			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Confirmed By Supplier
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ConfirmedBySupplier() As Boolean
			Get
				Return _Case.ConfirmedBySupplier
			End Get
			Set(ByVal value As Boolean)
				If _Case.ConfirmedBySupplier <> value Then
					_Case.ConfirmedBySupplier = value
				End If
			End Set
		End Property

		''' <summary>
		''' Sales Option
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property SalesOption() As Boolean
			Get
				Return _Case.SalesOption
			End Get
			Set(ByVal value As Boolean)
				If _Case.SalesOption <> value Then
					_Case.SalesOption = value
				End If
			End Set
		End Property

		''' <summary>
		''' Closed for invoicing
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ClosedForInvoicing() As Boolean
			Get
				Return _Case.ClosedForInvoicing
			End Get
			Set(ByVal value As Boolean)
				If _Case.ClosedForInvoicing <> value Then
					_Case.ClosedForInvoicing = value
				End If
			End Set
		End Property

		Public ReadOnly Property BusinessProcessId() As Long
			Get
				Return _Case.BusinessProcessid
			End Get
		End Property

		Public Property StandardTask() As StandardTask
			Get
				Return _Case.StandardTask
			End Get
			Set(ByVal value As StandardTask)
				If _Case IsNot Nothing Then
					If (_Case.StandardTask Is Nothing OrElse _Case.StandardTask.Id <> value.Id) Then
						_Case.StandardTask = value
						OnDataChanged()
					End If
				End If
			End Set
		End Property

		''' <summary>
		''' Find Status By Id
		''' </summary>
		''' <param name="status"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindStatusById(ByVal status As ICaseFactsStatus) As Boolean
			Return status.Id = _idToFind
		End Function

		''' <summary>
		''' Find Statuses To Remove
		''' </summary>
		''' <param name="status"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindStatusesToRemove(ByVal status As ICaseFactsStatus) As Boolean
			Return statusCollection.FindMatches(StatusFields.StatusId = status.Id).Count = 0
		End Function

		Public Sub Inject(ByVal phaselist As IPhaseList)
			_Phases = phaselist
		End Sub


		Public Sub Inject(ByVal standardTaskList As StandardTaskList)
			_StandardTasks = standardTaskList
		End Sub

		Public Property CaseCategory() As ICaseCategory
			Get
				Return _Case.CaseCategory
			End Get
			Set(value As ICaseCategory)
				If _
					_Case IsNot Nothing AndAlso
					(_Case.CaseCategory Is Nothing OrElse _Case.CaseCategory.CategoryId <> value.CategoryId) Then
					_Case.CaseCategory = value
					OnDataChanged()
				End If
			End Set
		End Property

		Public Property Component() As IComponent
			Get
				Return _Case.Component
			End Get
			Set(value As IComponent)
				If _Case IsNot Nothing AndAlso (_Case.Component Is Nothing OrElse _Case.Component.ComponentId <> value.ComponentId) _
					Then
					_Case.Component = value
					OnDataChanged()
				End If
			End Set
        End Property
        ' PKB 74840 PS
        Public Property ProjectScope() As IProjectScope
            Get
                Return _Case.ProjectScope
            End Get
            Set(value As IProjectScope)
                If _Case IsNot Nothing AndAlso (_Case.ProjectScope Is Nothing OrElse _Case.ProjectScope.ProjectScopeId <> value.ProjectScopeId) _
                 Then
                    _Case.ProjectScope = value
                    OnDataChanged()
                End If
            End Set
        End Property

		Public Property PersonalSafety() As IPersonalSafety
			Get
				Return _Case.PersonalSafety
			End Get
			Set(value As IPersonalSafety)
				If _
					_Case IsNot Nothing AndAlso
					(_Case.PersonalSafety Is Nothing OrElse _Case.PersonalSafety.PersonalSafetyId <> value.PersonalSafetyId) Then
					_Case.PersonalSafety = value
					OnDataChanged()
				End If
			End Set
		End Property
	End Class
End Namespace
