Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
	Public NotInheritable Class PBU
		Implements IPBU

		Private ReadOnly _Id As Long
		Private ReadOnly _Name As String

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As PbuEntity)
			_Id = entity.Pbuid
			_Name = entity.Name
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long Implements IPBU.Id
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String Implements IPBU.Name
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' ToString()
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides Function ToString() As String
			Return _Name
		End Function
	End Class
End Namespace
