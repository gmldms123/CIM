﻿Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
	Public NotInheritable Class PersonalSafety
		Implements IPersonalSafety

		Private ReadOnly _PersonalSafetyId As Long
		Private ReadOnly _Name As String
		Private ReadOnly _Color As String
		Private ReadOnly _Sort As Long
		Private ReadOnly _CreatedById As Long
		Private ReadOnly _Created As DateTime
		Private ReadOnly _DeletedById As Nullable(Of Long)
		Private ReadOnly _Deleted As Nullable(Of DateTime)

		Public Sub New(ByVal entity As PersonalSafetyEntity)
			_PersonalSafetyId = entity.PersonalSafetyId
			_Name = entity.Name
			_Color = entity.Color
			_Sort = entity.Sort
			_CreatedById = entity.CreatedById
			_Created = entity.Created
			_DeletedById = entity.DeletedById
			_Deleted = entity.Deleted
		End Sub


		Public ReadOnly Property ComponentId() As Long Implements IPersonalSafety.PersonalSafetyId
			Get
				Return _PersonalSafetyId
			End Get
		End Property

		Public ReadOnly Property Name() As String Implements IPersonalSafety.Name
			Get
				Return _Name
			End Get
		End Property

		Public ReadOnly Property Color() As String Implements IPersonalSafety.Color
			Get
				Return _Color
			End Get
		End Property

		Public ReadOnly Property Sort() As Long Implements IPersonalSafety.Sort
			Get
				Return _Sort
			End Get
		End Property

		Public ReadOnly Property CreatedById() As Long Implements IPersonalSafety.CreatedById
			Get
				Return _CreatedById
			End Get
		End Property

		Public ReadOnly Property Created() As Date Implements IPersonalSafety.Created
			Get
				Return _Created
			End Get
		End Property

		Public ReadOnly Property DeletedById() As Nullable(Of Long) Implements IPersonalSafety.DeletedById
			Get
				Return _DeletedById
			End Get
		End Property

		Public ReadOnly Property Deleted() As Nullable(Of DateTime) Implements IPersonalSafety.Deleted
			Get
				Return _Deleted
			End Get
		End Property
	End Class
End Namespace
