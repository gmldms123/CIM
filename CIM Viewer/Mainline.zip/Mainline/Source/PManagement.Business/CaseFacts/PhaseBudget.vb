Imports PManagement.DataLayer.DbBasedModel.CaseFacts
Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
	Public NotInheritable Class PhaseBudget
		Implements IPhaseBudget

		Private ReadOnly _Id As Long = - 1
		Private ReadOnly _Phase As IPhase
		Private _Relevant As Boolean = True
		Private _RelevantIsDirty As Boolean
		Private _Budget As Decimal
		Private _BudgetIsDirty As Boolean
		Private _Realised As Decimal
		Private _RealisedIsDirty As Boolean
		Private _Deadline As Date = Date.UtcNow
		Private _DeadlineIsDirty As Boolean

		''' <summary>
		''' New
		''' </summary>
		''' <param name="phase"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal phase As IPhase)
			_Phase = phase
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As Case2PhaseEntity)
			_Id = entity.Case2PhaseId
			_Phase = New Phase(entity.Phase)
			_Relevant = entity.Relevant
			_Budget = entity.Budget
			_Realised = entity.Realised
			_Deadline = entity.DeadlineDate
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long Implements IPhaseBudget.Id
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Phase
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Phase() As IPhase Implements IPhaseBudget.Phase
			Get
				Return _Phase
			End Get
		End Property

		''' <summary>
		''' Relevant
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Relevant() As Boolean Implements IPhaseBudget.Relevant
			Get
				Return _Relevant
			End Get
			Set(ByVal value As Boolean)
				If _Relevant <> value Then
					_Relevant = value
					_RelevantIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Budget
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Budget() As Decimal Implements IPhaseBudget.Budget
			Get
				Return _Budget
			End Get
			Set(ByVal value As Decimal)
				If _Budget <> value Then
					_Budget = value
					_BudgetIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Realised
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Realised() As Decimal Implements IPhaseBudget.Realised
			Get
				Return _Realised
			End Get
			Set(ByVal value As Decimal)
				If _Realised <> value Then
					_Realised = value
					_RealisedIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Deadline
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Deadline() As Date Implements IPhaseBudget.Deadline
			Get
				Return _Deadline.Date.ToLocalTime()
			End Get
			Set(ByVal value As Date)
				If Not _Deadline.Equals(value) Then
					_Deadline = value.Date.ToUniversalTime()
					_DeadlineIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Is Dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsDirty() As Boolean 'Implements IPhaseBudget.
			Get
				Return _RelevantIsDirty OrElse
				       _BudgetIsDirty OrElse
				       _RealisedIsDirty OrElse
				       _DeadlineIsDirty OrElse
				       IsNew
			End Get
		End Property

		''' <summary>
		''' Is New
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsNew() As Boolean
			Get
				Return _Id = - 1
			End Get
		End Property
	End Class
End Namespace
