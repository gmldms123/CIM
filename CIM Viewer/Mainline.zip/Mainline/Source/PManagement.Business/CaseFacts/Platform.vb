Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
	Public NotInheritable Class Platform
		Implements IPlatform

		Private ReadOnly _Id As Long
		Private _Name As String
		Private _Coordinator As IParticipant

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As PlatformEntity)
			_Id = entity.PlatformId
			_Name = entity.Name
			_Coordinator = New Participant.Participant(entity.Participant)
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long Implements IPlatform.Id
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Name() As String Implements IPlatform.Name
			Get
				Return _Name
			End Get
			Set(ByVal value As String)
				_Name = value
			End Set
		End Property

		''' <summary>
		''' 
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Coordinator() As IParticipant Implements IPlatform.Coordinator
			Get
				Return _Coordinator
			End Get
			Set(ByVal value As IParticipant)
				_Coordinator = value
			End Set
		End Property
	End Class
End Namespace