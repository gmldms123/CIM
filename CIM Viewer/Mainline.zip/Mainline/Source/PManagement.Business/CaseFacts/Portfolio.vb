﻿Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
	Public Class Portfolio
		Implements IPortfolio

		Private ReadOnly _id As Long
		Private ReadOnly _name As String
		Private ReadOnly _managerInitials As String
		Private ReadOnly _managerName As String

		Public Sub New(ByVal entity As PortfolioEntity)
			_id = entity.PortfolioId
			_name = entity.Name
			_managerInitials = entity.ManagerInitials
			_managerName = entity.ManagerName
		End Sub

		Public ReadOnly Property Id() As Long Implements IPortfolio.Id
			Get
				Return _id
			End Get
		End Property

		Public ReadOnly Property ManagerInitials() As String Implements IPortfolio.ManagerInitials
			Get
				Return _managerInitials
			End Get
		End Property

		Public ReadOnly Property ManagerName() As String
			Get
				Return _managerName
			End Get
		End Property

		Public ReadOnly Property Name() As String Implements IPortfolio.Name
			Get
				Return _name
			End Get
		End Property
	End Class
End Namespace