Namespace CaseFacts
	Public NotInheritable Class Project
		Private ReadOnly _Id As Long
		Private _Name As String
		Private ReadOnly _Sort As Integer

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As ProjectEntity)
			_Id = entity.ProjectId
			_Sort = entity.Sort
			_Name = entity.Name
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As ProjectEntity) As Boolean
			Dim dataChanged As Boolean

			'Name
			If _Name <> entity.Name Then
				_Name = entity.Name
				dataChanged = True
			End If

			Return dataChanged
		End Function

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Sort
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Sort() As Integer
			Get
				Return _Sort
			End Get
		End Property

		''' <summary>
		''' ToString()
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides Function ToString() As String
			Return _Name
		End Function
	End Class
End Namespace
