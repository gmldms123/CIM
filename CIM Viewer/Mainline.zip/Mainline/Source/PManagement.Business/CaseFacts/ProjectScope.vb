﻿Imports PManagement.DataLayer.Interfaces

Namespace CaseFacts
    Public NotInheritable Class ProjectScope
        Implements IProjectScope

        Private ReadOnly _ProjectScopeId As Long
        Private ReadOnly _Name As String
        Private ReadOnly _CreatedById As Long
        Private ReadOnly _Created As DateTime
        Private ReadOnly _DeletedById As Nullable(Of Long)
        Private ReadOnly _Deleted As Nullable(Of DateTime)

        Public Sub New(ByVal entity As ProjectScopeEntity)
            _ProjectScopeId = entity.ProjectScopeId
            _Name = entity.Name
            _CreatedById = entity.CreatedById
            _Created = entity.Created
            _DeletedById = entity.DeletedById
            _Deleted = entity.Deleted
            
        End Sub


        Public ReadOnly Property ProjectScopeId() As Long Implements IProjectScope.ProjectScopeId
            Get
                Return _ProjectScopeId
            End Get
        End Property

        Public ReadOnly Property Name() As String Implements IProjectScope.Name
            Get
                Return _Name
            End Get
        End Property

        Public ReadOnly Property CreatedById() As Long Implements IProjectScope.CreatedById
            Get
                Return _CreatedById
            End Get
        End Property

        Public ReadOnly Property Created() As Date Implements IProjectScope.Created
            Get
                Return _Created
            End Get
        End Property

        Public ReadOnly Property DeletedById() As Nullable(Of Long) Implements IProjectScope.DeletedById
            Get
                Return _DeletedById
            End Get
        End Property

        Public ReadOnly Property Deleted() As Nullable(Of DateTime) Implements IProjectScope.Deleted
            Get
                Return _Deleted
            End Get
        End Property
    End Class
End Namespace
