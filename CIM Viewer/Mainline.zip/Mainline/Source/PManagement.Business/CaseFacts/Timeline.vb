Namespace CaseFacts
  Public NotInheritable Class Timeline
    Private ReadOnly _Id As Long
    Private ReadOnly _Text As String
    Private ReadOnly _Changed As Date
    Private ReadOnly _ChangedBy As Participant.Participant

    ''' <summary>
    ''' New
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <remarks></remarks>
    Public Sub New(ByVal entity As TimelineEntity)
      _Id = entity.TimelineId
      _Text = entity.Text
      _Changed = entity.Changed
      _ChangedBy = New Participant.Participant(entity.ChangedByParticipant)
    End Sub

    ''' <summary>
    ''' Id
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Id() As Long
      Get
        Return _Id
      End Get
    End Property

    ''' <summary>
    ''' Name
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Text() As String
      Get
        Return _Text
      End Get
    End Property

    ''' <summary>
    ''' Changed
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Changed() As Date
      Get
        Return _Changed
      End Get
    End Property

    ''' <summary>
    ''' Changed By
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ChangedBy() As Participant.Participant
      Get
        Return _ChangedBy
      End Get
    End Property
  End Class
End Namespace
