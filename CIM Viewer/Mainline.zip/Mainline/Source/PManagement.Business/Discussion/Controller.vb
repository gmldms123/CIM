Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace Discussion
	''' <summary>
	''' Manage all interaction with data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model
		Private _changeLogService As IChangeLogService

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' Save object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			'Dummy implementation
			Return New ValidationSummary()
		End Function

		''' <summary>
		''' Threads
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Threads() As List(Of Thread)
			Get
				Dim ec As New EntityCollection(Of DiscussionEntity)(New DiscussionEntityFactory())
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Dim fb As New RelationPredicateBucket()
					fb.PredicateExpression.Add(DiscussionFields.CaseId = _Context.CaseId)
					fb.PredicateExpression.Add(DiscussionFields.ReplyToDiscussionId = DBNull.Value)
					Dim pp As New PrefetchPath2(DirectCast(EntityType.DiscussionEntity, Integer))
					pp.Add(DiscussionEntity.PrefetchPathCreatedByParticipant)
					pp.Add(DiscussionEntity.PrefetchPathModifiedByParticipant)
					Try
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.InjectThreads(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.Threads
			End Get
		End Property

		''' <summary>
		''' Replies
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Replies(ByVal id As Long) As List(Of Thread)
			Get
				Dim ec As New EntityCollection(Of DiscussionEntity)(New DiscussionEntityFactory())
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Dim fb As New RelationPredicateBucket()
					fb.PredicateExpression.Add(DiscussionFields.CaseId = _Context.CaseId)
					fb.PredicateExpression.Add(DiscussionFields.ReplyToDiscussionId = id)
					Dim pp As New PrefetchPath2(DirectCast(EntityType.DiscussionEntity, Integer))
					pp.Add(DiscussionEntity.PrefetchPathCreatedByParticipant)
					pp.Add(DiscussionEntity.PrefetchPathModifiedByParticipant)
					Try
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.InjectReplies(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.Replies(id)
			End Get
		End Property

		''' <summary>
		''' Last Activity of a thread
		''' </summary>
		''' <param name="id"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property LatestReply(ByVal id As Long) As Thread
			Get
				Dim ec As New EntityCollection(Of DiscussionEntity)(New DiscussionEntityFactory())
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Dim fb As New RelationPredicateBucket()
					fb.PredicateExpression.Add(DiscussionFields.CaseId = _Context.CaseId)
					fb.PredicateExpression.Add(DiscussionFields.ReplyToDiscussionId = id)
					Dim pp As New PrefetchPath2(DirectCast(EntityType.DiscussionEntity, Integer))
					pp.Add(DiscussionEntity.PrefetchPathCreatedByParticipant)
					pp.Add(DiscussionEntity.PrefetchPathModifiedByParticipant)
					Try
						daa.FetchEntityCollection(ec, fb, 1, Nothing, pp)
						_Model.InjectReplies(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.LatestReply(id)
			End Get
		End Property

		''' <summary>
		''' May Create Discussion
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayCreateDiscussion() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Discussions_Create)
			End Get
		End Property

		''' <summary>
		''' May Edit Discussion
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayEditDiscussion(ByVal item As Thread) As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Discussions_Edit) Or
				       _Context.User.Substring(_Context.User.IndexOf("\"c) + 1).Equals(item.CreatedBy.VestasInitials)
			End Get
		End Property

		''' <summary>
		''' May Reply To Discussion
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayReplyToDiscussion() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Discussions_Reply)
			End Get
		End Property

		''' <summary>
		''' Select Thread
		''' </summary>
		''' <remarks></remarks>
		Public Sub SelectThread(ByVal item As Thread)
			_Model.SelectThread(item)
		End Sub

		''' <summary>
		''' Add new discussion or reply
		''' </summary>
		''' <param name="Subject"></param>
		''' <param name="Message"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal Subject As String, ByVal Message As String, ByVal ReplyToId As Nullable(Of Long))
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					Dim ec As New EntityCollection(Of DiscussionEntity)(New DiscussionEntityFactory())
					Dim entity As DiscussionEntity = ec.AddNew()
					entity.CaseId = _Context.CaseId.Value
					If ReplyToId.HasValue Then entity.ReplyToDiscussionId = ReplyToId.Value
					entity.Name = Subject
					entity.Description = Message
					entity.CreatedByParticipant = _Context.UserParticipant
					daa.StartTransaction(IsolationLevel.Serializable, "DiscussionTransaction")
					Dim EntitySaved As Boolean = daa.SaveEntity(entity, True, False)
					If Not EntitySaved Then
						Throw New ApplicationException("A database operation failed. Please try again.")
					End If
					Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                _Context.UserParticipant.ParticipantId,
					                                                                ChangeTypeEnum.AnyChanges, String.Empty,
					                                                                String.Empty,
					                                                                [Enum].Format(GetType(AnyChangesEnum),
					                                                                              AnyChangesEnum.Discussions, "d").
					                                                               	ToString)
					If (vs.GetErrors.Count > 0) Then
						Throw New Exception(vs.ToString())
					End If
					daa.Commit()
					If ReplyToId.HasValue Then
						_Model.InjectReplies(ec)
					Else
						_Model.InjectThreads(ec)
					End If
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()
				End Try
			End Using
		End Sub

		''' <summary>
		''' Edit discussion or reply
		''' </summary>
		''' <param name="Subject"></param>
		''' <param name="Message"></param>
		''' <remarks></remarks>
		Public Sub Edit(ByVal item As Thread, ByVal Subject As String, ByVal Message As String)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					Dim ec As New EntityCollection(Of DiscussionEntity)(New DiscussionEntityFactory())
					Dim entity As DiscussionEntity = ec.AddNew()
					entity.DiscussionId = item.Id
					Dim pp As New PrefetchPath2(DirectCast(EntityType.DiscussionEntity, Integer))
					pp.Add(DiscussionEntity.PrefetchPathCreatedByParticipant)
					pp.Add(DiscussionEntity.PrefetchPathModifiedByParticipant)
					daa.FetchEntity(entity, pp)
					If String.Compare(entity.Name, Subject) <> 0 Then entity.Name = Subject
					If String.Compare(entity.Description, Message) <> 0 Then entity.Description = Message
					If entity.IsDirty Then
						entity.Modified = Date.UtcNow
						entity.ModifiedByParticipant = _Context.UserParticipant
					End If
					daa.StartTransaction(IsolationLevel.Serializable, "DiscussionTransaction")
					Dim EntitySaved As Boolean = daa.SaveEntity(entity, True, False)
					If Not EntitySaved Then
						Throw New ApplicationException("A database operation failed. Please try again.")
					End If
					Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                _Context.UserParticipant.ParticipantId,
					                                                                ChangeTypeEnum.AnyChanges, String.Empty,
					                                                                String.Empty,
					                                                                [Enum].Format(GetType(AnyChangesEnum),
					                                                                              AnyChangesEnum.Discussions, "d").
					                                                               	ToString)
					If (vs.GetErrors.Count > 0) Then
						Throw New Exception(vs.ToString())
					End If
					daa.Commit()
					_Model.Update(item, entity)
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()
				End Try
			End Using
		End Sub
	End Class
End Namespace
