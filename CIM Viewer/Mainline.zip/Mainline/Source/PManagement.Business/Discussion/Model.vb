Namespace Discussion
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Private ReadOnly _lThread As New List(Of Thread)
		Private ReadOnly _lReply As New List(Of Thread)
		Private _idToFind As Long
		Private _searchEntityCollection As EntityCollection(Of DiscussionEntity)

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return False
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_lThread.Clear()
			_lReply.Clear()
			OnDataChanged()
		End Sub

		''' <summary>
		''' Threads
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Threads() As List(Of Thread)
			Get
				Return _lThread
			End Get
		End Property

		''' <summary>
		''' Replies
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Replies(ByVal id As Long) As List(Of Thread)
			Get
				_idToFind = id
				Return _lReply.FindAll(New Predicate(Of Thread)(AddressOf FindReply))
			End Get
		End Property

		''' <summary>
		''' Latest Reply
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property LatestReply(ByVal id As Long) As Thread
			Get
				_idToFind = id
				Dim li As List(Of Thread) = _lReply.FindAll(New Predicate(Of Thread)(AddressOf FindReply))
				Dim itemIndex As Integer = - 1
				Dim lastCreated As New Date(1, 1, 1)
				For Each item As Thread In li
					If item.Created > lastCreated Then
						itemIndex = li.IndexOf(item)
						lastCreated = item.Created
					End If
				Next
				If itemIndex > - 1 Then
					Return li(itemIndex)
				Else
					Return Nothing
				End If
			End Get
		End Property

		''' <summary>
		''' Inject Threads
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub InjectThreads(ByVal ec As EntityCollection(Of DiscussionEntity))
			Dim dataChanged As Boolean = False

			'Add/Update
			For i As Integer = 0 To ec.Count - 1
				_idToFind = ec(i).DiscussionId
				Dim item As Thread = _lThread.Find(New Predicate(Of Thread)(AddressOf FindItemById))
				If item Is Nothing Then
					'Add
					_lThread.Add(New Thread(ec(i)))
					dataChanged = True
				Else
					'Update
					If Not _lThread.IndexOf(item).Equals(i) Then
						'Change sort order of threads
						_lThread.Remove(item)
						_lThread.Insert(i, item)
						dataChanged = True
					End If
					dataChanged = dataChanged Or item.Update(ec(i))
				End If
			Next

			'Remove
			_searchEntityCollection = ec
			dataChanged = dataChanged Or _lThread.RemoveAll(New Predicate(Of Thread)(AddressOf FindItemToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Inject Replies
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub InjectReplies(ByVal ec As EntityCollection(Of DiscussionEntity))
			Dim dataChanged As Boolean = False

			'Add/Update
			For i As Integer = 0 To ec.Count - 1
				_idToFind = ec(i).DiscussionId
				Dim item As Thread = _lReply.Find(New Predicate(Of Thread)(AddressOf FindItemById))
				If item Is Nothing Then
					'Add
					_lReply.Add(New Thread(ec(i)))
					dataChanged = True
				Else
					'Update
					_idToFind = item.ReplyToId.Value
					Dim li As List(Of Thread) = _lReply.FindAll(New Predicate(Of Thread)(AddressOf FindReply))
					If Not li.IndexOf(item).Equals(i) Then
						'Change sort order of threads
						Dim otherItem As Thread = li(i)
						_lReply.Remove(item)
						_lReply.Insert(_lReply.IndexOf(otherItem), item)
						dataChanged = True
					End If
					dataChanged = dataChanged Or item.Update(ec(i))
				End If
			Next

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Select Thread
		''' </summary>
		''' <remarks></remarks>
		Public Sub SelectThread(ByVal item As Thread)
			If Not item.Selected Then
				Dim prevSel As Thread = _lThread.Find(New Predicate(Of Thread)(AddressOf FindSelected))
				If prevSel IsNot Nothing Then prevSel.Selected = False
				item.Selected = True
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="item"></param>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub Update(ByVal item As Thread, ByVal entity As DiscussionEntity)
			If item.Update(entity) Then OnDataChanged()
		End Sub

		''' <summary>
		''' Find Item By Id
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemById(ByVal item As Thread) As Boolean
			Return item.Id.Equals(_idToFind)
		End Function

		''' <summary>
		''' Find Item To Remove
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemToRemove(ByVal item As Thread) As Boolean
			Return _searchEntityCollection.FindMatches(DiscussionFields.DiscussionId = item.Id).Count = 0
		End Function

		''' <summary>
		''' Find Reply
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindReply(ByVal item As Thread) As Boolean
			Return item.ReplyToId.Equals(_idToFind)
		End Function

		''' <summary>
		''' Find Selected Item
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSelected(ByVal item As Thread) As Boolean
			Return item.Selected
		End Function
	End Class
End Namespace
