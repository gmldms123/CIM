

Namespace Discussion
	''' <summary>
	''' Thread
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Thread
		Private ReadOnly _Id As Long = - 1
		Private ReadOnly _ReplyToId As Nullable(Of Long) = Nothing
		Private _Name As String = String.Empty
		Private _Description As String = String.Empty
		Private ReadOnly _Created As Date = Date.UtcNow
		Private ReadOnly _CreatedBy As ParticipantEntity = Nothing
		Private _Modified As Nullable(Of Date) = Nothing
		Private _ModifiedBy As ParticipantEntity = Nothing
		Private _Selected As Boolean = False

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As DiscussionEntity)
			_Id = entity.DiscussionId
			If entity.ReplyToDiscussionId.HasValue Then
				_ReplyToId = entity.ReplyToDiscussionId.Value
			End If
			_Name = entity.Name
			_Description = entity.Description
			_Created = entity.Created
			_CreatedBy = entity.CreatedByParticipant
			_Modified = entity.Modified
			_ModifiedBy = entity.ModifiedByParticipant
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As DiscussionEntity) As Boolean
			Dim updated As Boolean = False
			If String.Compare(_Name, entity.Name) <> 0 Then
				_Name = entity.Name
				updated = True
			End If
			If String.Compare(_Description, entity.Description) <> 0 Then
				_Description = entity.Description
				updated = True
			End If
			If Not entity.Modified.Equals(Modified) Then
				_Modified = entity.Modified
				updated = True
			End If
			If entity.ModifiedByParticipant IsNot Nothing Then
				If _
					_ModifiedBy Is Nothing OrElse
					(_ModifiedBy IsNot Nothing AndAlso Not entity.ModifiedByParticipant.Equals(_ModifiedBy)) Then
					_ModifiedBy = entity.ModifiedByParticipant
					updated = True
				End If
			Else
				If _ModifiedBy IsNot Nothing Then
					_ModifiedBy = Nothing
					updated = True
				End If
			End If
			Return updated
		End Function

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Reply To Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ReplyToId() As Nullable(Of Long)
			Get
				Return _ReplyToId
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Description() As String
			Get
				Return _Description
			End Get
		End Property

		''' <summary>
		''' Created
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Created() As Date
			Get
				Return _Created
			End Get
		End Property

		''' <summary>
		''' Created By
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property CreatedBy() As ParticipantEntity
			Get
				Return _CreatedBy
			End Get
		End Property

		''' <summary>
		''' Modified
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Modified() As Nullable(Of Date)
			Get
				Return _Modified
			End Get
		End Property

		''' <summary>
		''' Modified By Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ModifiedBy() As ParticipantEntity
			Get
				Return _ModifiedBy
			End Get
		End Property

		''' <summary>
		''' Selected
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Selected() As Boolean
			Get
				Return _Selected
			End Get
			Set(ByVal value As Boolean)
				_Selected = value
			End Set
		End Property
	End Class
End Namespace
