

Namespace Document.BeforeSaveActions.MSProjectIntegration
	''' <summary>
	''' Utillity class used for interfacing to Microsoft Project 2003 files
	''' </summary>
	''' <remarks></remarks>
		Public Class MPP_MPX_Interface
		Public Sub New()
		End Sub

		' Mapping from custom field(s) in the Project file to PManagement database fields
		' Task.Number18 = BrandId 
		' Task.Number19 = PhaseId
		' Task.Number20 = StandardTaskId
		' Task.Text1    = ScheduleComments

		' Information from the project file on the definition of Hours in Days, Weeks and Months
		' Offset to handle the constraint on the Aspose.Tasks component in trial edition
	End Class
End Namespace
