Namespace Document.BeforeSaveActions.MSProjectIntegration
	''' <summary>
	''' Holds the relationship between Phases in the database and the corresponding Tasks in the project file
	''' </summary>
	''' <remarks></remarks>
		Public Class Phase2Task
		Public Case2Phase As Case2PhaseEntity = Nothing
		'Public PhaseTask As Task = Nothing

		Public Sub New(ByVal oCase2Phase As Case2PhaseEntity)
			Case2Phase = oCase2Phase
		End Sub
	End Class
End NameSpace
