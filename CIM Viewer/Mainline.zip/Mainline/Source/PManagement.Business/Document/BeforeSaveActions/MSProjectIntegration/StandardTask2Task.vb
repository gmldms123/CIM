Namespace Document.BeforeSaveActions.MSProjectIntegration
	''' <summary>
	''' Holds the relationship between Standard Tasks in the database and the corresponding Tasks in the project file
	''' </summary>
	''' <remarks></remarks>
		Public Class StandardTask2Task
		Public StandardTask As StandardTaskEntity = Nothing
		'Public ProjectTask As Task = Nothing

		Public Sub New(ByVal oStandardTask As StandardTaskEntity)
			StandardTask = oStandardTask
		End Sub
	End Class
End NameSpace
