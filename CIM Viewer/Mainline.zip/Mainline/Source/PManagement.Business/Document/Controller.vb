Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.Framework
Imports PManagement.Framework.Imaging
Imports PManagement.ServiceLayer.Services.Interfaces.Performance
Imports PManagement.ServiceLayer.Services.Interfaces
Imports PManagement.ModelLayer
Imports PManagement.Services.DmsDocumentService
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.Interfaces
Imports PManagement.Framework.ValidationResults
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Services
Imports StructureMap

Namespace Document
    ''' <summary>
    ''' Manage all interaction with document data model from viewers
    ''' </summary>
    ''' <remarks></remarks>
    Partial Public NotInheritable Class Controller
        Inherits BaseClasses.Controller
        Implements IInformationSaver

        Private _Model As Model
        Private _Upload As Upload
        Private _Download As Download
        Public CaseManagerRowsOnOpen As Integer
        Public newPopList As Boolean = False
        Private _changeLogService As IChangeLogService
        Private Shared Locresponse As Y_CA_DMS02_GET_DMS_DOCResponse
        Private Shared LocCaseNumber As Long

        ''' <summary>
        ''' Finalize
        ''' </summary>
        ''' <remarks></remarks>
        Protected Overrides Sub Finalize()
            If _Initialized Then
                RemoveHandler _Upload.DocumentSaved, AddressOf OnDocumentSaved
                RemoveHandler _Upload.DocumentUpdated, AddressOf OnDocumentUpdated
                RemoveHandler _Upload.UploadFailed, AddressOf OnUploadFailed
                UndoPromotions()
                _Model = Nothing
                _Upload = Nothing
                _Download = Nothing
            End If
            MyBase.Finalize()
        End Sub

        ''' <summary>
        ''' Initialize
        ''' </summary>
        ''' <param name="environment"></param>
        ''' <param name="context"></param>
        ''' <param name="accesscontrol"></param>
        ''' <param name="model"></param>
        ''' <remarks></remarks>
        Public Shadows Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
                                      ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model,
                                      ByRef upload As Upload, ByRef download As Download)
            _Model = DirectCast(model, Model)
            ObjectFactory.GetInstance(Of IDocumentService)()

            _Upload = upload
            _Download = download

            AddHandler _Upload.DocumentSaved, AddressOf OnDocumentSaved
            AddHandler _Upload.DocumentUpdated, AddressOf OnDocumentUpdated
            AddHandler _Upload.UploadFailed, AddressOf OnUploadFailed

            MyBase.Initialize(environment, context, accesscontrol, model)

            _changeLogService = ObjectFactory.GetInstance(Of IChangeLogService)()
            ObjectFactory.GetInstance(Of IPerformanceActionService)()
            ObjectFactory.GetInstance(Of IPerformanceDataService)()
        End Sub

        Public Function GetFileExtension(ByVal filename As String) As String
            Return Path.GetExtension(filename)
        End Function

        ''' <summary>
        ''' Is model dirty
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Overrides ReadOnly Property IsDirty() As Boolean
            Get
                Return _Model.IsDirty
            End Get
        End Property
        ''' <summary>
        ''' DmsServiceReponse
        ''' </summary>
        ''' <returns>Locresponse</returns>
        Public Shared Property DmsServiceReponse() As Y_CA_DMS02_GET_DMS_DOCResponse
            Get
                Return Locresponse
            End Get
            Set(ByVal value As Y_CA_DMS02_GET_DMS_DOCResponse)
                Locresponse = value
            End Set
        End Property

        ''' <summary>
        ''' PrpCasenumber
        ''' </summary>
        ''' <returns>LocCaseNumber</returns>
        Public Shared Property PrpCasenumber() As Long
            Get
                Return LocCaseNumber
            End Get
            Set(ByVal value As Long)
                LocCaseNumber = value
            End Set
        End Property

        ''' <summary>
        ''' Are any Documents loced by the current user
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property HasLockedDocuments() As Boolean
            Get
                Return _Model.LockedDocuments.Count > 0
            End Get
        End Property

        ''' <summary>
        ''' Clear object model
        ''' </summary>
        ''' <remarks></remarks>
        Public Overrides Sub Clear()
            If _Model IsNot Nothing Then _Model.Clear()
        End Sub

        ''' <summary>
        ''' Set the title of the document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <param name="Title"></param>
        ''' <remarks></remarks>
        Public Sub SetDocumentTitle(ByVal doc As Document, ByVal Title As String)
            If Not Title.Trim = String.Empty Then
                _Model.SetDocumentTitle(doc, Title)
            Else
                Throw New ApplicationException("Title must be supplied.")
            End If
        End Sub

        ''' <summary>
        ''' Set the description of the document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <param name="Description"></param>
        ''' <remarks></remarks>
        Public Sub SetDocumentDescription(ByVal doc As Document, ByVal Description As String)
            _Model.SetDocumentDescription(doc, Description)
        End Sub

        Public Function GetFolderImageIndex(ByVal folder As Folder) As Integer
            Dim imageIndex As Integer
            Select Case folder.Type
                Case Folder.Types.StandardFolder
                    imageIndex = 6
                Case Folder.Types.InboxFolder
                    imageIndex = 0
                Case Folder.Types.CustomFolder
                    imageIndex = 5
                Case Folder.Types.PictureFolder
                    imageIndex = 4
                Case Folder.Types.TrashCanFolder
                    imageIndex = 2
                Case Folder.Types.PhaseFolder
                    imageIndex = 6
                Case Folder.Types.PopulationListFolder
                    imageIndex = 6
                Case Folder.Types.ProjectPlanFolder
                    imageIndex = 6
            End Select
            Return imageIndex
        End Function

        ''' <summary>
        ''' Set the Classification of the document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <param name="Classification"></param>
        ''' <remarks></remarks>
        Public Sub SetDocumentClassification(ByVal doc As Document, ByVal Classification As Long)
            Select Case Classification
                Case 1
                    If Not _AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass1Documents) Then
                        Throw _
                            New ApplicationException("You do not have sufficient access rights to change the Classification to Class 1.")
                    End If
                Case 2
                    If Not _AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass2Documents) Then
                        Throw _
                            New ApplicationException("You do not have sufficient access rights to change the Classification to Class 2.")
                    End If
                Case 3
                    If Not _AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass3TechnicalDocuments) Then
                        Throw _
                            New ApplicationException(
                                "You do not have sufficient access rights to change the Classification to Class 3 Technical.")
                    End If
                Case 4
                    If Not _AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass3FinancialDocuments) Then
                        Throw _
                            New ApplicationException(
                                "You do not have sufficient access rights to change the Classification to Class 3 Financial.")
                    End If
            End Select

            _Model.SetDocumentClassification(doc, Classification)
        End Sub

        ''' <summary>
        ''' Set the CaseFactsStatus of the document
        ''' </summary>
        ''' <param name="Parent"></param>
        ''' <param name="Doc"></param>
        ''' <param name="StatusId"></param>
        ''' <param name="StatusName"></param>
        ''' <remarks></remarks>
        Public Sub SetDocumentStatus(ByVal Parent As Folder, ByVal Doc As Document, ByVal StatusId As Long,
                                     ByVal StatusName As String)
            _Model.SetDocumentStatus(Parent, Doc, StatusId, StatusName)
        End Sub

        ''' <summary>
        ''' Set the Link No of the document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <param name="LinkNo"></param>
        ''' <remarks></remarks>
        Public Sub SetDocumentLinkNo(ByVal doc As Document, ByVal LinkNo As Nullable(Of Long))
            If Not LinkNo.HasValue Or (LinkNo.HasValue AndAlso (LinkNo.Value >= 0 And LinkNo.Value <= Short.MaxValue)) Then
                Dim shrt As Nullable(Of Short) = Nothing
                If LinkNo.HasValue Then shrt = Short.Parse(LinkNo.Value.ToString())
                _Model.SetDocumentLinkNo(doc, shrt)
            Else
                Throw New ApplicationException(String.Format("LinkNo must be a number between 0 and {0}", Short.MaxValue))
            End If
        End Sub

        ''' <summary>
        ''' Set the Turbine No of the document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <param name="TurbineNo"></param>
        ''' <remarks></remarks>
        Public Sub SetDocumentTurbineNo(ByVal doc As Document, ByVal TurbineNo As String)
            _Model.SetDocumentTurbineNo(doc, TurbineNo)
        End Sub

        ''' <summary>
        ''' Set the name of the folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <param name="name"></param>
        ''' <remarks></remarks>
        Public Sub SetFolderName(ByVal folder As Folder, ByVal name As String)
            If name IsNot Nothing AndAlso name.Trim().Length = 0 Then _
                Throw New ApplicationException("You must give your folder a name with at least one non whitespace character")
            If name IsNot Nothing Then _Model.SetFolderName(folder, name)
        End Sub

        ''' <summary>
        ''' Save document to database
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Private Sub OnDocumentSaved(ByVal e As UploadEventArgs)
            Using daa As New DataAccessAdapter(e.Document.Environment.PManagement_ConnectionString, True)
                Dim entity As New DocumentEntity()
                For Each folder As Folder In e.Document.Folders
                    Dim fldr2docent As New Folder2DocumentEntity()
                    fldr2docent.FolderId = folder.Id
                    fldr2docent.DocumentId = e.Document.Id
                    fldr2docent.DocumentStatusId = e.Document.StatusId(folder)
                    entity.Folder2Document.Add(fldr2docent)
                Next
                entity.DocumentBinaryId = e.DocumentBinaryId
                entity = UpdateDocumentEntity(entity, e.Document)
                entity.FileDate = e.Document.FileDate
                entity.FileName = e.Document.FileName
                entity.FileSize = e.Document.FileSize
                entity.Created = e.Document.Created
                entity.CreatedById = e.Document.CreatedByParticipant.ParticipantId
                entity.PictureHeight = e.Document.PictureHeight
                entity.PictureWidth = e.Document.PictureWidth
                entity.PictureDate = e.Document.PictureDateTaken
                If e.Document.ThumbNail IsNot Nothing Then
                    'Convert image to byte array
                    entity.Thumbnail = ImageByteArrayConverter.ImageToByteArray(e.Document.ThumbNail, e.Document.ThumbNail.RawFormat)
                End If

                Try
                    'Set higher timeout to allow for page split on database
                    daa.CommandTimeOut = 300
                    daa.SaveEntity(entity, True, True)
                    'Only update the model if we're still in the same environment and PmanContext

                    Dim environmentUnchanged As Boolean = e.Document.Environment.Environment = _Environment.Environment
                    Dim brandIdUnchanged As Boolean = e.Document.Context.BrandId.Equals(_Context.BrandId)
                    Dim caseIdUnchanged As Boolean = e.Document.Context.CaseId.Equals(_Context.CaseId)

                    If environmentUnchanged And brandIdUnchanged And caseIdUnchanged Then
                        _Model.DocumentSaved(e.Document, entity.DocumentId, entity.DocumentBinaryId)
                    End If

                    'Move temporary file to cache
                    moveTemporaryFileToCache(e)

                Catch ex As ORMQueryExecutionException
                    PmanTrace.WriteVerbose("DocumentController", "OnDocumentSaved",
                                           String.Format("Failed to save ""{0}""{1}{2}{1}{3}{4}", e.Document.FullPathAndFileName,
                                                         System.Environment.NewLine, ex.Message, ex.StackTrace, ex.QueryExecuted))
                    Throw New ApplicationException("A database operation failed. Please try again.")
                End Try
            End Using
        End Sub

        ''' <summary>
        ''' Update document to database
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Private Sub OnDocumentUpdated(ByVal e As UploadEventArgs)
            Using daa As New DataAccessAdapter(e.Document.Environment.PManagement_ConnectionString, True)
                'Update document to database
                Dim entity As New DocumentEntity(e.Document.Id)
                Try
                    Dim pp As New PrefetchPath2(CInt(EntityType.DocumentEntity))
                    pp.Add(DocumentEntity.PrefetchPathFolder2Document)
                    daa.FetchEntity(entity, pp)
                Catch ex As ORMQueryExecutionException
                    daa.CloseConnection()
                    Throw New ApplicationException("A database operation failed. Please try again.")
                End Try

                'Update document
                entity.DocumentBinaryId = e.DocumentBinaryId
                entity = UpdateDocumentEntity(entity, e.Document)
                entity.FileDate = e.Document.FileDate
                entity.FileName = e.Document.FileName
                entity.FileSize = e.Document.FileSize
                entity.Created = e.Document.Created
                entity.CreatedById = e.Document.CreatedByParticipant.ParticipantId
                entity.Locked = Nothing
                entity.LockedById = Nothing
                Try
                    daa.SaveEntity(entity, False, True)
                    Dim oldBinary As New DocumentBinaryEntity(e.Document.DocumentBinaryId.Value)
                    Dim di As New DirectoryInfo(Path.GetDirectoryName(e.Document.FullPathAndFileName))
                    'Only update the model if we're still in the same environment and PmanContext
                    If e.Document.Environment.Environment = _Environment.Environment And
                       e.Document.Context.BrandId.Equals(_Context.BrandId) And
                       e.Document.Context.CaseId.Equals(_Context.CaseId) Then
                        _Model.DocumentSaved(e.Document, e.Document.Id, e.DocumentBinaryId)
                    End If
                    'Move cached file to new directory
                    Dim fi As FileInfo = Nothing
                    Try
                        fi = di.GetFiles()(0)
                        fi.Attributes = FileAttributes.Normal
                        Dim newfi As FileInfo = General.GetFileInfo(e.Document)
                        newfi.Directory.Create()
                        fi.MoveTo(newfi.FullName)
                        fi.Attributes = FileAttributes.Normal Or FileAttributes.ReadOnly
                        di.Delete()
                    Catch ex As Exception
                        Try
                            'If download thread has already begun downloading the new file, just delete the old file
                            If fi IsNot Nothing AndAlso fi.Exists Then
                                fi.Attributes = FileAttributes.Normal
                                fi.Directory.Delete(True)
                            ElseIf di IsNot Nothing AndAlso di.Exists Then
                                di.Delete(True)
                            End If
                        Catch
                        End Try
                    End Try

                    'Delete old binary
                    Try
                        daa.DeleteEntity(oldBinary)
                    Catch
                        'It can be cleaned up later and will not mess up anything
                    End Try
                Catch ex As ORMQueryExecutionException
                    Throw New ApplicationException("A database operation failed. Please try again.")
                Finally
                    daa.CloseConnection()
                End Try
            End Using
        End Sub

        ''' <summary>
        ''' Update database document entity
        ''' </summary>
        ''' <param name="entity"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function UpdateDocumentEntity(ByVal entity As DocumentEntity, ByVal doc As Document) As DocumentEntity
            If String.Compare(entity.Title, doc.Title) <> 0 Then entity.Title = doc.Title
            If String.Compare(entity.Description, doc.Description) <> 0 Then entity.Description = doc.Description
            If doc.Type <> DocumentTypes.Template And entity.DocumentClassificationId <> doc.ClassificationId Then _
                entity.DocumentClassificationId = doc.ClassificationId
            If Not entity.LinkNo.Equals(doc.LinkNo) Then entity.LinkNo = doc.LinkNo
            If String.Compare(entity.TurbineNumber, doc.TurbineNumber) <> 0 Then entity.TurbineNumber = doc.TurbineNumber
            If Not entity.Deleted.Equals(doc.Recycled) Then entity.Deleted = doc.Recycled

            If doc.Type = DocumentTypes.Template Then
                For Each item As KeyValuePair(Of Long, Status) In doc.Statuses
                    Dim indices As List(Of Integer) = entity.Folder2Document.FindMatches(Folder2DocumentFields.FolderId = item.Key)
                    If indices.Count = 1 AndAlso entity.Folder2Document(indices(0)).DocumentStatusId <> item.Value.Id Then
                        entity.Folder2Document(indices(0)).DocumentStatusId = item.Value.Id
                    End If
                Next
            Else
                If entity.Folder2Document.Count = 0 Then
                    Dim f2d As Folder2DocumentEntity = entity.Folder2Document.AddNew()
                    f2d.FolderId = -1
                    f2d.DocumentStatusId = -1
                End If
                If entity.Folder2Document(0).FolderId <> doc.Folders(0).Id Then _
                    entity.Folder2Document(0).FolderId = doc.Folders(0).Id
                If entity.Folder2Document(0).DocumentStatusId <> doc.StatusId(doc.Folders(0)) Then _
                    entity.Folder2Document(0).DocumentStatusId = doc.StatusId(doc.Folders(0))
            End If
            Return entity
        End Function

        ''' <summary>
        ''' Re-enqueue document for another go
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Private Sub OnUploadFailed(ByVal e As UploadEventArgs)
            PmanTrace.WriteVerbose("DocumentController", "OnUploadFailed",
                                   String.Format("Failed to upload ""{0}""", e.Document.FullPathAndFileName))
            'TODO: This exception is not catched anywhere in the application and will result in an unexpected unhandled error
            Throw New ApplicationException(String.Format("The document ""{0}"" failed to upload.", e.Document.Title))
        End Sub

        ''' <summary>
        ''' Fetch folders for the current case
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub FetchFolders()
            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)

                daa.CommandTimeOut = 120
                Dim ec As New EntityCollection(Of FolderEntity)(New FolderEntityFactory())
                Dim fb As New RelationPredicateBucket()
                Dim se As New SortExpression()
                fb.PredicateExpression.Add(FolderFields.CaseId = _Context.CaseId)
                Dim pp As New PrefetchPath2(CInt(EntityType.FolderEntity))
                pp.Add(FolderEntity.PrefetchPathCreatedByParticipant)
                pp.Add(FolderEntity.PrefetchPathLockedByParticipant)
                pp.Add(FolderEntity.PrefetchPathParentFolder)
                se.Add(FolderFields.Sort Or SortOperator.Ascending)
                se.Add(FolderFields.FolderTypeId Or SortOperator.Ascending)
                se.Add(FolderFields.Name Or SortOperator.Ascending)
                se.Add(FolderFields.Created Or SortOperator.Ascending)
                Try
                    daa.FetchEntityCollection(ec, fb, 0, se, pp)
                    _Model.InjectFolders(ec)
                Catch ex As ORMQueryExecutionException
                    Throw New ApplicationException("A database operation failed. Please try again.")
                Finally
                    daa.CloseConnection()
                End Try
            End Using
        End Sub

        ''' <summary>
        ''' Get all phase folders for the current case
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property PhaseFolders() As List(Of Folder)
            Get
                FetchFolders()
                Return _Model.PhaseFolders
            End Get
        End Property

        ''' <summary>
        ''' Get all document folders for the current case
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property Folders() As List(Of Folder)
            Get
                FetchFolders()
                Return _Model.Folders
            End Get
        End Property

        ''' <summary>
        ''' Get all documents with LinkNo
        ''' </summary>
        ''' <param name="LinkNo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetDocumentsByLinkNo(ByVal LinkNo As Short) As List(Of Document)
            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                Dim ec As New EntityCollection(Of DocumentEntity)(New DocumentEntityFactory())
                Dim fb As New RelationPredicateBucket()
                fb.Relations.Add(DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId)
                fb.Relations.Add(Folder2DocumentEntity.Relations.FolderEntityUsingFolderId)
                fb.PredicateExpression.Add(FolderFields.Deleted = False)
                fb.PredicateExpression.Add(FolderFields.CaseId = _Context.CaseId)
                fb.PredicateExpression.AddWithAnd(DocumentFields.LinkNo = LinkNo)

                Dim pp As New PrefetchPath2(CInt(EntityType.DocumentEntity))
                pp.Add(DocumentEntity.PrefetchPathCreatedByParticipant)
                pp.Add(DocumentEntity.PrefetchPathLockedByParticipant)
                Dim ppe As IPrefetchPathElement2 = pp.Add(DocumentEntity.PrefetchPathFolder2Document)
                ppe.SubPath.Add(Folder2DocumentEntity.PrefetchPathFolder)
                ppe.SubPath.Add(Folder2DocumentEntity.PrefetchPathDocumentStatus)

                Try
                    daa.FetchEntityCollection(ec, fb, pp)
                    FetchFolders()
                    _Model.InjectDocuments(ec)
                Catch ex As ORMQueryExecutionException
                    Throw New ApplicationException("A database operation failed. Please try again.")
                Finally
                    daa.CloseConnection()
                End Try

            End Using
            Return _Model.Documents(LinkNo)
        End Function

        ''' <summary>
        ''' Gets information on all documents for the current case
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetDocumentsForCase() As List(Of DocumentInfo)
            Dim documents As New List(Of DocumentInfo)

            Dim connection As SqlConnection = New SqlConnection(_Environment.PManagement_ConnectionString)
            Dim reader As SqlDataReader = Nothing

            Try
                connection.Open()
                Dim command As SqlCommand = New SqlCommand()
                command.Connection = connection
                command.CommandText = "GetDocumentsForCase"
                command.CommandType = CommandType.StoredProcedure

                Dim caseIdParameter As New SqlParameter("@CaseId", SqlDbType.BigInt)
                caseIdParameter.Value = _Context.CaseId
                command.Parameters.Add(caseIdParameter)

                reader = command.ExecuteReader()

                Dim folderIdOrdinal As Integer = reader.GetOrdinal("FolderId")
                Dim folderTypeIdOrdinal As Integer = reader.GetOrdinal("FolderTypeId")
                Dim documentIdOrdinal As Integer = reader.GetOrdinal("DocumentId")
                Dim fileNameOrdinal As Integer = reader.GetOrdinal("FileName")
                Dim classifictionIdOrdinal As Integer = reader.GetOrdinal("DocumentClassificationId")
                Dim titleOrdinal As Integer = reader.GetOrdinal("Title")
                Dim fileSizeOrdinal As Integer = reader.GetOrdinal("FileSize")
                Dim linkNoOrdinal As Integer = reader.GetOrdinal("LinkNo")
                Dim statusNameOrdinal As Integer = reader.GetOrdinal("StatusName")
                Dim fileDateOrdinal As Integer = reader.GetOrdinal("FileDate")
                Dim createdOrdinal As Integer = reader.GetOrdinal("Created")
                Dim createdByOrdinal As Integer = reader.GetOrdinal("CreatedBy")
                Dim deletedOrdinal As Integer = reader.GetOrdinal("Deleted")


                While reader.Read()
                    Dim de As New DocumentInfo()
                    de.DocumentId = reader.GetInt64(documentIdOrdinal)
                    de.Title = reader.GetString(titleOrdinal)
                    de.FolderId = reader.GetInt64(folderIdOrdinal)
                    de.FolderType = DirectCast([Enum].Parse(GetType(Folder.Types), reader.GetInt64(folderTypeIdOrdinal).ToString()),
                                               Folder.Types)
                    de.FileSize = reader.GetInt64(fileSizeOrdinal)
                    de.FileName = reader.GetString(fileNameOrdinal)
                    de.ClassificationId = reader.GetInt64(classifictionIdOrdinal)
                    de.Status = reader.GetString(statusNameOrdinal)
                    de.FileDate = reader.GetDateTime(fileDateOrdinal)
                    de.Deleted = reader.GetBoolean(deletedOrdinal)

                    If (reader.IsDBNull(linkNoOrdinal) = False) Then
                        de.LinkNo = reader.GetInt16(linkNoOrdinal)
                    End If
                    If (reader.IsDBNull(createdOrdinal) = False) Then
                        de.Created = reader.GetDateTime(createdOrdinal)
                    End If
                    If (reader.IsDBNull(createdByOrdinal) = False) Then
                        de.CreatedBy = reader.GetString(createdByOrdinal)
                    End If

                    Dim extension As String = String.Empty
                    Dim index As Integer = de.FileName.LastIndexOf("."c)
                    If (index > 0) Then
                        extension = de.FileName.Substring(index)
                    End If

                    ' document type
                    If de.FolderType = Folder.Types.PopulationListFolder Then
                        de.Type = DocumentTypes.PopulationList
                    ElseIf General.IsPicture(extension) Then
                        de.Type = DocumentTypes.Picture
                    End If

                    documents.Add(de)
                End While

            Finally
                If reader IsNot Nothing Then
                    reader.Close()
                End If
                connection.Close()
            End Try


            Return documents
        End Function

        ''' <summary>
        ''' Get all documents for the selected folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetDocumentsByFolder(ByVal folder As Folder) As List(Of Document)

            If Not folder.Type = Folder.Types.ProjectPlanFolder Then
                'Do not fetch data for new folders or the trashcan
                If Not folder.IsNew Then
                    Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                        Dim ec As New EntityCollection(Of DocumentEntity)(New DocumentEntityFactory())
                        Dim fb As New RelationPredicateBucket()
                        fb.Relations.Add(DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId)
                        If folder.Type = Folder.Types.TrashCanFolder Then
                            fb.Relations.Add(Folder2DocumentEntity.Relations.FolderEntityUsingFolderId)
                            fb.PredicateExpression.Add(FolderFields.Deleted = False)
                            fb.PredicateExpression.Add(
                                DocumentFields.Deleted = (folder.Type = Folder.Types.TrashCanFolder Or folder.Recycled Or folder.Deleted))
                            fb.PredicateExpression.Add(FolderFields.CaseId = _Context.CaseId)
                        Else
                            fb.PredicateExpression.Add(Folder2DocumentFields.FolderId = folder.Id)
                        End If

                        Dim pp As New PrefetchPath2(CInt(EntityType.DocumentEntity))
                        pp.Add(DocumentEntity.PrefetchPathCreatedByParticipant)
                        pp.Add(DocumentEntity.PrefetchPathLockedByParticipant)
                        Dim ppe As IPrefetchPathElement2 = pp.Add(DocumentEntity.PrefetchPathFolder2Document)
                        ppe.SubPath.Add(Folder2DocumentEntity.PrefetchPathFolder)
                        ppe.SubPath.Add(Folder2DocumentEntity.PrefetchPathDocumentStatus)
                        Try
                            daa.FetchEntityCollection(ec, fb, pp)
                            _Model.InjectDocuments(ec, folder)
                        Catch ex As ORMQueryExecutionException
                            Throw New ApplicationException("A database operation failed. Please try again.")
                        Finally
                            daa.CloseConnection()
                        End Try
                    End Using
                End If
            End If

            Return _Model.Documents(folder)
        End Function

        ''' <summary>
        ''' Download file
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns>Path and filename to the locally cached document</returns>
        ''' <remarks></remarks>
        Public Function GetFile(ByVal doc As Document) As String
            If Not doc.IsNew And doc.FullPathAndFileName.Length > 0 Then
                _Download.PriorityDownload(doc)
                Return doc.FullPathAndFileName
            Else
                Throw New ApplicationException("You must save the file before trying to view it")
            End If
        End Function

        Public Function CheckAccessRightsForDocument(ByVal doc As Document) As ValidationSummary
            Dim validationSummary As New ValidationSummary()

            Dim documentAccessRights As New DocumentAccessRights()

            If doc.IsProjectPlan Then
                documentAccessRights.ValidateProjectPlanDocuments(doc, validationSummary, _AccessControl)
            Else
                documentAccessRights.ValidateDocument(doc, validationSummary, _AccessControl)
            End If

            Return validationSummary
        End Function

        ''' <summary>
        ''' Is folder in Inbox folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function IsInInboxFolder(ByVal folder As Folder) As Boolean
            Dim rootFolder As Folder = folder
            While rootFolder.Parent IsNot Nothing
                rootFolder = rootFolder.Parent
            End While
            Return rootFolder.Type = Folder.Types.InboxFolder
        End Function

        ''' <summary>
        ''' Checks whether the current user has rights for creating and deleting documents and folders outside inbox
        ''' </summary>
        ''' <returns>True if the user has rights for creating and deleting documents and folders outside inbox</returns>
        ''' <remarks></remarks>
        Private Function HasAdminDeleteCreateRights() As Boolean
            Return _AccessControl.OperationIsLegal(Permissions.Editor_Documents_MoveFromInBoxToFolder)
        End Function

        ''' <summary>
        ''' May user add a folder to the selected folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayAddFolder(ByVal folder As Folder) As Boolean
            Dim isInInboxFolder As Boolean = Me.IsInInboxFolder(folder)
            Dim isCaseManager As Boolean = False
            If _Context.IsCaseManager.HasValue Then isCaseManager = _Context.IsCaseManager.Value
            Return folder.Type <> Folder.Types.PhaseFolder And
                   folder.Type <> Folder.Types.PopulationListFolder And
                   folder.Type <> Folder.Types.ProjectPlanFolder And
                   folder.Type <> Folder.Types.TrashCanFolder And
                   Not folder.Recycled And
                   Not folder.Deleted And
                   (isCaseManager Or HasAdminDeleteCreateRights() Or isInInboxFolder)
        End Function

        ''' <summary>
        ''' May the selected folder receive a folder
        ''' </summary>
        ''' <param name="folder">The selected folder to receive a folder</param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayReceiveFolder(ByVal folder As Folder) As Boolean
            Dim isInInboxFolder As Boolean = Me.IsInInboxFolder(folder)
            Dim hasRights As Boolean = _AccessControl.OperationIsLegal(Permissions.Editor_Documents_MoveFromInBoxToFolder)
            Return folder.Type <> Folder.Types.PhaseFolder And
                   folder.Type <> Folder.Types.PopulationListFolder And
                   folder.Type <> Folder.Types.ProjectPlanFolder And
                   folder.Type <> Folder.Types.TrashCanFolder And
                   Not folder.Recycled And
                   Not folder.Deleted And
                   (hasRights Or isInInboxFolder)
        End Function

        ''' <summary>
        ''' May user delete the selected folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayDeleteFolder(ByVal folder As Folder) As Boolean
            Dim isInInboxFolder As Boolean = Me.IsInInboxFolder(folder)
            Dim isCaseManager As Boolean = False
            If _Context.IsCaseManager.HasValue Then isCaseManager = _Context.IsCaseManager.Value
            Return folder.Type <> Folder.Types.PhaseFolder And
                   folder.Type <> Folder.Types.PopulationListFolder And
                   folder.Type <> Folder.Types.ProjectPlanFolder And
                   (Not folder.Recycled Or
                    _AccessControl.OperationIsLegal(Permissions.Editor_Documents_DeletePermanently)) And
                   (isCaseManager Or HasAdminDeleteCreateRights() Or isInInboxFolder)
        End Function

        ''' <summary>
        ''' May user rename the selected folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayRenameFolder(ByVal folder As Folder) As Boolean
            Return folder.Type = Folder.Types.CustomFolder And
                   folder.Type <> Folder.Types.PopulationListFolder And
                   folder.Type <> Folder.Types.ProjectPlanFolder And
                   Not folder.Recycled And
                   Not folder.Deleted
        End Function

        ''' <summary>
        ''' May user drag the selected folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayDragFolder(ByVal folder As Folder) As Boolean
            Dim isInInboxFolder As Boolean = Me.IsInInboxFolder(folder)
            Dim hasRights As Boolean = _AccessControl.OperationIsLegal(Permissions.Editor_Documents_MoveFromInBoxToFolder)
            Return folder.Type = Folder.Types.CustomFolder And
                   folder.Type <> Folder.Types.PopulationListFolder And
                   folder.Type <> Folder.Types.ProjectPlanFolder And
                   Not folder.Recycled And
                   Not folder.Deleted And
                   (hasRights Or isInInboxFolder)
        End Function

        ''' <summary>
        ''' May user drag the selected document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayDragDocument(ByVal folder As Folder, ByVal doc As Document) As Boolean
            Dim isInInboxFolder As Boolean = Me.IsInInboxFolder(folder)
            Dim hasRights As Boolean = _AccessControl.OperationIsLegal(Permissions.Editor_Documents_MoveFromInBoxToFolder)
            Return Not (doc.Recycled Or
                        doc.Deleted Or
                        doc.Type = DocumentTypes.Template Or
                        folder.Type = Folder.Types.PopulationListFolder Or
                        folder.Type = Folder.Types.ProjectPlanFolder Or
                        _Upload.IsEnqueued(doc)) And
                   (hasRights Or isInInboxFolder)
        End Function

        ''' <summary>
        ''' May user add documents to the selected folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayAddDocument(ByVal folder As Folder) As Boolean
            Dim isInInboxFolder As Boolean = Me.IsInInboxFolder(folder)
            Dim isCaseManager As Boolean = False
            If _Context.IsCaseManager.HasValue Then isCaseManager = _Context.IsCaseManager.Value
            Return folder.Type <> Folder.Types.PhaseFolder And
                   folder.Type <> Folder.Types.PopulationListFolder And
                   folder.Type <> Folder.Types.ProjectPlanFolder And
                   folder.Type <> Folder.Types.TrashCanFolder And
                   Not folder.Recycled And
                   Not folder.Deleted And
                   (isCaseManager Or HasAdminDeleteCreateRights() Or isInInboxFolder)
        End Function

        ''' <summary>
        ''' May the selected folder receive a document
        ''' </summary>
        ''' <param name="folder">The selected folder to receive a document</param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayReceiveDocument(ByVal folder As Folder, ByVal doc As Document) As Boolean
            Dim isInInboxFolder As Boolean = Me.IsInInboxFolder(folder)
            Dim hasRights As Boolean = _AccessControl.OperationIsLegal(Permissions.Editor_Documents_MoveFromInBoxToFolder)
            Return Not (folder.Recycled Or
                        folder.Deleted Or
                        folder.Type = Folder.Types.PopulationListFolder Or
                        folder.Type = Folder.Types.PhaseFolder Or
                        folder.Type = Folder.Types.TrashCanFolder Or
                        folder.Type = Folder.Types.ProjectPlanFolder Or
                        doc.Folders.Contains(folder)) And
                   (hasRights Or isInInboxFolder)
        End Function

        ''' <summary>
        ''' May the selected document be promoted
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayPromoteDocument(ByVal doc As Document) As Boolean
            Return Not doc.IsNew
        End Function

        ''' <summary>
        ''' May user delete documents in the selected folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayDeleteDocument(ByVal folder As Folder) As Boolean
            Return folder.Type <> Folder.Types.PhaseFolder And
                   folder.Type <> Folder.Types.PopulationListFolder And
                   folder.Type <> Folder.Types.ProjectPlanFolder And
                   (Not folder.Recycled Or
                    _AccessControl.OperationIsLegal(Permissions.Editor_Documents_DeletePermanently))
        End Function


        ''' <summary>
        ''' May user delete documents in the selected folder, if it is a projectplan it is not allowed
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayDeleteDocument(ByVal folder As Folder, ByVal doc As Document) As Boolean
            Return Not doc.IsProjectPlan(folder)
        End Function

        ''' <summary>
        ''' May user delete the specified document, not in use
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayDeleteDocument(ByVal doc As Document) As Boolean
            Return (Not doc.Recycled Or
                    _AccessControl.OperationIsLegal(Permissions.Editor_Documents_DeletePermanently)) And
                   Not _Upload.IsEnqueued(doc) And
                   (doc.LockedByParticipant Is Nothing OrElse doc.LockedByParticipant.Equals(_Context.UserParticipant))
        End Function

        ''' <summary>
        ''' May user edit the specified document, not in use
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayEditDocument(ByVal doc As Document) As Boolean
            Return Not doc.IsNew And
                   Not doc.Recycled And
                   Not doc.Deleted And
                   Not _Upload.IsEnqueued(doc) And
                   (doc.LockedByParticipant Is Nothing OrElse doc.LockedByParticipant.Equals(_Context.UserParticipant)) And
                   (Not doc.IsProjectPlan And Not doc.IsPopulationList) Or
                   doc.IsProjectPlan And _AccessControl.OperationIsLegal(Permissions.Editor_Documents_EditProjectPlan) _
                   Or doc.IsPopulationList
        End Function

        ''' <summary>
        ''' May user edit document title
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayEditDocumentTitle(ByVal doc As Document) As Boolean
            Return doc.Type <> DocumentTypes.Template And Not _Upload.IsEnqueued(doc)
        End Function

        ''' <summary>
        ''' May user edit document description
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayEditDocumentDescription(ByVal doc As Document) As Boolean
            Return doc.Type <> DocumentTypes.Template OrElse doc.TemplateCreated And Not _Upload.IsEnqueued(doc)
        End Function

        ''' <summary>
        ''' May user edit document classification
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayEditDocumentClassification(ByVal doc As Document) As Boolean
            Return doc.Type <> DocumentTypes.Template And Not _Upload.IsEnqueued(doc)
        End Function

        ''' <summary>
        ''' May user edit document CaseFactsStatus
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayEditDocumentStatus(ByVal doc As Document) As Boolean
            Return ((_Context.IsCaseManager.HasValue AndAlso _Context.IsCaseManager.Value) Or
                    (doc.Type <> DocumentTypes.Template OrElse doc.TemplateCreated)) And
                   Not _Upload.IsEnqueued(doc)
        End Function

        ''' <summary>
        ''' May user edit document link no
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayEditDocumentLinkNo(ByVal doc As Document) As Boolean
            Return doc.Type <> DocumentTypes.Template OrElse doc.TemplateCreated And Not _Upload.IsEnqueued(doc)
        End Function

        ''' <summary>
        ''' May user edit document turbine no
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayEditDocumentTurbineNo(ByVal doc As Document) As Boolean
            Return doc.Type <> DocumentTypes.Template OrElse doc.TemplateCreated And Not _Upload.IsEnqueued(doc)
        End Function

        ''' <summary>
        ''' May user undo edit of the specified document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MayUndoEditDocument(ByVal doc As Document) As Boolean
            Return ((doc.LockedByParticipant IsNot Nothing AndAlso doc.LockedByParticipant.Equals(_Context.UserParticipant)) Or
                    (doc.LockedByParticipant IsNot Nothing And
                     _AccessControl.OperationIsLegal(Permissions.Editor_Documents_UndoAllCheckouts))) And
                   Not doc.Promoted And
                   Not doc.IsNew And
                   Not doc.Recycled And
                   Not doc.Deleted And
                   Not _Upload.IsEnqueued(doc)
        End Function

        ''' <summary>
        ''' May user save screen contents
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function MaySave() As Boolean
            Return True
        End Function

        ''' <summary>
        ''' Add new folder
        ''' </summary>
        ''' <param name="Name"></param>
        ''' <param name="Parent"></param>
        ''' <remarks></remarks>
        Public Sub AddFolder(ByVal Name As String, ByVal Parent As Folder)
            _Model.AddFolder(Name, Parent)
        End Sub

        ''' <summary>
        ''' Select folder
        ''' </summary>
        ''' <param name="Folder"></param>
        ''' <remarks></remarks>
        Public Sub SelectFolder(ByVal Folder As Folder)
            _Model.SelectFolder(Folder)
        End Sub

        ''' <summary>
        ''' Expand/Collapse folder
        ''' </summary>
        ''' <param name="Folder"></param>
        ''' <param name="Expanded"></param>
        ''' <remarks></remarks>
        Public Sub ExpandFolder(ByVal Folder As Folder, ByVal Expanded As Boolean)
            _Model.ExpandFolder(Folder, Expanded)
        End Sub

        ''' <summary>
        ''' Change folder view
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <param name="view"></param>
        ''' <remarks></remarks>
        Public Sub SetFolderView(ByVal folder As Folder, ByVal view As Folder.FolderViews)
            _Model.SetFolderView(folder, view)
        End Sub

        ''' <summary>
        ''' Delete folder
        ''' </summary>
        ''' <param name="folder"></param>
        ''' <remarks></remarks>
        Public Sub DeleteFolder(ByVal folder As Folder)
            If folder.Type <> Folder.Types.CustomFolder Then
                Throw New ApplicationException("You can not delete this folder")
            Else
                _Model.DeleteFolder(folder, folder.Recycled)
            End If
        End Sub

        ''' <summary>
        ''' Add document
        ''' </summary>
        ''' <param name="Parent"></param>
        ''' <param name="File"></param>
        ''' <param name="Title"></param>
        ''' <param name="ClassificationId"></param>
        ''' <param name="StatusId"></param>
        ''' <param name="LinkNo"></param>
        ''' <param name="TurbineNo"></param>
        ''' <remarks></remarks>
        Public Sub AddDocument(ByVal Parent As Folder, ByVal File As FileInfo, ByVal Title As String,
                               ByVal Description As String, ByVal ClassificationId As Long, ByVal StatusId As Long,
                               ByVal StatusName As String, ByVal LinkNo As Nullable(Of Short), ByVal TurbineNo As String)
            _Model.AddDocument(Parent, File, Title, Description, ClassificationId, StatusId, StatusName, LinkNo, TurbineNo)
        End Sub

        ''' <summary>
        ''' Deselect all documents
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub DeselectDocuments()
            _Model.DeselectDocuments()
        End Sub

        ''' <summary>
        ''' Select document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <remarks></remarks>
        Public Sub SelectDocument(ByVal doc As Document)
            _Model.SelectDocument(doc)
        End Sub

        ''' <summary>
        ''' Edit specified document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function EditDocument(ByVal doc As Document) As String
            Try
                If doc.LockedByParticipant Is Nothing OrElse Not doc.LockedByParticipant.Equals(_Context.UserParticipant) Then
                    Lock(doc)
                End If

                If Not doc.TemplateCreated Then CreateDocumentTemplate(doc)

                File.SetAttributes(GetFile(doc), FileAttributes.Normal)
                Return doc.FullPathAndFileName
            Catch ex As IOException
                UndoEditDocument(doc)
                Throw _
                    New ApplicationException(
                        String.Format(
                            "The file ""{2}"" could not be edited. Check that you have enough disk space free to store the file on your harddisk.{0}You currently use the path ""{1}"" to store your files.",
                            System.Environment.NewLine, _Environment.DocumentCacheDirectory, doc.FileName))
            End Try
        End Function

        ''' <summary>
        ''' Copy document template to instance and link it to the document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <remarks></remarks>
        Private Sub CreateDocumentTemplate(ByVal doc As Document)
            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                Try
                    Dim documentBinaryId As Long = -1
                    Dim created As Date = Date.UtcNow
                    ActionProcedures.CreateBinaryFromTemplate(doc.Id, doc.DocumentBinaryId.Value,
                                                              _Context.UserParticipant.ParticipantId, documentBinaryId, created, daa)
                    If documentBinaryId = -1 Then
                        Throw New ApplicationException("A database operation failed. Please try again.")
                    Else
                        _Model.UpdateDocumentBinaryId(doc, documentBinaryId)
                        _Model.CreateDocument(doc, created)
                    End If
                Catch ex As ORMQueryExecutionException
                    Throw New ApplicationException("A database operation failed. Please try again.")
                Catch ex As SqlException
                    Throw New ApplicationException("Missing rights to execute stored procedure ""CreateBinaryFromTemplate"".")
                Finally
                    daa.CloseConnection()
                End Try
            End Using
        End Sub

        ''' <summary>
        ''' Lock document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <remarks></remarks>
        Private Sub Lock(ByVal doc As Document)
            If Not doc.IsNew And Not doc.Locked.HasValue Then
                Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                    Dim entity As New DocumentEntity(doc.Id)
                    Dim pp As New PrefetchPath2(CInt(EntityType.DocumentEntity))
                    pp.Add(DocumentEntity.PrefetchPathLockedByParticipant)
                    Try
                        daa.FetchEntity(entity, pp)
                    Catch ex As Exception
                        daa.CloseConnection()
                        Throw New ApplicationException("A database operation failed. Please try again.")
                    End Try
                    If entity.IsNew Then
                        'Document has been deleted from database
                        _Model.RemoveDocument(doc)
                        daa.CloseConnection()
                        Throw New ApplicationException("The document has been deleted since the view was refreshed.")
                    Else
                        If Not entity.Locked.HasValue Then
                            'Update document
                            entity.Locked = Date.UtcNow
                            entity.LockedById = _Context.UserParticipant.ParticipantId
                            Try
                                If _
                                    daa.SaveEntity(entity, True,
                                                   New PredicateExpression(
                                                       DocumentFields.Locked = DBNull.Value And DocumentFields.LockedById = DBNull.Value), False) Then
                                    _Model.LockDocument(doc, entity.Locked)
                                Else
                                    daa.CloseConnection()
                                    _Model.LockDocument(doc, entity.Locked, entity.LockedByParticipant)
                                    Throw _
                                        New ApplicationException(String.Format("""{0}"" is currently being edited by {1} since {2}", doc.Title,
                                                                               doc.LockedByParticipant.VestasInitials, doc.Locked))
                                End If
                            Catch ex As ORMQueryExecutionException
                                daa.CloseConnection()
                                Throw New ApplicationException("A database operation failed. Please try again.")
                            End Try
                        Else
                            daa.CloseConnection()
                            _Model.LockDocument(doc, entity.Locked, entity.LockedByParticipant)
                            Throw _
                                New ApplicationException(String.Format("""{0}"" is currently being edited by {1} since {2}", doc.Title,
                                                                       doc.LockedByParticipant.VestasInitials, doc.Locked))
                        End If
                    End If

                    daa.CloseConnection()
                End Using
            End If
        End Sub

        ''' <summary>
        ''' Undo edit of the specified document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <remarks></remarks>
        Public Sub UndoEditDocument(ByVal doc As Document)
            Try
                ' removed 2842
                'If doc.Type = DocumentTypes.PopulationList Then
                '    UnlockPopulationList(doc)
                'Else
                Unlock(doc)
                ' removed 2842
                'End If

                If Directory.Exists(Path.GetDirectoryName(doc.FullPathAndFileName)) Then
                    If File.Exists(doc.FullPathAndFileName) Then
                        File.SetAttributes(doc.FullPathAndFileName, FileAttributes.Normal)
                    End If
                    Directory.Delete(Path.GetDirectoryName(doc.FullPathAndFileName), True)
                End If
            Catch ex As Exception
                Throw
            End Try
        End Sub

        ''' <summary>
        ''' Unlock document
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <remarks></remarks>
        Public Sub Unlock(ByVal doc As Document)
            If MayUndoEditDocument(doc) Then
                Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                    Dim entity As New DocumentEntity(doc.Id)
                    Try
                        daa.FetchEntity(entity)
                    Catch ex As Exception
                        daa.CloseConnection()
                        Throw New ApplicationException("A database operation failed. Please try again.")
                    End Try
                    If entity.IsNew Then
                        'Document has been deleted from database
                        _Model.RemoveDocument(doc)
                        Throw New ApplicationException("The document has been deleted since the view was refreshed.")
                    Else
                        'Update document
                        entity.Locked = Nothing
                        entity.LockedById = Nothing
                        Try
                            daa.SaveEntity(entity, False, False)
                            _Model.UnlockDocument(doc)
                        Catch ex As ORMQueryExecutionException
                            daa.CloseConnection()
                            Throw New ApplicationException("A database operation failed. Please try again.")
                        End Try
                    End If

                    daa.CloseConnection()
                End Using
            ElseIf doc.LockedByParticipant IsNot Nothing Then
                Throw New ApplicationException(String.Format("Only {0} can unlock this document", doc.LockedBy))
            End If
        End Sub

        ''' <summary>
        ''' Convert a document to a template
        ''' </summary>
        ''' <param name="doc"></param>
        ''' <param name="template"></param>
        ''' <remarks></remarks>
        Public Sub ConvertDocumentToTemplate(ByVal doc As Document, ByVal template As Document)
            If doc.IsNew Then
                Throw _
                    New ApplicationException("You can not promote a document to a template if the document has has not been saved yet")
            ElseIf template.ClassificationId < doc.ClassificationId Then
                Throw _
                    New ApplicationException(
                        "You can not promote a document to a template if the document has a higher classification than the template")
            Else
                Try
                    'Lock documents
                    If doc.LockedByParticipant Is Nothing OrElse Not doc.LockedByParticipant.Equals(_Context.UserParticipant) Then _
                        Lock(doc)
                    If template.LockedByParticipant Is Nothing OrElse Not template.LockedByParticipant.Equals(_Context.UserParticipant) _
                        Then Lock(template)
                    'Convert doc to template
                    _Model.ConvertDocumentToTemplate(doc, template)
                Catch ex As Exception
                    'Unlock documents
                    Try
                        Unlock(doc)
                    Catch
                    End Try
                    Try
                        Unlock(template)
                    Catch
                    End Try
                End Try
            End If
        End Sub

        ''' <summary>
        ''' Undo all documents that has been promoted to templates
        ''' </summary>
        ''' <remarks>After this routine, the model must be cleared as no updating of existing documents takes place</remarks>
        Public Sub UndoPromotions()
            'Model might be disposed when this is called while shutting down the application
            If _Model IsNot Nothing Then
                Dim docs As List(Of Document) = _Model.PromotedDocuments
                For Each doc As Document In docs
                    Try
                        Unlock(doc)
                        _Model.Demote(doc)
                    Catch
                    End Try
                Next
            End If
        End Sub

        ''' <summary>
        ''' Move document
        ''' </summary>
        ''' <param name="sourceDoc">Document to move</param>
        ''' <param name="targetFolder">Folder to receive the document</param>
        ''' <remarks></remarks>
        Public Sub MoveDocument(ByVal sourceDoc As Document, ByVal targetFolder As Folder)
            Select Case targetFolder.Type
                Case Folder.Types.TrashCanFolder
                    _Model.DeleteDocument(sourceDoc, sourceDoc.Recycled)
                Case Folder.Types.PhaseFolder
                    'This functionality is handled in ConvertDocumentToTemplate and should never be called handled here
                    Throw New ApplicationException("Internal application error MoveDocument to PhaseFolder")
                Case Else
                    _Model.MoveDocument(sourceDoc, targetFolder)
            End Select
        End Sub

        ''' <summary>
        ''' Move folder
        ''' </summary>
        ''' <param name="sourceFolder">Folder to move</param>
        ''' <param name="targetFolder">Folder to receive the source folder</param>
        ''' <remarks></remarks>
        Public Sub MoveFolder(ByVal sourceFolder As Folder, ByVal targetFolder As Folder)
            Select Case targetFolder.Type
                Case Folder.Types.TrashCanFolder
                    _Model.DeleteFolder(sourceFolder, sourceFolder.Recycled)
                Case Folder.Types.PhaseFolder
                    'Not allowed
                Case Else
                    _Model.MoveFolder(sourceFolder, targetFolder)
            End Select
        End Sub

        ''' <summary>
        ''' Delete document
        ''' </summary>
        ''' <param name="doc">Document to delete</param>
        ''' <remarks></remarks>
        Public Sub DeleteDocument(ByVal doc As Document)
            If doc.Type = DocumentTypes.Template Then
                Throw New ApplicationException("You can not delete a template")
            Else
                _Model.DeleteDocument(doc, doc.Recycled)
            End If
        End Sub

        ''' <summary>
        ''' CheckExistenceAndReadabilityOfLocalFile
        ''' </summary>
        ''' <param name="filename"></param>
        ''' <returns></returns>
        ''' <remarks>Chek that file exists and can be opened for read access</remarks>
        Private Function CheckExistenceAndReadabilityOfLocalFile(ByVal filename As String) As Boolean
            Dim result As Boolean = False
            Dim fi As New FileInfo(filename)
            Try
                Dim fs As FileStream = fi.Open(FileMode.Open, FileAccess.Read, FileShare.None)
                fs.Close()
                fs.Dispose()
                result = True
            Catch
            End Try
            Return result
        End Function

        ''' <summary>
        ''' Save model
        ''' </summary>
        ''' <remarks></remarks>
        Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
                                       Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary _
            Implements IInformationSaver.Save
            Dim sbError As New StringBuilder()
            'Save/Update folders
            Dim folderlist(_Model.CustomFolders.Count - 1) As Folder
            _Model.CustomFolders.CopyTo(folderlist)
            For i As Integer = 0 To folderlist.Length - 1
                Dim folder As Folder = folderlist(i)
                If folder.IsDirty Then
                    Dim entity As FolderEntity
                    If folder.IsNew Then
                        If folder.Deleted Then
                            'Remove folder from model
                            _Model.RemoveFolder(folder)
                        Else
                            'Save folder to database
                            entity = New FolderEntity()
                            entity.CaseId = _Context.CaseId.Value
                            entity.FolderTypeId = folder.Type
                            entity.Name = folder.Name
                            entity.ParentFolderId = folder.Parent.Id
                            entity.Sort = folder.Sort
                            entity.Created = folder.Created
                            entity.CreatedBy = folder.CreatedBy.ParticipantId
                            entity.Deleted = folder.Recycled
                            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                                Try
                                    daa.SaveEntity(entity, True)
                                    Dim docsToUpdate As List(Of Document) = _Model.Documents(folder)
                                    For Each doc As Document In docsToUpdate
                                        doc.FolderSaved(entity.FolderId, folder.Id)
                                    Next
                                    _Model.FolderSaved(folder, entity.FolderId)
                                Catch ex As ORMQueryExecutionException
                                    Throw New ApplicationException("A database operation failed. Please try again.")
                                End Try
                            End Using
                        End If
                    ElseIf folder.Deleted Then
                        'Handle below
                    Else
                        'Update folder to database
                        entity = New FolderEntity(folder.Id)
                        Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                            Try
                                daa.FetchEntity(entity)
                            Catch ex As ORMQueryExecutionException
                                Throw New ApplicationException("A database operation failed. Please try again.")
                            End Try
                        End Using
                        If entity.IsNew Then
                            'Folder has been deleted from database
                            _Model.RemoveFolder(folder)
                        Else
                            'Update folder
                            If Not entity.ParentFolderId.Equals(folder.Parent.Id) Then entity.ParentFolderId = folder.Parent.Id
                            If String.Compare(entity.Name, folder.Name) <> 0 Then entity.Name = folder.Name
                            If entity.Sort <> folder.Sort Then entity.Sort = folder.Sort
                            If Not entity.Deleted.Equals(folder.Recycled) Then entity.Deleted = folder.Recycled
                            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                                Try
                                    daa.SaveEntity(entity, False)
                                    _Model.FolderSaved(folder, folder.Id)
                                Catch ex As ORMQueryExecutionException
                                    Throw New ApplicationException("A database operation failed. Please try again.")
                                End Try
                            End Using
                        End If
                    End If
                End If
            Next
            'Delete documents
            Dim docs(_Model.Documents.Count - 1) As Document
            _Model.Documents.CopyTo(docs)
            For i As Integer = 0 To docs.Length - 1
                Dim doc As Document = docs(i)
                If Not doc.IsNew And doc.Deleted Then
                    Dim docentity As New DocumentEntity(doc.Id)
                    Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                        Try
                            daa.DeleteEntity(docentity)
                            _Model.RemoveDocument(doc)
                        Catch ex As ORMQueryExecutionException
                            Throw New ApplicationException("A database operation failed. Please try again.")
                        End Try
                    End Using
                End If
            Next
            'Deletion of folders must be done in reverse order as cascading deletes is not supported when referencing the same table
            For i As Integer = folderlist.Length - 1 To 0 Step -1
                Dim folder As Folder = folderlist(i)
                If Not folder.IsNew And folder.Deleted Then
                    'Delete folder from database
                    Dim entity As FolderEntity = New FolderEntity(folder.Id)
                    Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                        Try
                            daa.DeleteEntity(entity)
                            _Model.RemoveFolder(folder)
                        Catch ex As ORMQueryExecutionException
                            Throw New ApplicationException("A database operation failed. Please try again.")
                        End Try
                    End Using
                End If
            Next
            'Save/Update documents
            For i As Integer = 0 To docs.Length - 1
                Dim doc As Document = docs(i)
                If _
                    doc.IsDirty Or
                    (doc.LockedByParticipant IsNot Nothing AndAlso doc.LockedByParticipant.Equals(_Context.UserParticipant)) Then
                    If Not doc.Type = DocumentTypes.ProjectPlan Then
                        SaveDocument(doc, sbError)
                    End If
                End If
            Next
            If sbError.Length > 0 Then
                Throw New ApplicationException(sbError.ToString())
            End If
            Return New ValidationSummary()
        End Function

        ''' <summary>
        ''' Saves the or update document.
        ''' </summary>
        ''' <param name="doc">The doc.</param>
        ''' <param name="sbError">The sb error.</param>
        Public Sub SaveDocument(ByRef doc As Document, ByRef sbError As StringBuilder)
            Dim entity As DocumentEntity
            If doc.IsNew Then
                If doc.Deleted Then
                    'Remove folder from model
                    _Model.RemoveDocument(doc)
                Else
                    If CheckExistenceAndReadabilityOfLocalFile(doc.FullPathAndFileName) Then
                        If doc.IsProjectPlan Then
                            Return
                        End If
                        'Upload document - the document is saved when returning from upload
                        Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                            If Not _Upload.IsEnqueued(doc) Then
                                _Upload.Enqueue(doc)
                            End If

                            _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value, _Context.UserParticipant.ParticipantId,
                                                              ChangeTypeEnum.AnyChanges, String.Empty, String.Empty,
                                                              [Enum].Format(GetType(AnyChangesEnum), AnyChangesEnum.Documents, "d").ToString)
                        End Using
                    Else
                        Try
                            UndoEditDocument(doc)
                        Catch
                        End Try
                        PmanTrace.WriteError("Document.Controller", "Save",
                                             String.Format(
                                                 "The file ""{0}"" is not accessible - it is either deleted or held by another process",
                                                 doc.FileName))
                        sbError.AppendFormat("The file ""{0}"" is not accessible - it is either deleted or held by another process!{1}",
                                             doc.FileName, System.Environment.NewLine)
                    End If
                End If
            Else
                'Update document to database
                entity = New DocumentEntity(doc.Id)
                Dim pp As New PrefetchPath2(CInt(EntityType.DocumentEntity))
                pp.Add(DocumentEntity.PrefetchPathFolder2Document).SubPath.Add(Folder2DocumentEntity.PrefetchPathFolder)
                Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                    Try
                        daa.FetchEntity(entity, pp)
                    Catch ex As Exception
                        Throw New ApplicationException("A database operation failed. Please try again.")
                    End Try
                End Using
                If entity.IsNew Then
                    'Document has been deleted from database
                    _Model.RemoveDocument(doc)
                Else
                    'Update document
                    If doc.IsLockedByParticipant(_Context.UserParticipant) Then
                        GetFile(doc)

                        If CheckExistenceAndReadabilityOfLocalFile(doc.FullPathAndFileName) Then
                            If doc.IsProjectPlan Then
                                Return
                            End If

                            Dim fi As New FileInfo(doc.FullPathAndFileName)
                            doc.FileDate = fi.LastWriteTimeUtc
                            doc.FileSize = fi.Length
                            If doc.Folders(0).Type = Folder.Types.PhaseFolder And doc.Promoted Then
                                entity = UpdateDocumentEntity(entity, doc)
                                entity.DocumentBinaryId = doc.DocumentBinaryId.Value
                                entity.FileDate = doc.FileDate
                                entity.FileName = doc.FileName
                                entity.FileSize = doc.FileSize
                                entity.Thumbnail = ImageByteArrayConverter.ImageToByteArray(doc.ThumbNail, doc.ThumbNail.RawFormat)
                                entity.PictureHeight = doc.PictureHeight
                                entity.PictureWidth = doc.PictureWidth
                                entity.PictureDate = doc.PictureDateTaken
                                entity.Created = doc.Created
                                entity.CreatedById = doc.CreatedByParticipant.ParticipantId
                                entity.Locked = Nothing
                                entity.LockedById = Nothing
                                entity.Deleted = False
                                Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                                    If daa.SaveEntity(entity, False, True) Then
                                        _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value, _Context.UserParticipant.ParticipantId,
                                                                          ChangeTypeEnum.AnyChanges, String.Empty, String.Empty,
                                                                          [Enum].Format(GetType(AnyChangesEnum), AnyChangesEnum.Documents, "d").
                                                                             ToString)
                                        _Model.DocumentSaved(doc)
                                    End If
                                End Using
                            Else
                                'Upload document if locked by user
                                Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                                    If Not _Upload.IsEnqueued(doc) Then
                                        _Upload.Enqueue(doc)
                                        _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value, _Context.UserParticipant.ParticipantId,
                                                                          ChangeTypeEnum.AnyChanges, String.Empty, String.Empty,
                                                                          [Enum].Format(GetType(AnyChangesEnum), AnyChangesEnum.Documents, "d").
                                                                             ToString)
                                    End If
                                End Using
                            End If
                        Else
                            Try
                                UndoEditDocument(doc)
                            Catch
                            End Try
                            PmanTrace.WriteError("Document.Controller", "Save",
                                                 String.Format(
                                                     "The file ""{0}"" is not accessible - it is either deleted or held by another process",
                                                     doc.FileName))
                            sbError.AppendFormat("The file ""{0}"" is not accessible - it is either deleted or held by another process!{1}",
                                                 doc.FileName, System.Environment.NewLine)
                        End If
                    Else
                        'Update document properties
                        entity = UpdateDocumentEntity(entity, doc)
                        Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString & ";Connect Timeout=60", True)
                            If daa.SaveEntity(entity, False, True) Then
                                _Model.DocumentSaved(doc)
                                _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value, _Context.UserParticipant.ParticipantId,
                                                                  ChangeTypeEnum.AnyChanges, String.Empty, String.Empty,
                                                                  [Enum].Format(GetType(AnyChangesEnum), AnyChangesEnum.Documents, "d").ToString)
                            End If
                        End Using
                    End If
                End If
            End If
        End Sub

        ''' <summary>
        ''' Document CaseFactsStatus'es
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property DocumentStatus() As List(Of DocumentStatus)
            Get
                Dim liDS As New List(Of DocumentStatus)
                Try
                    Dim ec As New EntityCollection(Of DocumentStatusEntity)(New DocumentStatusEntityFactory())
                    Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                        Try
                            daa.FetchEntityCollection(ec, Nothing)
                        Catch ex As ORMQueryExecutionException
                            Throw New ApplicationException("A database operation failed. Please try again.")
                        Finally
                            daa.CloseConnection()
                        End Try
                    End Using
                    For i As Integer = 0 To ec.Count - 1
                        liDS.Add(New DocumentStatus(ec(i).DocumentStatusId, ec(i).Name))
                    Next
                Catch ex As Exception
                End Try
                Return liDS
            End Get
        End Property

        ''' <summary>
        ''' Document Classifications
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property DocumentClassification() As List(Of DocumentClassification)
            Get
                Dim liDC As New List(Of DocumentClassification)
                Dim ec As New EntityCollection(Of DocumentClassificationEntity)(New DocumentClassificationEntityFactory())
                Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                    Try
                        daa.FetchEntityCollection(ec, Nothing)
                    Catch ex As ORMQueryExecutionException
                        Throw New ApplicationException("A database operation failed. Please try again.")
                    Finally
                        daa.CloseConnection()
                    End Try
                End Using
                For i As Integer = 0 To ec.Count - 1
                    liDC.Add(New DocumentClassification(ec(i).DocumentClassificationId, ec(i).Name))
                Next
                Return liDC
            End Get
        End Property

        ''' <summary>
        ''' Check file extension against windows to ensure validity
        ''' </summary>
        ''' <param name="FileName"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function FileExtensionUnknown(ByVal FileName As String) As Boolean
            Return General.IsFileExtensionUnknown(FileName)
        End Function

        ''' <summary>
        ''' Locked Documents
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property LockedDocuments() As List(Of Document)
            Get
                Dim ec As New EntityCollection(Of DocumentEntity)(New DocumentEntityFactory())

                Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                    Dim fb As New RelationPredicateBucket()
                    fb.Relations.Add(DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId)
                    fb.Relations.Add(Folder2DocumentEntity.Relations.FolderEntityUsingFolderId)
                    fb.PredicateExpression.Add(FolderFields.CaseId = _Context.CaseId)
                    fb.PredicateExpression.Add(DocumentFields.Locked <> DBNull.Value)
                    Dim pp As New PrefetchPath2(CInt(EntityType.DocumentEntity))
                    pp.Add(DocumentEntity.PrefetchPathLockedByParticipant)
                    Dim ppe As IPrefetchPathElement2 = pp.Add(DocumentEntity.PrefetchPathFolder2Document)
                    ppe.SubPath.Add(Folder2DocumentEntity.PrefetchPathFolder).SubPath.Add(FolderEntity.PrefetchPathParentFolder)
                    ppe.SubPath.Add(Folder2DocumentEntity.PrefetchPathDocumentStatus)
                    Try
                        daa.FetchEntityCollection(ec, fb, pp)
                    Catch ex As ORMQueryExecutionException
                        Throw New ApplicationException("A database operation failed. Please try again.")
                    End Try
                End Using

                Dim li As New List(Of Document)
                For i As Integer = 0 To ec.Count - 1
                    Dim parentFolder As Folder = Nothing
                    If ec(i).Folder2Document(0).Folder.ParentFolder IsNot Nothing Then _
                        parentFolder = New Folder(ec(i).Folder2Document(0).Folder.ParentFolder, Nothing)
                    li.Add(New Document(_Environment, _Context, ec(i), New Folder(ec(i).Folder2Document(0).Folder, parentFolder)))
                Next
                Return li
            End Get
        End Property

        Public Function GetParticipantByParticipantId(ByVal participantId As Long) As ParticipantEntity
            Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
            fb.PredicateExpression.AddWithOr(ParticipantFields.ParticipantId = participantId)

            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                Dim ec As New EntityCollection(Of ParticipantEntity)()
                daa.FetchEntityCollection(ec, fb)

                Dim entity As ParticipantEntity = ec.SingleOrDefault(Function(e) e.ParticipantId = participantId)
                Return entity
            End Using
        End Function

        Public Function GetParticipantByInitials(ByVal initials As String) As ParticipantEntity
            Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
            fb.PredicateExpression.AddWithOr(ParticipantFields.VestasInitials = initials)

            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                Dim ec As New EntityCollection(Of ParticipantEntity)()
                daa.FetchEntityCollection(ec, fb)

                Dim entity As ParticipantEntity = ec.FirstOrDefault()
                Return entity
            End Using
        End Function

        Private Sub moveTemporaryFileToCache(ByVal e As UploadEventArgs)

            Try
                Dim di As New DirectoryInfo(Path.GetDirectoryName(e.Document.FullPathAndFileName))
                If Not di.Exists Then di.Create()
                e.Document.TempFile.MoveTo(di.FullName)
                e.Document.TempFile.Attributes = FileAttributes.Normal Or FileAttributes.ReadOnly
            Catch ex As Exception
                e.Document.TempFile.Delete()
            Finally
                e.Document.TempFile = Nothing
            End Try
        End Sub

        Public Function GetStatusIdByName(ByVal statusName As String) As Byte
            Dim StatusId As Byte = 0

            Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
            fb.PredicateExpression.AddWithOr(StatusFields.Name = statusName)
            fb.PredicateExpression.Add(StatusFields.Deleted = DBNull.Value)

            Dim entity As StatusEntity
            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                Dim ec As New EntityCollection(Of StatusEntity)()
                daa.FetchEntityCollection(ec, fb)

                entity = ec.SingleOrDefault(Function(e) e.Name = statusName)

                If entity IsNot Nothing Then
                    StatusId = entity.StatusId
                End If
            End Using

            Return StatusId
        End Function

        Public Function GetStatusNameById(ByVal statusId As Long) As String
            Dim statusName As String = String.Empty

            Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
            fb.PredicateExpression.AddWithOr(StatusFields.StatusId = statusId)
            fb.PredicateExpression.Add(StatusFields.Deleted = DBNull.Value)

            Dim entity As StatusEntity
            Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
                Dim ec As New EntityCollection(Of StatusEntity)()
                daa.FetchEntityCollection(ec, fb)

                entity = ec.SingleOrDefault(Function(e) e.StatusId = statusId)

                If entity IsNot Nothing Then
                    statusName = entity.Name
                End If
            End Using

            Return statusName
        End Function

        Public Function GetDmsDocuments(ByVal dmsRoot As Folder) As List(Of Folder)
            Dim dmsDocumentService As New DmsDocumentServices()
            Dim Caseno As Long = Convert.ToInt64(System.Web.HttpContext.Current.Session("CaseNum"))
            If ((LocCaseNumber <= 0) Or (LocCaseNumber <> Caseno)) Then
                'If (DmsServiceReponse Is Nothing) Then
                Dim response As Y_CA_DMS02_GET_DMS_DOCResponse = dmsDocumentService.LoadDmsDocuments(_Context.CaseNo,
                                                                                                _Environment.DmsServiceUrl(),
                                                                                                _Environment.DmsServiceUserName(),
                                                                                                _Environment.DmsServicePassword())

                DmsServiceReponse = response
                LocCaseNumber = Convert.ToInt64(_Context.CaseNo)
                'End If
            End If
            Dim result As New List(Of Folder)

            If (DmsServiceReponse.T_TREE IsNot Nothing) Then
                result.AddRange(
                    From folderData In DmsServiceReponse.T_TREE.Where(Function(t_tree) t_tree.ISFOLDER = "X")
                    Select BuildDmsFolder(DmsServiceReponse.T_TREE, folderData, DmsServiceReponse.T_DOCDATA))
            End If

            ' Unite folders with their parents
            For Each Folder As Folder In result
                Dim id As Long = Folder.Id
                Dim childNode As MTREESNODE = DmsServiceReponse.T_TREE.FirstOrDefault(Function(f) f.NODE_KEY.EndsWith(id.ToString))
                Dim parentNode As MTREESNODE = DmsServiceReponse.T_TREE.FirstOrDefault(Function(f) f.NODE_KEY = childNode.RELATKEY)
                If parentNode Is Nothing Then
                    Folder.Parent = dmsRoot
                Else
                    Dim parentFolder As Folder =
                            result.FirstOrDefault(
                                Function(f) f.Id = Long.Parse(parentNode.NODE_KEY.Substring(parentNode.NODE_KEY.IndexOf("/") + 1)))
                    If parentFolder IsNot Nothing Then 'It really should not be
                        Folder.Parent = parentFolder
                    End If
                End If
            Next
            Return result
            Locresponse = Nothing
        End Function

        Private Function BuildDmsFolder(ByVal folderDataList As IEnumerable(Of MTREESNODE),
                                        ByVal currentFolderData As MTREESNODE, ByVal docDataList As YDMS_INT()) As Folder
            Dim folderId As Long = Long.Parse(currentFolderData.NODE_KEY.Substring(currentFolderData.NODE_KEY.IndexOf("/") + 1))
            Dim result As Folder = New Folder(currentFolderData.TEXT)
            result.Id = folderId
            result.Type = Folder.Types.DmsFolder

            ' The business objects are a bit different in the viewer than in the editor. So here we'll connect the parent folders later (in GetDmsDocuments())

            ' T_TREE contains both document and folder nodes. Document nodes are known by no value in ISFOLDER
            For Each documentData As IGrouping(Of String, MTREESNODE) In folderDataList _
                .Where(Function(doc) doc.ISFOLDER Is Nothing AndAlso doc.RELATKEY = currentFolderData.NODE_KEY) _
                .GroupBy(Function(d) d.NODE_KEY)

                ' Find the corresponding YDMS_INT containing the document information
                Dim localdocumentData As IGrouping(Of String, MTREESNODE) = documentData
                Dim docData As YDMS_INT = docDataList _
                        .Where(Function(d) ConvertDmsStatusToEnum(d.STATUSLOG) <> DocumentStatusEnum.ObsoleteDms) _
                        .OrderByDescending(Function(d) d.DOCUMENTVERSION) _
                        .FirstOrDefault(Function(d) d.DOCUMENTNUMBER = localdocumentData.Key)

                If docData IsNot Nothing Then
                    Dim newDocument As Document = New Document(docData.DESCRIPTION, DocumentTypes.Document, result) _
                            With {.Description = docData.DESCRIPTION}
                    newDocument.AddFolder(result)
                    newDocument.Description = docData.DESCRIPTION
                    If docData.DOCUMENTURLS IsNot Nothing AndAlso docData.DOCUMENTURLS.Any() Then
                        newDocument.Url = docData.DOCUMENTURLS.First().DOCURL
                    End If
                    If docData.CHARACTERISTICVALUES IsNot Nothing Then
                        Dim userData As BAPI_CHARACTERISTIC_VALUES =
                                docData.CHARACTERISTICVALUES.FirstOrDefault(Function(c) c.CHARNAME = "DMS_REF_USER")
                        If userData IsNot Nothing Then
                            newDocument.CreatedByParticipant = GetParticipantByInitials(userData.CHARVALUE.ToLower())
                        End If
                    End If
                    If Not docData.DOCUMENTFILES Is Nothing Then
                        Dim docFile As BAPI_DOC_FILES2 = docData.DOCUMENTFILES(0)
                        newDocument.FileName = Path.GetFileName(docFile.DOCFILE)
                        'newDocument.FileDate = FormatToDateTime(docFile.CHANGED_AT)
                        newDocument.FileDate = DocFormatToDateTime(docFile.CHANGED_AT)
                        newDocument.Classification = ConvertDmsClassificationToEnum(docData.CHARACTERISTICVALUES)
                        newDocument.DmsStatus = ConvertDmsStatusToEnum(docData.STATUSLOG)
                    Else
                        newDocument.FileName = "[No file in DMS]"
                        newDocument.Title = newDocument.Title + " [No file in DMS]"
                        newDocument.FileDate = Nothing
                        newDocument.Classification = DocumentClassificationEnum.Undefined
                        newDocument.DmsStatus = DocumentStatusEnum.Undefined
                    End If
                    result.DmsDocuments.Add(newDocument)
                End If
            Next

            Return result
        End Function

        ''' <summary>
        ''' Convert a string and return it as a DateTime.
        ''' E.g. "20120222115457" = 2012-02-22 11:54:57
        ''' If convert fails then 2000-01-01 00:00:00 is returned
        ''' </summary>
        ''' <param name="datetime"></param>
        ''' <returns></returns>
        Private Function FormatToDateTime(ByVal datetime As String) As DateTime
            Dim res As DateTime = New DateTime(2000, 1, 1, 0, 0, 0)
            If datetime.Length = 14 Then
                res = New DateTime(Convert.ToInt32(datetime.Substring(0, 4)),
                                   Convert.ToInt32(datetime.Substring(4, 2)),
                                   Convert.ToInt32(datetime.Substring(6, 2)),
                                   Convert.ToInt32(datetime.Substring(8, 2)),
                                   Convert.ToInt32(datetime.Substring(10, 2)),
                                   Convert.ToInt32(datetime.Substring(12, 2)))
            End If

            Return res
        End Function

        ''' <summary>
        ''' Convert a string and return it as a DateTime.
        ''' E.g. "22022012115457" = 2012-02-22 11:54:57
        ''' If convert fails then 2000-01-01 00:00:00 is returned
        ''' </summary>
        ''' <param name="datetime"></param>
        ''' <returns></returns>
        Private Function DocFormatToDateTime(ByVal datetime As String) As DateTime

            Dim ValidDate As DateTime
            Dim iDay, iMon, iYear, iHrs, iMin, iSec As Integer
            If datetime.Length = 14 Then
                iDay = CInt(datetime.Substring(0, 2))
                iMon = CInt(datetime.Substring(2, 2))
                iYear = CInt(datetime.Substring(4, 4))
                iHrs = CInt(datetime.Substring(8, 2))
                iMin = CInt(datetime.Substring(10, 2))
                iSec = CInt(datetime.Substring(12, 2))
                ValidDate = New DateTime(iYear, iMon, iDay, iHrs, iMin, iSec)
            End If

            Return ValidDate
        End Function

        Private Function ConvertDmsClassificationToEnum(
                                                        ByVal characteristicvalues As _
                                                        IEnumerable(Of BAPI_CHARACTERISTIC_VALUES)) _
            As DocumentClassificationEnum

            Dim res As DocumentClassificationEnum = DocumentClassificationEnum.Undefined

            Dim bapiCharacteristicValues As BAPI_CHARACTERISTIC_VALUES =
                    characteristicvalues.FirstOrDefault(Function(c) c.CHARNAME = "DMS_SECURITY_LEVEL")
            If bapiCharacteristicValues IsNot Nothing Then

                Dim classValue As String = bapiCharacteristicValues.CHARVALUE

                ' Convert value from DMS to enum
                Select Case classValue.ToLower()

                    Case "top secret"
                        res = DocumentClassificationEnum.TopSecret
                    Case "secret"
                        res = DocumentClassificationEnum.Secret
                    Case "confidential"
                        res = DocumentClassificationEnum.Confidential
                    Case "restricted"
                        res = DocumentClassificationEnum.Restricted
                    Case "public"
                        res = DocumentClassificationEnum.PublicAvailable
                    Case Else
                        res = DocumentClassificationEnum.Undefined
                End Select

            End If
            Return res
        End Function

        Private Function ConvertDmsStatusToEnum(ByVal statuslog As IEnumerable(Of BAPI_DOC_DRAP)) As DocumentStatusEnum

            Dim res As DocumentStatusEnum = DocumentStatusEnum.Undefined

            ' Find newest status
            Dim status As BAPI_DOC_DRAP = Nothing
            Dim newestDt As DateTime = New DateTime(1900, 1, 1)
            For Each bapiDocDrap As BAPI_DOC_DRAP In statuslog
                ' We assume that data is in format "yyyy-mm-dd (e.g. "2012-02-27") - and time is in "hhmmss"
                Dim d As String = bapiDocDrap.LOGDATE.Substring(0, 4) + bapiDocDrap.LOGDATE.Substring(5, 2) +
                                  bapiDocDrap.LOGDATE.Substring(8, 2) + bapiDocDrap.LOGTIME
                Dim dt As DateTime = FormatToDateTime(d)
                If status Is Nothing Or dt > newestDt Then
                    status = bapiDocDrap
                    newestDt = dt
                End If
            Next

            If status IsNot Nothing Then
                ' Convert value from DMS to enum
                Select Case status.STATUSEXTERN.ToLower()

                    Case "z1"
                        res = DocumentStatusEnum.DraftDms
                    Case "z2"
                        res = DocumentStatusEnum.ForReviewDms
                    Case "z3"
                        res = DocumentStatusEnum.ReProcessDms
                    Case "z4"
                        res = DocumentStatusEnum.ReviewedDms
                    Case "z5"
                        res = DocumentStatusEnum.ApprovedDms
                    Case "z6"
                        res = DocumentStatusEnum.ObsoleteDms
                    Case "z7"
                        res = DocumentStatusEnum.ForApprovalDms
                    Case "zZ"
                        res = DocumentStatusEnum.AdminDms
                    Case Else
                        res = DocumentStatusEnum.Undefined
                End Select
            End If
            '            Z1(Draft)
            'Z2           For Review
            '            Z3(Re - Process)
            '            Z4(Reviewed)
            '            Z5(Approved)
            '            Z6(Obsolete)
            'Z7           For Approval
            '            ZZ(Admin)
            Return res
        End Function
    End Class
End Namespace
