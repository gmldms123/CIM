﻿Public Class CustomField
	Private _ccn As String
	Private _ccv As String
	Private _order As Integer

	Public Sub New(ByVal ccn As String, ByVal ccv As String, ByVal order As Integer)
		_ccn = ccn
		_ccv = ccv
		_order = order
	End Sub

	Public Property Ccn() As String
		Get
			Return _ccn
		End Get
		Set(ByVal value As String)
			_ccn = value
		End Set
	End Property

	Public Property Ccv() As String
		Get
			Return _ccv
		End Get
		Set(ByVal value As String)
			_ccv = value
		End Set
	End Property

	Public Property Order() As Integer
		Get
			Return _order
		End Get
		Set(ByVal value As Integer)
			_order = value
		End Set
	End Property
End Class
