Imports PManagement.Framework.Imaging
Imports PManagement.Framework
Imports PManagement.ModelLayer
Imports PManagement.DataLayer.Documents
Imports PManagement.Business.BaseClasses

Namespace Document
	Public NotInheritable Class Document
		Inherits BaseObject
		Implements IDocument

		Private Shared _NewId As Long = 0
		Private _Type As DocumentTypes
		' Removed 2842
		'Private _State As PopulationListState
		Private _Phase As String
		Private _Version As Nullable(Of Integer)
		Private ReadOnly _Folders As New List(Of Folder)
		Private _FoldersAreDirty As Boolean
		Private _DmsStatus As DocumentStatusEnum
		Private _Classification As DocumentClassificationEnum
		Private _DocumentBinaryId As Nullable(Of Long)
		Private _DocumentBinaryIdIsDirty As Boolean
		Private _ClassificationId As Long
		Private _ClassificationIdIsDirty As Boolean
		Private ReadOnly _Status As New Dictionary(Of Long, Status)
		Private _StatusIsDirty As Boolean
		Private _FileName As String
		Private _FileSize As Long
		Private _FileDate As Date
		Private _Title As String
		Private _TitleIsDirty As Boolean
		Private _Description As String
		Private _DescriptionIsDirty As Boolean
		Private _LinkNo As Nullable(Of Short)
		Private _LinkNoIsDirty As Boolean
		Private _PictureDateTaken As Nullable(Of Date)
		Private _PictureHeight As Nullable(Of Integer)
		Private _PictureWidth As Nullable(Of Integer)
		Private _ThumbNail As Image
		Private _TurbineNumber As String
		Private _TurbineNumberIsDirty As Boolean
		Private _Url As String
		Private _Created As Nullable(Of Date)
		Private _CreatedBy As ParticipantEntity
		Private _Locked As Nullable(Of Date)
		Private _LockedBy As ParticipantEntity
		Private _LockedIsDirty As Boolean
		Private _Selected As Boolean
		Private _Recycled As Boolean
		Private _RecycledIsDirty As Boolean
		Private _Promoted As Boolean
		Private _TempFile As FileInfo
		'The following variables are used by the uploading thread
		Private _Environment As Environment
		Private _Context As PmanContext

		Public Sub New(ByVal title As String, ByVal documentType As DocumentTypes, ByVal Parent As Folder)
			_Title = title
			_Type = documentType
			AddFolder(Parent)
		End Sub

		''' <summary>
		''' Initialize new document
		''' </summary>
		''' <param name="File"></param>
		''' <param name="Parent"></param>
		''' <param name="Title"></param>
		''' <param name="ClassificationId"></param>
		''' <param name="StatusId"></param>
		''' <param name="LinkNo"></param>
		''' <param name="TurbineNumber"></param>
		''' <remarks>Initialize new document from metadata and parent folder</remarks>
		Public Sub New(ByVal environment As Environment, ByVal context As PmanContext, ByVal File As FileInfo,
		               ByVal Parent As Folder, ByVal Title As String, ByVal Description As String,
		               ByVal ClassificationId As Long, ByVal StatusId As Long, ByVal StatusName As String,
		               ByVal LinkNo As Nullable(Of Short), ByVal TurbineNumber As String)
			Dim tmppath As String = Path.GetTempFileName()
			Try
				My.Computer.FileSystem.CopyFile(File.FullName, tmppath, True)
				My.Computer.FileSystem.GetFileInfo(tmppath).Attributes = FileAttributes.Normal
			Catch ex As Exception
				PmanTrace.WriteError("Document", "New",
				                     String.Format("Failed to copy file ""{0}"" to ""{1}""{2}{3}{4}", File.FullName, tmppath,
				                                   System.Environment.NewLine, ex.Message, ex.StackTrace))
				Throw
			End Try
			_TempFile = New FileInfo(tmppath)
			If General.IsPicture(File.Extension) Then
				_Type = DocumentTypes.Picture
				Dim oThumbnail As Thumbnail = General.CreateThumbnail(Image.FromFile(_TempFile.FullName))
				_ThumbNail = oThumbnail.Thumbnail
				_PictureHeight = oThumbnail.OriginalHeight
				_PictureWidth = oThumbnail.OriginalWidth
				_PictureDateTaken = oThumbnail.Date
			Else
				_Type = DocumentTypes.Document
				_ThumbNail = General.GetFileIcon(File.FullName)
				_PictureHeight = Nothing
				_PictureWidth = Nothing
				_PictureDateTaken = Nothing
			End If
			Interlocked.Decrement(_NewId)
			'Create new unique id
			_Id = _NewId
			AddFolder(Parent)
			_FoldersAreDirty = False
			_DocumentBinaryId = Nothing
			_DocumentBinaryIdIsDirty = True
			_ClassificationId = ClassificationId
			_ClassificationIdIsDirty = True
			_Status.Add(Parent.Id, New Status(StatusId, StatusName))
			_StatusIsDirty = True
			_FileName = File.Name
			_FileSize = File.Length
			_FileDate = File.LastWriteTimeUtc
			_Title = Title
			_TitleIsDirty = True
			_Description = Description
			_DescriptionIsDirty = True
			_LinkNo = LinkNo
			_LinkNoIsDirty = True
			_TurbineNumber = TurbineNumber
			_TurbineNumberIsDirty = True
			Dim _Now As Date = Date.UtcNow
			_Created = _Now
			_CreatedBy = context.UserParticipant
			_Locked = _Now
			_LockedBy = context.UserParticipant
			_Selected = False
			_Recycled = False
			_RecycledIsDirty = True
			_Deleted = False
			_Promoted = False
			_Environment = New Environment()
			_Environment.Traceable = False
			_Environment.Environment = environment.Environment
			_Context = New PmanContext()
			_Context.Traceable = False
			_Context.User = context.User
			_Context.BrandId = context.BrandId
			_Context.CaseId = context.CaseId
			_Context.Initialize(_Environment)
		End Sub

		''' <summary>
		''' Initialize new document
		''' </summary>
		''' <param name="entity"></param>
		''' <param name="Parent"></param>
		''' <remarks>Initialize new document from document entity and parent folder</remarks>
		Public Sub New(ByVal environment As Environment, ByVal context As PmanContext, ByVal entity As DocumentEntity,
		               ByVal Parent As Folder)
			If General.IsPicture(Path.GetExtension(entity.FileName)) Then
				_Type = DocumentTypes.Picture
				_PictureHeight = entity.PictureHeight
				_PictureWidth = entity.PictureWidth
				_PictureDateTaken = entity.PictureDate
			Else
				_Type = DocumentTypes.Document
				_PictureHeight = Nothing
				_PictureWidth = Nothing
				_PictureDateTaken = Nothing
			End If
			_ThumbNail = ImageByteArrayConverter.ByteArrayToImage(entity.Thumbnail)
			_Id = entity.DocumentId
			AddFolder(Parent)
			_FoldersAreDirty = False
			Dim indices As List(Of Integer) = entity.Folder2Document.FindMatches(Folder2DocumentFields.FolderId = Parent.Id)
			If indices.Count = 1 Then
				Dim index As Integer = indices(0)
				Dim collection As Folder2DocumentEntity = entity.Folder2Document(index)
				Dim documentStatus As DocumentStatusEntity = collection.DocumentStatus
				Dim value As Status = New Status(documentStatus.DocumentStatusId, documentStatus.Name)
				_Status.Add(Parent.Id, value)
			End If
			_StatusIsDirty = False
			If Parent.Type = Folder.Types.PhaseFolder Then _Type = DocumentTypes.Template

			_DocumentBinaryId = entity.DocumentBinaryId
			_DocumentBinaryIdIsDirty = False
			_ClassificationId = entity.DocumentClassificationId
			_ClassificationIdIsDirty = False
			_FileName = entity.FileName
			_FileSize = entity.FileSize
			_FileDate = entity.FileDate
			_Title = entity.Title
			_TitleIsDirty = False
			_Description = entity.Description
			_DescriptionIsDirty = False
			_LinkNo = entity.LinkNo
			_LinkNoIsDirty = False
			_TurbineNumber = entity.TurbineNumber
			_TurbineNumberIsDirty = False
			_Created = entity.Created
			_CreatedBy = entity.CreatedByParticipant
			_Locked = entity.Locked
			_LockedBy = entity.LockedByParticipant
			_Selected = False
			_Recycled = entity.Deleted
			_RecycledIsDirty = False
			_Deleted = False
			_Promoted = False
			_Environment = New Environment()
			_Environment.Traceable = False
			_Environment.Environment = environment.Environment
			_Context = New PmanContext()
			_Context.Traceable = False
			_Context.User = context.User
			_Context.BrandId = context.BrandId
			_Context.CaseId = context.CaseId
			_Context.Initialize(_Environment)
		End Sub

		''' <summary>
		''' Get whether the document has been saved or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>The document is marked as new until a valid id has been set</remarks>
		Public Overrides ReadOnly Property IsNew() As Boolean
			Get
				Return _Id < 0
			End Get
		End Property

		''' <summary>
		''' Get/Set whether document has dirty properties or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _FoldersAreDirty Or
				       _DocumentBinaryIdIsDirty Or
				       _ClassificationIdIsDirty Or
				       _StatusIsDirty Or
				       _TitleIsDirty Or
				       _DescriptionIsDirty Or
				       _LinkNoIsDirty Or
				       _TurbineNumberIsDirty Or
				       _LockedIsDirty Or
				       _RecycledIsDirty Or
				       _Deleted
			End Get
		End Property

		''' <summary>
		''' Specify is dirty.
		''' </summary>
		''' <param name="isDirty">if set to <c>true</c> [is dirty].</param>
		Public Sub Dirty(ByVal isDirty As Boolean)
			_FoldersAreDirty = isDirty
			_DocumentBinaryIdIsDirty = isDirty
			_ClassificationIdIsDirty = isDirty
			_StatusIsDirty = isDirty
			_TitleIsDirty = isDirty
			_DescriptionIsDirty = isDirty
			_LinkNoIsDirty = isDirty
			_TurbineNumberIsDirty = isDirty
			_Promoted = isDirty
			_LockedIsDirty = isDirty
			_RecycledIsDirty = isDirty
		End Sub

		''' <summary>
		''' Get whether folder property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property FoldersAreDirty() As Boolean
			Get
				Return _FoldersAreDirty
			End Get
		End Property

		''' <summary>
		''' Get whether classification id property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ClassificationIdIsDirty() As Boolean
			Get
				Return _ClassificationIdIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether CaseFactsStatus id property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property StatusIdIsDirty() As Boolean
			Get
				Return _StatusIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether title property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TitleIsDirty() As Boolean
			Get
				Return _TitleIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether description property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DescriptionIsDirty() As Boolean
			Get
				Return _DescriptionIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether link no property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property LinkNoIsDirty() As Boolean
			Get
				Return _LinkNoIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether turbine number property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TurbineNumberIsDirty() As Boolean
			Get
				Return _TurbineNumberIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether filename property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DocumentBinaryIdIsDirty() As Boolean
			Get
				Return _DocumentBinaryIdIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether document lock is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property LockedIsDirty() As Boolean
			Get
				Return _LockedIsDirty
			End Get
			Set(ByVal value As Boolean)
				_LockedIsDirty = value
			End Set
		End Property

		''' <summary>
		''' Get whether recycled property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RecycledIsDirty() As Boolean
			Get
				Return _RecycledIsDirty
			End Get
		End Property

		''' <summary>
		''' Get type
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function GetDocumentType() As DocumentTypes
			Return _Type
		End Function

		''' <summary>
		''' Get/Set type
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Type() As DocumentTypes
			Get
				Return _Type
			End Get
			Set(ByVal value As DocumentTypes)
				_Type = value
			End Set
		End Property

		''' <summary>
		''' Gets or sets the phase.
		''' </summary>
		''' <value>The phase.</value>
		Public Property Phase() As String
			Get
				Return _Phase
			End Get
			Set(ByVal value As String)
				_Phase = value
			End Set
		End Property

		''' <summary>
		''' Gets or sets the url for DMS documents.
		''' </summary>
		''' <value>The url.</value>
		Public Property Url As String
			Get
				Return _Url
			End Get
			Set(ByVal value As String)
				_Url = value
			End Set
		End Property

		Public Property DmsStatus As DocumentStatusEnum
			Get
				Return _DmsStatus
			End Get
			Set(ByVal value As DocumentStatusEnum)
				_DmsStatus = value
			End Set
		End Property

		Public Property Classification As DocumentClassificationEnum
			Get
				Return _Classification
			End Get
			Set(ByVal value As DocumentClassificationEnum)
				_Classification = value
			End Set
		End Property

		''' <summary>
		''' Gets or sets the version.
		''' </summary>
		''' <value>The version.</value>
		Public Property Version() As Nullable(Of Integer)
			Get
				Return _Version
			End Get
			Set(ByVal value As Nullable(Of Integer))
				_Version = value
			End Set
		End Property

		''' <summary>
		''' Get/Set id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Id() As Long Implements IDocument.Id
			Get
				Return _Id
			End Get
			Set(ByVal value As Long)
				_Id = value
			End Set
		End Property

		''' <summary>
		''' Get folders
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function GetFolders() As List(Of Folder)
			Return _Folders
		End Function

		''' <summary>
		''' Get folders
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Folders() As List(Of Folder)
			Get
				Return _Folders
			End Get
		End Property

		''' <summary>
		''' Add folder
		''' </summary>
		''' <param name="folder"></param>
		''' <remarks></remarks>
		Public Sub AddFolder(ByVal folder As Folder)
			If Not _Folders.Contains(folder) Then
				_Folders.Add(folder)
				_FoldersAreDirty = True
			End If
		End Sub

		''' <summary>
		''' Add CaseFactsStatus
		''' </summary>
		''' <param name="Parent"></param>
		''' <param name="StatusId"></param>
		''' <param name="StatusName"></param>
		''' <remarks></remarks>
		Public Sub AddStatus(ByVal Parent As Folder, ByVal StatusId As Long, ByVal StatusName As String)
			If Not _Status.ContainsKey(Parent.Id) Then
				_Status.Add(Parent.Id, New Status(StatusId, StatusName))
				_StatusIsDirty = True
			End If
		End Sub

		''' <summary>
		''' Remove folder
		''' </summary>
		''' <param name="folder"></param>
		''' <remarks></remarks>
		Public Sub RemoveFolder(ByVal folder As Folder)
			If _Folders.Contains(folder) Then
				_Folders.Remove(folder)
				_FoldersAreDirty = True
			End If
		End Sub

		''' <summary>
		''' Get/Set document binary id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property DocumentBinaryId() As Nullable(Of Long) Implements IDocument.DocumentBinaryId
			Get
				Return _DocumentBinaryId
			End Get
			Set(ByVal value As Nullable(Of Long))
				_DocumentBinaryId = value
				_DocumentBinaryIdIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Set classification id
		''' </summary>
		''' <param name="ClassificationId"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetClassificationId(ByVal ClassificationId As Long)
			_ClassificationId = ClassificationId
			_ClassificationIdIsDirty = False
		End Sub

		''' <summary>
		''' Get/Set classification id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public Property ClassificationId() As Long Implements IDocument.ClassificationId
			Get
				Return _ClassificationId
			End Get
			Set(ByVal value As Long)
				_ClassificationId = value
				_ClassificationIdIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Set CaseFactsStatus id
		''' </summary>
		''' <param name="StatusId"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetStatusId(ByVal Parent As Folder, ByVal StatusId As Long, ByVal StatusName As String)
			If _Status.ContainsKey(Parent.Id) Then
				_Status(Parent.Id) = New Status(StatusId, StatusName)
			Else
				_Status.Add(Parent.Id, New Status(StatusId, StatusName))
			End If
			_StatusIsDirty = True
		End Sub

		''' <summary>
		''' Get/Set CaseFactsStatus id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public ReadOnly Property StatusId(ByVal parent As Folder) As Long
			Get
				If parent.Type = Folder.Types.TrashCanFolder Then
					parent = Folders(0)
				End If
				Return _Status(parent.Id).Id
			End Get
		End Property

		''' <summary>
		''' Get CaseFactsStatus
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Status(ByVal parent As Folder) As String
			Get
				Return _Status(parent.Id).Name
			End Get
		End Property

		''' <summary>
		''' Statuses
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Statuses() As Dictionary(Of Long, Status)
			Get
				Return _Status
			End Get
		End Property

		''' <summary>
		''' Set filename
		''' </summary>
		''' <param name="FileName"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetFileName(ByVal FileName As String)
			_FileName = FileName
		End Sub

		''' <summary>
		''' Get/Set filename
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public Property FileName() As String Implements IDocument.FileName
			Get
				Return _FileName
			End Get
			Set(ByVal value As String)
				_FileName = value
			End Set
		End Property

		''' <summary>
		''' Get/Set file size
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property FileSize() As Long Implements IDocument.FileSize
			Get
				Return _FileSize
			End Get
			Set(ByVal value As Long)
				_FileSize = value
			End Set
		End Property

		''' <summary>
		''' Get/Set file lastmodified timestamp
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property FileDate() As Date Implements IDocument.FileDate
			Get
				Return _FileDate
			End Get
			Set(ByVal value As Date)
				_FileDate = value
			End Set
		End Property

		''' <summary>
		''' Set title
		''' </summary>
		''' <param name="Title"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetTitle(ByVal Title As String)
			_Title = Title
			_TitleIsDirty = False
		End Sub

		''' <summary>
		''' Get/Set title
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public Property Title() As String Implements IDocument.Title
			Get
				Return _Title
			End Get
			Set(ByVal value As String)
				_Title = value
				_TitleIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Set description
		''' </summary>
		''' <param name="Description"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetDescription(ByVal Description As String)
			_Description = Description
			_DescriptionIsDirty = False
		End Sub

		''' <summary>
		''' Get/Set description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public Property Description() As String
			Get
				Return _Description
			End Get
			Set(ByVal value As String)
				_Description = value
				_DescriptionIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Set link no
		''' </summary>
		''' <param name="LinkNo"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetLinkNo(ByVal LinkNo As Nullable(Of Short))
			_LinkNo = LinkNo
			_LinkNoIsDirty = False
		End Sub

		''' <summary>
		''' Get/Set link no
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public Property LinkNo() As Nullable(Of Short)
			Get
				Return _LinkNo
			End Get
			Set(ByVal value As Nullable(Of Short))
				_LinkNo = value
				_LinkNoIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Set turbine number
		''' </summary>
		''' <param name="TurbineNumber"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetTurbineNumber(ByVal TurbineNumber As String)
			_TurbineNumber = TurbineNumber
			_TurbineNumberIsDirty = False
		End Sub

		''' <summary>
		''' Get/Set turbine number
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property TurbineNumber() As String
			Get
				Return _TurbineNumber
			End Get
			Set(ByVal value As String)
				_TurbineNumber = value
				_TurbineNumberIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Get/Set picture height
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property PictureDateTaken() As Nullable(Of Date)
			Get
				Return _PictureDateTaken
			End Get
			Set(ByVal value As Nullable(Of Date))
				_PictureDateTaken = value
			End Set
		End Property

		''' <summary>
		''' Get/Set picture height
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property PictureHeight() As Nullable(Of Integer)
			Get
				Return _PictureHeight
			End Get
			Set(ByVal value As Nullable(Of Integer))
				_PictureHeight = value
			End Set
		End Property

		''' <summary>
		''' Get/Set picture width
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property PictureWidth() As Nullable(Of Integer)
			Get
				Return _PictureWidth
			End Get
			Set(ByVal value As Nullable(Of Integer))
				_PictureWidth = value
			End Set
		End Property

		''' <summary>
		''' Get/Set thumbnail
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Non-picture documents have a hardcoded icon</remarks>
		Public Property ThumbNail() As Image Implements IDocument.ThumbNail
			Get
				Return _ThumbNail
			End Get
			Set(ByVal value As Image)
				_ThumbNail = value
			End Set
		End Property

		''' <summary>
		''' Get/Set created
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Timestamp of when document was added</remarks>
		Public Property Created() As Nullable(Of Date)
			Get
				Return _Created
			End Get
			Set(ByVal value As Nullable(Of Date))
				_Created = value
				If value.HasValue Then
					_CreatedBy = _Context.UserParticipant
				Else
					_CreatedBy = Nothing
				End If
			End Set
		End Property

		''' <summary>
		''' Get created by
		''' </summary>
		''' <value></value>
		''' <returns>String</returns>
		''' <remarks>User initials</remarks>
		Public ReadOnly Property CreatedBy() As String
			Get
				Dim str As String = String.Empty
				If _CreatedBy IsNot Nothing Then str = _CreatedBy.VestasInitials
				Return str
			End Get
		End Property

		''' <summary>
		''' Get created by
		''' </summary>
		''' <value></value>
		''' <returns>Participant entity</returns>
		''' <remarks></remarks>
		Public Property CreatedByParticipant() As ParticipantEntity
			Get
				Return _CreatedBy
			End Get
			Set(ByVal value As ParticipantEntity)
				_CreatedBy = value
			End Set
		End Property

		''' <summary>
		''' Get/Set locked
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Timestamp of when document was locked. Sets locked by to nothing when cleared (nothing) and current user when supplied a timestamp</remarks>
		Public Property Locked() As Nullable(Of Date) Implements IDocument.Locked
			Get
				Return _Locked
			End Get
			Set(ByVal value As Nullable(Of Date))
				_Locked = value
				If value.HasValue Then
					_LockedBy = _Context.UserParticipant
				Else
					_LockedBy = Nothing
				End If
			End Set
		End Property

		''' <summary>
		''' Get locked by
		''' </summary>
		''' <value></value>
		''' <returns>String</returns>
		''' <remarks>User initials</remarks>
		Public ReadOnly Property LockedBy() As String
			Get
				Dim value As String = String.Empty
				If _LockedBy IsNot Nothing Then value = _LockedBy.VestasInitials
				Return value
			End Get
		End Property

		''' <summary>
		''' Get locked by
		''' </summary>
		''' <value></value>
		''' <returns>Participant entity</returns>
		''' <remarks></remarks>
		Public Property LockedByParticipant() As ParticipantEntity
			Get
				Return _LockedBy
			End Get
			Set(ByVal value As ParticipantEntity)
				_LockedBy = value
			End Set
		End Property

		''' <summary>
		''' Get/Set whether document is selected or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Selected() As Boolean
			Get
				Return _Selected
			End Get
			Set(ByVal value As Boolean)
				_Selected = value
			End Set
		End Property

		''' <summary>
		''' Set recycled
		''' </summary>
		''' <param name="Recycled"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetRecycled(ByVal Recycled As Boolean)
			_Recycled = Recycled
			_RecycledIsDirty = False
			_Deleted = False
		End Sub

		''' <summary>
		''' Get whether document is recycled or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Recycled() As Boolean
			Get
				Return _Recycled
			End Get
			Set(ByVal value As Boolean)
				_Recycled = value
				_RecycledIsDirty = True
				_Deleted = False
			End Set
		End Property

		''' <summary>
		''' Get/Set whether document is promoted or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Promoted() As Boolean Implements IDocument.Promoted
			Get
				Return _Promoted
			End Get
			Set(ByVal value As Boolean)
				_Promoted = value
			End Set
		End Property

		''' <summary>
		''' Get whether a document template has been created or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TemplateCreated() As Boolean
			Get
				Return _Created.HasValue
			End Get
		End Property

		''' <summary>
		''' Get/Set fileinfo of temporary file for new documents
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property TempFile() As FileInfo
			Get
				Return _TempFile
			End Get
			Set(ByVal value As FileInfo)
				_TempFile = value
				If value IsNot Nothing Then
					Try
						_TempFile.Attributes = FileAttributes.Normal
					Catch
					End Try
				End If
			End Set
		End Property

		''' <summary>
		''' Get path and filename
		''' </summary>
		''' <value></value>
		''' <returns>Full path and filename of the document cached to local disk</returns>
		''' <remarks></remarks>
		Public ReadOnly Property FullPathAndFileName() As String Implements IDocument.FullPathAndFileName
			Get
				Dim dpf As New DocumentPathFactory(_Environment)
				Return dpf.GetDocumentPath(_DocumentBinaryId, _FileName, _Type, _TempFile)
			End Get
		End Property

		''' <summary>
		''' Is Project Plan
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsProjectPlan() As Boolean
			Get
				Return _Type = DocumentTypes.ProjectPlan
			End Get
		End Property

		''' <summary>
		''' Is Project Plan
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsProjectPlan(ByVal folder As Folder) As Boolean
			Get
				Dim result As Boolean = False

				If folder.Type = Folder.Types.ProjectPlanFolder Then
					result = True
				End If

				Return result
			End Get
		End Property

		''' <summary>
		''' Is Population List
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsPopulationList() As Boolean
			Get
				Return _Type = DocumentTypes.PopulationList
			End Get
		End Property

		''' <summary>
		''' Environment to upload to
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Environment() As Environment
			Get
				Return _Environment
			End Get
			Set(ByVal value As Environment)
				_Environment = value
			End Set
		End Property

		''' <summary>
		''' PmanContext to upload to
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Context() As PmanContext
			Get
				Return _Context
			End Get
			Set(ByVal value As PmanContext)
				_Context = value
			End Set
		End Property

		''' <summary>
		''' Update CaseFactsStatus dictionary with updated key
		''' </summary>
		''' <param name="newId"></param>
		''' <param name="oldId"></param>
		''' <remarks></remarks>
		Public Sub FolderSaved(ByVal newId As Long, ByVal oldId As Long)
			If _Status.ContainsKey(oldId) Then
				Dim tmp As Status = _Status(oldId)
				_Status.Remove(oldId)
				_Status.Add(newId, tmp)
			End If
		End Sub

		Public Function IsLockedByParticipant(ByVal participantEntity As ParticipantEntity) As Boolean
			' if it isn't locked, it's certainly not locked by the specific participant
			If (LockedByParticipant Is Nothing) Then
				Return False
			End If
			Return LockedByParticipant.Equals(participantEntity)
		End Function

		Public Function GetFileDate() As Date Implements IDocument.GetFileDate
			Return New Date(FileDate.Year, FileDate.Month, FileDate.Day, FileDate.Hour, FileDate.Minute, FileDate.Second)
		End Function
	End Class
End Namespace
