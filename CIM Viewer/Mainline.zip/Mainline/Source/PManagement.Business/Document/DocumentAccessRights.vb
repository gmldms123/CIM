﻿Imports PManagement.Framework.ValidationResults

Namespace Document
	Public Class DocumentAccessRights
		Public Sub ValidateProjectPlanDocuments(ByVal doc As Document, ByVal validationSummary As ValidationSummary,
		                                        ByVal accessControl As AccessControl)
			If doc.Type = DocumentTypes.ProjectPlan Then
				If Not accessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass2Documents) Then
					Const infoToUser As String =
					      	"You do not have sufficient access rights to view Class 2 documents. Please contact the Project Manager for further information."
					Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
					validationSummary.AddValidationItem(validationItem)
				End If
			End If
		End Sub

		Public Sub ValidateDocument(ByVal doc As Document, ByVal validationSummary As ValidationSummary,
		                            ByVal accessControl As AccessControl)
			If doc.Type <> DocumentTypes.ProjectPlan Or doc.Type <> DocumentTypes.PopulationList Then
				Select Case doc.ClassificationId
					Case 1
						If Not accessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass1Documents) Then
							Const infoToUser As String =
							      	"You do not have sufficient access rights to view Class 1 documents. Please contact the Project Manager for further information."
							Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
							validationSummary.AddValidationItem(validationItem)
						End If
					Case 2
						If Not accessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass2Documents) Then
							Const infoToUser As String =
							      	"You do not have sufficient access rights to view Class 2 documents. Please contact the Project Manager for further information."
							Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
							validationSummary.AddValidationItem(validationItem)
						End If
					Case 3
						If Not accessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass3TechnicalDocuments) Then
							Const infoToUser As String =
							      	"You do not have sufficient access rights to view Class 3 technical documents. Please contact the Project Manager for further information."
							Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
							validationSummary.AddValidationItem(validationItem)
						End If
					Case 4
						If Not accessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass3FinancialDocuments) Then
							Const infoToUser As String =
							      	"You do not have sufficient access rights to view Class 3 financial documents. Please contact the Project Manager for further information."
							Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
							validationSummary.AddValidationItem(validationItem)
						End If
				End Select
			End If
		End Sub
	End Class
End Namespace

