﻿Imports PManagement.Framework.ValidationResults

Namespace Document
	Public Class DocumentAccessRightsForWeb
		Public Sub ValidateDocument(ByVal doc As DocumentInfo, ByVal validationSummary As ValidationSummary,
		                            ByVal accessControl As AccessControl)
			ValidateDocument(doc.ClassificationId, validationSummary, accessControl)
		End Sub

		Public Sub ValidateDocument(ByVal doc As Document, ByVal validationSummary As ValidationSummary,
		                            ByVal accessControl As AccessControl)
			ValidateDocument(doc.ClassificationId, validationSummary, accessControl)
		End Sub

		Public Sub ValidateDocument(ByVal classificationId As Long, ByVal validationSummary As ValidationSummary,
		                            ByVal accessControl As AccessControl)
			Select Case classificationId
				Case 1
					If Not accessControl.OperationIsLegal(Permissions.Can_Open_Restricted_Documents) Then
						Const infoToUser As String = "Restricted"
						Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
						validationSummary.AddValidationItem(validationItem)
					End If
				Case 2
					If Not accessControl.OperationIsLegal(Permissions.Can_Open_Confidential_Documents) Then
						Const infoToUser As String = "Confidential"
						Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
						validationSummary.AddValidationItem(validationItem)
					End If
				Case 3
					If Not accessControl.OperationIsLegal(Permissions.Can_Open_Secret_Documents) Then
						Const infoToUser As String = "Secret"
						Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
						validationSummary.AddValidationItem(validationItem)
					End If
				Case 4
					If Not accessControl.OperationIsLegal(Permissions.Can_Open_TopSecret_Documents) Then
						Const infoToUser As String = "TopSecret"
						Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
						validationSummary.AddValidationItem(validationItem)
					End If
				Case 5
					If Not accessControl.OperationIsLegal(Permissions.Can_Open_Public_Documents) Then
						Const infoToUser As String = "Public"
						Dim validationItem As New ValidationItem(ValidationResult.vrError, infoToUser)
						validationSummary.AddValidationItem(validationItem)
					End If
			End Select
		End Sub
	End Class
End Namespace

