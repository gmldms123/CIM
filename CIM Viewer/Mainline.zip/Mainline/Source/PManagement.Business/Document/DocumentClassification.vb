Namespace Document
	''' <summary>
	''' DocumentStatus
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class DocumentClassification
		Private ReadOnly _Id As Long
		Private ReadOnly _Name As String

		''' <summary>
		''' New
		''' </summary>
		''' <param name="Id"></param>
		''' <param name="Name"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal Id As Long, ByVal Name As String)
			_Id = Id
			_Name = Name
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property
	End Class
End Namespace
