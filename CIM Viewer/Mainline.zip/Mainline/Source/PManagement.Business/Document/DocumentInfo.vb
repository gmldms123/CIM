

Namespace Document
	''' <summary>
	''' Document information container class
	''' </summary>
	''' <remarks></remarks>
		Public Class DocumentInfo
		Public DocumentId As Long
		Public Title As String
		Public LinkNo As Short? = Nothing
		Public FolderId As Long
		Public FolderType As Folder.Types = Folder.Types.StandardFolder
		Public FileSize As Long
		Public ClassificationId As Long
		Public FileName As String
		Public Status As String
		Public Type As DocumentTypes = DocumentTypes.Document
		Public FileDate As Date
		Public Created As Date? = Nothing
		Public CreatedBy As String = String.Empty
		Public Deleted As Boolean

		Public Sub New()
		End Sub

		Public Sub New(ByVal title As String, ByVal documentType As DocumentTypes, ByVal folderType As Folder.Types)
			Me.Title = title
			Type = documentType
			Me.FolderType = folderType
		End Sub
	End Class
End Namespace