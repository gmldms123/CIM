Imports PManagement.Framework.Interfaces
Imports PManagement.DataLayer.Factories

Namespace Document
	Public Class DocumentPathFactory
		Implements IDocumentPathFactory

		Private ReadOnly _environment As IEnvironment

		Public Sub New(ByVal environment As IEnvironment)
			_environment = environment
		End Sub

		Public Function GetDocumentPath(ByVal documentBinaryId As Long?, ByVal fileName As String,
		                                ByVal documentType As DocumentTypes, ByVal tempFile As FileInfo) As String _
			Implements IDocumentPathFactory.GetDocumentPath
			Dim path As String = String.Empty
			' Removed 2842
			'            If documentBinaryId.HasValue And Not documentType = DocumentTypes.PopulationList Then
			If documentBinaryId.HasValue Then
				path = String.Format("{0}\{1}\{2}", _environment.DocumentCacheDirectory, documentBinaryId, fileName)
				' Removed 2842
				'ElseIf documentBinaryId.HasValue And documentType = DocumentTypes.PopulationList Then
				'    path = String.Format("{0}\POP_{1}\{2}", _environment.DocumentCacheDirectory, documentBinaryId, fileName)
			ElseIf tempFile IsNot Nothing Then
				path = tempFile.FullName
			End If
			Return path
		End Function
	End Class
End Namespace