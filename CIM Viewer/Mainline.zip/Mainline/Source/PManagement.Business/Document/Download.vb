Imports PManagement.Business.Genericed
Imports PManagement.Framework
Imports PManagement.DataLayer.Documents
Imports PManagement.Framework.Interfaces

Namespace Document
	Public Class Download
		Implements IDisposable, IDocumentDownload

		Private Const MINAVAILABLEFREEBYTESONCACHEDRIVE As Long = 5*CLng(1024*1024*1024)
		'5GB

		Private Shared _MonitorLock As New Object()

		Private _Initialized As Boolean = False
		Private _Environment As Environment = Nothing
		Private _Context As PmanContext = Nothing
		Private _AccessControl As AccessControl = Nothing
		Private _BackgroundThread As New Thread(AddressOf BackgroundProcess)
		Private ReadOnly _DocumentQueue As New Queue(Of DocumentEntity)
		Private _DocBeingDownloadedId As Long = - 1
		Private _PriorityDownloadInProgress As Long = - 1

		''' <summary>
		''' Is instance initialized using Sub Initialize
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Initialized() As Boolean
			Get
				Return _Initialized
			End Get
		End Property

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <remarks></remarks>
		Public Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                      ByRef accesscontrol As AccessControl)
			If Not Initialized Then
				PmanTrace.WriteInfo("Download", "Initialize")
				Using New Guard(Of Object)(_MonitorLock)
					If Not Initialized Then

						_Environment = environment
						_Context = context
						_AccessControl = accesscontrol
						AddHandler _Environment.EnvironmentChanged, AddressOf EnvironmentChanged
						AddHandler _Context.ContextChanged, AddressOf ContextChanged

						_BackgroundThread.Priority = ThreadPriority.Lowest
						_BackgroundThread.IsBackground = True

						_Initialized = True

						ContextChanged_i()
					End If
				End Using
			End If
		End Sub

		''' <summary>
		''' OnEnvironmentChanged
		''' </summary>
		''' <remarks>Called via external events</remarks>
		Private Sub EnvironmentChanged()
			PmanTrace.WriteInfo("Download", "EnvironmentChanged")
			Using New Guard(Of Object)(_MonitorLock)
				_DocumentQueue.Clear()
			End Using
		End Sub

		''' <summary>
		''' OnContextChanged
		''' </summary>
		''' <remarks>Called via external events</remarks>
		Private Sub ContextChanged()
			PmanTrace.WriteInfo("Download", "ContextChanged")
			Using New Guard(Of Object)(_MonitorLock)
				ContextChanged_i()
			End Using
		End Sub

		''' <summary>
		''' OnContextChanged implementation method
		''' </summary>
		''' <remarks></remarks>
		Private Sub ContextChanged_i()
			_DocumentQueue.Clear()

			If _
				_Environment.Platform = Environment.Platforms.Windows And _Context.CaseId.HasValue And
				_BackgroundThread.ThreadState = (Threading.ThreadState.Unstarted Or Threading.ThreadState.Background) Then
				_BackgroundThread.Start()
			End If
		End Sub

		Public Sub PriorityDownload(ByVal documentId As Long) Implements IDocumentDownload.PriorityDownload
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString)
				Dim documentEntity As New DocumentEntity(documentId)
				Dim pp As New PrefetchPath2(DirectCast(EntityType.DocumentEntity, Integer))
				Dim elem As IPrefetchPathElement2 = pp.Add(documentEntity.PrefetchPathFolder2Document)
				elem.SubPath.Add(Folder2DocumentEntity.PrefetchPathFolder)
				elem.SubPath.Add(Folder2DocumentEntity.PrefetchPathDocumentStatus)
				daa.FetchEntity(documentEntity, pp)

				' Temp hack - project plans were created without folder2document entity before 2010-01-14, 
				' hence data exists in dev where documents have no associated folder.
				' We select an arbitrary folder to associate - it's not used for anything in this specific call sequence.
				Dim folder2DocumentEntities As EntityCollection(Of Folder2DocumentEntity) = documentEntity.Folder2Document
				Dim folderEntity As FolderEntity
				If (folder2DocumentEntities.Count = 0) Then
					Dim folderCollection As New EntityCollection(Of FolderEntity)()
					daa.FetchEntityCollection(folderCollection, Nothing, 1)
					folderEntity = folderCollection(0)
				Else
					Dim firstFolder As Folder2DocumentEntity = folder2DocumentEntities.First()
					folderEntity = firstFolder.Folder
				End If

				Dim folder As New Folder(folderEntity, Nothing)
				Dim doc As New Document(_Environment, _Context, documentEntity, folder)
				PriorityDownload(doc)
			End Using
		End Sub

		''' <summary>
		''' Download specified document at first priority temporarily suspending cache downloading
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub PriorityDownload(ByVal doc As IDocument)
			PmanTrace.WriteInfo("Download", "PriorityDownload")

			Try
				Dim fi As FileInfo = General.GetFileInfo(doc)

				'Lessen precision as database timestamp is less precise than file timestamp
				Dim dtEntity As Date = doc.GetFileDate()
				' New Date(doc.FileDate.Year, doc.FileDate.Month, doc.FileDate.Day, doc.FileDate.Hour, doc.FileDate.Minute, doc.FileDate.Second)
				Dim dtFile As Date = New Date(fi.LastWriteTimeUtc.Year, fi.LastWriteTimeUtc.Month, fi.LastWriteTimeUtc.Day,
				                              fi.LastWriteTimeUtc.Hour, fi.LastWriteTimeUtc.Minute, fi.LastWriteTimeUtc.Second)

				If Not fi.Exists OrElse (dtFile <> dtEntity And Not doc.Promoted And Not doc.Locked.HasValue) Then
					Interlocked.Exchange(_PriorityDownloadInProgress, doc.DocumentBinaryId.Value)

					'If it is not the same file being downloaded in the background
					If Not Equals(_DocBeingDownloadedId, _PriorityDownloadInProgress) Then
						PmanTrace.WriteVerbose("Download", "PriorityDownload", "Downloading document as priority")
						FetchAndSave(New DocumentEntity(doc.Id), fi, True, doc.Promoted)
					Else
						PmanTrace.WriteVerbose("Download", "PriorityDownload",
						                       "Waiting for backgroundprocess to finish downloading document")
						_BackgroundThread.Priority = ThreadPriority.Normal
						While Equals(_DocBeingDownloadedId, _PriorityDownloadInProgress)
							Thread.Sleep(500)
						End While
						_BackgroundThread.Priority = ThreadPriority.Lowest
						PmanTrace.WriteVerbose("Download", "PriorityDownload", "Backgroundprocess finished downloading document")
					End If
				End If
			Catch ex As Exception
				PmanTrace.WriteVerbose("Download", "PriorityDownload",
				                       String.Format("Failed to download ""{0}"" (""{1}"") {2}{3}{2}{4}", doc.Title,
				                                     doc.FullPathAndFileName, System.Environment.NewLine, ex.Message, ex.StackTrace))
			Finally
				Interlocked.Exchange(_PriorityDownloadInProgress, - 1)
			End Try
		End Sub

		''' <summary>
		''' Download documents attached to chosen caseid
		''' </summary>
		''' <remarks></remarks>
		Private Sub BackgroundProcess()
			PmanTrace.WriteInfo("Download", "BackgroundProcess")

			Dim AccessRightsLastChecked As Date = Date.UtcNow.AddMinutes(- 15)
			Dim Editor_Documents_HandleClass1Documents As Boolean = False
			Dim Editor_Documents_HandleClass2Documents As Boolean = False
			Dim Editor_Documents_HandleClass3TechnicalDocuments As Boolean = False
			Dim Editor_Documents_HandleClass3FinancialDocuments As Boolean = False

			Try
				While True
					Thread.Sleep(1000)

					'Continue the while loop if there is less than MINAVAILABLEFREEBYTESONCACHEDRIVE space available on the drives used for the cached files
					Dim cacheDrive As New DriveInfo(_Environment.DocumentCacheDirectory.Substring(0, 1))
					If cacheDrive.AvailableFreeSpace < MINAVAILABLEFREEBYTESONCACHEDRIVE Then
						PmanTrace.WriteVerbose("Download", "BackgroundProcess",
						                       String.Format("Available cache space on {0} is less than {1} bytes", cacheDrive,
						                                     MINAVAILABLEFREEBYTESONCACHEDRIVE))
						Thread.Sleep(60000)
						Continue While
					End If

					Dim entity As DocumentEntity = Nothing

					'Check AccessControl outside guard to avoid a deadlock situation
					If Interlocked.Read(_DocumentQueue.Count) = 0 And Date.UtcNow.AddMinutes(- 10) > AccessRightsLastChecked Then
						AccessRightsLastChecked = Date.UtcNow
						Editor_Documents_HandleClass1Documents =
							_AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass1Documents)
						Editor_Documents_HandleClass2Documents =
							_AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass2Documents)
						Editor_Documents_HandleClass3TechnicalDocuments =
							_AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass3TechnicalDocuments)
						Editor_Documents_HandleClass3FinancialDocuments =
							_AccessControl.OperationIsLegal(Permissions.Editor_Documents_HandleClass3FinancialDocuments)
					End If

					Using New Guard(Of Object)(_MonitorLock)
						'Check download cache
						If _DocumentQueue.Count = 0 Then
							'Get document id's for current case
							'Trace.WriteVerbose("Download", "BackgroundProcess", "Fetching document queue")
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim ecDocument As New EntityCollection(Of DocumentEntity)(New DocumentEntityFactory())
								Dim filterBucket As IRelationPredicateBucket = New RelationPredicateBucket()
								filterBucket.Relations.Add(DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId)
								filterBucket.Relations.Add(Folder2DocumentEntity.Relations.FolderEntityUsingFolderId)
								filterBucket.PredicateExpression.AddWithAnd(FolderFields.CaseId = _Context.CaseId)
								filterBucket.PredicateExpression.AddWithAnd(DocumentFields.DocumentBinaryId <> DBNull.Value)
								filterBucket.PredicateExpression.AddWithAnd(DocumentFields.Created <> DBNull.Value)
								If Not Editor_Documents_HandleClass1Documents Then
									filterBucket.PredicateExpression.AddWithAnd(DocumentFields.DocumentClassificationId <> 1)
								End If
								If Not Editor_Documents_HandleClass2Documents Then
									filterBucket.PredicateExpression.AddWithAnd(DocumentFields.DocumentClassificationId <> 2)
								End If
								If Not Editor_Documents_HandleClass3TechnicalDocuments Then
									filterBucket.PredicateExpression.AddWithAnd(DocumentFields.DocumentClassificationId <> 3)
								End If
								If Not Editor_Documents_HandleClass3FinancialDocuments Then
									filterBucket.PredicateExpression.AddWithAnd(DocumentFields.DocumentClassificationId <> 4)
								End If
								Try
									daa.FetchEntityCollection(ecDocument, filterBucket)
								Catch
								End Try
								daa.CloseConnection()
								'Trace.WriteVerbose("Download", "BackgroundProcess", "Filling document queue")
								For Each entity In ecDocument
									_DocumentQueue.Enqueue(entity)
								Next
							End Using
						End If
						If _DocumentQueue.Count > 0 Then entity = _DocumentQueue.Dequeue()
					End Using

					If entity IsNot Nothing Then
						Try
							'Trace.WriteVerbose("Download", "BackgroundProcess", String.Format("Considering ""{0}"" ({1})", entity.Title, entity.DocumentId))

							Dim fi As FileInfo = General.GetFileInfo(entity, _Environment)

							'Lessen precision as database timestamp is less precise than file timestamp
							Dim dtEntity As Date = New Date(entity.FileDate.Year, entity.FileDate.Month, entity.FileDate.Day,
							                                entity.FileDate.Hour, entity.FileDate.Minute, entity.FileDate.Second)
							Dim dtFile As Date = New Date(fi.LastWriteTimeUtc.Year, fi.LastWriteTimeUtc.Month, fi.LastWriteTimeUtc.Day,
							                              fi.LastWriteTimeUtc.Hour, fi.LastWriteTimeUtc.Minute, fi.LastWriteTimeUtc.Second)

							If Not fi.Exists OrElse dtFile < dtEntity Then
								Interlocked.Exchange(_DocBeingDownloadedId, entity.DocumentBinaryId)
								FetchAndSave(entity, fi, False, False)
							End If
						Catch ex As ThreadAbortException
							'Handle exception thrown by Dispose()
							Throw
						Catch ex As Exception
							PmanTrace.WriteVerbose("Download", "BackgroundProcess",
							                       String.Format("Failed to download ""{0}"" (""{1}"") {2}{3}{2}{4}", entity.Title,
							                                     General.GetFileInfo(entity, _Environment), System.Environment.NewLine,
							                                     ex.Message, ex.StackTrace))
						Finally
							Interlocked.Exchange(_DocBeingDownloadedId, - 1)
						End Try
					End If
				End While
			Catch ex As ThreadAbortException
				'Handle exception thrown by Dispose()
			Finally
				Interlocked.Exchange(_DocBeingDownloadedId, - 1)
				Using New Guard(Of Object)(_MonitorLock)
					_DocumentQueue.Clear()
				End Using
			End Try
		End Sub

		''' <summary>
		''' Fetch and save document
		''' </summary>
		''' <param name="entity"></param>
		''' <param name="fileinfo"></param>
		''' <remarks></remarks>
		Private Sub FetchAndSave(ByRef entity As DocumentEntity, ByRef fileinfo As FileInfo, ByRef Priority As Boolean,
		                         ByRef promoted As Boolean)
			PmanTrace.WriteInfo("Download", "FetchAndSave")

			Try
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					'Refetch entity as much can have happened since it was enqueued
					daa.FetchEntity(entity)
					daa.CloseConnection()
				End Using

				If _
					Priority Or
					(Not entity.IsNew AndAlso
					 (Not entity.LockedById.HasValue Or
					  (entity.LockedById.HasValue AndAlso entity.LockedById.Value <> _Context.UserParticipant.ParticipantId))) Then
					Dim connection As New SqlConnection(_Environment.PManagement_ConnectionString)
					connection.Open()

					' Get the pointer to the Blob
					Dim _
						cmdPointer As _
							New SqlCommand(
								"SELECT @Pointer = TEXTPTR(Document), @Length=DataLength(Document) FROM DocumentBinary WHERE DocumentBinaryId = @Identity",
								connection)
					If promoted Then
						cmdPointer.Parameters.Add("@Identity", SqlDbType.BigInt).Value =
							fileinfo.DirectoryName.Substring(fileinfo.DirectoryName.LastIndexOf(Path.DirectorySeparatorChar) + 1)
					Else
						cmdPointer.Parameters.Add("@Identity", SqlDbType.BigInt).Value = entity.DocumentBinaryId
					End If
					Dim ptrParm As SqlParameter = cmdPointer.Parameters.Add("@Pointer", SqlDbType.Binary, 16)
					ptrParm.Direction = ParameterDirection.Output
					Dim LengthParm As SqlParameter = cmdPointer.Parameters.Add("@Length", SqlDbType.Int)
					LengthParm.Direction = ParameterDirection.Output
					cmdPointer.ExecuteNonQuery()

					' Handle the situation where there is nothing to retrieve
					If ptrParm.Value IsNot DBNull.Value Then
						' Configure the buffer length for performance/memory consumption
						Const BUFFERSIZE As Integer = 512*1024
						' The size of the chunks to retrieve from the database

						' Prepare the database interface
						Dim cmdDBBinary As New SqlCommand("READTEXT DocumentBinary.Document @Pointer @Offset @Size", connection)
						Dim paramPointer As SqlParameter = cmdDBBinary.Parameters.Add("@Pointer", SqlDbType.Binary, 16)
						paramPointer.Value = DirectCast(ptrParm.Value, Byte())
						Dim paramOffset As SqlParameter = cmdDBBinary.Parameters.Add("@Offset", SqlDbType.Int)
						paramOffset.Value = 0
						Dim paramSize As SqlParameter = cmdDBBinary.Parameters.Add("@Size", SqlDbType.Int)
						paramSize.Value = BUFFERSIZE

						Try
							If fileinfo.Exists Then
								PmanTrace.WriteVerbose("Download", "FetchAndSave", "Resetting file attributes")
								fileinfo.Attributes = FileAttributes.Normal
							Else
								PmanTrace.WriteVerbose("Download", "FetchAndSave", "Creating directory")
								fileinfo.Directory.Create()
							End If

							PmanTrace.WriteVerbose("Download", "FetchAndSave", String.Format("Downloading ""{0}""", fileinfo.FullName))
							Using outputStream As New FileStream(fileinfo.FullName, FileMode.Create, FileAccess.Write, FileShare.None)
								Dim input_bytesRead As Integer
								Dim buffer(BUFFERSIZE - 1) As Byte
								Dim output_offset As Integer = 0

								If DirectCast(LengthParm.Value, Integer) < BUFFERSIZE Then paramSize.Value = LengthParm.Value

								Dim dr As SqlDataReader = cmdDBBinary.ExecuteReader(CommandBehavior.SingleResult)
								dr.Read()
								input_bytesRead = Integer.Parse(dr.GetBytes(0, 0, buffer, 0, DirectCast(paramSize.Value, Integer)).ToString())
								dr.Close()
								While input_bytesRead > 0
									outputStream.Write(buffer, 0, input_bytesRead)
									outputStream.Flush()

									' Adjust the offset and size of the next chunk to read
									output_offset += input_bytesRead
									paramOffset.Value = output_offset
									If output_offset + BUFFERSIZE >= DirectCast(LengthParm.Value, Integer) Then
										paramSize.Value = DirectCast(LengthParm.Value, Integer) - output_offset
									Else
										paramSize.Value = BUFFERSIZE
									End If

									Dim anotherPriorityDownloadInProgress As Boolean = False

									'Check for priority download
									If Equals(_PriorityDownloadInProgress, _DocBeingDownloadedId) Then
										'IMPORTANT: You can not trace here, as main thread sleeps - it will cause a deadlock
										Priority = True
									Else
										anotherPriorityDownloadInProgress = Equals(_PriorityDownloadInProgress, _DocBeingDownloadedId)
									End If

									'Wait for priority download
									While Not Priority And anotherPriorityDownloadInProgress
										PmanTrace.WriteVerbose("Download", "FetchAndSave", "Waiting for priority download to finish")
										Thread.Sleep(1000)

										'Check for priority download
										If Equals(_PriorityDownloadInProgress, _DocBeingDownloadedId) Then
											'IMPORTANT: You can not trace here, as main thread sleeps - it will cause a deadlock
											Priority = True
										Else
											anotherPriorityDownloadInProgress = Equals(_PriorityDownloadInProgress, _DocBeingDownloadedId)
										End If
									End While

									If Not Priority Then
										PmanTrace.WriteVerbose("Download", "FetchAndSave", "Making room for other network traffic")
										Thread.Sleep(1000)
									End If

									' Read the next chunk from the database
									dr = cmdDBBinary.ExecuteReader(CommandBehavior.SingleResult)
									dr.Read()
									input_bytesRead = Integer.Parse(dr.GetBytes(0, 0, buffer, 0, DirectCast(paramSize.Value, Integer)).ToString())
									dr.Close()
								End While
								outputStream.Close()
								fileinfo.LastWriteTimeUtc = entity.FileDate
								fileinfo.Attributes = FileAttributes.Normal Or FileAttributes.ReadOnly
							End Using
						Catch
							Try
								GC.Collect()
								GC.WaitForPendingFinalizers()
								fileinfo.Directory.Delete(True)
							Catch
							End Try
						End Try
					End If
					connection.Close()
				End If
			Catch ex As ORMEntityOutOfSyncException
				PmanTrace.WriteError("Download", "BackgroundProcess",
				                     String.Format("ORMEntityOutOfSyncException{0}{1}{0}{2}", System.Environment.NewLine, ex.Message,
				                                   ex.StackTrace))
			Catch ex As ThreadAbortException
				Throw ex
			End Try
		End Sub

		Private disposedValue As Boolean = False
		' To detect redundant calls

		' IDisposable
		Protected Sub Dispose(ByVal disposing As Boolean)
			PmanTrace.WriteInfo("Download", "Dispose")

			If Not disposedValue Then
				If disposing Then
					If _BackgroundThread IsNot Nothing Then
						Try
							PmanTrace.WriteVerbose("Download", "Dispose", "Aborting background process")
							_BackgroundThread.Priority = ThreadPriority.Normal
							_BackgroundThread.Abort()
							_BackgroundThread = Nothing
						Catch ex As Exception
							PmanTrace.WriteVerbose("Download", "Dispose",
							                       String.Format("Failed to abort background process{0}{1}{0}{2}", System.Environment.NewLine,
							                                     ex.Message, ex.StackTrace))
						End Try
					End If
					_AccessControl = Nothing
					_Context = Nothing
					_Environment = Nothing
				End If
				PmanTrace.WriteVerbose("Download", "Dispose", "Disposed")
			End If
			disposedValue = True
		End Sub

#Region " IDisposable Support "

		' This code added by Visual Basic to correctly implement the disposable pattern.
		Public Sub Dispose() Implements IDisposable.Dispose
			' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
			Dispose(True)
			GC.SuppressFinalize(Me)
		End Sub

#End Region
	End Class
End Namespace
