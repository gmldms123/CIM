
Imports PManagement.Business.BaseClasses

Namespace Document
	Public NotInheritable Class Folder
		Inherits BaseObject

		Private Shared _NewId As Long = 0
		Private _Type As Types
		' Removed 2842
		'Private _PopulationListState As PopulationListState
		Private _Name As String
		Private _NameIsDirty As Boolean
		Private _Parent As Folder
		Private _ParentIsDirty As Boolean
		Private _Sort As Long
		Private _SortIsDirty As Boolean
		Private _Created As Date
		Private _CreatedBy As ParticipantEntity
		Private _Locked As Nullable(Of Date)
		Private _LockedBy As ParticipantEntity
		Private _FolderView As FolderViews
		Private _Expanded As Boolean
		Private _Selected As Boolean
		Private _Recycled As Boolean
		Private _RecycledIsDirty As Boolean
		Private ReadOnly _DmsDocuments As List(Of Document) = New List(Of Document)

		''' <summary>
		''' Types of folder object
		''' </summary>
		''' <remarks></remarks>
			Public Enum Types
			InboxFolder
			PhaseFolder
			TrashCanFolder
			StandardFolder
			PictureFolder
			CustomFolder
			PopulationListFolder
			ProjectPlanFolder
			DmsFolder
		End Enum

		''' <summary>
		''' Types of views to present a folder
		''' </summary>
		''' <remarks></remarks>
			Public Enum FolderViews
			Detail
			Thumbnail
		End Enum

		''' <summary>
		''' Initialize new folder
		''' </summary>
		''' <param name="Parent"></param>
		''' <remarks>Initialize new custom folder from name and parent folder</remarks>
		Public Sub New(ByVal Name As String, ByVal Parent As Folder, ByRef context As PmanContext)
			Interlocked.Decrement(_NewId)
			'Create new unique id
			_Id = _NewId
			_Type = Types.CustomFolder
			_Name = Name
			_NameIsDirty = True
			_Parent = Parent
			_ParentIsDirty = True
			CalcSort()
			_SortIsDirty = True
			Dim d As Date = Date.UtcNow()
			_Created = d
			_CreatedBy = context.UserParticipant
			_Locked = d
			_LockedBy = context.UserParticipant
			_FolderView = FolderViews.Detail
			_Expanded = False
			_Selected = False
			_Recycled = False
			_RecycledIsDirty = True
			_Deleted = False
		End Sub

		' Removed 2842

		'Public Sub PopulationListSetTypeAndState(ByVal entity As FolderEntity)
		'  If (entity.Name = "Population List" Or entity.Name = "Approved" Or entity.Name = "Superseeded") And entity.FolderTypeId = 6 Then
		'    _Type = Types.PopulationListFolder
		'    If entity.Name = "Approved" Then
		'      _PopulationListState = PopulationListState.Approved
		'    ElseIf entity.Name = "Superseeded" Then
		'      _PopulationListState = PopulationListState.Superseeded
		'    End If
		'  End If
		'End Sub

		Public Sub ProjectPlanSetTypeAndState(ByVal entity As FolderEntity)
			If (entity.Name = "Project Plan") And entity.FolderTypeId = 9 Then
				_Type = Types.ProjectPlanFolder
			End If
		End Sub

		''' <summary>
		''' Initialize new folder
		''' </summary>
		''' <param name="entity"></param>
		''' <param name="Parent"></param>
		''' <remarks>Initialize new folder from folder entity and parent folder</remarks>
		Public Sub New(ByVal entity As FolderEntity, ByVal Parent As Folder)
			_Id = entity.FolderId
			_Type = DirectCast([Enum].Parse(GetType(Types), entity.FolderTypeId.ToString()), Types)

			' Removed 2842
			'PopulationListSetTypeAndState(entity)
			ProjectPlanSetTypeAndState(entity)

			If _Type = Types.PictureFolder Then
				_FolderView = FolderViews.Thumbnail
			Else
				_FolderView = FolderViews.Detail
			End If
			_Name = entity.Name
			_NameIsDirty = False
			_Parent = Parent
			_ParentIsDirty = False
			_Sort = entity.Sort
			_SortIsDirty = False
			_Created = entity.Created
			_CreatedBy = entity.CreatedByParticipant
			_Locked = entity.Locked
			_LockedBy = entity.LockedByParticipant
			_Expanded = False
			_Selected = False
			_Recycled = entity.Deleted
			_RecycledIsDirty = False
			_Deleted = False

			_DmsDocuments = New List(Of Document)
		End Sub

		Public Sub New(ByVal Name As String)
			_Name = name
		End Sub

		''' <summary>
		''' Get whether the folder has been saved or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>The folder is marked as new until a valid id has been set</remarks>
		Public Overrides ReadOnly Property IsNew() As Boolean
			Get
				Return _Id < 0
			End Get
		End Property

		''' <summary>
		''' Get/Set whether folder has dirty properties or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _NameIsDirty Or
				       _ParentIsDirty Or
				       _RecycledIsDirty Or
				       _Deleted Or
				       _SortIsDirty
			End Get
			'Use Dirty() instead
			'Set(ByVal value As Boolean)
			'  _NameIsDirty = value
			'  _ParentIsDirty = value
			'  _RecycledIsDirty = value
			'  _SortIsDirty = value
			'End Set
		End Property

		''' <summary>
		''' Specify is dirty.
		''' </summary>
		''' <param name="isDirty">if set to <c>true</c> [is dirty].</param>
		Public Sub Dirty(ByVal isDirty As Boolean)
			_NameIsDirty = isDirty
			_ParentIsDirty = isDirty
			_RecycledIsDirty = isDirty
			_SortIsDirty = isDirty
		End Sub

		''' <summary>
		''' Get whether name property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NameIsDirty() As Boolean
			Get
				Return _NameIsDirty
			End Get
		End Property

		''' <summary>
		''' Get whether parent property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ParentIsDirty() As Boolean
			Get
				Return _ParentIsDirty
			End Get
		End Property

		''' <summary>
		''' Get/Set id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Id() As Long
			Get
				Return _Id
			End Get
			Set(ByVal value As Long)
				_Id = value
			End Set
		End Property

		''' <summary>
		''' Get/Set type
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Type() As Types
			Get
				Return _Type
			End Get
			Set(ByVal value As Types)
				_Type = value
			End Set
		End Property

		' Removed 2842
		'Public Property PopulationListState() As PopulationListState
		'    Get
		'        Return _PopulationListState
		'    End Get
		'    Set(ByVal value As PopulationListState)
		'        _PopulationListState = value
		'    End Set
		'End Property

		''' <summary>
		''' Set name
		''' </summary>
		''' <param name="Name"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetName(ByVal Name As String)
			_Name = Name
			_NameIsDirty = False
		End Sub

		''' <summary>
		''' Get/Set name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public Property Name() As String
			Get
				Return _Name
			End Get
			Set(ByVal value As String)
				_Name = value
				_NameIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Set parent folder
		''' </summary>
		''' <param name="folder"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetParent(ByVal folder As Folder)
			_Parent = folder
			_ParentIsDirty = False
		End Sub

		''' <summary>
		''' Get/Set parent folder
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Sets dirty to true</remarks>
		Public Property Parent() As Folder
			Get
				Return _Parent
			End Get
			Set(ByVal value As Folder)
				_Parent = value
				_ParentIsDirty = True
			End Set
		End Property

		''' <summary>
		''' Get/Set created
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Created() As Date
			Get
				Return _Created
			End Get
			Set(ByVal value As Date)
				_Created = value
			End Set
		End Property

		''' <summary>
		''' Get/Set created by
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property CreatedBy() As ParticipantEntity
			Get
				Return _CreatedBy
			End Get
			Set(ByVal value As ParticipantEntity)
				_CreatedBy = value
			End Set
		End Property

		Public ReadOnly Property DmsDocuments As List(Of Document)
			Get
				Return _DmsDocuments
			End Get
		End Property

		''' <summary>
		''' Get/Set locked
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Locked() As Nullable(Of Date)
			Get
				Return _Locked
			End Get
			Set(ByVal value As Nullable(Of Date))
				_Locked = value
			End Set
		End Property

		''' <summary>
		''' Get/Set locked by
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property LockedBy() As ParticipantEntity
			Get
				Return _LockedBy
			End Get
			Set(ByVal value As ParticipantEntity)
				_LockedBy = value
			End Set
		End Property

		''' <summary>
		''' Get/Set folder view
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property FolderView() As FolderViews
			Get
				Return _FolderView
			End Get
			Set(ByVal value As FolderViews)
				_FolderView = value
			End Set
		End Property

		''' <summary>
		''' Get/Set whether folder is expended or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Expanded() As Boolean
			Get
				Return _Expanded
			End Get
			Set(ByVal value As Boolean)
				_Expanded = value
			End Set
		End Property

		''' <summary>
		''' Get/Set whether folder is selected or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Selected() As Boolean
			Get
				Return _Selected
			End Get
			Set(ByVal value As Boolean)
				_Selected = value
			End Set
		End Property

		''' <summary>
		''' Get whether recycled property is dirty or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RecycledIsDirty() As Boolean
			Get
				Return _RecycledIsDirty
			End Get
		End Property

		''' <summary>
		''' Set recycled
		''' </summary>
		''' <param name="Recycled"></param>
		''' <remarks>Sets dirty to false</remarks>
		Public Sub SetRecycled(ByVal Recycled As Boolean)
			_Recycled = Recycled
			_RecycledIsDirty = False
			_Deleted = False
		End Sub

		''' <summary>
		''' Get/Set whether folder is recycled or not
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Recycled() As Boolean
			Get
				Return _Recycled
			End Get
			Set(ByVal value As Boolean)
				_Recycled = value
				_RecycledIsDirty = True
				_Deleted = False
			End Set
		End Property

		''' <summary>
		''' Sort
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Sort() As Long
			Get
				Return _Sort
			End Get
		End Property

		''' <summary>
		''' Calculate sort
		''' </summary>
		''' <remarks></remarks>
		Public Sub CalcSort()
			Dim s As Long = 0
			Dim _Folder As Folder = _Parent
			While _Folder IsNot Nothing
				s += 1
				_Folder = _Folder.Parent
			End While
			If s <> _Sort Then
				_Sort = s
				_SortIsDirty = True
			End If
		End Sub
	End Class
End Namespace
