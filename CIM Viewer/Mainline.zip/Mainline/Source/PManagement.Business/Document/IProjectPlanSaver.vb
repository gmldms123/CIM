Imports PManagement.Framework.ValidationResults

Namespace Document
	Public Interface IProjectPlanSaver
		Function SaveProjectPlan(ByRef doc As Document, ByVal docIsDragged As Boolean,
		                         ByVal backgroundWorker As BackgroundWorker) As validationsummary
	End Interface
End Namespace