Imports PManagement.Business.Genericed

Namespace Document
	Partial Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Private ReadOnly liFolder As List(Of Folder)
		Private ReadOnly liDocument As List(Of Document)
		Private fldToFind As Folder
		Private idToFind As Nullable(Of Long)
		Private linknoToFinde As Nullable(Of Short)
		Private _searchEntityCollection As EntityCollection(Of DocumentEntity)

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return liFolder.FindAll(Predicate (Of Folder).IsDirty).Count > 0 Or
				       liDocument.FindAll(Predicate (Of Document).IsDirty).Count > 0
			End Get
		End Property

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New()
			liFolder = New List(Of Folder)()
			liDocument = New List(Of Document)()
			fldToFind = Nothing
			idToFind = Nothing
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			liFolder.Clear()
			liDocument.Clear()
			fldToFind = Nothing
			idToFind = Nothing
			OnDataChanged()
		End Sub

		''' <summary>
		''' Phase Folders
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PhaseFolders() As List(Of Folder)
			Get
				Return liFolder.FindAll(New System.Predicate(Of Folder)(AddressOf FindPhaseFolder))
			End Get
		End Property

		''' <summary>
		''' Folders
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Folders() As List(Of Folder)
			Get
				Return liFolder
			End Get
		End Property

		''' <summary>
		''' Custom Folders
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property CustomFolders() As List(Of Folder)
			Get
				Return liFolder.FindAll(New System.Predicate(Of Folder)(AddressOf FindCustomFolder))
			End Get
		End Property

		''' <summary>
		''' Return specified document
		''' </summary>
		''' <param name="Id"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Document(ByVal Id As Long) As Document
			Get
				idToFind = Id
				Dim doc As Document = liDocument.Find(New System.Predicate(Of Document)(AddressOf FindDocument))
				idToFind = Nothing
				Return doc
			End Get
		End Property

		''' <summary>
		''' Get all documents
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Documents() As List(Of Document)
			Get
				Return liDocument
			End Get
		End Property

		''' <summary>
		''' Get documents with the a specific LinkNo
		''' </summary>
		''' <param name="LinkNo"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Documents(ByVal LinkNo As Short) As List(Of Document)
			Get
				Dim docs As List(Of Document)
				linknoToFinde = LinkNo
				docs = liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindDocumentsWithLinkNo))
				linknoToFinde = Nothing
				Return docs
			End Get
		End Property

		''' <summary>
		''' Get documents 
		''' </summary>
		''' <param name="folder"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Documents(ByVal folder As Folder) As List(Of Document)
			Get
				Dim docs As List(Of Document)
				If folder.Type = Folder.Types.TrashCanFolder Then
					docs = liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindDeletedDocuments))
				Else
					fldToFind = folder
					docs = liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindDocumentsInFolder))
					fldToFind = Nothing
				End If
				Return docs
			End Get
		End Property

		''' <summary>
		''' Get promoted documents
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PromotedDocuments() As List(Of Document)
			Get
				Return liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindPromotedDocuments))
			End Get
		End Property

		''' <summary>
		''' Get documents locked by curent user
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property LockedDocuments() As List(Of Document)
			Get
				Return liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindLockedDocuments))
			End Get
		End Property

		''' <summary>
		''' Return whether document is deleted
		''' </summary>
		''' <param name="doc"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSelectedDocuments(ByVal doc As Document) As Boolean
			Return doc.Selected
		End Function

		''' <summary>
		''' Return whether document is deleted
		''' </summary>
		''' <param name="doc"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindDeletedDocuments(ByVal doc As Document) As Boolean
			Return _
				doc.Recycled And Not doc.Deleted And Not doc.Promoted And
				doc.Folders.FindAll(New System.Predicate(Of Folder)(AddressOf FindDeletedFolders)).Count < doc.Folders.Count
		End Function

		''' <summary>
		''' Return whether folder is deleted
		''' </summary>
		''' <param name="folder"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindDeletedFolders(ByVal folder As Folder) As Boolean
			Return folder.Recycled And Not folder.Deleted
		End Function

		''' <summary>
		''' Return whether document is promoted
		''' </summary>
		''' <param name="doc"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindPromotedDocuments(ByVal doc As Document) As Boolean
			Return doc.Promoted
		End Function

		''' <summary>
		''' Return whether document is locked
		''' </summary>
		''' <param name="doc"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindLockedDocuments(ByVal doc As Document) As Boolean
			Return doc.LockedBy = _Context.UserParticipant.VestasInitials
		End Function

		''' <summary>
		''' Return whether document has the a specific LinkNo
		''' </summary>
		''' <param name="doc"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindDocumentsWithLinkNo(ByVal doc As Document) As Boolean
			Return doc.LinkNo.Equals(linknoToFinde)
		End Function

		''' <summary>
		''' Return whether document is part of the specified folder
		''' </summary>
		''' <param name="doc"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindDocumentsInFolder(ByVal doc As Document) As Boolean
			Return _
				doc.Folders.Contains(fldToFind) And (Not doc.Recycled Or doc.Recycled And fldToFind.Recycled) And Not doc.Deleted
		End Function

		''' <summary>
		''' Return whether folder is a custom folder
		''' </summary>
		''' <param name="folder"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindCustomFolder(ByVal folder As Folder) As Boolean
			Return folder.Type = Folder.Types.CustomFolder
		End Function

		''' <summary>
		''' Insert/Update folder model
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub InjectFolders(ByVal ec As EntityCollection(Of FolderEntity))
			Dim dataChanged As Boolean = False
			For i As Integer = 0 To ec.Count - 1
				idToFind = ec(i).FolderId
				Dim folder As Folder = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindFolder))
				idToFind = Nothing
				If folder Is Nothing Then
					'Add new folder
					'Find parent folder
					Dim parentFolder As Folder = Nothing
					If ec(i).ParentFolderId.HasValue Then
						idToFind = ec(i).ParentFolderId
						parentFolder = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindFolder))
						idToFind = Nothing
					End If
					'Create new folder object
					folder = New Folder(ec(i), parentFolder)
					'Insert folder in model
					Select Case folder.Type
						Case Folder.Types.InboxFolder
							liFolder.Insert(0, folder)
							'Select inbox folder as default
							folder.Selected = True
						Case Folder.Types.PhaseFolder, Folder.Types.TrashCanFolder
							liFolder.Add(folder)
						Case Else
							If folder.Parent Is Nothing Then
								'Insert standard root folders before trashcan
								if (liFolder.Count > 0) then
									liFolder.Insert(liFolder.Count - 1, folder)
								end if
								'Expand standard folders in root folder
								folder.Expanded = True
							Else
								liFolder.Insert(IndexToInsertFolder(folder.Parent, folder.Name), folder)
							End If
					End Select
					dataChanged = True
				Else
					'Update existing folder
					'Parent folder
					Dim parentFolder As Folder = Nothing
					If ec(i).ParentFolderId.HasValue Then
						idToFind = ec(i).ParentFolderId
						parentFolder = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindFolder))
						idToFind = Nothing
					End If
					If folder.Parent IsNot parentFolder And Not folder.ParentIsDirty Then
						folder.SetParent(parentFolder)
						dataChanged = True
					End If
					'Name
					If String.Compare(folder.Name, ec(i).Name) <> 0 And Not folder.NameIsDirty Then
						folder.SetName(ec(i).Name)
						dataChanged = True
					End If
					'Recycled (equivalent to db field "Deleted")
					If Not folder.Recycled.Equals(ec(i).Deleted) And Not folder.RecycledIsDirty Then
						folder.SetRecycled(ec(i).Deleted)
						dataChanged = True
					End If
				End If
			Next

			'Remove deleted folders
			Dim foldersToRemove As New List(Of Folder)
			For i As Integer = 0 To liFolder.Count - 1
				If Not liFolder(i).IsNew And ec.FindMatches(FolderFields.FolderId = liFolder(i).Id).Count = 0 Then _
					foldersToRemove.Add(liFolder(i))
			Next
			If foldersToRemove.Count > 0 Then
				For Each fldr As Folder In foldersToRemove
					liFolder.Remove(fldr)
				Next
				dataChanged = True
			End If

			' Resolve missing parent folders:
			' After introducing the new folder structure the sorting has changed, resolving in parent folders not always being loaded before their child folders.
			' Here we attempt to resolve the parent relation for all the folders that are missing a parent folder.
			For Each entity As FolderEntity In ec
				If Not entity.ParentFolderId.HasValue() Then
					Continue For
				End If

				idToFind = entity.FolderId
				Dim folder As Folder = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindFolder))
				idToFind = Nothing

				If folder Is Nothing Then
					Continue For
				End If

				If folder.Parent IsNot Nothing Then
					Continue For
				End If

				idToFind = entity.ParentFolderId
				Dim parentFolder As Folder = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindFolder))
				idToFind = Nothing

				If parentFolder Is Nothing Then
					Continue For
				End If

				folder.Parent = parentFolder
				liFolder.Remove(folder)
				liFolder.Insert(IndexToInsertFolder(folder.Parent, folder.Name), folder)
			Next

			If dataChanged Then OnDataChanged()
		End Sub

		Private Function IndexToInsertFolder(ByVal Parent As Folder, ByVal Name As String) As Integer
			Dim index As Integer
			fldToFind = Parent
			Dim folders As List(Of Folder) = liFolder.FindAll(New System.Predicate(Of Folder)(AddressOf FindFoldersInFolder))
			fldToFind = Nothing
			If folders.Count = 0 Then
				'Insert as first folder after parent folder in list
				index = liFolder.Count
			Else
				'Insert in correct sorted order amongst the other folders in the parent folder
				index = liFolder.Count
				For i As Integer = 0 To folders.Count - 1
					If String.Compare(Name, folders(i).Name) <= 0 Then
						index = Math.Max(liFolder.IndexOf(folders(i)), index)
						Exit For
					End If
				Next
			End If
			Return index
		End Function

		''' <summary>
		''' Return the specified folder
		''' </summary>
		''' <param name="folder"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindFolder(ByVal folder As Folder) As Boolean
			Return idToFind.Equals(folder.Id)
		End Function

		''' <summary>
		''' Return the specified folder
		''' </summary>
		''' <param name="folder"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSelectedFolder(ByVal folder As Folder) As Boolean
			Return folder.Selected
		End Function

		''' <summary>
		''' Return whether a folder is a phase folder
		''' </summary>
		''' <param name="folder"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindPhaseFolder(ByVal folder As Folder) As Boolean
			Return folder.Type = Folder.Types.PhaseFolder
		End Function

		''' <summary>
		''' Return whether a folder is in another folder
		''' </summary>
		''' <param name="folder"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindFoldersInFolder(ByVal folder As Folder) As Boolean
			Return Not folder.Deleted And folder.Parent IsNot Nothing AndAlso folder.Parent.Equals(fldToFind)
		End Function

		''' <summary>
		''' Add new folder
		''' </summary>
		''' <param name="Name"></param>
		''' <param name="Parent"></param>
		''' <remarks></remarks>
		Public Sub AddFolder(ByVal Name As String, ByVal Parent As Folder)
			liFolder.Insert(IndexToInsertFolder(Parent, Name), New Folder(Name, Parent, _Context))
			Parent.Expanded = True
			OnDataChanged()
		End Sub

		''' <summary>
		''' Delete folder
		''' </summary>
		''' <param name="folder"></param>
		''' <remarks></remarks>
		Public Sub DeleteFolder(ByVal folder As Folder, ByVal Permanent As Boolean)
			DeleteFolderRecursive(folder, Permanent)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Delete folders and documents recursively
		''' </summary>
		''' <param name="folder"></param>
		''' <remarks></remarks>
		Private Sub DeleteFolderRecursive(ByVal folder As Folder, ByVal Permanent As Boolean)
			fldToFind = folder
			Dim folders As List(Of Folder) = liFolder.FindAll(New System.Predicate(Of Folder)(AddressOf FindFoldersInFolder))
			For Each fldr As Folder In folders
				DeleteFolderRecursive(fldr, Permanent)
			Next
			If Permanent Then
				folder.Deleted = True
			Else
				folder.Recycled = True
			End If
			Dim docs As List(Of Document) = Documents(folder)
			For Each doc As Document In docs
				If Permanent Then
					doc.Deleted = True
				Else
					doc.Recycled = True
				End If
			Next
		End Sub

		''' <summary>
		''' Remove folder from model
		''' </summary>
		''' <param name="folder"></param>
		''' <remarks></remarks>
		Public Sub RemoveFolder(ByVal folder As Folder)
			fldToFind = folder
			Dim folders As List(Of Folder) = liFolder.FindAll(New System.Predicate(Of Folder)(AddressOf FindFoldersInFolder))
			Dim docs As List(Of Document) = liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindDocumentsInFolder))
			fldToFind = Nothing
			If folders.Count > 0 Or docs.Count > 0 Then
				Throw New ApplicationException("Can not remove folder. Folder is not empty")
			End If
			liFolder.Remove(folder)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Update folderid to database id
		''' </summary>
		''' <param name="folder"></param>
		''' <param name="NewId"></param>
		''' <remarks></remarks>
		Public Sub FolderSaved(ByVal folder As Folder, ByVal NewId As Long)
			folder.Id = NewId
			folder.Dirty(False)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Remove document from model
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub RemoveDocument(ByVal doc As Document)
			liDocument.Remove(doc)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Select folder
		''' </summary>
		''' <param name="Folder"></param>
		''' <remarks></remarks>
		Public Sub SelectFolder(ByVal folder As Folder)
			If Not folder.Selected Then
				fldToFind = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindSelectedFolder))
				If fldToFind IsNot Nothing Then
					fldToFind.Selected = False
					Dim docs As List(Of Document) =
					    	liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindDocumentsInFolder))
					fldToFind = Nothing
					For Each doc As Document In docs
						doc.Selected = False
					Next
				End If
				folder.Selected = True
			End If
		End Sub

		''' <summary>
		''' Expand/Collapse folder
		''' </summary>
		''' <param name="Folder"></param>
		''' <param name="Expanded"></param>
		''' <remarks></remarks>
		Public Sub ExpandFolder(ByVal folder As Folder, ByVal Expanded As Boolean)
			If folder.Expanded <> Expanded Then
				folder.Expanded = Expanded
			End If
		End Sub

		''' <summary>
		''' Change folder view
		''' </summary>
		''' <param name="folder"></param>
		''' <param name="view"></param>
		''' <remarks></remarks>
		Public Sub SetFolderView(ByVal folder As Folder, ByVal view As Folder.FolderViews)
			If folder.FolderView <> view Then
				folder.FolderView = view
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Insert documents
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub InjectDocuments(ByVal ec As EntityCollection(Of DocumentEntity))
			Dim dataChanged As Boolean = False
			Dim Parent As Folder
			For i As Integer = 0 To ec.Count - 1
				'Get parent folder
				idToFind = ec(i).Folder2Document(0).FolderId
				Parent = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindFolder))
				idToFind = Nothing

				idToFind = ec(i).DocumentId
				Dim doc As Document = liDocument.Find(New System.Predicate(Of Document)(AddressOf FindDocument))
				idToFind = Nothing

				If doc Is Nothing Then
					InsertDocument(New Document(_Environment, _Context, ec(i), Parent), Parent)
				Else
					'Update existing documents with the following properties if not already changed locally by the user
					'Folder
					If Not doc.Folders.Contains(Parent) And (Not doc.FoldersAreDirty Or doc.Type = DocumentTypes.Template) Then
						If Not doc.Type = DocumentTypes.Template Then
							doc.Folders.Clear()
							doc.Statuses.Clear()
						End If
						doc.AddFolder(Parent)
						Dim folderindices As List(Of Integer) =
						    	ec(i).Folder2Document.FindMatches(Folder2DocumentFields.FolderId = Parent.Id)
						doc.AddStatus(Parent, ec(i).Folder2Document(folderindices(0)).DocumentStatus.DocumentStatusId,
						              ec(i).Folder2Document(folderindices(0)).DocumentStatus.Name)
						dataChanged = True
					End If
					'DocumentClassification
					If ec(i).DocumentClassificationId <> doc.ClassificationId And Not doc.ClassificationIdIsDirty Then
						doc.SetClassificationId(ec(i).DocumentClassificationId)
						dataChanged = True
					End If
					'DocumentStatus
					Dim indices As List(Of Integer) = ec(i).Folder2Document.FindMatches(Folder2DocumentFields.FolderId = Parent.Id)
					If doc.Type = DocumentTypes.Template Or doc.Type <> DocumentTypes.Template And doc.Folders(0).Id = Parent.Id Then
						If ec(i).Folder2Document(indices(0)).DocumentStatusId <> doc.StatusId(Parent) And Not doc.StatusIdIsDirty Then
							doc.SetStatusId(Parent, ec(i).Folder2Document(indices(0)).DocumentStatus.DocumentStatusId,
							                ec(i).Folder2Document(indices(0)).DocumentStatus.Name)
							dataChanged = True
						End If
					ElseIf doc.Type <> DocumentTypes.Template And doc.Folders(0).Id <> Parent.Id Then
						If ec(i).Folder2Document(indices(0)).DocumentStatusId <> doc.StatusId(doc.Folders(0)) And Not doc.StatusIdIsDirty _
							Then
							doc.SetStatusId(doc.Folders(0), ec(i).Folder2Document(indices(0)).DocumentStatus.DocumentStatusId,
							                ec(i).Folder2Document(indices(0)).DocumentStatus.Name)
							dataChanged = True
						End If
					End If
					'Title
					If String.Compare(doc.Title, ec(i).Title) <> 0 And Not doc.TitleIsDirty Then
						doc.SetTitle(ec(i).Title)
						dataChanged = True
					End If
					'Description
					If String.Compare(doc.Description, ec(i).Description) <> 0 And Not doc.DescriptionIsDirty Then
						doc.SetDescription(ec(i).Description)
						dataChanged = True
					End If
					'LinkNo
					If Not ec(i).LinkNo.Equals(doc.LinkNo) And Not doc.LinkNoIsDirty Then
						doc.SetLinkNo(ec(i).LinkNo)
						dataChanged = True
					End If
					'TurbineNumber
					If String.Compare(doc.TurbineNumber, ec(i).TurbineNumber) <> 0 And Not doc.TurbineNumberIsDirty Then
						doc.SetTurbineNumber(ec(i).TurbineNumber)
						dataChanged = True
					End If
					'DocumentBinary and related properties
					If _
						Not doc.DocumentBinaryId.HasValue OrElse
						Not doc.DocumentBinaryId.Value.Equals(ec(i).DocumentBinaryId) And Not doc.DocumentBinaryIdIsDirty Then
						doc.DocumentBinaryId = ec(i).DocumentBinaryId
						doc.SetFileName(ec(i).FileName)
						doc.FileDate = ec(i).FileDate
						doc.FileSize = ec(i).FileSize
						doc.PictureDateTaken = ec(i).PictureDate
						doc.PictureHeight = ec(i).PictureHeight
						doc.PictureWidth = ec(i).PictureWidth
						dataChanged = True
					End If
					'Locked
					If Not (doc.Created.Equals(ec(i).Created) Or doc.Locked.Equals(ec(i).Locked)) Then
						doc.Created = ec(i).Created
						doc.CreatedByParticipant = ec(i).CreatedByParticipant
						doc.Locked = ec(i).Locked
						doc.LockedByParticipant = ec(i).LockedByParticipant
						dataChanged = True
					End If
					'Recycled (equivalent to db field "Deleted")
					If Not doc.Recycled.Equals(ec(i).Deleted) And Not doc.RecycledIsDirty Then
						doc.SetRecycled(ec(i).Deleted)
						dataChanged = True
					End If
				End If

				If dataChanged Then OnDataChanged()
			Next
		End Sub

		''' <summary>
		''' Insert/Update documents in folder
		''' </summary>
		''' <param name="ec"></param>
		''' <param name="Parent"></param>
		''' <remarks></remarks>
		Public Sub InjectDocuments(ByVal ec As EntityCollection(Of DocumentEntity), ByVal Parent As Folder)
			Dim dataChanged As Boolean = False

			For i As Integer = 0 To ec.Count - 1
				Dim parentFolder As Folder = Parent
				If Parent.Type = Folder.Types.TrashCanFolder Then
					'Get real parent folder if checking the trashcan
					idToFind = ec(i).Folder2Document(0).FolderId
					parentFolder = liFolder.Find(New System.Predicate(Of Folder)(AddressOf FindFolder))
				End If

				idToFind = ec(i).DocumentId
				Dim doc As Document = liDocument.Find(New System.Predicate(Of Document)(AddressOf FindDocument))
				idToFind = Nothing
				If doc Is Nothing Then
					'Add new documents
					InsertDocument(New Document(_Environment, _Context, ec(i), parentFolder), parentFolder)
					dataChanged = True
				Else
					'Update existing documents with the following properties if not already changed locally by the user
					'Folder
					If Not doc.Folders.Contains(parentFolder) And (Not doc.FoldersAreDirty Or doc.Type = DocumentTypes.Template) Then
						If Not doc.Type = DocumentTypes.Template Then
							doc.Folders.Clear()
							doc.Statuses.Clear()
						End If
						doc.AddFolder(parentFolder)
						Dim folderindices As List(Of Integer) =
						    	ec(i).Folder2Document.FindMatches(Folder2DocumentFields.FolderId = parentFolder.Id)
						doc.AddStatus(parentFolder, ec(i).Folder2Document(folderindices(0)).DocumentStatus.DocumentStatusId,
						              ec(i).Folder2Document(folderindices(0)).DocumentStatus.Name)
						dataChanged = True
					End If
					'DocumentClassification
					If ec(i).DocumentClassificationId <> doc.ClassificationId And Not doc.ClassificationIdIsDirty Then
						doc.SetClassificationId(ec(i).DocumentClassificationId)
						dataChanged = True
					End If
					'DocumentStatus
					Dim indices As List(Of Integer) =
					    	ec(i).Folder2Document.FindMatches(Folder2DocumentFields.FolderId = parentFolder.Id)
					If doc.Type = DocumentTypes.Template Or doc.Type <> DocumentTypes.Template And doc.Folders(0).Id = parentFolder.Id _
						Then
						If ec(i).Folder2Document(indices(0)).DocumentStatusId <> doc.StatusId(parentFolder) And Not doc.StatusIdIsDirty _
							Then
							doc.SetStatusId(parentFolder, ec(i).Folder2Document(indices(0)).DocumentStatus.DocumentStatusId,
							                ec(i).Folder2Document(indices(0)).DocumentStatus.Name)
							dataChanged = True
						End If
					ElseIf doc.Type <> DocumentTypes.Template And doc.Folders(0).Id <> parentFolder.Id Then
						If ec(i).Folder2Document(indices(0)).DocumentStatusId <> doc.StatusId(doc.Folders(0)) And Not doc.StatusIdIsDirty _
							Then
							doc.SetStatusId(doc.Folders(0), ec(i).Folder2Document(indices(0)).DocumentStatus.DocumentStatusId,
							                ec(i).Folder2Document(indices(0)).DocumentStatus.Name)
							dataChanged = True
						End If
					End If
					'Title
					If String.Compare(doc.Title, ec(i).Title) <> 0 And Not doc.TitleIsDirty Then
						doc.SetTitle(ec(i).Title)
						dataChanged = True
					End If
					'Description
					If String.Compare(doc.Description, ec(i).Description) <> 0 And Not doc.DescriptionIsDirty Then
						doc.SetDescription(ec(i).Description)
						dataChanged = True
					End If
					'LinkNo
					If Not ec(i).LinkNo.Equals(doc.LinkNo) And Not doc.LinkNoIsDirty Then
						doc.SetLinkNo(ec(i).LinkNo)
						dataChanged = True
					End If
					'TurbineNumber
					If String.Compare(doc.TurbineNumber, ec(i).TurbineNumber) <> 0 And Not doc.TurbineNumberIsDirty Then
						doc.SetTurbineNumber(ec(i).TurbineNumber)
						dataChanged = True
					End If
					'DocumentBinary and related properties
					If _
						Not doc.DocumentBinaryId.HasValue OrElse
						Not doc.DocumentBinaryId.Value.Equals(ec(i).DocumentBinaryId) And Not doc.DocumentBinaryIdIsDirty Then
						doc.DocumentBinaryId = ec(i).DocumentBinaryId
						doc.SetFileName(ec(i).FileName)
						doc.FileDate = ec(i).FileDate
						doc.FileSize = ec(i).FileSize
						doc.PictureDateTaken = ec(i).PictureDate
						doc.PictureHeight = ec(i).PictureHeight
						doc.PictureWidth = ec(i).PictureWidth
						dataChanged = True
					End If
					'Locked
					If Not (doc.Created.Equals(ec(i).Created) Or doc.Locked.Equals(ec(i).Locked)) Then
						doc.Created = ec(i).Created
						doc.CreatedByParticipant = ec(i).CreatedByParticipant
						doc.Locked = ec(i).Locked
						doc.LockedByParticipant = ec(i).LockedByParticipant
						dataChanged = True
					End If
					'Recycled (equivalent to db field "Deleted")
					If Not doc.Recycled.Equals(ec(i).Deleted) And Not doc.RecycledIsDirty Then
						doc.SetRecycled(ec(i).Deleted)
						dataChanged = True
					End If
				End If
			Next

			'Remove deleted documents
			_searchEntityCollection = ec
			fldToFind = Parent
			dataChanged = dataChanged Or liDocument.RemoveAll(New System.Predicate(Of Document)(AddressOf FindItemToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Return the specified document
		''' </summary>
		''' <param name="doc"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindDocument(ByVal doc As Document) As Boolean
			Return doc.Id.Equals(idToFind)
		End Function

		''' <summary>
		''' Find Item To Remove
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemToRemove(ByVal item As Document) As Boolean
			Return _
				Not item.IsDirty And item.Folders.Contains(fldToFind) And
				_searchEntityCollection.FindMatches(DocumentFields.DocumentId = item.Id).Count = 0
		End Function

		''' <summary>
		''' Mark document as deleted
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub DeleteDocument(ByVal doc As Document, ByVal Permanent As Boolean)
			If Permanent Then
				If Not doc.Deleted Then
					doc.Deleted = True
					OnDataChanged()
				End If
			Else
				If Not doc.Recycled Then
					doc.Recycled = True
					OnDataChanged()
				End If
			End If
		End Sub

		''' <summary>
		''' Add document
		''' </summary>
		''' <param name="Parent"></param>
		''' <param name="File"></param>
		''' <param name="Title"></param>
		''' <param name="ClassificationId"></param>
		''' <param name="StatusId"></param>
		''' <param name="LinkNo"></param>
		''' <param name="TurbineNo"></param>
		''' <remarks></remarks>
		Public Sub AddDocument(ByVal Parent As Folder, ByVal File As FileInfo, ByVal Title As String,
		                       ByVal Description As String, ByVal ClassificationId As Long, ByVal StatusId As Long,
		                       ByVal StatusName As String, ByVal LinkNo As Nullable(Of Short), ByVal TurbineNo As String)
			InsertDocument(
				New Document(_Environment, _Context, File, Parent, Title, Description, ClassificationId, StatusId, StatusName,
				             LinkNo, TurbineNo), Parent)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Deselect all documents
		''' </summary>
		''' <remarks></remarks>
		Public Sub DeselectDocuments()
			Dim docs As List(Of Document) = liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindSelectedDocuments))
			For Each doc As Document In docs
				doc.Selected = False
			Next
		End Sub

		''' <summary>
		''' Select document
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub SelectDocument(ByVal doc As Document)
			If Not doc.Selected Then doc.Selected = True
		End Sub

		''' <summary>
		''' Insert document into document list
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="Parent"></param>
		''' <remarks></remarks>
		Private Sub InsertDocument(ByVal doc As Document, ByVal Parent As Folder)
			fldToFind = Parent
			Dim docs As List(Of Document) = liDocument.FindAll(New System.Predicate(Of Document)(AddressOf FindDocumentsInFolder))
			fldToFind = Nothing
			If docs.Count = 0 Then
				'Insert as first document in parent folder
				liDocument.Add(doc)
			Else
				'Insert in correct sorted order amongst the other documents in the parent folder
				Dim i As Integer
				For i = 0 To docs.Count - 1
					If String.Compare(doc.Title, docs(i).Title) <= 0 Then
						liDocument.Insert(liDocument.IndexOf(docs(i)), doc)
						Exit For
					End If
				Next
				If i = docs.Count Then
					liDocument.Insert(liDocument.IndexOf(docs(i - 1)) + 1, doc)
				End If
			End If
		End Sub

		''' <summary>
		''' Mark document as saved
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub DocumentSaved(ByVal doc As Document)
			doc.Dirty(False)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Mark document as saved
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="DocumentId"></param>
		''' <param name="DocumentBinaryId"></param>
		''' <remarks></remarks>
		Public Sub DocumentSaved(ByVal doc As Document, ByVal DocumentId As Long, ByVal DocumentBinaryId As Long)
			doc.Id = DocumentId
			doc.DocumentBinaryId = DocumentBinaryId
			doc.Locked = Nothing
			doc.Dirty(False)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Set new DocumentBinaryId
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="DocumentBinaryId"></param>
		''' <remarks></remarks>
		Public Sub UpdateDocumentBinaryId(ByVal doc As Document, ByVal DocumentBinaryId As Long)
			doc.DocumentBinaryId = DocumentBinaryId
			OnDataChanged()
		End Sub

		''' <summary>
		''' Set created date
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="Created"></param>
		''' <remarks></remarks>
		Public Sub CreateDocument(ByVal doc As Document, ByVal Created As Nullable(Of Date))
			doc.Created = Created
			OnDataChanged()
		End Sub

		''' <summary>
		''' Set locked date
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="locked"></param>
		''' <remarks></remarks>
		Public Sub LockDocument(ByVal doc As Document, ByVal locked As Nullable(Of Date))
			doc.Locked = locked
			doc.LockedIsDirty = True
			OnDataChanged()
		End Sub

		''' <summary>
		''' Set locked date
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="locked"></param>
		''' <remarks></remarks>
		Public Sub LockDocument(ByVal doc As Document, ByVal locked As Nullable(Of Date),
		                        ByVal LockedByParticipant As ParticipantEntity)
			doc.Locked = locked
			doc.LockedByParticipant = LockedByParticipant
			OnDataChanged()
		End Sub

		''' <summary>
		''' Remove locked date
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub UnlockDocument(ByVal doc As Document)
			doc.Locked = Nothing
			OnDataChanged()
		End Sub

		''' <summary>
		''' Move folder
		''' </summary>
		''' <param name="sourceFolder"></param>
		''' <param name="targetFolder"></param>
		''' <remarks></remarks>
		Public Sub MoveFolder(ByVal sourceFolder As Folder, ByVal targetFolder As Folder)
			sourceFolder.Parent = targetFolder
			sourceFolder.CalcSort()
			MoveFolderRecursive(sourceFolder)
			targetFolder.Expanded = True
			OnDataChanged()
		End Sub

		''' <summary>
		''' Move a folder and all sub folders of a folder to a new location in the model
		''' </summary>
		''' <param name="folder"></param>
		''' <remarks></remarks>
		Private Sub MoveFolderRecursive(ByVal folder As Folder)
			liFolder.Remove(folder)
			liFolder.Insert(IndexToInsertFolder(folder.Parent, folder.Name), folder)
			folder.CalcSort()
			fldToFind = folder
			Dim folders As List(Of Folder) = liFolder.FindAll(New System.Predicate(Of Folder)(AddressOf FindFoldersInFolder))
			fldToFind = Nothing
			For Each fldr As Folder In folders
				MoveFolderRecursive(fldr)
			Next
		End Sub

		''' <summary>
		''' Move Document
		''' </summary>
		''' <param name="document"></param>
		''' <param name="targetFolder"></param>
		''' <remarks></remarks>
		Public Sub MoveDocument(ByVal document As Document, ByVal targetFolder As Folder)
			Dim status As Status = document.Statuses(document.Folders(0).Id)
			document.Folders.Clear()
			document.AddFolder(targetFolder)
			document.Statuses.Clear()
			document.AddStatus(targetFolder, status.Id, status.Name)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Set the title of the document
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="Title"></param>
		''' <remarks></remarks>
		Public Sub SetDocumentTitle(ByVal doc As Document, ByVal Title As String)
			If doc.Title <> Title Then
				doc.Title = Title
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Set the description of the document
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="Description"></param>
		''' <remarks></remarks>
		Public Sub SetDocumentDescription(ByVal doc As Document, ByVal Description As String)
			If doc.Description <> Description Then
				doc.Description = Description
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Set the Classification of the document
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="Classification"></param>
		''' <remarks></remarks>
		Public Sub SetDocumentClassification(ByVal doc As Document, ByVal Classification As Long)
			If doc.ClassificationId <> Classification Then
				doc.ClassificationId = Classification
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Set the CaseFactsStatus of the document
		''' </summary>
		''' <param name="Parent"></param>
		''' <param name="doc"></param>
		''' <param name="StatusId"></param>
		''' <param name="StatusName"></param>
		''' <remarks></remarks>
		Public Sub SetDocumentStatus(ByVal Parent As Folder, ByVal doc As Document, ByVal StatusId As Long,
		                             ByVal StatusName As String)
			If doc.StatusId(Parent) <> StatusId Then
				doc.SetStatusId(Parent, StatusId, StatusName)
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Set the Link No of the document
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="LinkNo"></param>
		''' <remarks></remarks>
		Public Sub SetDocumentLinkNo(ByVal doc As Document, ByVal LinkNo As Nullable(Of Short))
			If Not doc.LinkNo.Equals(LinkNo) Then
				doc.LinkNo = LinkNo
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Set the Turbine No of the document
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="TurbineNo"></param>
		''' <remarks></remarks>
		Public Sub SetDocumentTurbineNo(ByVal doc As Document, ByVal TurbineNo As String)
			If doc.TurbineNumber <> TurbineNo Then
				doc.TurbineNumber = TurbineNo
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Set the name of the folder
		''' </summary>
		''' <param name="folder"></param>
		''' <param name="name"></param>
		''' <remarks></remarks>
		Public Sub SetFolderName(ByVal folder As Folder, ByVal name As String)
			folder.Name = name
		End Sub

		''' <summary>
		''' Convert a document to a template
		''' </summary>
		''' <param name="doc"></param>
		''' <param name="template"></param>
		''' <remarks></remarks>
		Public Sub ConvertDocumentToTemplate(ByVal doc As Document, ByVal template As Document)
			'Update template
			template.DocumentBinaryId = doc.DocumentBinaryId
			template.FileDate = doc.FileDate
			template.FileName = doc.FileName
			template.FileSize = doc.FileSize
			If doc.Type = DocumentTypes.Picture Then
				template.PictureDateTaken = doc.PictureDateTaken
				template.PictureHeight = doc.PictureHeight
				template.PictureWidth = doc.PictureWidth
			Else
				template.PictureDateTaken = Nothing
				template.PictureHeight = Nothing
				template.PictureWidth = Nothing
			End If
			template.ThumbNail = doc.ThumbNail
			template.Created = Date.UtcNow()
			template.Promoted = True

			'Delete promoted document
			doc.Deleted = True
			doc.Promoted = True

			OnDataChanged()
		End Sub

		''' <summary>
		''' Convert a document from a promoted document to a normal document
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub Demote(ByVal doc As Document)
			doc.Deleted = False
			doc.Promoted = False
		End Sub

		Public Function GetDocById(ByVal documentId As Long) As Document
			For Each document As Document In liDocument
				If (document.Id = documentId) Then
					Return document
				End If
			Next

			Return Nothing
		End Function
	End Class
End Namespace
