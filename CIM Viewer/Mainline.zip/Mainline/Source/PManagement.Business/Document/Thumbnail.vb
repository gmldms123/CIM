Imports System.Drawing.Imaging

Namespace Document
	''' <summary>
	''' Thumbnail
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Thumbnail
		Private ReadOnly _Thumbnail As Image
		Private ReadOnly _Date As Nullable(Of Date)
		Private ReadOnly _Height As Integer
		Private ReadOnly _Width As Integer

		''' <summary>
		''' New
		''' </summary>
		''' <param name="Thumbnail"></param>
		''' <param name="Date"></param>
		''' <param name="Height"></param>
		''' <param name="Width"></param>
		''' <remarks></remarks>
		Public Sub New(ByRef Thumbnail As Image, ByRef [Date] As Nullable(Of Date), ByRef Height As Integer,
		               ByRef Width As Integer)
			_Thumbnail = Thumbnail
			_Date = [Date]
			_Height = Height
			_Width = Width
		End Sub

		''' <summary>
		''' Thumbnail
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Thumbnail() As Image
			Get
				Return _Thumbnail
			End Get
		End Property

		''' <summary>
		''' Format
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Format() As ImageFormat
			Get
				Return _Thumbnail.RawFormat
			End Get
		End Property

		''' <summary>
		''' Date
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property [Date]() As Nullable(Of Date)
			Get
				Return _Date
			End Get
		End Property

		''' <summary>
		''' Original Height
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OriginalHeight() As Integer
			Get
				Return _Height
			End Get
		End Property

		''' <summary>
		''' Original Width
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OriginalWidth() As Integer
			Get
				Return _Width
			End Get
		End Property
	End Class
End Namespace
