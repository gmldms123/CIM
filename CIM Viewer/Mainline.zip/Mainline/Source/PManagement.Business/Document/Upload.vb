Imports PManagement.Framework.FileUpload
Imports PManagement.Business.Genericed
Imports PManagement.Framework
Imports PManagement.Framework.Interfaces

Namespace Document
	''' <summary>
	''' Upload
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Upload
		Implements IDisposable, IDocumentUpload

		Private Shared _MonitorLock As New Object()

		Private _Initialized As Boolean = False
		Private _Environment As Environment = Nothing
		Private _BackgroundThread As Thread = Nothing
		Private _DocumentBeingSaved As Document = Nothing
		Private ReadOnly _DocumentQueue As Queue(Of Document) = New Queue(Of Document)

		Public Event DocumentSaved(ByVal e As UploadEventArgs)
		Public Event DocumentUpdated(ByVal e As UploadEventArgs)
		Public Event UploadFailed(ByVal e As UploadEventArgs)
		Public Event DocumentQueueSizeChanged(ByVal e As UploadEventArgs)

		''' <summary>
		''' Is instance initialized using Sub Initialize
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Initialized() As Boolean
			Get
				Return _Initialized
			End Get
		End Property

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <remarks></remarks>
		Public Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext)
			If Not Initialized Then
				PmanTrace.WriteInfo("Upload", "Initialize")
				Using New Guard(Of Object)(_MonitorLock)
					If Not Initialized Then
						_Environment = environment

						If _BackgroundThread Is Nothing Then
							If _Environment.Platform <> Environment.Platforms.Web Then
								_BackgroundThread = New Thread(AddressOf BackgroundProcess)
								_BackgroundThread.Priority = ThreadPriority.Lowest
								_BackgroundThread.IsBackground = True
								_BackgroundThread.Start()
							End If
						End If

						_Initialized = True
					End If
				End Using
			End If
		End Sub

		''' <summary>
		''' Raise event DocumentQueueSizeChanged
		''' </summary>
		''' <remarks></remarks>
		Private Sub OnDocumentQueueSizeChanged()
			PmanTrace.WriteInfo("Upload", "OnDocumentQueueSizeChanged")

			RaiseEvent DocumentQueueSizeChanged(New UploadEventArgs(DocumentsEnqueued_i))
		End Sub

		''' <summary>
		''' Raise event DocumentSaved
		''' </summary>
		''' <remarks></remarks>
		Private Sub OnDocumentSaved(ByRef Doc As Document, ByVal DocumentBinaryId As Long)
			PmanTrace.WriteInfo("Upload", "OnDocumentSaved")

			RaiseEvent DocumentSaved(New UploadEventArgs(Doc, DocumentBinaryId))
		End Sub

		''' <summary>
		''' Raise event DocumentUpdated
		''' </summary>
		''' <remarks></remarks>
		Private Sub OnDocumentUpdated(ByRef Doc As Document, ByVal DocumentBinaryId As Long)
			PmanTrace.WriteInfo("Upload", "OnDocumentUpdated")

			RaiseEvent DocumentUpdated(New UploadEventArgs(Doc, DocumentBinaryId))
		End Sub

		''' <summary>
		''' Raise event UploadFailed
		''' </summary>
		''' <remarks></remarks>
		Private Sub OnUploadFailed(ByRef Doc As Document)
			PmanTrace.WriteInfo("Upload", "OnUploadFailed")

			RaiseEvent UploadFailed(New UploadEventArgs(Doc))
		End Sub

		''' <summary>
		''' Get number of documents in upload queue
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DocumentsEnqueued() As Integer
			Get
				Using New Guard(Of Object)(_MonitorLock)
					Return DocumentsEnqueued_i
				End Using
			End Get
		End Property

		''' <summary>
		''' DocumentsEnqueued implementation method
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Private ReadOnly Property DocumentsEnqueued_i() As Integer
			Get
				Dim addDocument As Integer
				If _DocumentBeingSaved IsNot Nothing Then addDocument = 1
				Return _DocumentQueue.Count + addDocument
			End Get
		End Property

		''' <summary>
		''' Return whether queue contains the specified document
		''' </summary>
		''' <param name="doc"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsEnqueued(ByVal doc As Document) As Boolean
			Get
				Using New Guard(Of Object)(_MonitorLock)
					Return _DocumentQueue.Contains(doc) Or _DocumentBeingSaved Is doc
				End Using
			End Get
		End Property

		Public Sub Enqueue(ByRef documentId As Long) Implements IDocumentUpload.Enqueue
		End Sub

		''' <summary>
		''' Enqueue a document
		''' </summary>
		''' <param name="doc"></param>
		''' <remarks></remarks>
		Public Sub Enqueue(ByRef doc As Document)
			PmanTrace.WriteInfo("Upload", "Enqueue")

			Using guard As New Guard(Of Object)(_MonitorLock)
				_DocumentQueue.Enqueue(doc)
				guard.Pulse()
				OnDocumentQueueSizeChanged()
			End Using
		End Sub

		''' <summary>
		''' Upload queued documents
		''' </summary>
		''' <remarks></remarks>
		Private Sub BackgroundProcess()
			PmanTrace.WriteInfo("Upload", "BackgroundProcess")

			Try
				While True
					Using guard As New Guard(Of Object)(_MonitorLock)
						While _DocumentQueue.Count = 0
							guard.Wait()
							'Release lock on locking object as long as no document is enqueued. Enqueue signals for this wait command to reaquire the lock.
						End While

						'Get document from queue
						_DocumentBeingSaved = _DocumentQueue.Dequeue()
					End Using

					PmanTrace.WriteVerbose("Upload", "BackgroundProcess",
					                       String.Format("Uploading ""{0}"" (""{1}"")", _DocumentBeingSaved.Title,
					                                     _DocumentBeingSaved.FullPathAndFileName))
					'Upload document
					Using daa As New DataAccessAdapter(_DocumentBeingSaved.Environment.PManagement_ConnectionString, False)
						Dim entity As New DocumentBinaryEntity()
						Try
							'Create new documentbinary to store file
							entity.Document = New Byte() {}
							daa.SaveEntity(entity, True)
							PmanTrace.WriteVerbose("Upload", "BackgroundProcess",
							                       String.Format("DocumentBinary ({0}) placeholder created", entity.DocumentBinaryId))

							'Upload file
							Dim ex As Exception = FileUploader.UploadFile(_DocumentBeingSaved.Environment.PManagement_ConnectionString,
							                                              entity.DocumentBinaryId, _DocumentBeingSaved.FullPathAndFileName)

							'Handle upload
							If ex Is Nothing Then
								If _DocumentBeingSaved.IsNew Then
									OnDocumentSaved(_DocumentBeingSaved, entity.DocumentBinaryId)
								Else
									OnDocumentUpdated(_DocumentBeingSaved, entity.DocumentBinaryId)
								End If
							Else
								Throw ex
							End If
						Catch ex As Exception
							PmanTrace.WriteVerbose("Upload", "BackgroundProcess",
							                       String.Format("Failed to upload ""{0}"" (""{1}"") {2}{3}{2}{4}", _DocumentBeingSaved.Title,
							                                     _DocumentBeingSaved.FullPathAndFileName, System.Environment.NewLine,
							                                     ex.Message, ex.StackTrace))
							'Clean up entity
							Dim documentBinaryId As Long = entity.DocumentBinaryId
							Try
								daa.DeleteEntity(entity)
								PmanTrace.WriteVerbose("Upload", "BackgroundProcess",
								                       String.Format("DocumentBinary ({0}) deleted", documentBinaryId))
							Catch
								PmanTrace.WriteVerbose("Upload", "BackgroundProcess",
								                       String.Format("DocumentBinary ({0}) NOT deleted", documentBinaryId))
							End Try
							OnUploadFailed(_DocumentBeingSaved)
						Finally
							daa.CloseConnection()
							Using New Guard(Of Object)(_MonitorLock)
								_DocumentBeingSaved = Nothing
								OnDocumentQueueSizeChanged()
							End Using
						End Try
					End Using
				End While
			Catch ex As ThreadAbortException
				'Handle exception thrown by Dispose()
				Using New Guard(Of Object)(_MonitorLock)
					_DocumentQueue.Clear()
					_DocumentBeingSaved = Nothing
				End Using
			End Try
		End Sub

		Private disposedValue As Boolean = False
		' To detect redundant calls

		' IDisposable
		Private Sub Dispose(ByVal disposing As Boolean)
			PmanTrace.WriteInfo("Upload", "Dispose")

			If Not disposedValue Then
				If disposing Then
					If _BackgroundThread IsNot Nothing Then
						Try
							PmanTrace.WriteVerbose("Upload", "Dispose", "Aborting background process")
							_BackgroundThread.Priority = ThreadPriority.Normal
							_BackgroundThread.Abort()
							_BackgroundThread = Nothing
						Catch ex As Exception
							PmanTrace.WriteVerbose("Upload", "Dispose",
							                       String.Format("Failed to abort background process{0}{1}{0}{2}", System.Environment.NewLine,
							                                     ex.Message, ex.StackTrace))
						End Try
					End If
					_Environment = Nothing
				End If
				PmanTrace.WriteVerbose("Upload", "Dispose", "Disposed")
			End If
			disposedValue = True
		End Sub

#Region " IDisposable Support "

		' This code added by Visual Basic to correctly implement the disposable pattern.
		Public Sub Dispose() Implements IDisposable.Dispose
			' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
			Dispose(True)
			GC.SuppressFinalize(Me)
		End Sub

#End Region
	End Class
End Namespace
