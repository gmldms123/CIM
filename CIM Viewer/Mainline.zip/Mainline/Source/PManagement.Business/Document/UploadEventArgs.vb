Namespace Document
	''' <summary>
	''' UploadEventArgs
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class UploadEventArgs
		Inherits EventArgs

		Private ReadOnly _Doc As Document
		Private ReadOnly _DocumentBinaryId As Long
		Private ReadOnly _DocumentsEnqueued As Integer

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New(ByVal documentsEnqueued As Integer)
			_Doc = Nothing
			_DocumentBinaryId = - 1
			_DocumentsEnqueued = documentsEnqueued
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="Doc"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal Doc As Document)
			_Doc = Doc
			_DocumentBinaryId = - 1
			_DocumentsEnqueued = - 1
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="Doc"></param>
		''' <param name="DocumentBinaryId"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal Doc As Document, ByVal DocumentBinaryId As Long)
			_Doc = Doc
			_DocumentBinaryId = DocumentBinaryId
			_DocumentsEnqueued = - 1
		End Sub

		''' <summary>
		''' Document
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Document() As Document
			Get
				Return _Doc
			End Get
		End Property

		''' <summary>
		''' Document Binary Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DocumentBinaryId() As Long
			Get
				Return _DocumentBinaryId
			End Get
		End Property

		''' <summary>
		''' Documents Enqueued
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DocumentsEnqueued() As Integer
			Get
				Return _DocumentsEnqueued
			End Get
		End Property
	End Class
End Namespace
