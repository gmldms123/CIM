' Manage which environment is used for running the application
Imports System.Deployment.Application
Imports PManagement.Framework
Imports PManagement.Framework.Interfaces
Imports System.Web

Public NotInheritable Class Environment
	Implements IEnvironment
    Private _Environment As Environments = Environments.Development
	Private _IsNetworkDeployed As Boolean = True
	Private _Platform As Platforms = Platforms.Windows
	Private _Traceable As Boolean = True

	Public Event EnvironmentChanged()

	''' <summary>
	''' Raise event EnvironmentChanged
	''' </summary>
	''' <remarks></remarks>
	Private Sub OnEnvironmentChanged()
		If Traceable Then PmanTrace.WriteInfo("Environment", "OnEnvironmentChanged")

		RaiseEvent EnvironmentChanged()
	End Sub

	''' <summary>
	''' Types of environments
	''' </summary>
	''' <remarks></remarks>
		Public Enum Environments
		Development
		Test
		Production
		UnitTest
		QA
	End Enum

	''' <summary>
	''' Platform to determine how to setup the environment
	''' </summary>
	''' <remarks></remarks>
		Public Enum Platforms
		Windows
		Web
	End Enum

	''' <summary>
	''' Environment
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property Environment() As Environments
		Get
			Return _Environment
		End Get
		Set(ByVal value As Environments)
			If Traceable Then PmanTrace.WriteInfo("Environment", "Environment (Set)")

			If _Environment <> value Then
				If Traceable Then _
					PmanTrace.WriteVerbose("Environment", "Environment (Set)", String.Format("Changing Environment to ""{0}""", value))

				_Environment = value

				OnEnvironmentChanged()
			End If
		End Set
	End Property

	''' <summary>
	''' Platform
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property Platform() As Platforms
		Get
			Return _Platform
		End Get
		Set(ByVal value As Platforms)
			If Traceable Then PmanTrace.WriteInfo("Environment", "Platform (Set)")

			If _Platform <> value Then
				If Traceable Then _
					PmanTrace.WriteVerbose("Environment", "Platform (Set)", String.Format("Changing platform to ""{0}""", value))

				_Platform = value
			End If
		End Set
	End Property

	''' <summary>
	''' Is application network deployed
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property IsNetworkDeployed() As Boolean
		Get
			Return _IsNetworkDeployed
		End Get
		Set(ByVal value As Boolean)
			If Traceable Then PmanTrace.WriteInfo("Environment", "IsNetworkDeployed (Set)")

			If _IsNetworkDeployed <> value Then
				If Traceable Then _
					PmanTrace.WriteVerbose("Environment", "IsNetworkDeployed (Set)",
					                       String.Format("Changing IsNetworkDeployed to ""{0}""", value))

				_IsNetworkDeployed = value
			End If
		End Set
	End Property

	''' <summary>
	''' Does this instance write trace messages
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property Traceable() As Boolean
		Get
			Return _Traceable
		End Get
		Set(ByVal value As Boolean)
			If value Then PmanTrace.WriteInfo("Environment", "Traceable (Set)")

			If _Traceable <> value Then
				If value Then _
					PmanTrace.WriteVerbose("Environment", "Traceable (Set)", String.Format("Changing Traceable to ""{0}""", value))

				_Traceable = value
			End If
		End Set
	End Property

	''' <summary>
	''' Get Service Polling Interval
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property ServicePollingInterval() As TimeSpan
		Get
			Dim timeSpan As TimeSpan
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest, Environments.QA
					timeSpan = My.Settings.ServicePollingInterval_Development
				Case Environments.Test
					timeSpan = My.Settings.ServicePollingInterval_Test
				Case Environments.Production
					timeSpan = My.Settings.ServicePollingInterval_Prod
			End Select
			Return timeSpan
		End Get
	End Property

	''' <summary>
	''' Setup the environment to use
	''' </summary>
	''' <remarks>The environment depends on which machine has started the application</remarks>
	Public Sub SetupEnvironment(ByVal platforms As Platforms)
		If Traceable Then PmanTrace.WriteInfo("Environment", "SetupEnvironment")
		Platform = platforms
		Select Case Platform
			Case Platforms.Windows
				Select Case _IsNetworkDeployed
					'The app was not deployes from a network using ClickOnce. Therfore Development environment or Service
					Case False
						Dim App_ActivatedFromComputerName As String = My.Computer.Name
						If String.Compare(My.Settings.AssumeDevServiceWhenMachineIs, App_ActivatedFromComputerName, True) = 0 Then
							Environment = Environments.Development
						ElseIf String.Compare(My.Settings.AssumeQAServiceWhenMachineIs, App_ActivatedFromComputerName, True) = 0 Then
							Environment = Environments.QA
						ElseIf String.Compare(My.Settings.AssumeTestServiceWhenMachineIs, App_ActivatedFromComputerName, True) = 0 Then
							Environment = Environments.Test
						ElseIf String.Compare(My.Settings.AssumeProdServiceWhenMachineIs, App_ActivatedFromComputerName, True) = 0 Then
							Environment = Environments.Production
						Else
							'Assume development environment
							Environment = Environments.Development
						End If
					Case True
						'Dim errorOccured As Boolean = False
						'Try
						'Dim lblDsnName As String = System.Net.Dns.GetHostEntry("localhost").HostName '   ByName("localhost").HostName
						Dim App_ActivatedFromComputerName As String = ApplicationDeployment.CurrentDeployment.UpdateLocation.DnsSafeHost
						If My.Settings.AssumeDevelopmentWhenMachineIs.IndexOf(App_ActivatedFromComputerName) > - 1 Then
							Environment = Environments.Development
						ElseIf My.Settings.AssumeQAWhenMachineIs.IndexOf(App_ActivatedFromComputerName) > - 1 Then
							Environment = Environments.QA
						ElseIf My.Settings.AssumeTestWhenMachineIs.IndexOf(App_ActivatedFromComputerName) > - 1 Then
							Environment = Environments.Test
						ElseIf My.Settings.AssumeProductionWhenMachineIs.IndexOf(App_ActivatedFromComputerName) > - 1 Then
							Environment = Environments.Production
						Else
                            Environment = Environments.Development
                        End If
				End Select
			Case Platforms.Web
				Try
					Dim HTTP_HOST As String = HttpContext.Current.Request.ServerVariables("HTTP_HOST").ToLower()

					' TODO: proper host header for QA environment here
					If HTTP_HOST.StartsWith("dkrdstfs04") Or HTTP_HOST.StartsWith("pman-qa.vestas.net") Then
						Environment = Environments.QA
					ElseIf HTTP_HOST.StartsWith("pman-test.vestas.net") Then
						Environment = Environments.Test
					ElseIf HTTP_HOST.StartsWith("pman.vestas.net") Then
                        Environment = Environments.Production
                    ElseIf HTTP_HOST.ToLower = "pman" Then
                        Environment = Environments.Production
                    Else
                        ' default to development (localhost, pman-dev.vestas.net, etc etc)
                        Environment = Environments.Development
					End If
				Catch ex As Exception
					Throw New Exception("ERROR", ex.InnerException)
				End Try

		End Select
	End Sub

	''' <summary>
	''' Get URL for very old CIRs
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property CIROld_URL() As String
		Get
			Return My.Settings.CIRVeryOld_URL
		End Get
	End Property

	''' <summary>
	''' Get CIR URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property CIR_URL() As String
		Get
			Dim dir As String = String.Empty
			Select Case Environment
				Case Environments.Development, Environments.UnitTest
					dir = My.Settings.CIR_URL_Development
				Case Environments.QA
					dir = My.Settings.CIR_URL_QA
				Case Environments.Test
					dir = My.Settings.CIR_URL_Test
				Case Environments.Production
					dir = My.Settings.CIR_URL_Prod
			End Select
			Return dir
		End Get
	End Property

	''' <summary>
	''' Get New CIR URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property CIRNew_URL() As String
		Get
			Dim dir As String = String.Empty
			Select Case Environment
				Case Environments.Development, Environments.UnitTest
					dir = My.Settings.CIRNew_URL_Development
				Case Environments.QA
					dir = My.Settings.CIRNew_URL_QA
				Case Environments.Test
					dir = My.Settings.CIRNew_URL_Test
				Case Environments.Production
					dir = My.Settings.CIRNew_URL_Production
			End Select
			Return dir
		End Get
	End Property

	Public Function PManagement_ConnectionEnvironment() As String Implements IEnvironment.PManagement_ConnectionEnvironment
		Dim env As String = String.Empty
		Select Case Environment
			Case Environments.UnitTest
				env = "UnitTest"
			Case Environments.Development
				env = "Development"
			Case Environments.QA
				env = "QA"
			Case Environments.Test
				env = "Test"
			Case Environments.Production
				env = "Production"
		End Select

		Return env
	End Function

	''' <summary>
	''' Get document cache directory
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property DocumentCacheDirectory() As String Implements IEnvironment.DocumentCacheDirectory
		Get
			Dim dir As String = String.Empty
			Select Case Environment
				Case Environments.Development, Environments.UnitTest
					dir = My.Settings.DocumentCache_Dev
				Case Environments.QA
					dir = My.Settings.DocumentCache_QA
				Case Environments.Test
					dir = My.Settings.DocumentCache_Test
				Case Environments.Production
					dir = My.Settings.DocumentCache_Prod
			End Select
			Return dir
		End Get
	End Property


	''' <summary>
	''' Get PManagement connection string
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property ProjectPortal_ConnectionString() As String
		Get
			Dim ConnectionString As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest, Environments.QA
					ConnectionString = My.Settings.ProjectPortal_ConnectionString_Development
				Case Environments.Test
					ConnectionString = My.Settings.ProjectPortal_ConnectionString_Test
				Case Environments.Production
					ConnectionString = My.Settings.ProjectPortal_ConnectionString_Production
			End Select
			Return ConnectionString
		End Get
	End Property

	''' <summary>
	''' Get Project Portal URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property ProjectPortal_URL() As String Implements IEnvironment.ProjectPortal_URL
		Get
			Dim Url As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest
					Url = My.Settings.ProjectPortal_URL_Dev
				Case Environments.QA
					Url = My.Settings.ProjectPortal_URL_QA
				Case Environments.Test
					Url = My.Settings.ProjectPortal_URL_Test
				Case Environments.Production
					Url = My.Settings.ProjectPortal_URL_Prod
			End Select
			Return Url
		End Get
	End Property

	Public ReadOnly Property Editor_Alert_URL() As String Implements IEnvironment.Editor_Alert_URL
		Get
			Dim Url As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest
					Url = My.Settings.Case_EditorAlert_URL_Dev
				Case Environments.QA
					Url = My.Settings.Case_EditorAlert_URL_QA
				Case Environments.Test
					Url = My.Settings.Case_EditorAlert_URL_Test
				Case Environments.Production
					Url = My.Settings.Case_EditorAlert_URL_Prod
			End Select
			Return Url
		End Get
	End Property

	''' <summary>
	''' Get Project Portal web service URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property ProjectPortal_WebService_URL() As String
		Get
			Dim Url As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest, Environments.QA
					Url = My.Settings.ProjectPortal_WebService_URL_Dev
				Case Environments.Test
					Url = My.Settings.ProjectPortal_WebService_URL_Test
				Case Environments.Production
					Url = My.Settings.ProjectPortal_WebService_URL_Prod
			End Select
			Return Url
		End Get
	End Property

	''' <summary>
	''' Get Old Project Portal URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property Old_ProjectPortal_URL() As String
		Get
			Dim Url As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest, Environments.QA
					Url = My.Settings.Old_ProjectPortal_URL_Development
				Case Environments.Test
					Url = My.Settings.Old_ProjectPortal_URL_Test
				Case Environments.Production
					Url = My.Settings.Old_ProjectPortal_URL_Production
			End Select
			Return Url
		End Get
	End Property

	''' <summary>
	''' Get Vestas People URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property VestasPeople_URL() As String
		Get
			Dim Url As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest, Environments.QA
					Url = My.Settings.VestasPeople_URL_Dev
				Case Environments.Test
					Url = My.Settings.VestasPeople_URL_Test
				Case Environments.Production
					Url = My.Settings.VestasPeople_URL_Prod
			End Select
			Return Url
		End Get
	End Property

	''' <summary>
	''' Get Case Editor URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property CaseEditor_URL() As String
		Get
			Dim Url As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest
					Url = My.Settings.Case_Editor_URL_Dev
				Case Environments.QA
					Url = My.Settings.Case_Editor_URL_QA
				Case Environments.Test
					Url = My.Settings.Case_Editor_URL_Test
				Case Environments.Production
					Url = My.Settings.Case_Editor_URL_Prod
			End Select
			Return Url
		End Get
	End Property

	''' <summary>
	''' Get Employee Photos URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property EmployeePhotos_URL() As String
		Get
			Return My.Settings.EmployeePhoto_URL_Prod
		End Get
	End Property

	Public Function PManagement_ConnectionString() As String Implements IEnvironment.PManagement_ConnectionString
		Dim ConnectionString As String = String.Empty
		Select Case _Environment
			Case Environments.Development, Environments.UnitTest
				ConnectionString = My.Settings.PManagement_ConnectionString_Development
			Case Environments.QA
				ConnectionString = My.Settings.PManagement_ConnectionString_QA
			Case Environments.Test
				ConnectionString = My.Settings.PManagement_ConnectionString_Test
			Case Environments.Production
				ConnectionString = My.Settings.PManagement_ConnectionString_Production
		End Select
		Return ConnectionString
	End Function

	Public Function CIMProjectServer_URL() As String Implements IEnvironment.CIMProjectServer_URL
		Dim result As String = String.Empty
		Select Case _Environment
			' Please note: The Project Server does only have a Test and a Prod environment.
			Case Environments.Development, Environments.UnitTest
				result = My.Settings.CIMProjectServer_URL_Test
			Case Environments.QA
				result = My.Settings.CIMProjectServer_URL_Test
			Case Environments.Test
				result = My.Settings.CIMProjectServer_URL_Test
			Case Environments.Production
				result = My.Settings.CIMProjectServer_URL_Prod
		End Select
		Return result
	End Function

	''' <summary>
	''' Get Reject CIR web service URL
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property RejectCir_WebService_URL() As String
		Get
			Dim Url As String = String.Empty
			Select Case _Environment
				Case Environments.Development, Environments.UnitTest
					Url = My.Settings.RejectCirDev
				Case Environments.QA
					Url = My.Settings.RejectCirQA
				Case Environments.Test
					Url = My.Settings.RejectCirTest
				Case Environments.Production
					Url = My.Settings.RejectCirProduction
			End Select
			Return Url
		End Get
	End Property

	Public Function DmsServiceUrl() As String
		Dim Url As String = String.Empty
		Select Case _Environment
			Case Environments.Development, Environments.UnitTest
                'Url =
                '    "http://sapdxa.vestas.net:50000/sap/xi/engine?type=entry&amp;version=3.0&amp;Sender.Service=CIM&amp;Interface=urn%3Avestas%3Api%3Aplm%3APLM0207_DMS_CimDocuments%5EPLM0207_CIMDMSDocumetStructure_OB"
                ''PKB DMS Service Update
                Url =
                    "http://sapdxc.vestas.net:50000/WSAdapter/integration/dms/v1/DocumentStructure"

			Case Environments.QA
                'Url =
                '    "http://sapqxa.vestas.net:50200/sap/xi/engine?type=entry&amp;version=3.0&amp;Sender.Service=CIM&amp;Interface=urn%3Avestas%3Api%3Aplm%3APLM0207_DMS_CimDocuments%5EPLM0207_CIMDMSDocumetStructure_OB"
                'PKB DMS Service Update
                Url =
                    "http://sapqow.vestas.net:8094/WSAdapter/integration/dms/v1/DocumentStructure"
			Case Environments.Test
                'Url =
                '    "http://sapqxa.vestas.net:50200/sap/xi/engine?type=entry&amp;version=3.0&amp;Sender.Service=CIM&amp;Interface=urn%3Avestas%3Api%3Aplm%3APLM0207_DMS_CimDocuments%5EPLM0207_CIMDMSDocumetStructure_OB"
                'PKB DMS Service Update
                Url =
                    "http://sapqow.vestas.net:8094/WSAdapter/integration/dms/v1/DocumentStructure"

			Case Environments.Production
                'Url =
                '    "http://sapwxa.vestas.net:8100/sap/xi/engine?type=entry&amp;version=3.0&amp;Sender.Service=CIM&amp;Interface=urn%3Avestas%3Api%3Aplm%3APLM0207_DMS_CimDocuments%5EPLM0207_CIMDMSDocumetStructure_OB"
                'PKB DMS Service Update
                Url =
                    "http://sappow.vestas.net:8094/WSAdapter/integration/dms/v1/DocumentStructure"

		End Select
		Return Url
	End Function

	Public Function DmsServiceUserName() As String
		Dim UserName As String = String.Empty
		Select Case _Environment
			Case Environments.Development, Environments.UnitTest
                'UserName = "PICIMDMSWS"
                'PKB DMS Service Update
                UserName = "SOAPCIMD"
			Case Environments.QA
                'UserName = "PICIMDMSWS"
                'PKB DMS Service Update
                UserName = "SOAPCIMQ"
			Case Environments.Test
                'UserName = "PICIMDMSWS"
                'PKB DMS Service Update
                UserName = "SOAPCIMQ"
			Case Environments.Production
                'UserName = "PICIMDMSWS"
                'PKB DMS Service Update
                UserName = "SOAPCIMP"
		End Select
		Return UserName
	End Function

	Public Function DmsServicePassword() As String
		Dim Password As String = String.Empty
		Select Case _Environment
			Case Environments.Development, Environments.UnitTest
                'Password = "fGt6UhfW8&yu"
                'PKB DMS Service Update
                Password = "Cxw3xdnd"
			Case Environments.QA
                'Password = "fGt6UhfW8&yu"
                'PKB DMS Service Update
                Password = "jGSezhGT1"
			Case Environments.Test
                'Password = "fGt6UhfW8&yu"
                'PKB DMS Service Update
                Password = "jGSezhGT1"
			Case Environments.Production
                'Password = "etyFr%pa87AxZHs3"
                'PKB DMS Service Update
                Password = "UB1Wuh5h"
		End Select
		Return Password
	End Function
End Class
