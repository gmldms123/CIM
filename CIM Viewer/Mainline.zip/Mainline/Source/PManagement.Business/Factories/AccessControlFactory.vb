Imports PManagement.Business.Genericed

Namespace Factories
	''' <summary>
	''' Facory for generating Controller objects
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class AccessControlFactory
		Private Shared ReadOnly _Mutex As New Mutex()

		Private Sub New()
		End Sub

		Public Shared Function CreateInstance(ByRef environment As Environment, ByRef context As PmanContext,
		                                      ByRef syncobject As ISynchronizeInvoke) As AccessControl
			Dim instance As AccessControl
			Select Case environment.Environment
				Case Environment.Environments.UnitTest
					'For unittesting, always generate new instance
					instance = New AccessControl()
				Case Else
					'Otherwise return as singleton
					instance = Singleton (Of AccessControl).Instance
			End Select
			If Not instance.Initialized Then
				'Double-Checked locking pattern
				_Mutex.WaitOne()
				Try
					If Not instance.Initialized Then
						instance.Initialize(environment, context, syncobject, WindowsIdentity.GetCurrent())
					End If
				Finally
					_Mutex.ReleaseMutex()
				End Try
			End If
			Return instance
		End Function
	End Class
End Namespace
