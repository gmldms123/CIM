Imports PManagement.Business.Genericed

Namespace Factories
	''' <summary>
	''' Factory for generating PmanContext objects
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class ContextFactory
		Private Shared ReadOnly _Mutex As New Mutex()

		Private Sub New()
		End Sub

		Public Shared Function CreateInstance(ByRef environment As Environment) As PmanContext
			Dim instance As PmanContext
'      Select Case environment.Environment
'        Case Business.Environment.Environments.UnitTest
'
'          'For unittesting, always generate new instance
'          instance = New PmanContext()
'
'          ' always use anjul for access control queries
'          instance.User = "anjul"
'
'        Case Else
'          'Otherwise return as singleton
			instance = Singleton (Of PmanContext).Instance
'      End Select
			If Not instance.Initialized Then
				'Double-Checked locking pattern
				_Mutex.WaitOne()
				If Not instance.Initialized Then
					instance.Initialize(environment)
					If environment.Environment = Environment.Environments.UnitTest Then
						instance.User = "tthol"
					Else
						instance.User = My.User.Name
					End If
				End If
				_Mutex.ReleaseMutex()
			End If
			Return instance
		End Function
	End Class
End Namespace
