Imports PManagement.Business.Genericed
Imports PManagement.Business.Interfaces

Namespace Factories
	''' <summary>
	''' Facory for generating Controller objects
	''' </summary>
	''' <typeparam name="T"></typeparam>
	''' <remarks></remarks>
		Public NotInheritable Class ControllerFactory (Of T As {New, Controller})
		Private Shared _Mutex As New Mutex()

		Private Sub New()
		End Sub

		Public Shared Function CreateInstance(ByRef environment As Environment, ByRef context As PmanContext,
		                                      ByRef accesscontrol As AccessControl, ByVal model As Model) As T
			Dim instance As T
			Select Case environment.Environment
				Case Environment.Environments.UnitTest
					'For unittesting, always generate new instance
					instance = New T()
				Case Else
					'Otherwise return as singleton
					instance = Singleton (Of T).Instance
			End Select
			If Not instance.Initialized Then
				'Double-Checked locking pattern
				_Mutex.WaitOne()
				If Not instance.Initialized Then
					instance.Initialize(environment, context, accesscontrol, model)
				End If
				_Mutex.ReleaseMutex()
			End If
			Return instance
		End Function
	End Class
End Namespace
