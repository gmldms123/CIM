Imports PManagement.Business.Genericed
Imports PManagement.Business.Document

Namespace Factories
	''' <summary>
	''' Factory for generating Document Download objects
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class DocumentDownloadFactory
		Private Shared ReadOnly _Mutex As New Mutex()

		Private Sub New()
		End Sub

		Public Shared Function CreateInstance(ByRef environment As Environment, ByRef context As PmanContext,
		                                      ByRef accesscontrol As AccessControl) As Download
			Dim instance As Download
			Select Case environment.Environment
				Case Environment.Environments.UnitTest
					'For unittesting, always generate new instance
					instance = New Download()
				Case Else
					'Otherwise return as singleton
					instance = Singleton (Of Download).Instance
			End Select
			If Not instance.Initialized Then
				'Double-Checked locking pattern
				_Mutex.WaitOne()
				If Not instance.Initialized Then
					instance.Initialize(environment, context, accesscontrol)
				End If
				_Mutex.ReleaseMutex()
			End If
			Return instance
		End Function
	End Class
End Namespace
