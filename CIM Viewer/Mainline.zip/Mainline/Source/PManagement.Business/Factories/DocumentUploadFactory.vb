Imports PManagement.Business.Genericed
Imports PManagement.Business.Document

Namespace Factories
	''' <summary>
	''' Factory for generating Document Upload objects
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class DocumentUploadFactory
		Private Shared ReadOnly _Mutex As New Mutex()

		Private Sub New()
		End Sub

		Public Shared Function CreateInstance(ByRef environment As Environment, ByRef context As PmanContext) As Upload
			Dim instance As Upload
			Select Case environment.Environment
				Case Environment.Environments.UnitTest
					'For unittesting, always generate new instance
					instance = New Upload()
				Case Else
					'Otherwise return as singleton
					instance = Singleton (Of Upload).Instance
			End Select
			If Not instance.Initialized Then
				'Double-Checked locking pattern
				_Mutex.WaitOne()
				If Not instance.Initialized Then
					instance.Initialize(environment, context)
				End If
				_Mutex.ReleaseMutex()
			End If
			Return instance
		End Function
	End Class
End Namespace
