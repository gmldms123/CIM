Imports PManagement.Business.Genericed

Namespace Factories
	''' <summary>
	''' Factory for generating Environment objects
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class EnvironmentFactory
		Private Sub New()
		End Sub

		Public Shared Function CreateInstance() As Environment
			Dim environment As Environment = Singleton (Of Environment).Instance
			Return environment
		End Function
	End Class
End Namespace
