Imports PManagement.Business.Genericed
Imports PManagement.Business.Interfaces

Namespace Factories
	''' <summary>
	''' Facory for generating Controller objects
	''' </summary>
	''' <typeparam name="T"></typeparam>
	''' <remarks></remarks>
		Public NotInheritable Class ModelFactory (Of T As {New, Model})
		Private Shared _Mutex As New Mutex()

		Private Sub New()
		End Sub

		Public Shared Function CreateInstance(ByRef environment As Environment, ByRef context As PmanContext) As T
			Dim instance As T
			Select Case environment.Environment
				Case Environment.Environments.UnitTest
					'For unittesting, always generate new instance
					instance = New T()
				Case Else
					'Otherwise return as singleton
					instance = Singleton (Of T).Instance
			End Select
			If Not instance.Initialized Then
				'Double-Checked locking pattern
				_Mutex.WaitOne()
				If Not instance.Initialized Then
					instance.Initialize(environment, context)
				End If
				_Mutex.ReleaseMutex()
			End If
			Return instance
		End Function
	End Class
End Namespace
