Imports System.Windows.Forms
Imports PManagement.Business.Document
Imports PManagement.DataLayer.Documents

''' <summary>
''' General static functions and procedures to be used widely in the business layer
''' </summary>
''' <remarks></remarks>
	Public NotInheritable Class General
	Private Sub New()
	End Sub

	''' <summary>
	''' Enum describing shortnames for KiloByte, MegaByte etc.
	''' </summary>
	''' <remarks></remarks>
		Public Enum ByteDivider
		bytes = 0
		KB = 1
		MB = 2
		GB = 3
		TB = 4
		PB = 5
		EB = 6
		ZB = 7
		YB = 8
	End Enum

	Private Const MAXFILENAMELENGTH As Byte = 217
	'Maximum filename length Excel 2003 can handle

	'Declarations for checking associated application for a filename
	Private Declare Ansi Function FindExecutableA Lib "shell32.dll"(ByVal lpFile As String, ByVal lpDirectory As String,
	                                                                ByVal lpResult As StringBuilder) As Long

	''' <summary>
	''' Get fileinfo based on either the complete filename, or partial filename if specified name is too long
	''' </summary>
	''' <param name="doc"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Shared Function GetFileInfo(ByVal doc As IDocument) As FileInfo
		Dim di As New DirectoryInfo(Path.GetDirectoryName(doc.FullPathAndFileName))
		Dim fileName As String = Path.GetFileNameWithoutExtension(doc.FileName)
		Dim extension As String = Path.GetExtension(doc.FileName)
		Dim oGeneral As New General()
		'Shared functions cannot refer to an instance member of a class from within a shared method or shared member
		Return oGeneral.GetFileInfo(di, fileName, extension)
	End Function

	''' <summary>
	''' Get fileinfo based on either the complete filename, or partial filename if specified name is too long
	''' </summary>
	''' <param name="entity"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Shared Function GetFileInfo(ByRef entity As DocumentEntity, ByRef env As Environment) As FileInfo
		Dim di As New DirectoryInfo(String.Format("{0}\{1}\", env.DocumentCacheDirectory, entity.DocumentBinaryId))
		Dim fileName As String = Path.GetFileNameWithoutExtension(entity.FileName)
		Dim extension As String = Path.GetExtension(entity.FileName)
		Dim oGeneral As New General()
		'Shared functions cannot refer to an instance member of a class from within a shared method or shared member
		Return oGeneral.GetFileInfo(di, fileName, extension)
	End Function

	''' <summary>
	''' GetFileInfo
	''' </summary>
	''' <param name="di"></param>
	''' <param name="filename"></param>
	''' <param name="extension"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Private Function GetFileInfo(ByRef di As DirectoryInfo, ByRef filename As String, ByRef extension As String) _
		As FileInfo
		Dim fi As FileInfo = Nothing

		'If di.Exists Then
		'  Dim files As FileInfo() = di.GetFiles()

		'  If files.Length > 0 Then
		'    'If file is already downloaded with a legal name, just keep that file
		'    fi = files(0)
		'  End If
		'End If

		If di.Exists Then
			Dim files As FileInfo() = di.GetFiles()

			For Each file As FileInfo In files
				If file.Name = filename
					fi = file
					Exit For
				End If
			Next
		End If

		If fi Is Nothing Then
			'If no file exists, generate a new file handle with a legal filename
			If di.FullName.Length + filename.Length + extension.Length > MAXFILENAMELENGTH Then
				filename = filename.Substring(0, MAXFILENAMELENGTH - di.FullName.Length - extension.Length)
			End If
			fi = New FileInfo(String.Concat(di.FullName, Path.DirectorySeparatorChar, filename, extension))
		End If

		Return fi
	End Function

	''' <summary>
	''' Accept only numbers for input
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	''' <remarks></remarks>
	Shared Sub tb_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
		If e.KeyChar = ChrW(Keys.Back) Then
			'Do nothing to allow for backspace to be pressed
		ElseIf Not Char.IsDigit(e.KeyChar) Then
			'Only number keys will be accepted as input
			e.Handled = True
		End If
	End Sub


	''' <summary>
	''' Returns whether the given file extension is accepted as a picture extension
	''' </summary>
	''' <param name="Extension"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Shared Function IsPicture(ByRef Extension As String) As Boolean
		Dim _IsPicture As Boolean
		Select Case Extension.ToLower()
			Case ".bmp", ".gif", ".jpg", ".jpeg", ".png"
				_IsPicture = True
			Case Else
				_IsPicture = False
		End Select
		Return _IsPicture
	End Function

	''' <summary>
	''' Get associated icon from a file
	''' </summary>
	''' <param name="FilePath"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Shared Function GetFileIcon(ByRef FilePath As String) As Image
		Return Icon.ExtractAssociatedIcon(FilePath).ToBitmap
	End Function

	''' <summary>
	''' Create thumbnail image
	''' </summary>
	''' <returns></returns>
	''' <remarks></remarks>
	Shared Function CreateThumbnail(ByRef ImageToConvert As Image) As Thumbnail
		Const MAXTHUMBNAILHEIGHT As Byte = 48
		Const MAXTHUMBNAILWIDTH As Byte = 48

		Dim oGeneral As New General()
		'Shared functions cannot refer to an instance member of a class from within a shared method or shared member
		Dim _Height As Integer
		Dim _Width As Integer
		Dim _DateTaken As Nullable(Of Date)

		_Height = Integer.Parse(ImageToConvert.PhysicalDimension.Height.ToString())
		_Width = Integer.Parse(ImageToConvert.PhysicalDimension.Width.ToString())
		Try
			_DateTaken = Date.ParseExact(oGeneral.GetString(ImageToConvert.GetPropertyItem(&H9003).Value),
			                             "yyyy\:MM\:dd HH\:mm\:ss", Nothing)
		Catch ex As Exception
			_DateTaken = Nothing
		End Try

		'Calculate the correct size of the thumbnail if the size exceeds the sizes specified above
		Dim intHeight As Integer = Integer.Parse(ImageToConvert.PhysicalDimension.Height.ToString())
		Dim intWidth As Integer = Integer.Parse(ImageToConvert.PhysicalDimension.Width.ToString())
		If intHeight > MAXTHUMBNAILHEIGHT Or intWidth > MAXTHUMBNAILWIDTH Then
			If intHeight > intWidth Then
				intHeight =
					Integer.Parse(
						Math.Round(ImageToConvert.PhysicalDimension.Height/(ImageToConvert.PhysicalDimension.Height/MAXTHUMBNAILHEIGHT)).
					             	ToString())
				intWidth =
					Integer.Parse(
						Math.Round(ImageToConvert.PhysicalDimension.Width/(ImageToConvert.PhysicalDimension.Height/MAXTHUMBNAILHEIGHT)).
					             	ToString())
			Else
				intHeight =
					Integer.Parse(
						Math.Round(ImageToConvert.PhysicalDimension.Height/(ImageToConvert.PhysicalDimension.Width/MAXTHUMBNAILWIDTH)).
					             	ToString())
				intWidth =
					Integer.Parse(
						Math.Round(ImageToConvert.PhysicalDimension.Width/(ImageToConvert.PhysicalDimension.Width/MAXTHUMBNAILWIDTH)).
					             	ToString())
			End If
		End If

		Return _
			New Thumbnail(ImageToConvert.GetThumbnailImage(intWidth, intHeight, AddressOf oGeneral.ThumbNailAbort, Nothing),
			              _DateTaken, _Height, _Width)
	End Function

	''' <summary>
	''' Clean up EXIF string
	''' </summary>
	''' <param name="B"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Private Function GetString(ByRef B As Byte()) As String
		Dim R As String = Encoding.UTF8.GetString(B)
		If R.EndsWith(ControlChars.NullChar) Then R = R.Substring(0, R.Length - 1)
		Return R
	End Function

	''' <summary>
	''' Dummy delegate for creating a thumbnail
	''' </summary>
	''' <returns></returns>
	''' <remarks></remarks>
	Private Function ThumbNailAbort() As Boolean
		Return False
	End Function

	''' <summary>
	''' Check file extension against windows to ensure validity
	''' </summary>
	''' <param name="FileName"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Shared Function IsFileExtensionUnknown(ByRef FileName As String) As Boolean
		Dim objResultBuffer As StringBuilder = New StringBuilder(1024)
		Dim lngResult As Long = FindExecutableA(FileName, String.Empty, objResultBuffer)
		Return lngResult < 32 Or objResultBuffer.Length = 0
	End Function
End Class
