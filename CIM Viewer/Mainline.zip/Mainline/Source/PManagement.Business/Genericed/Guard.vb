Namespace Genericed
	''' <summary>
	''' Generic Guard
	''' </summary>
	''' <typeparam name="T"></typeparam>
	''' <remarks>Implements "Scoped Locking" design pattern</remarks>
		Public NotInheritable Class Guard (Of T As {New})
		Implements IDisposable

#Region "Variables"

		Private _Monitor_Lock As T
		'Lockable object
		Private _Owner As Boolean = False
		'Do I have the lock?

#End Region

#Region "Methods"

		''' <summary>
		''' New
		''' </summary>
		''' <param name="Monitor_Lock">Object to lock onto</param>
		''' <remarks>Locks onto supplied object using Monitor</remarks>
		Public Sub New(ByRef Monitor_Lock As T)
			_Monitor_Lock = Monitor_Lock
			Monitor.Enter(_Monitor_Lock)
			_Owner = True
		End Sub

		''' <summary>
		''' Wait for signal
		''' </summary>
		''' <remarks></remarks>
		Public Sub Wait()
			If _Owner Then Monitor.Wait(_Monitor_Lock)
		End Sub

		''' <summary>
		''' Signal waiting threads for changes
		''' </summary>
		''' <remarks></remarks>
		Public Sub Pulse()
			If _Owner Then Monitor.Pulse(_Monitor_Lock)
		End Sub

#End Region

#Region " IDisposable Support "

		Private disposedValue As Boolean = False
		' To detect redundant calls

		' IDisposable
		Private Sub Dispose(ByVal disposing As Boolean)
			If Not disposedValue Then
				If disposing Then
					If _Owner Then
						Monitor.Exit(_Monitor_Lock)
						_Owner = False
					End If
					_Monitor_Lock = Nothing
				End If
			End If
			disposedValue = True
		End Sub

		' This code added by Visual Basic to correctly implement the disposable pattern.
		Public Sub Dispose() Implements IDisposable.Dispose
			' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
			Dispose(True)
			GC.SuppressFinalize(Me)
		End Sub

#End Region
	End Class
End Namespace
