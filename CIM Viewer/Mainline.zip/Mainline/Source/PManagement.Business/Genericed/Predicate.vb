﻿Imports PManagement.DataLayer.Interfaces

Namespace Genericed
	''' <summary>
	''' Predicate
	''' </summary>
	''' <typeparam name="T"></typeparam>
	''' <remarks></remarks>
		Public NotInheritable Class Predicate (Of T As IBaseObject)

		''' <summary>
		''' Hide New method
		''' </summary>
		''' <remarks></remarks>
		Private Sub New()
		End Sub

		''' <summary>
		''' IsNew
		''' </summary>
		''' <remarks></remarks>
		Public Shared IsNew As System.Predicate(Of T) = Function(bo) bo.IsNew

		''' <summary>
		''' Deleted
		''' </summary>
		''' <remarks></remarks>
		Public Shared Deleted As System.Predicate(Of T) = Function(bo) bo.Deleted

		''' <summary>
		''' Not Deleted
		''' </summary>
		''' <remarks></remarks>
		Public Shared NotDeleted As System.Predicate(Of T) = Function(bo) Not bo.Deleted

		''' <summary>
		''' IsDirty
		''' </summary>
		''' <remarks></remarks>
		Public Shared IsDirty As System.Predicate(Of T) = Function(bo) bo.IsDirty
	End Class
End Namespace
