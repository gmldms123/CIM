Namespace Genericed
	''' <summary>
	''' Generic Singleton
	''' </summary>
	''' <typeparam name="T"></typeparam>
	''' <remarks>Read this article to get explanation: http://msdn2.microsoft.com/en-us/library/ms954629.aspx </remarks>
		Public NotInheritable Class Singleton (Of T As {New})
		Public Shared ReadOnly Instance As T = New T()

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Private Sub New()
		End Sub
	End Class
End Namespace
