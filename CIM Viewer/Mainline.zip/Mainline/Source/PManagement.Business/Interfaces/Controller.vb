Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults

Namespace Interfaces
	Public Interface Controller
		ReadOnly Property Initialized() As Boolean
		ReadOnly Property IsDirty() As Boolean

		Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext, ByRef accescontrol As AccessControl,
		               ByVal model As Model)

		Sub Clear()

		Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		              Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary

		Sub Dispose()
	End Interface
End Namespace
