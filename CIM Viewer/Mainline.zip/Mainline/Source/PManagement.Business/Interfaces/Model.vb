Namespace Interfaces
	Public Interface Model
		Event DataChanged()
		ReadOnly Property Initialized() As Boolean
		ReadOnly Property IsDirty() As Boolean
		Sub OnDataChanged()
		Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext)
		Sub Clear()
		Sub Dispose()
	End Interface
End Namespace
