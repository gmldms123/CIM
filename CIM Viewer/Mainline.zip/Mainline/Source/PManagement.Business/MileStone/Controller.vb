Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace Milestone
	''' <summary>
	''' Manage all interaction with case facts data model from viewers
	''' </summary>
	''' <remarks></remarks> 
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model
		Private _changeLogService As IChangeLogService


#Region "Overrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Milestones
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Milestones() As List(Of Milestone)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Dim ec As New EntityCollection(Of MilestoneEntity)(New MilestoneEntityFactory())
					Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
					filter.PredicateExpression.AddWithAnd(MilestoneFields.CaseId = _Context.CaseId)
					Dim prefetchPath As New PrefetchPath2(DirectCast(EntityType.MilestoneEntity, Integer))
					prefetchPath.Add(MilestoneEntity.PrefetchPathResponsiblePersonParticipant)
					Try
						daa.FetchEntityCollection(ec, filter, prefetchPath)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.Milestones
			End Get
		End Property

		''' <summary>
		''' May Add
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAdd() As Boolean
			Get
				Return _Context.CaseId.HasValue AndAlso
				       Not _Context.MSProjectIntegration AndAlso
				       _AccessControl.OperationIsLegal(Permissions.Editor_Milestones_Add)
			End Get
		End Property

		''' <summary>
		''' May Edit
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayEdit() As Boolean
			Get
				Return _Context.CaseId.HasValue AndAlso
				       Not _Context.MSProjectIntegration AndAlso
				       _AccessControl.OperationIsLegal(Permissions.Editor_Milestones_Edit)
			End Get
		End Property

		''' <summary>
		''' May Remove
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemove() As Boolean
			Get
				Return _Context.CaseId.HasValue AndAlso
				       Not _Context.MSProjectIntegration AndAlso
				       _AccessControl.OperationIsLegal(Permissions.Editor_Milestones_Remove)
			End Get
		End Property

#End Region

#Region "Methods"

		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As Milestone)
			If _Model.Exists(item) Then
				If item.IsNew Then
					_Model.Remove(item)
				Else
					_Model.Delete(item)
				End If
			End If
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Dim ecDelete As New EntityCollection(Of MilestoneEntity)(New MilestoneEntityFactory())
			For Each item As Milestone In _Model.DeletedMilestones
				ecDelete.Add(New MilestoneEntity(item.Id))
			Next

			Dim ecSave As New EntityCollection(Of MilestoneEntity)(New MilestoneEntityFactory())
			For Each item As Milestone In _Model.NewMilestones
				Dim ec As New MilestoneEntity()
				ec.CaseId = _Context.CaseId.Value
				ec.MilestoneId = item.Id
				ec.Description = item.Description
				ec.FinishDate = item.Done
				ec.DeadlineDate = item.Deadline
				ec.ResponsiblePersonId = item.Responsible.Id
				ecSave.Add(ec)
			Next

			Dim ecUpdated As New EntityCollection(Of MilestoneEntity)(New MilestoneEntityFactory())
			For Each item As Milestone In _Model.UpdatedMilestones
				Dim ec As New MilestoneEntity()
				ec.CaseId = _Context.CaseId.Value
				ec.MilestoneId = item.Id
				ec.Description = item.Description
				ec.FinishDate = item.Done
				ec.DeadlineDate = item.Deadline
				ec.ResponsiblePersonId = item.Responsible.Id
				ecUpdated.Add(ec)
			Next


			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					'Delete
					daa.StartTransaction(IsolationLevel.Serializable, "MilestoneSaveTransaction")
					daa.DeleteEntityCollection(ecDelete)
					If ecDelete.Count > 0 Then
						Dim vsDeleted As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
						                                                                       _Context.UserParticipant.ParticipantId,
						                                                                       ChangeTypeEnum.AnyChanges, String.Empty,
						                                                                       String.Empty,
						                                                                       [Enum].Format(GetType(AnyChangesEnum),
						                                                                                     AnyChangesEnum.Milestones,
						                                                                                     "d").ToString)
						If (vsDeleted.GetErrors.Count > 0) Then
							Throw New Exception(vsDeleted.ToString())
						End If
					End If
					'New
					daa.SaveEntityCollection(ecSave, True, False)
					If ecSave.Count > 0 Then
						Dim vsNew As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
						                                                                   _Context.UserParticipant.ParticipantId,
						                                                                   ChangeTypeEnum.AnyChanges, String.Empty,
						                                                                   String.Empty,
						                                                                   [Enum].Format(GetType(AnyChangesEnum),
						                                                                                 AnyChangesEnum.Milestones, "d").
						                                                                  	ToString)
						If (vsNew.GetErrors.Count > 0) Then
							Throw New Exception(vsNew.ToString())
						End If
					End If
					'Update
					For Each ec As MilestoneEntity In ecUpdated
						Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
						filter.PredicateExpression.AddWithAnd(MilestoneFields.MilestoneId = ec.MilestoneId)
						daa.UpdateEntitiesDirectly(ec, filter)
					Next
					If ecUpdated.Count > 0 Then
						Dim vsUpdated As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
						                                                                       _Context.UserParticipant.ParticipantId,
						                                                                       ChangeTypeEnum.AnyChanges, String.Empty,
						                                                                       String.Empty,
						                                                                       [Enum].Format(GetType(AnyChangesEnum),
						                                                                                     AnyChangesEnum.Milestones,
						                                                                                     "d").ToString)
						If (vsUpdated.GetErrors.Count > 0) Then
							Throw New Exception(vsUpdated.ToString())
						End If
					End If
					daa.Commit()

					'Clear og reload
					Clear()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()
				End Try
			End Using
			Return New ValidationSummary()
		End Function

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As Milestone)
			_Model.Add(item)
		End Sub

		''' <summary>
		''' Edit
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Edit(ByVal item As Milestone)
			_Model.Edit(item)
		End Sub

#End Region
	End Class
End Namespace
