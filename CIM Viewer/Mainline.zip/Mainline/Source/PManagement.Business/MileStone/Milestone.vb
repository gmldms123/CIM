Imports PManagement.Business.BaseClasses

Namespace Milestone
	Public NotInheritable Class Milestone
		Inherits BaseObject

		Private ReadOnly _Uid As Long = _Counter
		Private Shared _Counter As Long = 0
		Private ReadOnly _CaseId As Long
		Private _Description As String = String.Empty
		Private _Deadline As Date
		Private _Done As Nullable(Of Date)
		Private _Responsible As Participant.Participant
		Private _Updated As Boolean = False

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New()
			_Counter = _Counter - 1
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As MilestoneEntity)
			Me.New()
			_Id = entity.MilestoneId
			_CaseId = entity.CaseId
			_Description = entity.Description
			_Deadline = entity.DeadlineDate
			_Done = entity.FinishDate

			If entity.ResponsiblePersonParticipant IsNot Nothing Then
				_Responsible = New Participant.Participant(entity.ResponsiblePersonParticipant, Nothing)
			End If
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As Milestone)
			Me.New()
			_Id = entity.Id
			_CaseId = entity.CaseId
			_Description = entity.Description
			_Deadline = entity.Deadline
			_Done = entity.Done
			_Responsible = entity.Responsible
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property UniqueId() As Long
			Get
				Return _Uid
			End Get
		End Property

		''' <summary>
		''' CaseId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property CaseId() As Long
			Get
				Return _CaseId
			End Get
		End Property

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Description() As String
			Get
				Return _Description
			End Get
			Set(ByVal value As String)
				_Description = value
			End Set
		End Property

		''' <summary>
		''' Cleans the Description for VbCrLf's.
		''' </summary>
		''' <value></value>
		''' <returns>The carriage- and linefeed-free description.</returns>
		''' <remarks></remarks>
		Public ReadOnly Property CarriageFreeDescription() As String
			Get
				Try
					Return Description.Replace(vbCrLf, " ")
				Catch ex As NullReferenceException
					Return Description
				End Try
			End Get
		End Property

		''' <summary>
		''' Deadline
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Deadline() As Date
			Get
				Return _Deadline
			End Get
			Set(ByVal value As Date)
				_Deadline = value
			End Set
		End Property

		''' <summary>
		''' Done
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Done() As Nullable(Of Date)
			Get
				Return _Done
			End Get
			Set(ByVal value As Nullable(Of Date))
				_Done = value
			End Set
		End Property

		''' <summary>
		''' Responsible
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Responsible() As Participant.Participant
			Get
				Return _Responsible
			End Get
			Set(ByVal value As Participant.Participant)
				_Responsible = value
			End Set
		End Property

		''' <summary>
		''' Updated
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Updated() As Boolean
			Get
				Return _Updated
			End Get
			Set(ByVal value As Boolean)
				_Updated = value
			End Set
		End Property
	End Class
End Namespace
