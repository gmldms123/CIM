Imports PManagement.Business.Genericed

Namespace Milestone
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Private ReadOnly _lItem As New List(Of Milestone)
		Private _itemToFind As Milestone
		Private _searchEntityCollection As EntityCollection(Of MilestoneEntity)

#Region "Overrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _lItem.Find(Predicate (Of Milestone).IsDirty) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_lItem.Clear()
			OnDataChanged()
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Reason Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Milestones() As List(Of Milestone)
			Get
				Return _lItem.FindAll(New System.Predicate(Of Milestone)(AddressOf FindItem))
			End Get
		End Property

		''' <summary>
		''' Deleted Milestones
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedMilestones() As List(Of Milestone)
			Get
				Return _lItem.FindAll(Predicate (Of Milestone).Deleted)
			End Get
		End Property

		''' <summary>
		''' New Milestones
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NewMilestones() As List(Of Milestone)
			Get
				Return _lItem.FindAll(Predicate (Of Milestone).IsNew)
			End Get
		End Property

		''' <summary>
		''' Updated Milestones
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property UpdatedMilestones() As List(Of Milestone)
			Get
				Return _lItem.FindAll(New System.Predicate(Of Milestone)(AddressOf FindUpdatedItem))
			End Get
		End Property

		''' <summary>
		''' Exists
		''' </summary>
		''' <param name="item"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Exists(ByVal item As Milestone) As Boolean
			Get
				_itemToFind = item
				Return _lItem.Find(New System.Predicate(Of Milestone)(AddressOf FindItemById)) IsNot Nothing
			End Get
		End Property

#End Region

#Region "Methods"

		''' <summary>
		''' Inject
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of MilestoneEntity))
			Dim dataChanged As Boolean = False

			For i As Integer = 0 To ec.Count - 1
				'_idToFind = ec(i).MilestoneId
				_itemToFind = New Milestone(ec(i))
				Dim item As Milestone = _lItem.Find(New System.Predicate(Of Milestone)(AddressOf FindItemById))
				If item Is Nothing Then
					'Add
					item = New Milestone(ec(i))
					_lItem.Insert(i, item)
					dataChanged = True
				Else
					'Update
					If Not _lItem.IndexOf(item).Equals(i) Then
						'Change sort order
						_lItem.Remove(item)
						_lItem.Insert(i, item)
						dataChanged = True
					End If
					If item.IsNew Then
						dataChanged = True
					End If
				End If
			Next

			'Remove deleted
			_searchEntityCollection = ec
			dataChanged = dataChanged Or _lItem.RemoveAll(New System.Predicate(Of Milestone)(AddressOf FindItemToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Delete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As Milestone)
			If Exists(item) Then
				_itemToFind = item
				item = _lItem.Find(New System.Predicate(Of Milestone)(AddressOf FindItemById))
				If Not item.Deleted Then
					item.Deleted = True
					OnDataChanged()
				End If
			End If
		End Sub

		''' <summary>
		''' Undelete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Undelete(ByVal item As Milestone)
			If Exists(item) Then
				_itemToFind = item
				item = _lItem.Find(New System.Predicate(Of Milestone)(AddressOf FindItemById))
				If item.Deleted Then
					item.Deleted = False
					OnDataChanged()
				End If
			End If
		End Sub

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As Milestone)
			_lItem.Add(item)
			OnDataChanged()
		End Sub

		''' <summary>
		''' Edit
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Edit(ByVal item As Milestone)
			If Exists(item) Then
				Dim m As Milestone
				m = item
				m.Updated = True
				OnDataChanged()
			End If
		End Sub


		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Remove(ByVal item As Milestone)
			If Exists(item) Then
				_itemToFind = item
				_lItem.Remove(_lItem.Find(New System.Predicate(Of Milestone)(AddressOf FindItemById)))
				OnDataChanged()
			End If
		End Sub

#End Region

#Region "Find predicates"

		''' <summary>
		''' Find Item
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItem(ByVal item As Milestone) As Boolean
			Return Not item.Deleted
		End Function

		''' <summary>
		''' Find Item By Id
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemById(ByVal item As Milestone) As Boolean
			If item.Id = - 1 Then
				Return item.UniqueId.Equals(_itemToFind.UniqueId)
			End If
			Return item.Id.Equals(_itemToFind.Id)
		End Function

		''' <summary>
		''' Find Item To Remove
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemToRemove(ByVal item As Milestone) As Boolean
			Return _searchEntityCollection.FindMatches(MilestoneFields.MilestoneId = item.Id).Count = 0 And Not item.IsNew
		End Function

		''' <summary>
		''' Find Updated Item
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindUpdatedItem(ByVal item As Milestone) As Boolean
			Return item.Updated
		End Function

#End Region
	End Class
End Namespace
