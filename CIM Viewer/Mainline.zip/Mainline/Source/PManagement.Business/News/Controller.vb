Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace News
	''' <summary>
	''' Manage all interaction with data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model
		Private _changeLogService As IChangeLogService

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()

			MyBase.Initialize(environment, context, accesscontrol, model)
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' Save object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			'Dummy implementation
			Return New ValidationSummary()
		End Function

		''' <summary>
		''' News
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property News() As List(Of News)
			Get
				Dim ec As New EntityCollection(Of NewsEntity)(New NewsEntityFactory())
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Dim fb As New RelationPredicateBucket()
					fb.PredicateExpression.Add(NewsFields.CaseId = _Context.CaseId)
					Dim pp As New PrefetchPath2(DirectCast(EntityType.NewsEntity, Integer))
					pp.Add(NewsEntity.PrefetchPathCreatedByParticipant)
					pp.Add(NewsEntity.PrefetchPathModifiedByParticipant)
					Try
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.News
			End Get
		End Property

		''' <summary>
		''' May Create
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayCreate() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_News_Create)
			End Get
		End Property

		''' <summary>
		''' May Edit
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayEdit(ByVal item As News) As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_News_Edit) Or
				       _Context.User.Substring(_Context.User.IndexOf("\"c) + 1).Equals(item.CreatedBy.VestasInitials)
			End Get
		End Property

		''' <summary>
		''' Adds the specified news.
		''' </summary>
		''' <param name="news">The news.</param>
		Public Sub Add(ByVal news As News)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					'Save News
					Dim ec As New EntityCollection(Of NewsEntity)(New NewsEntityFactory())
					Dim entity As NewsEntity = ec.AddNew()
					entity.CaseId = _Context.CaseId.Value
					entity.Name = news.Name
					entity.Description = news.Description
					entity.CreatedByParticipant = _Context.UserParticipant
					daa.StartTransaction(IsolationLevel.Serializable, "NewsTransaction")
					Dim EntitySaved As Boolean = daa.SaveEntity(entity, True, False)

					Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                _Context.UserParticipant.ParticipantId,
					                                                                ChangeTypeEnum.AnyChanges, String.Empty,
					                                                                String.Empty,
					                                                                [Enum].Format(GetType(AnyChangesEnum),
					                                                                              AnyChangesEnum.News, "d").ToString)
					Dim vs2 As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                 _Context.UserParticipant.ParticipantId,
					                                                                 ChangeTypeEnum.NewsAdded, String.Empty,
					                                                                 String.Empty, String.Empty)

					If vs.GetErrors.Count > 0 AndAlso vs2.GetErrors.Count > 0 Then
						Throw New ApplicationException(vs.ToString)
					Else
						daa.Commit()
					End If

					If EntitySaved Then
						_Model.Inject(ec)
						'Save AlertParticipants (Not in transction because of call to _Model.Inject(). Causes a deadlock)
						Dim ecNews2Particicpants As New EntityCollection(Of News2ParticipantEntity)(New News2ParticipantEntityFactory())
						For Each participant As Participant.Participant In news.AlertParticipants
							Dim news2ParticicpantEntity As News2ParticipantEntity = ecNews2Particicpants.AddNew()
							news2ParticicpantEntity.NewsId = entity.NewsId
							news2ParticicpantEntity.ParticipantId = participant.Id
							If Not daa.SaveEntity(news2ParticicpantEntity, True, False) Then
								Throw New ApplicationException("A database operation failed. Please try again.")
							End If
						Next
					End If
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()
				End Try
			End Using
		End Sub

		''' <summary>
		''' Edit News
		''' </summary>
		''' <param name="Subject"></param>
		''' <param name="Message"></param>
		''' <remarks></remarks>
		Public Sub Edit(ByVal item As News, ByVal Subject As String, ByVal Message As String)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					Dim ec As New EntityCollection(Of NewsEntity)(New NewsEntityFactory())
					Dim entity As NewsEntity = ec.AddNew()
					entity.NewsId = item.Id
					Dim pp As New PrefetchPath2(DirectCast(EntityType.NewsEntity, Integer))
					pp.Add(NewsEntity.PrefetchPathCreatedByParticipant)
					pp.Add(NewsEntity.PrefetchPathModifiedByParticipant)
					daa.FetchEntity(entity, pp)
					If String.Compare(entity.Name, Subject) <> 0 Then entity.Name = Subject
					If String.Compare(entity.Description, Message) <> 0 Then entity.Description = Message
					If entity.IsDirty Then
						entity.Modified = Date.UtcNow
						entity.ModifiedByParticipant = _Context.UserParticipant
					End If
					daa.StartTransaction(IsolationLevel.Serializable, "NewsTransaction")
					Dim EntitySaved As Boolean = daa.SaveEntity(entity, True, False)
					Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                _Context.UserParticipant.ParticipantId,
					                                                                ChangeTypeEnum.AnyChanges, String.Empty,
					                                                                String.Empty,
					                                                                [Enum].Format(GetType(AnyChangesEnum),
					                                                                              AnyChangesEnum.News, "d").ToString)
					Dim vs2 As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                 _Context.UserParticipant.ParticipantId,
					                                                                 ChangeTypeEnum.NewsAdded, String.Empty,
					                                                                 String.Empty, String.Empty)

					If vs.GetErrors.Count > 0 AndAlso vs2.GetErrors.Count > 0 Then
						Throw New ApplicationException(vs.ToString)
					End If
					daa.Commit()
					If EntitySaved Then
						_Model.Update(item, entity)
					End If
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()
				End Try
			End Using
		End Sub
	End Class
End Namespace
