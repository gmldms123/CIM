Namespace News
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Private ReadOnly _lItems As New List(Of News)
		Private _idToFind As Long
		Private _searchEntityCollection As EntityCollection(Of NewsEntity)

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return False
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_lItems.Clear()
			OnDataChanged()
		End Sub

		''' <summary>
		''' News
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property News() As List(Of News)
			Get
				Return _lItems
			End Get
		End Property

		''' <summary>
		''' Inject
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of NewsEntity))
			Dim dataChanged As Boolean = False

			'Add/Update
			For i As Integer = 0 To ec.Count - 1
				_idToFind = ec(i).NewsId
				Dim item As News = _lItems.Find(New Predicate(Of News)(AddressOf FindItemById))
				If item Is Nothing Then
					'Add
					_lItems.Add(New News(ec(i)))
					dataChanged = True
				Else
					'Update
					If Not _lItems.IndexOf(item).Equals(i) Then
						'Change sort order of threads
						_lItems.Remove(item)
						_lItems.Insert(i, item)
						dataChanged = True
					End If
					dataChanged = dataChanged Or item.Update(ec(i))
				End If
			Next

			'Remove
			_searchEntityCollection = ec
			dataChanged = dataChanged Or _lItems.RemoveAll(New Predicate(Of News)(AddressOf FindItemToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="item"></param>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub Update(ByVal item As News, ByVal entity As NewsEntity)
			If item.Update(entity) Then OnDataChanged()
		End Sub

		''' <summary>
		''' Find Item By Id
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemById(ByVal item As News) As Boolean
			Return item.Id.Equals(_idToFind)
		End Function

		''' <summary>
		''' Find Item To Remove
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemToRemove(ByVal item As News) As Boolean
			Return _searchEntityCollection.FindMatches(NewsFields.NewsId = item.Id).Count = 0
		End Function
	End Class
End Namespace
