Imports PManagement.DataLayer.Interfaces

Namespace News
	''' <summary>
	''' News
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class News
		Private ReadOnly _Id As Long = - 1
		Private ReadOnly _CaseId As Long
		Private _Name As String = String.Empty
		Private _Description As String = String.Empty
		Private ReadOnly _Created As Date = Date.UtcNow
		Private ReadOnly _CreatedBy As ParticipantEntity = Nothing
		Private _Modified As Nullable(Of Date) = Nothing
		Private _ModifiedBy As ParticipantEntity = Nothing
		Private _AlertParticipants As List(Of IParticipant)

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New(ByVal name As String, ByVal description As String, ByVal alertParticipants As List(Of IParticipant))
			_Name = name
			_Description = description
			_AlertParticipants = alertParticipants
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As NewsEntity)
			_Id = entity.NewsId
			_CaseId = entity.CaseId
			_Name = entity.Name
			_Description = entity.Description
			_Created = entity.Created
			_CreatedBy = entity.CreatedByParticipant
			_Modified = entity.Modified
			_ModifiedBy = entity.ModifiedByParticipant
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As NewsEntity) As Boolean
			Dim updated As Boolean = False
			If String.Compare(_Name, entity.Name) <> 0 Then
				_Name = entity.Name
				updated = True
			End If
			If String.Compare(_Description, entity.Description) <> 0 Then
				_Description = entity.Description
				updated = True
			End If
			If Not entity.Modified.Equals(Modified) Then
				_Modified = entity.Modified
				updated = True
			End If
			If entity.ModifiedByParticipant IsNot Nothing Then
				If _
					_ModifiedBy Is Nothing OrElse
					(_ModifiedBy IsNot Nothing AndAlso Not entity.ModifiedByParticipant.Equals(_ModifiedBy)) Then
					_ModifiedBy = entity.ModifiedByParticipant
					updated = True
				End If
			Else
				If _ModifiedBy IsNot Nothing Then
					_ModifiedBy = Nothing
					updated = True
				End If
			End If
			Return updated
		End Function

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Gets the case id.
		''' </summary>
		''' <value>The case id.</value>
		Public ReadOnly Property CaseId() As Long
			Get
				Return _CaseId
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Description() As String
			Get
				Return _Description
			End Get
		End Property

		''' <summary>
		''' Gets the alert participants.
		''' </summary>
		''' <value>The alert participants.</value>
		Public Property AlertParticipants() As List(Of IParticipant)
			Get
				Return _AlertParticipants
			End Get
			Set(ByVal value As List(Of IParticipant))
				_AlertParticipants = value
			End Set
		End Property

		''' <summary>
		''' Created
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Created() As Date
			Get
				Return _Created
			End Get
		End Property

		''' <summary>
		''' Created By
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property CreatedBy() As ParticipantEntity
			Get
				Return _CreatedBy
			End Get
		End Property

		''' <summary>
		''' Modified
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Modified() As Nullable(Of Date)
			Get
				Return _Modified
			End Get
		End Property

		''' <summary>
		''' Modified By Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ModifiedBy() As ParticipantEntity
			Get
				Return _ModifiedBy
			End Get
		End Property
	End Class
End Namespace
