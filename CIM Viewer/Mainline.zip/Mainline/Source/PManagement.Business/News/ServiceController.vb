Imports PManagement.DataLayer.Interfaces

Namespace News
	Public Class ServiceController
		Private ReadOnly _Environment As Environment

		Public Sub New(ByRef environment As Environment)
			_Environment = environment
		End Sub

		''' <summary>
		''' Alerts on the news.
		''' </summary>
		''' <returns></returns>
		Public Function AlertOnNews() As List(Of News)
			Dim newsList As List(Of News) = New List(Of News)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Dim ec As New EntityCollection(Of NewsEntity)(New NewsEntityFactory())
				Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
				fb.Relations.Add(NewsEntity.Relations.News2ParticipantEntityUsingNewsId, JoinHint.Right)
				fb.PredicateExpression.Add(News2ParticipantFields.SendOn = DBNull.Value)

				Dim pp As New PrefetchPath2(DirectCast(EntityType.NewsEntity, Integer))
				pp.Add(NewsEntity.PrefetchPathNews2Participant, 0,
				       New PredicateExpression(News2ParticipantFields.SendOn = DBNull.Value))

				Try
					daa.FetchEntityCollection(ec, fb, pp)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try

				If ec.Count = 0 Then
					Return Nothing
				Else
					Dim oNews As News
					For Each nEntity As NewsEntity In ec
						oNews = New News(nEntity)
						oNews.AlertParticipants = AlertParticipants(oNews.Id)
						newsList.Add(oNews)
					Next
				End If
			End Using
			Return newsList
		End Function

		''' <summary>
		''' Alerts to these participants on the news.
		''' </summary>
		''' <param name="NewsID">The news ID.</param>
		''' <returns></returns>
		Private Function AlertParticipants(ByVal NewsID As Long) As List(Of IParticipant)
			Dim participantList As List(Of IParticipant) = New List(Of IParticipant)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Dim ec As New EntityCollection(Of ParticipantEntity)(New ParticipantEntityFactory())
				Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
				fb.Relations.Add(ParticipantEntity.Relations.News2ParticipantEntityUsingParticipantId, JoinHint.Right)
				fb.PredicateExpression.Add(News2ParticipantFields.NewsId = NewsID)
				Dim pp As New PrefetchPath2(DirectCast(EntityType.ParticipantEntity, Integer))
				pp.Add(ParticipantEntity.PrefetchPathNews2Participant, 0,
				       New PredicateExpression(News2ParticipantFields.NewsId = NewsID))
				Try
					daa.FetchEntityCollection(ec, fb, pp)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try
				If ec.Count = 0 Then
					Return Nothing
				Else
					For Each pEntity As ParticipantEntity In ec
						participantList.Add(New Participant.Participant(pEntity))
					Next
				End If
			End Using
			Return participantList
		End Function

		''' <summary>
		''' Participants is alerted on news.
		''' </summary>
		''' <param name="NewsID">The news ID.</param>
		Public Sub ParticipantsIsAlertedOnNews(ByVal NewsID As Long)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					daa.StartTransaction(IsolationLevel.Serializable, "News2ParticipantSaveTransaction")

					'Update SendOn on NewsID
					Dim ec As New News2ParticipantEntity()
					ec.SendOn = Date.Now()

					Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
					filter.PredicateExpression.AddWithAnd(News2ParticipantFields.NewsId = NewsID)
					daa.UpdateEntitiesDirectly(ec, filter)

					daa.Commit()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try
			End Using
		End Sub

		''' <summary>
		''' Gets the case no.
		''' </summary>
		''' <value>The case no.</value>
		Public ReadOnly Property CaseNo(ByVal CaseId As Long) As Long
			Get
				Dim tempNo As Long
				Try
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Dim entity As New CaseEntity(CaseId)
						daa.FetchEntity(entity)
						daa.CloseConnection()
						tempNo = entity.CaseNo
					End Using
				Catch
				End Try
				Return tempNo
			End Get
		End Property
	End Class
End Namespace

