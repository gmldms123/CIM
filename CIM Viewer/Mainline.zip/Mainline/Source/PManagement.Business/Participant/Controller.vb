Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace Participant
	Public Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model
		Private _changeLogService As IChangeLogService


#Region "Overrrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' ParticipantTypes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ParticipantTypes() As List(Of ParticipantType)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Dim ec As New EntityCollection(Of ParticipationTypeEntity)(New ParticipationTypeEntityFactory())
					Try
						daa.FetchEntityCollection(ec, Nothing)
						_Model.LoadParticipantTypes(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.ParticipantTypes
			End Get
		End Property

		''' <summary>
		''' May Add Participant to Project Group
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddParticipantToProjectGroup() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Participants_AddToProject)
			End Get
		End Property

		''' <summary>
		''' May Remove Participant from Project Group
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveParticipantFromProjectGroup() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Participants_RemoveFromProject)
			End Get
		End Property

		''' <summary>
		''' May Add Participant to Review Group
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddParticipantToReviewGroup() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Participants_AddToReview)
			End Get
		End Property

		''' <summary>
		''' May Remove Participant from Review Group
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveParticipantFromReviewGroup() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Participants_RemoveFromReview)
			End Get
		End Property

		''' <summary>
		''' May Add Participant to Know-How Group
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddParticipantToKnowHowGroup() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Participants_AddToKnowHow)
			End Get
		End Property

		''' <summary>
		''' May Remove Participant from Know-How Group
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveParticipantFromKnowHowGroup() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_Participants_RemoveFromKnowHow)
			End Get
		End Property

#End Region

#Region "Public methods"

		''' <summary>
		''' Participants by Case and ParticipantType
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Participants(ByVal type As ParticipantType) As List(Of Participant)
			If type IsNot Nothing Then
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Dim ec As New EntityCollection(Of ParticipantEntity)(New ParticipantEntityFactory())
					Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
					fb.Relations.Add(ParticipantEntity.Relations.Case2ParticipantEntityUsingParticipantId, JoinHint.Right)
					fb.PredicateExpression.Add(
						Case2ParticipantFields.CaseId = _Context.CaseId And Case2ParticipantFields.ParticipationTypeId = type.Id)
					Dim pp As New PrefetchPath2(DirectCast(EntityType.ParticipantEntity, Integer))
					pp.Add(ParticipantEntity.PrefetchPathCase2Participant, 0,
					       New PredicateExpression(
					       	Case2ParticipantFields.CaseId = _Context.CaseId And Case2ParticipantFields.ParticipationTypeId = type.Id))
					Try
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.InjectParticipants(ec, type)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
			End If
			Return _Model.Participants(type)
		End Function

		''' <summary>
		''' Participants by Name and Initials
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function FindParticipants(ByVal name As String, ByVal initials As String, ByVal maxNoItems As String) _
			As List(Of Participant)
			Dim list As List(Of Participant) = New List(Of Participant)

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				daa.CommandTimeOut = 120
				Dim ec As New EntityCollection(Of ParticipantEntity)(New ParticipantEntityFactory())

				'Only related cases of the chosen case
				Dim filterBucket As IRelationPredicateBucket = New RelationPredicateBucket()
				filterBucket.PredicateExpression.Add(ParticipantFields.Deleted = DBNull.Value)
				If name.Length > 0 Then
					filterBucket.PredicateExpression.AddWithAnd(ParticipantFields.FormattedName Mod String.Format("%{0}%", name))
				End If
				If initials.Length > 0 Then
					filterBucket.PredicateExpression.AddWithAnd(ParticipantFields.VestasInitials Mod String.Format("{0}%", initials))
				End If

				' MaximumNumberOfItems
				Dim maximumNumberOfItems As Integer = 0
				' 0 is All
				Integer.TryParse(maxNoItems, maximumNumberOfItems)

				Try
					'Fetch case
					daa.FetchEntityCollection(ec, filterBucket, maximumNumberOfItems)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try
				For i As Integer = 0 To ec.Count - 1
					list.Add(New Participant(ec(i), _Model.GetTypeByParticipantEntity(ec(i))))
				Next
				If initials.Length > 0 Then
					list.Sort(Function(p1 As Participant, p2 As Participant) p1.Initials.CompareTo(p2.Initials))
				End If
			End Using
			Return list
		End Function

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As Participant)
			_Model.Add(item)
		End Sub

		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As Participant)
			If _Model.Exists(item) Then
				If item.IsNew Then
					_Model.Remove(item)
				Else
					_Model.Delete(item)
				End If
			End If
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Dim ecDelete As New EntityCollection(Of Case2ParticipantEntity)(New Case2ParticipantEntityFactory())
			For Each item As Participant In _Model.DeletedParticipants
				ecDelete.Add(New Case2ParticipantEntity(item.RelationId))
			Next

			Dim ecSave As New EntityCollection(Of Case2ParticipantEntity)(New Case2ParticipantEntityFactory())
			For Each item As Participant In _Model.NewParticipants
				Dim ec As New Case2ParticipantEntity()
				ec.CaseId = _Context.CaseId.Value
				ec.ParticipantId = item.Id
				ec.ParticipationTypeId = item.Type.Id
				ecSave.Add(ec)
			Next

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					daa.StartTransaction(IsolationLevel.Serializable, "ParticipantSaveTransaction")
					daa.DeleteEntityCollection(ecDelete)
					daa.SaveEntityCollection(ecSave, True, False)
					Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                _Context.UserParticipant.ParticipantId,
					                                                                ChangeTypeEnum.AnyChanges, String.Empty,
					                                                                String.Empty,
					                                                                [Enum].Format(GetType(AnyChangesEnum),
					                                                                              AnyChangesEnum.Participants, "d").
					                                                               	ToString)
					If (vs.GetErrors.Count > 0) Then
						Throw New Exception(vs.ToString())
					End If
					daa.Commit()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()

					Dim deletedParticipants(_Model.DeletedParticipants.Count - 1) As Participant
					_Model.DeletedParticipants.CopyTo(deletedParticipants)
					For Each item As Participant In deletedParticipants
						_Model.Remove(item)
					Next

					Dim newParticipants(_Model.NewParticipants.Count - 1) As Participant
					_Model.NewParticipants.CopyTo(newParticipants)
					For Each item As Participant In newParticipants
						_Model.UpdateRelation(item,
						                      ecSave(
						                      	ecSave.FindMatches(
						                      		Case2ParticipantFields.CaseId = _Context.CaseId And
						                      		Case2ParticipantFields.ParticipantId = item.Id)(0)).Case2ParticipantId)
					Next
				End Try
			End Using
			Return New ValidationSummary()
		End Function

#End Region
	End Class
End Namespace
