Imports PManagement.Business.Genericed

Namespace Participant
	Public Class Model
		Inherits BaseClasses.Model

#Region "Variables"

		Private ReadOnly _lItem As New List(Of Participant)
		Private ReadOnly _lItemTypes As New List(Of ParticipantType)
		Private _idToFind As Long
		Private _ParticipantTypeToFind As ParticipantType = New ParticipantType()
		Private _searchEntityCollection As EntityCollection(Of ParticipantEntity)

#End Region

#Region "Overrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _lItem.Find(Predicate (Of Participant).IsDirty) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_lItem.Clear()
			OnDataChanged()
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Participants
		''' </summary>
		''' <param name="type">The type.</param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Participants(ByVal type As ParticipantType) As List(Of Participant)
			_ParticipantTypeToFind = type
			Return _lItem.FindAll(New System.Predicate(Of Participant)(AddressOf FindItemByParticipantType))
		End Function

		''' <summary>
		''' ParticipantTypes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ParticipantTypes() As List(Of ParticipantType)
			Get
				Return _lItemTypes
			End Get
		End Property

		''' <summary>
		''' Exists
		''' </summary>
		''' <param name="item"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Exists(ByVal item As Participant) As Boolean
			Get
				_idToFind = item.Id
				_ParticipantTypeToFind = item.Type
				Return _lItem.Find(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType)) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Deleted Participants
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedParticipants() As List(Of Participant)
			Get
				Return _lItem.FindAll(Predicate (Of Participant).Deleted)
			End Get
		End Property

		''' <summary>
		''' New Participants
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NewParticipants() As List(Of Participant)
			Get
				Return _lItem.FindAll(Predicate (Of Participant).IsNew)
			End Get
		End Property

#End Region

#Region "Methods"

		''' <summary>
		''' Inject Participant
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub InjectParticipants(ByVal ec As EntityCollection(Of ParticipantEntity), ByVal type As ParticipantType)
			Dim dataChanged As Boolean = False
			For i As Integer = 0 To ec.Count - 1

				'Find Participant
				_idToFind = ec(i).ParticipantId
				_ParticipantTypeToFind = type
				Dim item As Participant = _lItem.Find(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType))
				'Check if item is deleted before adding the item to _lItem (due to DropDown Postback)
				Dim isDeleted As Boolean =
				    	DeletedParticipants.Exists(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType))

				If item Is Nothing And Not isDeleted Then
					'Add
					item = New Participant(ec(i), type)
					_lItem.Insert(i, item)
					dataChanged = True
				ElseIf Not isDeleted Then
					'Update
					If Not _lItem.IndexOf(item).Equals(i) Then
						'Change sort order
						_lItem.Remove(item)
						_lItem.Insert(i, item)
						dataChanged = True
					End If
					If item.IsNew And ec(i).Case2Participant.Count = 1 Then
						'If saved by another user, the item is not new anymore
						item.RelationId = ec(i).Case2Participant(0).Case2ParticipantId
						dataChanged = True
					End If
				End If
			Next

			_searchEntityCollection = ec
			_ParticipantTypeToFind = type
			dataChanged = dataChanged Or _lItem.RemoveAll(New System.Predicate(Of Participant)(AddressOf FindItemToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Inject Participant
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub LoadParticipantTypes(ByVal ec As EntityCollection(Of ParticipationTypeEntity))
			'ParticipantType is loaded one time only. No check if item exists in list etc.., and therefore no OnDataChanged()
			If (_lItemTypes.Count = 0) Then
				For i As Integer = 0 To ec.Count - 1
					_lItemTypes.Insert(i, New ParticipantType(ec(i)))
				Next
			End If
		End Sub

		Public Function GetTypeByParticipantEntity(ByVal ec As ParticipantEntity) As ParticipantType
			'Find ParticipantType
			Dim type As ParticipantType = Nothing
			If ec.Case2Participant.Count = 1 Then
				_idToFind = ec.Case2Participant(0).ParticipationTypeId
				type = (_lItemTypes.Find(New System.Predicate(Of ParticipantType)(AddressOf FindItemById)))
			End If
			Return type
		End Function

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As Participant)
			If Exists(item) Then
				_idToFind = item.Id
				_ParticipantTypeToFind = item.Type
				Undelete(_lItem.Find(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType)))
			Else
				_lItem.Add(item)
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Undelete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Undelete(ByVal item As Participant)
			If Exists(item) Then
				_idToFind = item.Id
				_ParticipantTypeToFind = item.Type
				item = _lItem.Find(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType))
				If item.Deleted Then
					item.Deleted = False
					OnDataChanged()
				End If
			End If
		End Sub

		''' <summary>
		''' Delete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As Participant)
			If Exists(item) Then
				_idToFind = item.Id
				_ParticipantTypeToFind = item.Type
				item = _lItem.Find(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType))
				If Not item.Deleted Then
					item.Deleted = True
					OnDataChanged()
				End If
			End If
		End Sub

		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Remove(ByVal item As Participant)
			If Exists(item) Then
				_idToFind = item.Id
				_ParticipantTypeToFind = item.Type
				_lItem.Remove(_lItem.Find(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType)))
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Update Relation Id
		''' </summary>
		''' <param name="item"></param>
		''' <param name="RelationId"></param>
		''' <remarks></remarks>
		Public Sub UpdateRelation(ByVal item As Participant, ByVal RelationId As Long)
			If Exists(item) Then
				_idToFind = item.Id
				_ParticipantTypeToFind = item.Type
				item = _lItem.Find(New System.Predicate(Of Participant)(AddressOf FindItemByIdAndParticipantType))
				item.RelationId = RelationId
				OnDataChanged()
			End If
		End Sub

#End Region

#Region "Find Predicates"

		''' <summary>
		''' Find Item not deleted and with specific ParticipantType
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemByParticipantType(ByVal item As Participant) As Boolean
			Return Not item.Deleted And item.Type.Id.Equals(_ParticipantTypeToFind.Id)
		End Function

		''' <summary>
		''' Find Item By Id (also Deleted)
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemByIdAndParticipantType(ByVal item As Participant) As Boolean
			Return item.Id.Equals(_idToFind) And item.Type.Id.Equals(_ParticipantTypeToFind.Id)
		End Function

		''' <summary>
		''' Find Item By Id
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemById(ByVal item As ParticipantType) As Boolean
			Return item.Id.Equals(_idToFind)
		End Function

		''' <summary>
		''' Find Item To Remove
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemToRemove(ByVal item As Participant) As Boolean
			Dim notExists As Boolean = True
			'If there is no data in the type but the typeid doesn't match - don't remove participant
			If _searchEntityCollection.Count = 0 And Not _ParticipantTypeToFind.Id = item.Type.Id Then
				notExists = False
			End If
			'If type doesn't match or id and type match - don't remove participant 
			For Each ec As ParticipantEntity In _searchEntityCollection
				If Not _ParticipantTypeToFind.Id = item.Type.Id Or
				   ec.ParticipantId.Equals(item.Id) And _ParticipantTypeToFind.Id = item.Type.Id Then
					notExists = False
				End If
			Next
			'Also if item is new - don't remove participant
			Return notExists And Not item.IsNew
		End Function

#End Region
	End Class
End Namespace
