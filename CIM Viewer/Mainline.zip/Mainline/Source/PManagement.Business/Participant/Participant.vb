Imports PManagement.DataLayer.Interfaces
Imports PManagement.Business.BaseClasses

Namespace Participant
	Public NotInheritable Class Participant
		Inherits BaseObject
		Implements IParticipant

		Private ReadOnly _myId As Long
		Private ReadOnly _Vpid As Long
		Private ReadOnly _Initials As String = String.Empty
		Private ReadOnly _LoginInitials As String = String.Empty
		Private ReadOnly _Name As String = String.Empty
		Private ReadOnly _Phone As String = String.Empty
		Private ReadOnly _EMail As String = String.Empty
		Private ReadOnly _Title As String = String.Empty
		Private ReadOnly _Type As ParticipantType = Nothing
		Private ReadOnly _Department As String = String.Empty
		Private ReadOnly _BusinessUnit As String = String.Empty
		Private ReadOnly _BusinessUnitShortName As String = String.Empty

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As ParticipantEntity)
			_myId = entity.ParticipantId
			_Vpid = entity.VppersonId
			_Initials = entity.VestasInitials
			_LoginInitials = entity.LoginInitials
			_Name = entity.FormattedName
			_Phone = entity.Phone
			_EMail = entity.Email
			_Department = entity.Department
			_BusinessUnit = entity.BusinessUnit
			_BusinessUnitShortName = entity.BusinessUnitShortName
			_Title = entity.Title

			If entity.Case2Participant.Count = 1 Then
				_Id = entity.Case2Participant(0).Case2ParticipantId
			End If
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As ParticipantEntity, ByVal typeEntity As ParticipantType)
			_myId = entity.ParticipantId
			_Vpid = entity.VppersonId
			_Initials = entity.VestasInitials
			_LoginInitials = entity.LoginInitials
			_Name = entity.FormattedName
			_Phone = entity.Phone
			_EMail = entity.Email
			_Type = typeEntity
			_Department = entity.Department
			_BusinessUnit = entity.BusinessUnit
			_BusinessUnitShortName = entity.BusinessUnitShortName
			_Title = entity.Title

			If entity.Case2Participant.Count = 1 Then
				_Id = entity.Case2Participant(0).Case2ParticipantId
			End If
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As Participant)
			_myId = entity.Id
			_Vpid = entity.VPId
			_Id = entity.RelationId
			_Initials = entity.Initials
			_LoginInitials = entity.LoginInitials
			_Name = entity.Name
			_Phone = entity.Phone
			_EMail = entity.EMail
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As Participant, ByVal typeEntity As ParticipantType)
			_myId = entity.Id
			_Vpid = entity.VPId
			_Id = entity.RelationId
			_Initials = entity.Initials
			_LoginInitials = entity.LoginInitials
			_Name = entity.Name
			_Phone = entity.Phone
			_EMail = entity.Email
			_Type = typeEntity
			_Department = entity.Department
			_BusinessUnit = entity.BusinessUnit
			_BusinessUnitShortName = entity.BusinessUnitShortName
			_Title = entity.Title
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long Implements IParticipant.Id
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' VP Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property VPId() As Long Implements IParticipant.VPId
			Get
				Return _Vpid
			End Get
		End Property

		''' <summary>
		''' Initials
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Initials() As String Implements IParticipant.Initials
			Get
				Return _Initials
			End Get
		End Property

		''' <summary>
		''' Login Initials
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property LoginInitials() As String
			Get
				Return _LoginInitials
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String Implements IParticipant.Name
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Phone
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Phone() As String Implements IParticipant.Phone
			Get
				Return _Phone
			End Get
		End Property

		''' <summary>
		''' EMail
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property EMail() As String Implements IParticipant.EMail
			Get
				Return _EMail
			End Get
		End Property

		''' <summary>
		''' TypeName
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Type() As ParticipantType
			Get
				Return _Type
			End Get
		End Property

		''' <summary>
		''' Relation Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property RelationId() As Long
			Get
				Return _Id
			End Get
			Set(ByVal value As Long)
				_Id = value
			End Set
		End Property

		''' <summary>
		''' Department
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Department() As String
			Get
				Return _Department
			End Get
		End Property

		''' <summary>
		''' BusinessUnit
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property BusinessUnit() As String
			Get
				Return _BusinessUnit
			End Get
		End Property

		''' <summary>
		''' Shortname for BU
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property BusinessUnitShortName() As String
			Get
				Return _BusinessUnitShortName
			End Get
		End Property

		''' <summary>
		''' Title/Position
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Title() As String
			Get
				Return _Title
			End Get
		End Property
	End Class
End Namespace
