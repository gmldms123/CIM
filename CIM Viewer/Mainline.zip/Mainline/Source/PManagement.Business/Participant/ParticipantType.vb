

Namespace Participant
	Public NotInheritable Class ParticipantType
		Private ReadOnly _Id As Long
		Private ReadOnly _Name As String = String.Empty

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New()
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As ParticipationTypeEntity)
			_Id = entity.ParticipationTypeId
			_Name = entity.Name
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property
	End Class
End Namespace
