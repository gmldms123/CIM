Imports PManagement.Framework
Imports PManagement.Business.Caching

''' <summary>
''' Manage PmanContext used for running the application
''' </summary>
''' <remarks></remarks>
	Public NotInheritable Class PmanContext
	Private _Environment As Environment

	Private _Initialized As Boolean
	Private _Traceable As Boolean = True

	Private _BrandId As Nullable(Of Long) = 1
	Private _BrandInformationOutdated As Boolean = True
	Private _BrandName As String = String.Empty
	Private _InitialPortfolioId As Nullable(Of Long)
	Private _BrandPortalURL As String = String.Empty
	Private _BrandMasterMinorText As String = String.Empty

	Private ReadOnly _Features As New ArrayList()
	Private _FeaturesOutdated As Boolean = True

	Private _MSProjectIntegration As Boolean
	Private _MSProjectIntegrationOutdated As Boolean = True

	Private _CaseId As Nullable(Of Long)
	Private _CaseNo As Nullable(Of Long)
	Private _BusinessProcessId As Nullable(Of Long)
	Private _CaseNoOutdated As Boolean = True

	Private _IsCaseClosed As Nullable(Of Boolean)
	Private _IsCaseManager As Nullable(Of Boolean)
	Private _IsExecutionManager As Nullable(Of Boolean)
	Private _IsProjectParticipant As Nullable(Of Boolean)

    Private _User As String = String.Empty
    'Private _User As String = "vestas\pakbh"
	Private _UserParticipant As ParticipantEntity
	Private _UserParticipantOutdated As Boolean = True

	Private _CreatingNewCase As Boolean

	Private Shared _Cache As ICache = Nothing
	Private Shared ReadOnly _CacheSyncLock As Object = New Object()
	Private _LatestRepairedCaseId As Long?
	Private _latestDeclinedRepairCaseId As Nullable(Of Long)

	Public Event ContextChanged()

	''' <summary>
	''' Is instance initialized using Sub Initialize
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property Initialized() As Boolean
		Get
			Return _Initialized
		End Get
	End Property

	''' <summary>
	''' Current environment
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property Environment() As Environment
		Get
			Return _Environment
		End Get
	End Property

	Public ReadOnly Property Cache() As ICache
		Get
			Dim cacheReference As ICache
			SyncLock _CacheSyncLock
				cacheReference = _Cache
			End SyncLock
			Return cacheReference
		End Get
	End Property

	''' <summary>
	''' Finalize
	''' </summary>
	''' <remarks></remarks>
	Protected Overrides Sub Finalize()
		If Initialized Then
			RemoveHandler _Environment.EnvironmentChanged, AddressOf EnvironmentChanged
			_Environment = Nothing
		End If

		MyBase.Finalize()
	End Sub

	''' <summary>
	''' Initialize
	''' </summary>
	''' <param name="env"></param>
	''' <remarks></remarks>
	Public Sub Initialize(ByRef env As Environment)
		If Traceable Then PmanTrace.WriteInfo("PmanContext", "Initialize")

		_Environment = env
		AddHandler _Environment.EnvironmentChanged, AddressOf EnvironmentChanged

		InitializeCache()

		_Initialized = True
	End Sub

	Private Sub InitializeCache()
		SyncLock _CacheSyncLock
			Dim createNew As Boolean = False
			If _Cache Is Nothing Then
				createNew = True
			ElseIf _Environment.Platform <> _Cache.TargetPlatform Then
				createNew = True
			End If

			If createNew Then
				If _Environment.Platform = Environment.Platforms.Web Then
					_Cache = New WebCache()
				Else
					_Cache = New WinCache()
				End If
			End If
		End SyncLock
	End Sub

	''' <summary>
	''' OnEnvironmentChanged
	''' </summary>
	''' <remarks></remarks>
	Private Sub EnvironmentChanged()
		If Traceable Then PmanTrace.WriteInfo("PmanContext", "EnvironmentChanged")

		'_BrandId = Nothing
		'_BrandName = String.Empty
		'_InitialPortfolioId = Nothing
		_BrandInformationOutdated = True

		Reset()

		_CaseNoOutdated = True
		_UserParticipant = Nothing
		_UserParticipantOutdated = True

		InitializeCache()

		OnContextChanged()
	End Sub

	''' <summary>
	''' Raise event ContextChanged
	''' </summary>
	''' <remarks></remarks>
	Private Sub OnContextChanged()
		If Traceable Then PmanTrace.WriteInfo("PmanContext", "OnContextChanged")

		RaiseEvent ContextChanged()
	End Sub

	''' <summary>
	''' Does this instance write trace messages
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property Traceable() As Boolean
		Get
			Return _Traceable
		End Get
		Set(ByVal value As Boolean)
			If value Then PmanTrace.WriteInfo("PmanContext", "Traceable (Set)")

			If _Traceable <> value Then
				If value Then _
					PmanTrace.WriteVerbose("PmanContext", "Traceable (Set)", String.Format("Changing Traceable to ""{0}""", value))

				_Traceable = value
			End If
		End Set
	End Property

	''' <summary>
	''' Get/Set brand id
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property BrandId() As Nullable(Of Long)
		Get
			Return _BrandId
		End Get
		Set(ByVal value As Nullable(Of Long))
			If Traceable Then PmanTrace.WriteInfo("PmanContext", "BrandId (Set)")

			If Not _BrandId.Equals(value) Then
				If Traceable Then _
					PmanTrace.WriteVerbose("PmanContext", "BrandId (Set)", String.Format("Changing Brand Id to ""{0}""", value))

				_BrandId = value
				_BrandInformationOutdated = True
				_FeaturesOutdated = True
				_MSProjectIntegrationOutdated = True
				OnContextChanged()
			End If
		End Set
	End Property

	''' <summary>
	''' Get Brand Information
	''' </summary>
	''' <remarks></remarks>
	Private Sub GetBrandInformation()
		If _Environment IsNot Nothing Then
			If _BrandId.HasValue Then
				If _BrandInformationOutdated Then
					_BrandName = "CIM"
					' TODO: which!? (was: 79)
					_InitialPortfolioId = 1
					' TODO
					_BrandPortalURL = "http://teamsitesemea.vestas.net/sites/43008/default.aspx?PageView=Shared"
					_BrandMasterMinorText = String.Empty
					_BrandInformationOutdated = False
				End If
			Else
				_BrandName = String.Empty
				_InitialPortfolioId = Nothing
				_BrandInformationOutdated = True
			End If
		Else
			Throw New ArgumentException("Environment not set")
		End If
	End Sub

	''' <summary>
	''' Get brand name
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property BrandName() As String
		Get
			GetBrandInformation()
			Return _BrandName
		End Get
	End Property

	''' <summary>
	''' Get Initial Portfolio Id
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property InitialPortfolioId() As Nullable(Of Long)
		Get
			GetBrandInformation()
			Return _InitialPortfolioId
		End Get
	End Property

	''' <summary>
	''' Get brand portal url
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property BrandPortalURL() As String
		Get
			GetBrandInformation()
			Return _BrandPortalURL
		End Get
	End Property

	''' <summary>
	''' Get brand master minor text
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property BrandMasterMinorText() As String
		Get
			GetBrandInformation()
			Return _BrandMasterMinorText
		End Get
	End Property

	''' <summary>
	''' Features
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property Features() As ArrayList
		Get
			If _Environment IsNot Nothing Then
				If _BrandId.HasValue Then
					If _FeaturesOutdated Then
						Try
							Dim ec As New EntityCollection(Of FeatureEntity)(New FeatureEntityFactory())
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim filter As New RelationPredicateBucket(Brand2FeatureFields.BrandId = BrandId)
								filter.Relations.Add(FeatureEntity.Relations.Brand2FeatureEntityUsingFeatureId)
								daa.FetchEntityCollection(ec, filter)
								daa.CloseConnection()
							End Using

							_Features.Clear()
							For i As Integer = 0 To ec.Count - 1
								_Features.Add(ec(i).Description)
							Next
							_FeaturesOutdated = False
						Catch ex As ORMQueryExecutionException
							Throw New ArgumentException("A database operation failed. Please try again.", ex)
						End Try
					End If
				Else
					Throw New ArgumentException("BrandId not set")
				End If
			Else
				Throw New ArgumentException("Environment not set")
			End If
			Return _Features
		End Get
	End Property

	''' <summary>
	''' Get MS Project Integration
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property MSProjectIntegration() As Boolean
		Get
			If _Environment IsNot Nothing Then
				If _BrandId.HasValue Then
					If _MSProjectIntegrationOutdated Then
						Try
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim ec As New EntityCollection(Of Brand2FeatureEntity)(New Brand2FeatureEntityFactory())
								Dim fb As New RelationPredicateBucket()
								fb.PredicateExpression.Add(Brand2FeatureFields.BrandId = _BrandId.Value)
								fb.Relations.Add(Brand2FeatureEntity.Relations.FeatureEntityUsingFeatureId)
								fb.PredicateExpression.Add(FeatureFields.Description = "Microsoft Project Integration")
								daa.FetchEntityCollection(ec, fb)

								If ec.Count = 1 Then
									_MSProjectIntegration = True
									_MSProjectIntegrationOutdated = False
								Else
									_MSProjectIntegration = False
								End If
							End Using
						Catch
						End Try
					End If
				Else
					_MSProjectIntegration = False
				End If
			Else
				Throw New ApplicationException("Environment not set")
			End If
			Return _MSProjectIntegration
		End Get
	End Property

	Public Property LatestRepairedCaseId() As Nullable(Of Long)
		Get
			Return _LatestRepairedCaseId
		End Get
		Set(ByVal value As Nullable(Of Long))
			_LatestRepairedCaseId = value
		End Set
	End Property

	''' <summary>
	''' Get/Set case id
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property CaseId() As Nullable(Of Long)
		Get
			Return _CaseId
		End Get
		Set(ByVal value As Nullable(Of Long))
			If Traceable Then PmanTrace.WriteInfo("PmanContext", "CaseId (Set)")

			If Not value.HasValue Or value.HasValue And BrandId.HasValue Then
				_CaseNoOutdated = True

				If Not _CaseId.Equals(value) Then
					If Traceable Then _
						PmanTrace.WriteVerbose("PmanContext", "CaseId (Set)", String.Format("Changing Case Id to ""{0}""", value))

					Reset()
					_CaseId = value

					_CreatingNewCase = False

					OnContextChanged()
				End If
			Else
				Throw New ApplicationException("BrandId not initialized")
			End If
		End Set
	End Property

	''' <summary>
	''' Get case number
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property CaseNo() As Nullable(Of Long)
		Get
			If _Environment IsNot Nothing Then
				If _CaseId.HasValue Then
					If _CaseNoOutdated Then
						Try
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim entity As New CaseEntity(_CaseId.Value)
								daa.FetchEntity(entity)
								daa.CloseConnection()
								If Not entity.IsNew Then
									_CaseNo = entity.CaseNo
									_CaseNoOutdated = False
								Else
									_CaseNo = Nothing
								End If
							End Using
						Catch
							_CaseNo = Nothing
						End Try
					End If
				Else
					_CaseNo = Nothing
				End If
			Else
				Throw New ApplicationException("Environment not set")
			End If
			Return _CaseNo
		End Get
	End Property

	Public ReadOnly Property BusinessProcessId() As Nullable(Of Long)
		Get
			If _Environment IsNot Nothing Then
				If _CaseId.HasValue Then
					Try
						Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
							Dim entity As New CaseEntity(_CaseId.Value)
							daa.FetchEntity(entity)
							daa.CloseConnection()
							If Not entity.IsNew Then
								_BusinessProcessId = entity.BusinessProcessId
							Else
								_BusinessProcessId = Nothing
							End If
						End Using
					Catch
						_BusinessProcessId = Nothing
					End Try
				Else
					_BusinessProcessId = Nothing
				End If
			Else
				Throw New ApplicationException("Environment not set")
			End If
			Return _BusinessProcessId
		End Get
	End Property

	''' <summary>
	''' Is case closed
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property IsCaseClosed() As Nullable(Of Boolean)
		Get
			If _IsCaseClosed.HasValue = False Then
				If _Environment IsNot Nothing Then
					If _CaseId.HasValue Then
						Try
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim entity As New CaseEntity(_CaseId.Value)
								Dim pp As New PrefetchPath2(CInt(EntityType.CaseEntity))
								pp.Add(CaseEntity.PrefetchPathStatus)
								daa.FetchEntity(entity, pp)
								daa.CloseConnection()
								If entity.Fields.State = EntityState.Fetched Then
									_IsCaseClosed = (entity.Status.Name = "Closed" Or entity.Status.Name = "Solved")
									'HACK: CaseFactsStatus name 'Closed' hardcoded
								Else
									_IsCaseClosed = Nothing
									Throw New ArgumentException("Case information not found")
								End If
							End Using
						Catch ex As ORMQueryExecutionException
							Throw New ArgumentException("A database operation failed. Please try again.", ex)
						End Try
					Else
						Return False
					End If
				Else
					Throw New ArgumentException("Environment not set")
				End If
			End If
			Return _IsCaseClosed
		End Get
	End Property

	''' <summary>
	''' Is UserParticipant case manager
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property IsCaseManager() As Nullable(Of Boolean)
		Get
			If _IsCaseManager.HasValue = False Then
				If _Environment IsNot Nothing Then
					If _CaseId.HasValue Then
						Try
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim entity As New CaseEntity(_CaseId.Value)
								Dim prefetchpath As IPrefetchPath2 = New PrefetchPath2(CInt(EntityType.CaseEntity))
								prefetchpath.Add(CaseEntity.PrefetchPathManagerParticipant)
								daa.FetchEntity(entity, prefetchpath)
								daa.CloseConnection()
								If Not entity.IsNew Then
									_IsCaseManager = entity.ManagerParticipant IsNot Nothing AndAlso
									                 entity.ManagerParticipant.VestasInitials.ToLower() = UserParticipant.VestasInitials.ToLower()
								Else
									_IsCaseManager = Nothing
								End If
							End Using
						Catch
							_IsCaseManager = Nothing
						End Try
					Else
						_IsCaseManager = Nothing
					End If
				Else
					Throw New ApplicationException("Environment not set")
				End If
			End If
			Return _IsCaseManager
		End Get
	End Property

	''' <summary>
	''' Is UserParticipant execution manager
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property IsExecutionManager() As Nullable(Of Boolean)
		Get
			If _IsExecutionManager.HasValue = False Then
				If _Environment IsNot Nothing Then
					If _CaseId.HasValue Then
						Try
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim entity As New CaseEntity(_CaseId.Value)
								Dim prefetchpath As IPrefetchPath2 = New PrefetchPath2(CInt(EntityType.CaseEntity))
								prefetchpath.Add(CaseEntity.PrefetchPathExecutionManagerParticipant)
								daa.FetchEntity(entity, prefetchpath)
								daa.CloseConnection()
								If Not entity.IsNew Then
									_IsExecutionManager = entity.ExecutionManagerParticipant IsNot Nothing AndAlso
									                      entity.ExecutionManagerParticipant.VestasInitials.ToLower() =
									                      UserParticipant.VestasInitials.ToLower()
								Else
									_IsExecutionManager = Nothing
								End If
							End Using
						Catch
							_IsExecutionManager = Nothing
						End Try
					Else
						_IsExecutionManager = Nothing
					End If
				Else
					Throw New ApplicationException("Environment not set")
				End If
			End If
			Return _IsExecutionManager
		End Get
	End Property


	''' <summary>
	''' Is UserParticipant the technical specialist
	''' </summary>
	''' <value></value>
	''' <returns>False</returns>
	''' <remarks>This property has been added to provide future extensibility on the permissions setup</remarks>
	Public ReadOnly Property IsTechnicalSpecialist() As Nullable(Of Boolean)
		Get
			Return False
		End Get
	End Property

	''' <summary>
	''' Is UserParticipant the case creator
	''' </summary>
	''' <value></value>
	''' <returns>False</returns>
	''' <remarks>This property has been added to provide future extensibility on the permissions setup</remarks>
	Public ReadOnly Property IsCaseCreator() As Nullable(Of Boolean)
		Get
			Return False
		End Get
	End Property

	''' <summary>
	''' Is UserParticipant the platform manager
	''' </summary>
	''' <value></value>
	''' <returns>False</returns>
	''' <remarks>This property has been added to provide future extensibility on the permissions setup</remarks>
	Public ReadOnly Property IsPlatformManager() As Nullable(Of Boolean)
		Get
			Return False
		End Get
	End Property

	''' <summary>
	''' Is UserParticipant a project participant
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public ReadOnly Property IsProjectParticipant() As Nullable(Of Boolean)
		Get
			If _Environment IsNot Nothing Then
				If _CaseId.HasValue Then
					Try
						Dim ecParticipants As New EntityCollection(Of Case2ParticipantEntity)(New Case2ParticipantEntityFactory())
						Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
							Dim filterBucket As IRelationPredicateBucket = New RelationPredicateBucket()
							filterBucket.PredicateExpression.AddWithAnd(Case2ParticipantFields.CaseId = _CaseId.Value)
							filterBucket.PredicateExpression.AddWithAnd(Case2ParticipantFields.ParticipantId = UserParticipant.ParticipantId)
							daa.FetchEntityCollection(ecParticipants, filterBucket)
							daa.CloseConnection()
							If ecParticipants.Count > 0 Then
								_IsProjectParticipant = True
							Else
								_IsProjectParticipant = False
							End If
						End Using
					Catch
						_IsProjectParticipant = Nothing
					End Try
				Else
					_IsProjectParticipant = Nothing
				End If
			Else
				Throw New ApplicationException("Environment not set")
			End If
			Return _IsProjectParticipant
		End Get
	End Property

	''' <summary>
	''' Current User
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks>User must be supplied in the form "domain\username"</remarks>
	Public Property User() As String
		Get
			Return _User
		End Get
		Set(ByVal value As String)
			If Traceable Then PmanTrace.WriteInfo("PmanContext", "User (Set)")

			If String.Compare(_User, value) <> 0 Then
				If Traceable Then _
					PmanTrace.WriteVerbose("PmanContext", "User (Set)", String.Format("Changing User to ""{0}""", value))

				_User = value
				_UserParticipantOutdated = True

				OnContextChanged()
			End If
		End Set
	End Property

	''' <summary>
	''' Get user
	''' </summary>
	''' <value></value>
	''' <returns>Participant entity</returns>
	''' <remarks></remarks>
	Public ReadOnly Property UserParticipant() As ParticipantEntity
		Get
			If _Environment IsNot Nothing Then
				If _User.Length > 0 Then
					If _UserParticipantOutdated Then
						Try
							Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
								Dim ec As New EntityCollection(Of ParticipantEntity)(New ParticipantEntityFactory())
								Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
                                Dim UserName As String = _User.Substring(_User.IndexOf("\") + 1).ToLower()

                                'UserName = CStr(IIf(UserName.Equals("mabca"), "femta", UserName)) ' workaround for developer
                                UserName = CStr(IIf(UserName.Equals("mabca"), "pakbh", UserName))

								fb.PredicateExpression.Add(
									ParticipantFields.VestasInitials = UserName And ParticipantFields.LoginInitials = String.Empty And
									ParticipantFields.Deleted = DBNull.Value)
								fb.PredicateExpression.AddWithOr(
									ParticipantFields.LoginInitials = UserName And ParticipantFields.Deleted = DBNull.Value)
								daa.FetchEntityCollection(ec, fb)
								daa.CloseConnection()
								Select Case ec.Count
									Case 0
										_UserParticipant = Nothing
										Throw _
											New ApplicationException(
												"A match of the current user name to a corresponding Vestas People name was impossible.")
									Case 1
										_UserParticipant = ec(0)
										_UserParticipantOutdated = False
									Case Else
										_UserParticipant = Nothing
										Throw _
											New ApplicationException(
												"A precise match of your login name to the corresponding Vestas People name was impossible.")
								End Select
							End Using
						Catch ex As Exception
							Throw _
								New ApplicationException(
									"Error while retrieving data from database. Please contact IT Service or 5800. " + ex.ToString())
						End Try
					End If
				Else
					_UserParticipant = Nothing
				End If
			Else
				Throw New ApplicationException("Environment not set")
			End If
			Return _UserParticipant
		End Get
	End Property

	''' <summary>
	''' Creating New Case
	''' </summary>
	''' <value></value>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Property CreatingNewCase() As Boolean
		Get
			Return _CreatingNewCase
		End Get
		Set(ByVal value As Boolean)
			_CreatingNewCase = value
			If value Then
				Reset()
				_CaseNoOutdated = False
				OnContextChanged()
			End If
		End Set
	End Property

	Public Property LatestDeclinedRepairCaseId() As Nullable(Of Long)
		Get
			Return _latestDeclinedRepairCaseId
		End Get
		Set(ByVal value As Nullable(Of Long))
			_latestDeclinedRepairCaseId = value
		End Set
	End Property

	Private Sub Reset()
		_CaseId = Nothing
		_CaseNo = Nothing
		FlushCaseFacts()
	End Sub

	Friend Sub FlushCaseFacts()
		_IsCaseClosed = Nothing
		_IsCaseManager = Nothing
		_IsExecutionManager = Nothing
	End Sub
End Class

