Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults

Namespace ReasonCode
	''' <summary>
	''' Manage all interaction with case facts data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' Reason Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ReasonCodes() As List(Of ReasonCode)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Dim ec As New EntityCollection(Of ReasonCodeEntity)(New ReasonCodeEntityFactory())
					Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
					fb.Relations.Add(ReasonCodeEntity.Relations.Case2ReasonCodeEntityUsingReasonCodeId, JoinHint.Right)
					fb.PredicateExpression.Add(Case2ReasonCodeFields.CaseId = _Context.CaseId)
					Dim pp As New PrefetchPath2(DirectCast(EntityType.ReasonCodeEntity, Integer))
					pp.Add(ReasonCodeEntity.PrefetchPathCase2ReasonCode, 0,
					       New PredicateExpression(Case2ReasonCodeFields.CaseId = _Context.CaseId))
					Try
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.ReasonCodes
			End Get
		End Property

		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As ReasonCode)
			If _Model.Exists(item) Then
				If item.IsNew Then
					_Model.Remove(item)
				Else
					_Model.Delete(item)
				End If
			End If
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Dim ecDelete As New EntityCollection(Of Case2ReasonCodeEntity)(New Case2ReasonCodeEntityFactory())
			For Each item As ReasonCode In _Model.DeletedReasonCodes
				ecDelete.Add(New Case2ReasonCodeEntity(item.RelationId))
			Next

			Dim ecSave As New EntityCollection(Of Case2ReasonCodeEntity)(New Case2ReasonCodeEntityFactory())
			For Each item As ReasonCode In _Model.NewReasonCodes
				Dim ec As New Case2ReasonCodeEntity()
				ec.CaseId = _Context.CaseId.Value
				ec.ReasonCodeId = item.Id
				ecSave.Add(ec)
			Next

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					daa.StartTransaction(IsolationLevel.Serializable, "ReasonCodeSaveTransaction")
					daa.DeleteEntityCollection(ecDelete)
					daa.SaveEntityCollection(ecSave, True, False)
					daa.Commit()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()

					Dim deletedReasonCodes(_Model.DeletedReasonCodes.Count - 1) As ReasonCode
					_Model.DeletedReasonCodes.CopyTo(deletedReasonCodes)
					For Each item As ReasonCode In deletedReasonCodes
						_Model.Remove(item)
					Next

					Dim newReasonCodes(_Model.NewReasonCodes.Count - 1) As ReasonCode
					_Model.NewReasonCodes.CopyTo(newReasonCodes)
					For Each item As ReasonCode In newReasonCodes
						_Model.UpdateRelation(item,
						                      ecSave(
						                      	ecSave.FindMatches(
						                      		Case2ReasonCodeFields.CaseId = _Context.CaseId And
						                      		Case2ReasonCodeFields.ReasonCodeId = item.Id)(0)).Case2ReasonCodeId)
					Next
				End Try
			End Using
			Return New ValidationSummary()
		End Function

		''' <summary>
		''' Find reason codes from input criteria
		''' </summary>
		''' <param name="ReasonCode"></param>
		''' <param name="Name"></param>
		''' <param name="MaximumNumberOfItems"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function FindReasonCodes(ByVal ReasonCode As String, ByVal Name As String,
		                                ByVal MaximumNumberOfItems As Integer) As List(Of ReasonCode)
			Dim liItems As New List(Of ReasonCode)
			Dim ec As New EntityCollection(Of ReasonCodeEntity)(New ReasonCodeEntityFactory())

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				daa.CommandTimeOut = 120
				Dim fb As IRelationPredicateBucket = New RelationPredicateBucket()
				If ReasonCode <> String.Empty Then
					fb.PredicateExpression.AddWithAnd(ReasonCodeFields.ReasonCodeNo Mod String.Format("%{0}%", ReasonCode))
				End If
				If Name <> String.Empty Then
					fb.PredicateExpression.AddWithAnd(ReasonCodeFields.Name Mod String.Format("%{0}%", Name))
				End If
				Dim pp As New PrefetchPath2(DirectCast(EntityType.ReasonCodeEntity, Integer))
				pp.Add(ReasonCodeEntity.PrefetchPathCase2ReasonCode, 0,
				       New PredicateExpression(Case2ReasonCodeFields.CaseId = _Context.CaseId))
				Try
					daa.FetchEntityCollection(ec, fb, MaximumNumberOfItems, Nothing, pp)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try
			End Using

			For i As Integer = 0 To ec.Count - 1
				liItems.Add(New ReasonCode(ec(i)))
			Next

			Return liItems
		End Function

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As ReasonCode)
			_Model.Add(item)
		End Sub
	End Class
End Namespace
