Imports PManagement.Business.Genericed

Namespace ReasonCode
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Private ReadOnly _lItem As New List(Of ReasonCode)
		Private _idToFind As Long
		Private _searchEntityCollection As EntityCollection(Of ReasonCodeEntity)

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _lItem.Find(Predicate (Of ReasonCode).IsDirty) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_lItem.Clear()
			OnDataChanged()
		End Sub

		''' <summary>
		''' Reason Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ReasonCodes() As List(Of ReasonCode)
			Get
				Return _lItem.FindAll(New System.Predicate(Of ReasonCode)(AddressOf FindItem))
			End Get
		End Property

		''' <summary>
		''' Deleted Reason Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedReasonCodes() As List(Of ReasonCode)
			Get
				Return _lItem.FindAll(Predicate (Of ReasonCode).Deleted)
			End Get
		End Property

		''' <summary>
		''' New Reason Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NewReasonCodes() As List(Of ReasonCode)
			Get
				Return _lItem.FindAll(Predicate (Of ReasonCode).IsNew)
			End Get
		End Property

		''' <summary>
		''' Exists
		''' </summary>
		''' <param name="item"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Exists(ByVal item As ReasonCode) As Boolean
			Get
				_idToFind = item.Id
				Return _lItem.Find(New System.Predicate(Of ReasonCode)(AddressOf FindItemById)) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Inject
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of ReasonCodeEntity))
			Dim dataChanged As Boolean = False

			For i As Integer = 0 To ec.Count - 1
				_idToFind = ec(i).ReasonCodeId
				Dim item As ReasonCode = _lItem.Find(New System.Predicate(Of ReasonCode)(AddressOf FindItemById))
				If item Is Nothing Then
					'Add
					item = New ReasonCode(ec(i))
					_lItem.Insert(i, item)
					dataChanged = True
				Else
					'Update
					If Not _lItem.IndexOf(item).Equals(i) Then
						'Change sort order
						_lItem.Remove(item)
						_lItem.Insert(i, item)
						dataChanged = True
					End If
					If item.IsNew And ec(i).Case2ReasonCode.Count = 1 Then
						'If saved by another user, the item is not new anymore
						item.RelationId = ec(i).Case2ReasonCode(0).Case2ReasonCodeId
						dataChanged = True
					End If
				End If
			Next

			'Remove deleted
			_searchEntityCollection = ec
			dataChanged = dataChanged Or _lItem.RemoveAll(New System.Predicate(Of ReasonCode)(AddressOf FindItemToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Delete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Delete(ByVal item As ReasonCode)
			If Exists(item) Then
				_idToFind = item.Id
				item = _lItem.Find(New System.Predicate(Of ReasonCode)(AddressOf FindItemById))
				If Not item.Deleted Then
					item.Deleted = True
					OnDataChanged()
				End If
			End If
		End Sub

		''' <summary>
		''' Undelete
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Undelete(ByVal item As ReasonCode)
			If Exists(item) Then
				_idToFind = item.Id
				item = _lItem.Find(New System.Predicate(Of ReasonCode)(AddressOf FindItemById))
				If item.Deleted Then
					item.Deleted = False
					OnDataChanged()
				End If
			End If
		End Sub

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As ReasonCode)
			If Exists(item) Then
				_idToFind = item.Id
				Undelete(_lItem.Find(New System.Predicate(Of ReasonCode)(AddressOf FindItemById)))
			Else
				_lItem.Add(item)
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Remove
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Remove(ByVal item As ReasonCode)
			If Exists(item) Then
				_idToFind = item.Id
				_lItem.Remove(_lItem.Find(New System.Predicate(Of ReasonCode)(AddressOf FindItemById)))
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Update Relation Id
		''' </summary>
		''' <param name="item"></param>
		''' <param name="RelationId"></param>
		''' <remarks></remarks>
		Public Sub UpdateRelation(ByVal item As ReasonCode, ByVal RelationId As Long)
			If Exists(item) Then
				_idToFind = item.Id
				item = _lItem.Find(New System.Predicate(Of ReasonCode)(AddressOf FindItemById))
				item.RelationId = RelationId
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Find Item
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItem(ByVal item As ReasonCode) As Boolean
			Return Not item.Deleted
		End Function

		''' <summary>
		''' Find Item By Id
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemById(ByVal item As ReasonCode) As Boolean
			Return item.Id.Equals(_idToFind)
		End Function

		''' <summary>
		''' Find Item To Remove
		''' </summary>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemToRemove(ByVal item As ReasonCode) As Boolean
			Return _searchEntityCollection.FindMatches(ReasonCodeFields.ReasonCodeId = item.Id).Count = 0 And Not item.IsNew
		End Function
	End Class
End Namespace
