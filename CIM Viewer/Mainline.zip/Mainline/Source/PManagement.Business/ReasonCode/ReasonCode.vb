Imports PManagement.Business.BaseClasses

Namespace ReasonCode
	Public NotInheritable Class ReasonCode
		Inherits BaseObject
		Private ReadOnly _myId As Long
		Private ReadOnly _ReasonCode As String = String.Empty
		Private ReadOnly _Name As String = String.Empty

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As ReasonCodeEntity)
			_myId = entity.ReasonCodeId
			_ReasonCode = entity.ReasonCodeNo
			_Name = entity.Name
			If entity.Case2ReasonCode.Count = 1 Then
				_Id = entity.Case2ReasonCode(0).Case2ReasonCodeId
			End If
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' Reason Code
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ReasonCode() As String
			Get
				Return _ReasonCode
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Relation Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property RelationId() As Long
			Get
				Return _Id
			End Get
			Set(ByVal value As Long)
				_Id = value
			End Set
		End Property
	End Class
End Namespace
