Imports System.Windows.Forms
Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace RelevantTurbine
	''' <summary>
	''' Manage all interaction with relation data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

#Region "Variables"

		Private _Model As Model
		Private _changeLogService As IChangeLogService

#End Region

#Region "Methods"

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
			MyBase.Initialize(environment, context, accesscontrol, model)
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' Force redraw of screen contents
		''' </summary>
		''' <remarks></remarks>
		Public Sub ForceDataChanged()
			_Model.ForceDataChanged()
		End Sub

		''' <summary>
		''' Set Item Count
		''' </summary>
		''' <param name="o"></param>
		''' <remarks></remarks>
		Public Sub SetItemCount(ByVal o As Object, ByVal itemCount As ItemCount)
			Dim value As Integer = - 1
			If Integer.TryParse(o.ToString(), value) AndAlso value > - 1 Then
				_Model.SetItemCount(value, itemCount)
			Else
				Throw New ArgumentException(String.Format("Expected value between 0 and {0}", Integer.MaxValue))
			End If
		End Sub

		''' <summary>
		''' Set Item Count
		''' </summary>
		''' <param name="o"></param>
		''' <remarks></remarks>
		Public Sub SetItemCount(ByVal o As Object, ByVal itemCounts As List(Of ItemCount))
			Dim value As Integer = - 1
			If Integer.TryParse(o.ToString(), value) AndAlso value > - 1 Then
				_Model.SetItemCount(value, itemCounts)
			Else
				Throw New ArgumentException(String.Format("Expected value between 0 and {0}", Integer.MaxValue))
			End If
		End Sub

		''' <summary>
		''' Add turbine
		''' </summary>
		''' <param name="Turbines"></param>
		''' <remarks></remarks>
		Public Sub AddTurbine(ByRef Turbines As List(Of Turbine))
			_Model.AddTurbine(Turbines)
		End Sub

		''' <summary>
		''' Remove turbine
		''' </summary>
		''' <param name="Turbines"></param>
		''' <remarks></remarks>
		Public Sub RemoveTurbine(ByRef Turbines As List(Of Turbine))
			Dim triedToRemoveFailedTurbine As Boolean
			Dim failedTurbines As List(Of Turbine) = Turbines.FindAll(Turbine.FailedWithDeletedPredicate)
			If failedTurbines.Count > 0 Then
				triedToRemoveFailedTurbine = True
				Turbines.RemoveAll(Turbine.FailedWithDeletedPredicate)
			End If
			_Model.RemoveTurbine(Turbines)
			If triedToRemoveFailedTurbine Then _
				Throw _
					New ApplicationException("You can not remove failed turbines. Use Case Facts window to change Failed Turbines.")
		End Sub

		''' <summary>
		''' Add item
		''' </summary>
		''' <param name="Items"></param>
		''' <remarks></remarks>
		Public Sub AddItem(ByRef Items As List(Of Item), ByRef stage As Stage)
			_Model.AddItem(Items, stage)
		End Sub

		''' <summary>
		''' Remove item
		''' </summary>
		''' <param name="Items"></param>
		''' <param name="stage"></param>
		''' <remarks></remarks>
		Public Sub RemoveItem(ByRef Items As List(Of Item), ByRef stage As Stage)
			Dim triedToRemoveFailedItem As Boolean
			Dim item As Item = Items.Find(Item.FailedPredicate)
			If item IsNot Nothing AndAlso stage.Equals(_Model.Stages(0)) Then
				triedToRemoveFailedItem = True
				Items.Remove(item)
			End If
			_Model.RemoveItem(Items, stage)
			If triedToRemoveFailedItem Then _
				Throw New ApplicationException("You can not remove the failed item. Use Case Facts window to change Failed Item.")
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Dim validationSummary As New ValidationSummary()
			'Persist to database
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					If IsDirty Then
						daa.StartTransaction(IsolationLevel.Serializable, "RelevantTurbineTransaction")
						Save(daa, _Context.CaseId.Value)
						' HACK!!! The only way to find whether it's Relevant turbines or Case Implemented in MK Version is to look at the method name.
						Select Case New StackTrace().GetFrame(1).GetMethod.Name.ToString()
							Case "tsbSave_Click"
								' Relevant turbines
								Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
								                                                                _Context.UserParticipant.ParticipantId,
								                                                                ChangeTypeEnum.AnyChanges, String.Empty,
								                                                                String.Empty,
								                                                                [Enum].Format(GetType(AnyChangesEnum),
								                                                                              AnyChangesEnum.RelevantTurbines,
								                                                                              "d").ToString)
								If (vs.GetErrors.Count > 0) Then
									Throw New Exception(vs.ToString())
								End If
							Case "tsbMKSave_Click"
								' Case Implemented in MK Version
								Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
								                                                                _Context.UserParticipant.ParticipantId,
								                                                                ChangeTypeEnum.AnyChanges, String.Empty,
								                                                                String.Empty,
								                                                                [Enum].Format(GetType(AnyChangesEnum),
								                                                                              AnyChangesEnum.
								                                                                             	CaseImplementedinMKversion, "d").
								                                                               	ToString)
								If (vs.GetErrors.Count > 0) Then
									Throw New Exception(vs.ToString())
								End If
						End Select

						daa.Commit()
						Clear()
					End If
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()
				End Try
			End Using
			Return validationSummary
		End Function

		Public Function GetMethodName() As String
			Dim Trace As New StackTrace()
			MessageBox.Show(Trace.GetFrame(1).GetFileName.ToString())
			MessageBox.Show(Trace.GetFrame(1).GetMethod.Name.ToString())
			MessageBox.Show(Trace.GetFrame(1).GetMethod.Module.Name.ToString())
			Return Trace.GetFrame(1).GetMethod().Name
		End Function

		''' <summary>
		''' Save using delivered data access adapter
		''' </summary>
		''' <param name="daa"></param>
		''' <remarks></remarks>
		Public Overloads Sub Save(ByVal daa As DataAccessAdapter, ByVal caseId As Long)
			'ItemCounts to delete
			If _Model.DeletedItemCounts.Count > 0 Then
				Dim fbC2TUT2C2I As New RelationPredicateBucket()
				For Each itemCount As ItemCount In _Model.DeletedItemCounts
					fbC2TUT2C2I.PredicateExpression.AddWithOr(
						Case2TurbineMatrix2Case2ItemFields.Case2TurbineMatrix2Case2ItemId = itemCount.RelationId)
				Next
				daa.DeleteEntitiesDirectly(GetType(Case2TurbineMatrix2Case2ItemEntity), fbC2TUT2C2I)
			End If

			'Turbines to delete
			If _Model.DeletedTurbines.Count > 0 Then
				Dim fbC2TUT As New RelationPredicateBucket()
				For Each turbine As Turbine In _Model.DeletedTurbines
					fbC2TUT.PredicateExpression.AddWithOr(Case2TurbineMatrixFields.Case2TurbineMatrixId = turbine.RelationId)
				Next
				daa.DeleteEntitiesDirectly(GetType(Case2TurbineMatrixEntity), fbC2TUT)
			End If

			'Items to delete
			If _Model.DeletedItems.Count > 0 Then
				Dim fbC2I As New RelationPredicateBucket()
				For Each item As Item In _Model.DeletedItems
					fbC2I.PredicateExpression.AddWithOr(Case2ItemFields.Case2ItemId = item.RelationId)
				Next
				daa.DeleteEntitiesDirectly(GetType(Case2ItemEntity), fbC2I)
			End If

			'Turbines to save
			Dim ecTurbine As New EntityCollection(Of Case2TurbineMatrixEntity)(New Case2TurbineMatrixEntityFactory())
			If _Model.DirtyTurbines.Count > 0 Then
				For Each turbine As Turbine In _Model.DirtyTurbines
					If Not turbine.Deleted Then
						Dim entity As Case2TurbineMatrixEntity
						If turbine.IsNew Then
							entity = ecTurbine.AddNew()
							entity.CaseId = caseId
							entity.TurbineMatrixId = turbine.Id
						Else
							entity = New Case2TurbineMatrixEntity(turbine.RelationId)
							daa.FetchEntity(entity)
							ecTurbine.Add(entity)
						End If
						entity.InitialFailed = (turbine.Relation = Turbine.Relations.Failed)
						entity.MkversionActual = turbine.MKVersionActual
						entity.MkversionExpected = turbine.MKVersionExpected
					End If
				Next
				If ecTurbine.Count > 0 Then
					daa.SaveEntityCollection(ecTurbine, True, False)
				End If
			End If

			'Items to save
			Dim ecItem As New EntityCollection(Of Case2ItemEntity)(New Case2ItemEntityFactory())
			If _Model.DirtyItems.Count > 0 Then
				For Each item As Item In _Model.DirtyItems
					If Not item.Deleted Then
						Dim entity As Case2ItemEntity
						If item.IsNew Then
							entity = ecItem.AddNew()
							entity.CaseId = caseId
							entity.ItemId = item.Id
						Else
							entity = New Case2ItemEntity(item.RelationId)
							daa.FetchEntity(entity)
							ecItem.Add(entity)
						End If
						entity.Root = item.Root
					End If
				Next
				If ecItem.Count > 0 Then
					daa.SaveEntityCollection(ecItem, True, False)
				End If
			End If

			'ItemCounts to save
			Dim _
				ecItemCount As _
					New EntityCollection(Of Case2TurbineMatrix2Case2ItemEntity)(New Case2TurbineMatrix2Case2ItemEntityFactory())
			If _Model.DirtyItemCounts.Count > 0 Then
				Dim itemCounts As List(Of ItemCount) = _Model.DirtyItemCounts
				For Each itemCount As ItemCount In itemCounts
					If Not itemCount.Deleted Then
						Dim entity As Case2TurbineMatrix2Case2ItemEntity
						If itemCount.IsNew Then
							entity = ecItemCount.AddNew()
							'Turbine
							If itemCount.Turbine.IsNew Then
								'If the turbine is new, it must have been saved above with the rest of the turbines and the primary key can be found there
								Dim indices As List(Of Integer) =
								    	ecTurbine.FindMatches(
								    		New PredicateExpression(Case2TurbineMatrixFields.TurbineMatrixId = itemCount.Turbine.Id))
								entity.Case2TurbineMatrixId = ecTurbine(indices(0)).Case2TurbineMatrixId
							Else
								entity.Case2TurbineMatrixId = itemCount.Turbine.RelationId
							End If

							'Item
							If itemCount.Item.IsNew Then
								'If the item is new, it must have been saved above with the rest of the items and the primary key can be found there
								Dim filter As New PredicateExpression()
								filter.Add(Case2ItemFields.ItemId = itemCount.Item.Id)
								Dim indices As List(Of Integer) = ecItem.FindMatches(filter)
								entity.Case2ItemId = ecItem(indices(0)).Case2ItemId
							Else
								entity.Case2ItemId = itemCount.Item.RelationId
							End If

							'Stage
							entity.StageId = itemCount.Stage.Id
						Else
							entity = New Case2TurbineMatrix2Case2ItemEntity(itemCount.RelationId)
							daa.FetchEntity(entity)
							ecItemCount.Add(entity)
						End If
						entity.Count = itemCount.Count
						entity.InitialFailed = itemCount.InitialFailed
					End If
				Next
				If ecItemCount.Count > 0 Then
					daa.SaveEntityCollection(ecItemCount, False, False)
				End If
			End If

			' clear turbines from system cache
			_Context.Cache.RemoveItem("RelevantTurbines.Turbines." + _Context.CaseId.ToString())
			' clear items from system cache
			_Context.Cache.RemoveItem("RelevantTurbines.Items." + _Context.CaseId.ToString())
		End Sub

		''' <summary>
		''' Gets the itemcounts for all turbines in the given stage, transposed as specified in transposeDefault
		''' </summary>
		''' <param name="stage"></param>
		''' <param name="transposeDefault">True: Turbines are vertical axis. False: Turbines are horizontal axis.</param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function GetDetailData(ByVal stage As Stage, ByVal transposeDefault As Boolean) As DataTable
			Dim dt As New DataTable()
			''load the turbines
			Dim liTurbines As List(Of Turbine) = Turbines
			Dim liItems As List(Of Item) = Items(stage)

			Dim colRowHeaders As New DataColumn("headers", GetType(String))
			dt.Columns.Add(colRowHeaders)
			If Not transposeDefault Then

				For Each turbine As Turbine In liTurbines
					Dim colTurbine As New DataColumn("turbine" & turbine.Id, GetType(String))
					dt.Columns.Add(colTurbine)
				Next
				For Each item As Item In Items(stage)
					Dim rowItem As DataRow = dt.NewRow()

					rowItem("headers") = GetItemHeader(item, stage)
					For k As Integer = 0 To liTurbines.Count - 1
						Dim itemCount As ItemCount = Me.ItemCount(stage, liTurbines(k), item)
						rowItem("turbine" & liTurbines(k).Id) = itemCount.Count.ToString()
					Next
					''turbines
					dt.Rows.Add(rowItem)
				Next
				''items

				For k As Integer = 0 To liTurbines.Count - 1
					Dim turbine As Turbine = liTurbines(k)
					Dim col As DataColumn = dt.Columns("turbine" & turbine.Id)
					col.ColumnName = GetTurbineHeader(turbine)
				Next
				dt.Columns("headers").ColumnName = "Items/Turbines"

			Else

				For Each item As Item In liItems
					Dim colItem As New DataColumn("item" & item.Id, GetType(String))
					dt.Columns.Add(colItem)
				Next
				For Each turbine As Turbine In liTurbines
					Dim rowTurbine As DataRow = dt.NewRow
					rowTurbine("headers") = GetTurbineHeader(turbine)
					For i As Integer = 0 To liItems.Count - 1
						Dim itemCount As ItemCount = Me.ItemCount(stage, turbine, liItems(i))
						rowTurbine("item" & liItems(i).Id) = itemCount.Count.ToString
					Next
					''items
					dt.Rows.Add(rowTurbine)
				Next
				''turbines

				For y As Integer = 0 To liItems.Count - 1
					Dim item As Item = liItems(y)
					Dim col As DataColumn = dt.Columns("item" & item.Id)
					col.ColumnName = GetItemHeader(item, stage)
				Next
				dt.Columns("headers").ColumnName = "Turbines/Items"
			End If

			Return dt
		End Function

		''' <summary>
		''' Constructs an itemheader for web usage.
		''' </summary>
		''' <param name="item"></param>
		''' <param name="stage"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Shared Function GetItemHeader(ByRef item As Item, ByRef stage As Stage) As String
			Dim initheader As String
			If item.InitialFailed Then
				initheader = "Failed"
			Else
				Dim substringlength As Integer = stage.Name.LastIndexOf(" "c)
				If substringlength = - 1 Then substringlength = stage.Name.Length
				initheader = stage.Name.Substring(0, substringlength)
			End If
			Return String.Format("{0} item" & "<br/>" & "{1} ({2})", initheader, item.Number, item.ERPSystem.ToString())
		End Function

		''' <summary>
		''' Constructs a turbine header for web usage.
		''' </summary>
		''' <param name="turbine"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Shared Function GetTurbineHeader(ByVal turbine As Turbine) As String
			Return _
				String.Format("{0} Turbine " & "<br/>" & "{1}<br/>{2}<TurbineMatrixId{3}/>", turbine.Relation.ToString(),
				              turbine.ToString(), turbine.Description, turbine.Id)
		End Function

#End Region

#Region "Properties"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Stage
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Stages() As List(Of Stage)
			Get
				' lazy fetch stages
				If _Model.Stages Is Nothing OrElse _Model.Stages.Count = 0 Then
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Try
							Dim ec As New EntityCollection(Of StageEntity)(New StageEntityFactory())
							daa.FetchEntityCollection(ec, Nothing)
							_Model.Inject(ec)
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using
				End If

				Return _Model.Stages
			End Get
		End Property

		''' <summary>
		''' Stage to find
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property StageToFind() As Stage
			Get
				Return _Model.StageToFind
			End Get
			Set(ByVal value As Stage)
				_Model.StageToFind = value
			End Set
		End Property

		'Private Shared turbineCache As New Dictionary(Of Long?, EntityCollection(Of Case2TurbineMatrixEntity))

		''' <summary>
		''' Turbine
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Turbines() As List(Of Turbine)
			Get
				If Not _Context.CreatingNewCase Then
					'Inject all stages
					If _
						(_Context.CaseId IsNot Nothing) And
						(_Context.Cache.ContainsItem("RelevantTurbines.Turbines." + _Context.CaseId.ToString())) Then
						Dim ec As EntityCollection(Of Case2TurbineMatrixEntity) =
						    	_Context.Cache.GetItem (Of EntityCollection(Of Case2TurbineMatrixEntity))(
						    		"RelevantTurbines.Turbines." + _Context.CaseId.ToString())
						_Model.Inject(ec)
					Else
						Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
							Try
								Dim ec As New EntityCollection(Of Case2TurbineMatrixEntity)(New Case2TurbineMatrixEntityFactory())
								Dim fb As New RelationPredicateBucket()
								If _Context.CaseId.HasValue Then fb.PredicateExpression.Add(Case2TurbineMatrixFields.CaseId = _Context.CaseId)
								fb.Relations.Add(Case2TurbineMatrixEntity.Relations.TurbineMatrixEntityUsingTurbineMatrixId)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineEntityUsingTurbineId, JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbinePowerRegulationEntityUsingTurbinePowerRegulationId,
								                 JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineRotorDiameterEntityUsingTurbineRotorDiameterId,
								                 JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineNominelPowerEntityUsingTurbineNominelPowerId,
								                 JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineFrequencyEntityUsingTurbineFrequencyId, JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineVoltageEntityUsingTurbineVoltageId, JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineSmallGeneratorEntityUsingTurbineSmallGeneratorId,
								                 JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineTemperatureVariantEntityUsingTurbineTemperatureVariantId,
								                 JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineMarkVersionEntityUsingTurbineMarkVersionId, JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbinePlacementEntityUsingTurbinePlacementId, JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineManufacturerEntityUsingTurbineManufacturerId,
								                 JoinHint.Left)
								fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineOldEntityUsingTurbineOldId, JoinHint.Left)
								Dim pp As New PrefetchPath2(DirectCast(EntityType.Case2TurbineMatrixEntity, Integer))
								Dim ppe As PrefetchPathElement2 = DirectCast(pp.Add(Case2TurbineMatrixEntity.PrefetchPathTurbineMatrix),
								                                             PrefetchPathElement2)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbine)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbinePowerRegulation)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineRotorDiameter)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineNominelPower)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineFrequency)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineVoltage)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineSmallGenerator)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineTemperatureVariant)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineMarkVersion)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbinePlacement)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineManufacturer)
								ppe.SubPath.Add(TurbineMatrixEntity.PrefetchPathTurbineOld)
								Dim se As New SortExpression()
								se.Add(TurbineFields.Turbine Or SortOperator.Ascending)
								se.Add(TurbinePowerRegulationFields.PowerRegulation Or SortOperator.Ascending)
								se.Add(TurbineRotorDiameterFields.RotorDiameter Or SortOperator.Ascending)
								se.Add(TurbineNominelPowerFields.NominelPower Or SortOperator.Ascending)
								se.Add(TurbineFrequencyFields.Frequency Or SortOperator.Ascending)
								se.Add(TurbineVoltageFields.Voltage Or SortOperator.Ascending)
								se.Add(TurbineSmallGeneratorFields.SmallGenerator Or SortOperator.Ascending)
								se.Add(TurbineTemperatureVariantFields.TemperatureVariant Or SortOperator.Ascending)
								se.Add(TurbineMarkVersionFields.MarkVersion Or SortOperator.Ascending)
								se.Add(TurbinePlacementFields.Placement Or SortOperator.Ascending)
								se.Add(TurbineManufacturerFields.Manufacturer Or SortOperator.Ascending)
								se.Add(TurbineOldFields.Turbine Or SortOperator.Ascending)
								daa.FetchEntityCollection(ec, fb, 0, se, pp)
								_Model.Inject(ec)

								_Context.Cache.SetItem("RelevantTurbines.Turbines." + _Context.CaseId.ToString(), ec)
								'                turbineCache(_Context.CaseId) = ec
							Catch ex As ORMQueryExecutionException
								Throw New ApplicationException("A database operation failed. Please try again.", ex)
							Finally
								daa.CloseConnection()
							End Try
						End Using
					End If
				End If

				Return _Model.Turbines
			End Get
		End Property

		''' <summary>
		''' Failed Turbine
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property FailedTurbines() As List(Of Turbine)
			Get
				'Injects all turbines
				Return _Model.FailedTurbines
			End Get
			Set(ByVal value As List(Of Turbine))
				_Model.FailedTurbines = value
			End Set
		End Property

		''' <summary>
		''' Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Items(ByVal stage As Stage) As List(Of Item)
			Get
				If Not _Context.CreatingNewCase Then
					'Inject all turbines
					Dim ec As EntityCollection(Of Case2ItemEntity)

					If _Context.Cache.ContainsItem("RelevantTurbines.Items." + _Context.CaseId.ToString()) Then
						ec =
							_Context.Cache.GetItem (Of EntityCollection(Of Case2ItemEntity))(
								"RelevantTurbines.Items." + _Context.CaseId.ToString())
						_Model.Inject(ec)
					Else
						Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
							daa.CommandTimeOut = 120
							Try
								ec = New EntityCollection(Of Case2ItemEntity)(New Case2ItemEntityFactory())
								Dim fb As New RelationPredicateBucket()
								If _Context.CaseId.HasValue Then fb.PredicateExpression.Add(Case2ItemFields.CaseId = _Context.CaseId)
								fb.Relations.Add(Case2ItemEntity.Relations.Case2TurbineMatrix2Case2ItemEntityUsingCase2ItemId, JoinHint.Left)
								Dim pp As New PrefetchPath2(DirectCast(EntityType.Case2ItemEntity, Integer))
								pp.Add(Case2ItemEntity.PrefetchPathCase2TurbineUnitType2Case2Item).SubPath.Add(
									Case2TurbineMatrix2Case2ItemEntity.PrefetchPathCase2TurbineUnitType)
								Dim ppe As PrefetchPathElement2 = DirectCast(pp.Add(Case2ItemEntity.PrefetchPathItem), PrefetchPathElement2)
								ppe.SubPath.Add(ItemEntity.PrefetchPathErpsystem)
								'HACK: ERPSystemId hardcoded to 1 to only get Mapics relations
								ppe.SubPath.Add(ItemEntity.PrefetchPathRelatedItem).SubPath.Add(RelatedItemEntity.PrefetchPathItem_, 0,
								                                                                New PredicateExpression(
								                                                                	ItemFields.ErpsystemId = 1)).SubPath.Add(
								                                                                		ItemEntity.PrefetchPathErpsystem)
								daa.FetchEntityCollection(ec, fb, pp)
								_Model.Inject(ec)
								_Context.Cache.SetItem("RelevantTurbines.Items." + _Context.CaseId.ToString(), ec)
							Catch ex As ORMQueryExecutionException
								Throw New ApplicationException("A database operation failed. Please try again.", ex)
							Finally
								daa.CloseConnection()
							End Try
						End Using
					End If
				End If
				Return _Model.Items(stage)
			End Get
		End Property

		''' <summary>
		''' Failed Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property FailedItem() As Item
			Get
				'Inject all stages
				'Injects all items
				Return _Model.FailedItem
			End Get
			Set(ByVal value As Item)
				_Model.FailedItem = value
			End Set
		End Property

		''' <summary>
		''' Root Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property RootItem() As Item
			Get
				'Injects all items
				Return _Model.RootItem
			End Get
			Set(ByVal value As Item)
				_Model.RootItem = value
			End Set
		End Property

		''' <summary>
		''' ItemCount
		''' </summary>
		''' <param name="turbine"></param>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ItemCount(ByVal stage As Stage, ByVal turbine As Turbine, ByVal item As Item) As ItemCount
			Get
				Return _Model.ItemCount(stage, turbine, item)
			End Get
		End Property

		''' <summary>
		''' MayAddTurbineUnit
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddTurbineUnit() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_RelevantTurbines_AddTurbineUnit)
			End Get
		End Property

		''' <summary>
		''' MayAddItem
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddItem() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_RelevantTurbines_AddItem)
			End Get
		End Property

		''' <summary>
		''' MayRemoveTurbineUnit
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveTurbineUnit() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_RelevantTurbines_RemoveTubineUnit)
			End Get
		End Property

		''' <summary>
		''' MayRemoveItem
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveItem() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_RelevantTurbines_RemoveItem)
			End Get
		End Property

		''' <summary>
		''' MayEditCount
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayEditCount() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_RelevantTurbines_EditAmountUsed)
			End Get
		End Property

#End Region

#Region "Old CIM Turbine Window"

		''' <summary>
		''' Old CIM Turbine
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Only to be used in OldCIMTurbine window</remarks>
		Public ReadOnly Property OldTurbines() As List(Of Turbine)
			Get
				Dim ec As New EntityCollection(Of OldCimturbineEntity)(New OldCimturbineEntityFactory())

				If Not _Context.CreatingNewCase Then
					Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
						Dim fb As New RelationPredicateBucket(New PredicateExpression(OldCimturbineFields.CaseId = _Context.CaseId))
						Try
							daa.CommandTimeOut = 120
							daa.FetchEntityCollection(ec, fb)
						Catch ex As ORMQueryExecutionException
							Throw New ApplicationException("A database operation failed. Please try again.", ex)
						Finally
							daa.CloseConnection()
						End Try
					End Using
				End If

				Dim li As New List(Of Turbine)
				For i As Integer = 0 To ec.Count - 1
					li.Add(New Turbine(ec(i)))
				Next

				Return li
			End Get
		End Property

#End Region

#Region "Old CIM Item Window"

		''' <summary>
		''' Old CIM Items
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Only to be used in OldCIMItem window</remarks>
		Public ReadOnly Property OldItems() As List(Of Item)
			Get
				'Injects all items
				Return _Model.OldItems
			End Get
		End Property

#End Region

#Region "Turbine MK Version"

		''' <summary>
		''' Change MK Version Expected
		''' </summary>
		''' <param name="MKVersionExpected"></param>
		''' <remarks></remarks>
		Public Sub ChangeMKVersionExpected(ByRef MKVersionExpected As Object, ByRef item As Turbine)
			Dim value As Short = - 1
			If Short.TryParse(MKVersionExpected.ToString(), value) AndAlso value > - 1 Then
				_Model.ChangeMKVersionExpected(value, item)
			Else
				Throw New ArgumentException(String.Format("Expected value between 0 and {0}", Short.MaxValue))
			End If
		End Sub

		''' <summary>
		''' Change MK Version Actual
		''' </summary>
		''' <param name="MKVersionActual"></param>
		''' <remarks></remarks>
		Public Sub ChangeMKVersionActual(ByRef MKVersionActual As Object, ByRef item As Turbine)
			Dim value As Short = - 1
			If Short.TryParse(MKVersionActual.ToString(), value) AndAlso value > - 1 Then
				_Model.ChangeMKVersionActuel(value, item)
			Else
				Throw New ArgumentException(String.Format("Expected value between 0 and {0}", Short.MaxValue))
			End If
		End Sub

#End Region

#Region "Add Turbine Window"

		''' <summary>
		''' TurbineTypes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks>Only to be used in RelevantTurbineAddTurbine window</remarks>
		Public ReadOnly Property TurbineTypes() As List(Of Turbine)
			Get
				Dim ec As New EntityCollection(Of TurbineMatrixEntity)(New TurbineMatrixEntityFactory())

				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Try
						Dim fb As New RelationPredicateBucket()
						fb.PredicateExpression.AddWithAnd(TurbineMatrixFields.Deleted = DBNull.Value)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineEntityUsingTurbineId, JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbinePowerRegulationEntityUsingTurbinePowerRegulationId,
						                 JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineRotorDiameterEntityUsingTurbineRotorDiameterId,
						                 JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineNominelPowerEntityUsingTurbineNominelPowerId, JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineFrequencyEntityUsingTurbineFrequencyId, JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineVoltageEntityUsingTurbineVoltageId, JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineSmallGeneratorEntityUsingTurbineSmallGeneratorId,
						                 JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineTemperatureVariantEntityUsingTurbineTemperatureVariantId,
						                 JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineMarkVersionEntityUsingTurbineMarkVersionId, JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbinePlacementEntityUsingTurbinePlacementId, JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineManufacturerEntityUsingTurbineManufacturerId, JoinHint.Left)
						fb.Relations.Add(TurbineMatrixEntity.Relations.TurbineOldEntityUsingTurbineOldId, JoinHint.Left)
						Dim pp As New PrefetchPath2(DirectCast(EntityType.TurbineMatrixEntity, Integer))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbine, 0, New PredicateExpression(TurbineFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbinePowerRegulation, 0,
						       New PredicateExpression(TurbinePowerRegulationFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineRotorDiameter, 0,
						       New PredicateExpression(TurbineRotorDiameterFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineNominelPower, 0,
						       New PredicateExpression(TurbineNominelPowerFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineFrequency, 0,
						       New PredicateExpression(TurbineFrequencyFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineVoltage, 0,
						       New PredicateExpression(TurbineVoltageFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineSmallGenerator, 0,
						       New PredicateExpression(TurbineSmallGeneratorFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineTemperatureVariant, 0,
						       New PredicateExpression(TurbineTemperatureVariantFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineMarkVersion, 0,
						       New PredicateExpression(TurbineMarkVersionFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbinePlacement, 0,
						       New PredicateExpression(TurbinePlacementFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineManufacturer, 0,
						       New PredicateExpression(TurbineManufacturerFields.Deleted = DBNull.Value))
						pp.Add(TurbineMatrixEntity.PrefetchPathTurbineOld, 0,
						       New PredicateExpression(TurbineOldFields.Deleted = DBNull.Value))
						Dim se As New SortExpression()
						se.Add(TurbineFields.Turbine Or SortOperator.Ascending)
						se.Add(TurbinePowerRegulationFields.PowerRegulation Or SortOperator.Ascending)
						se.Add(TurbineRotorDiameterFields.RotorDiameter Or SortOperator.Ascending)
						se.Add(TurbineNominelPowerFields.NominelPower Or SortOperator.Ascending)
						se.Add(TurbineFrequencyFields.Frequency Or SortOperator.Ascending)
						se.Add(TurbineVoltageFields.Voltage Or SortOperator.Ascending)
						se.Add(TurbineSmallGeneratorFields.SmallGenerator Or SortOperator.Ascending)
						se.Add(TurbineTemperatureVariantFields.TemperatureVariant Or SortOperator.Ascending)
						se.Add(TurbineMarkVersionFields.MarkVersion Or SortOperator.Ascending)
						se.Add(TurbinePlacementFields.Placement Or SortOperator.Ascending)
						se.Add(TurbineManufacturerFields.Manufacturer Or SortOperator.Ascending)
						se.Add(TurbineOldFields.Turbine Or SortOperator.Ascending)
						daa.FetchEntityCollection(ec, fb, 0, se, pp)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Dim liTurbine As New List(Of Turbine)
				For i As Integer = 0 To ec.Count - 1
					liTurbine.Add(New Turbine(ec(i)))
				Next

				Return liTurbine
			End Get
		End Property

#End Region

#Region "Add Item Window"

		''' <summary>
		''' Find Item
		''' </summary>
		''' <param name="ERPSystemId"></param>
		''' <param name="ItemNumber"></param>
		''' <param name="ItemName"></param>
		''' <param name="MaximumNumberOfItems"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function FindItem(ByRef ERPSystemId As Integer, ByRef ItemNumber As String, ByRef ItemName As String,
		                         ByRef MaximumNumberOfItems As Integer) As List(Of Item)
			Dim collectionToFill As New EntityCollection(Of ItemEntity)(New ItemEntityFactory())

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				daa.CommandTimeOut = 120
				Try
					Dim filterBucket As New RelationPredicateBucket()
					filterBucket.PredicateExpression.Add(ItemFields.Deleted = DBNull.Value)
					If ERPSystemId > - 1 Then
						filterBucket.PredicateExpression.AddWithAnd(ItemFields.ErpsystemId = ERPSystemId)
					End If
					If ItemNumber.Length > 0 Then
						filterBucket.PredicateExpression.AddWithAnd(ItemFields.ItemNo Mod String.Format("%{0}%", ItemNumber))
					End If
					If ItemName.Length > 0 Then
						filterBucket.PredicateExpression.AddWithAnd(ItemFields.Description Mod String.Format("%{0}%", ItemName))
					End If

					Dim prefetchPath As New PrefetchPath2(DirectCast(EntityType.ItemEntity, Integer))
					prefetchPath.Add(ItemEntity.PrefetchPathErpsystem)
					prefetchPath.Add(ItemEntity.PrefetchPathRelatedItem).SubPath.Add(RelatedItemEntity.PrefetchPathItem_).SubPath.Add(
						ItemEntity.PrefetchPathErpsystem)

					daa.FetchEntityCollection(collectionToFill, filterBucket, MaximumNumberOfItems, Nothing, prefetchPath)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Finally
					daa.CloseConnection()
				End Try
			End Using

			Dim li As New List(Of Item)
			For i As Integer = 0 To collectionToFill.Count - 1
				li.Add(New Item(collectionToFill(i)))
			Next
			Return li
		End Function

#End Region
	End Class
End Namespace
