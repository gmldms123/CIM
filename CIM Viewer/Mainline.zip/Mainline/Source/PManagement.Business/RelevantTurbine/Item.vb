Imports PManagement.Business.BaseClasses

Namespace RelevantTurbine
	''' <summary>
	''' Item
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Item
		Inherits BaseObject

#Region "Enums"

		''' <summary>
		''' ERPSystems
		''' </summary>
		''' <remarks></remarks>
			Public Enum ERPSystems
			Mapics = 1
			SAP = 2
			Navision = 3
			Concorde = 4
		End Enum

#End Region

#Region "Predicates"

		Public Shared FailedPredicate As Predicate(Of Item) = Function(i) Not i.Deleted AndAlso i.InitialFailed

		Public Shared Function ItemsByStagePredicate(ByVal stage As Stage, ByVal itemCounts As List(Of ItemCount),
		                                             ByVal numTurbines As Long) As Predicate(Of Item)
			Return _
				Function(i) _
					numTurbines > 0 And itemCounts.FindAll(ItemCount.ItemCountsByStagePredicate(stage, i)).Count = numTurbines
		End Function

#End Region

#Region "Variables"

		Private ReadOnly _myId As Long = - 1
		Private _Number As String
		Private _Name As String
		Private _ERPSystem As ERPSystems = ERPSystems.Mapics
		Private _HasRelatedTurbines As Boolean
		Private _HasRelatedTurbinesIsDirty As Boolean
		Private _Root As Boolean
		Private _RootIsDirty As Boolean
		Private _InitialFailed As Boolean
		Friend _InitialFailedIsDirty As Boolean
		Private ReadOnly _Count As Integer

#End Region

#Region "Methods"

		''' <summary>
		''' MapicsItem
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Shared Function MapicsItem(ByVal entity As ItemEntity) As ItemEntity
			If entity.Erpsystem.Name <> [Enum].GetName(GetType(ERPSystems), ERPSystems.Mapics) And entity.RelatedItem.Count > 0 _
				Then
				For Each item As RelatedItemEntity In entity.RelatedItem
					If _
						item.Item_ IsNot Nothing AndAlso
						item.Item_.Erpsystem.Name = [Enum].GetName(GetType(ERPSystems), ERPSystems.Mapics) Then
						entity = item.Item_
						Exit For
					End If
				Next
			End If
			Return entity
		End Function

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As Case2ItemEntity)
			Dim itemEntity As ItemEntity = MapicsItem(entity.Item)
			_myId = itemEntity.ItemId
			_Number = itemEntity.ItemNo
			_Name = itemEntity.Description
			_ERPSystem = DirectCast([Enum].Parse(GetType(ERPSystems), itemEntity.Erpsystem.Name), ERPSystems)
			_Id = entity.Case2ItemId
			_Root = entity.Root
			If entity.Case2TurbineUnitType2Case2Item.Count > 0 Then
				_HasRelatedTurbines = True
				_InitialFailed =
					entity.Case2TurbineUnitType2Case2Item.FindMatches(
						New PredicateExpression(Case2TurbineMatrix2Case2ItemFields.InitialFailed = True)).Count > 0
				Dim c As Integer = 0
				For Each data As Case2TurbineMatrix2Case2ItemEntity In entity.Case2TurbineUnitType2Case2Item
					c = c + data.Count
				Next
				_Count = c
			End If
		End Sub

		''' <summary>
		''' New (Raw item)
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As ItemEntity)
			Dim itemEntity As ItemEntity = MapicsItem(entity)
			_myId = itemEntity.ItemId
			_Number = itemEntity.ItemNo
			_Name = itemEntity.Description
			_ERPSystem = DirectCast([Enum].Parse(GetType(ERPSystems), itemEntity.Erpsystem.Name), ERPSystems)
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As Case2ItemEntity) As Boolean
			Dim itemEntity As ItemEntity = MapicsItem(entity.Item)
			Dim updated As Boolean = False
			If _Name <> itemEntity.Description Then
				_Name = itemEntity.Description
				updated = True
			End If
			If _Number <> itemEntity.ItemNo Then
				_Number = itemEntity.ItemNo
				updated = True
			End If
			If [Enum].GetName(GetType(ERPSystems), ERPSystem) <> itemEntity.Erpsystem.Name Then
				_ERPSystem = DirectCast([Enum].Parse(GetType(ERPSystems), itemEntity.Erpsystem.Name), ERPSystems)
				updated = True
			End If
			If _Id <> entity.Case2ItemId Then
				_Id = entity.Case2ItemId
				updated = True
			End If
			If entity.Case2TurbineUnitType2Case2Item.Count > 0 Then
				_HasRelatedTurbines = True
				If Not _InitialFailedIsDirty AndAlso _InitialFailed <> entity.Case2TurbineUnitType2Case2Item(0).InitialFailed Then
					_InitialFailed = entity.Case2TurbineUnitType2Case2Item(0).InitialFailed
					updated = True
				End If
			Else
				If Not _HasRelatedTurbinesIsDirty AndAlso _HasRelatedTurbines Then
					_HasRelatedTurbines = False
					updated = True
				End If
				If Not _InitialFailedIsDirty AndAlso InitialFailed Then
					_InitialFailed = False
					_InitialFailedIsDirty = False
					updated = True
				End If
			End If
			If Not _RootIsDirty AndAlso _Root <> entity.Root Then
				_Root = entity.Root
				updated = True
			End If
			If updated Then
				_Deleted = False
			End If
			Return updated
		End Function

#End Region

#Region "Properties"

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' IsDirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return MyBase.IsDirty Or
				       _HasRelatedTurbinesIsDirty Or
				       _InitialFailedIsDirty Or
				       _RootIsDirty
			End Get
		End Property

		''' <summary>
		''' Number
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Number() As String
			Get
				Return _Number
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Count
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Count() As Integer
			Get
				Return _Count
			End Get
		End Property

		''' <summary>
		''' ERPSystem
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ERPSystem() As ERPSystems
			Get
				Return _ERPSystem
			End Get
		End Property

		''' <summary>
		''' RelationId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RelationId() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' HasRelatedTurbines
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property HasRelatedTurbines() As Boolean
			Get
				Return _HasRelatedTurbines
			End Get
			Set(ByVal value As Boolean)
				If _HasRelatedTurbines <> value Then
					_HasRelatedTurbines = value
					_HasRelatedTurbinesIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Root
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Root() As Boolean
			Get
				Return _Root
			End Get
			Set(ByVal value As Boolean)
				If _Root <> value Then
					_Root = value
					_RootIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Root Is Dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RootIsDirty() As Boolean
			Get
				Return _RootIsDirty
			End Get
		End Property

		''' <summary>
		''' InitialFailed
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property InitialFailed() As Boolean
			Get
				Return _InitialFailed
			End Get
			Set(ByVal value As Boolean)
				If _InitialFailed <> value Then
					_InitialFailed = value
					_InitialFailedIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Initial Failed Is Dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property InitialFailedIsDirty() As Boolean
			Get
				Return _InitialFailedIsDirty
			End Get
		End Property

#End Region
	End Class
End Namespace
