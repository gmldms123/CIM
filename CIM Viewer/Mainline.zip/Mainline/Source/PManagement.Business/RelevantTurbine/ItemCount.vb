Imports PManagement.Business.BaseClasses

Namespace RelevantTurbine
	''' <summary>
	''' ItemCount
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class ItemCount
		Inherits BaseObject

#Region "Predicates"

		Public Shared Function ItemCountsByStagePredicate(ByVal stage As Stage, ByVal item As Item) As Predicate(Of ItemCount)
			Return _
				Function(ic) _
					ic.Stage IsNot Nothing AndAlso Not ic.Deleted AndAlso ic.Item.Id = item.Id AndAlso stage IsNot Nothing AndAlso
					ic.Stage.Id = stage.Id
		End Function

		Public Shared Function ItemCountsByTurbinePredicate(ByVal turbine As Turbine) As Predicate(Of ItemCount)
			Return Function(ic) ic.Turbine IsNot Nothing AndAlso turbine IsNot Nothing AndAlso ic.Turbine.Id = turbine.Id
		End Function

		Public Shared Function ItemCountsByItemPredicate(ByVal item As Item) As Predicate(Of ItemCount)
			Return _
				Function(ic) _
					Not ic.Deleted AndAlso ic.Item IsNot Nothing AndAlso ic.Turbine IsNot Nothing AndAlso item IsNot Nothing AndAlso
					ic.Item.Id = item.Id
		End Function

		Public Shared Function AllItemCountsByStagePredicate(ByVal stage As Stage, ByVal item As Item) _
			As Predicate(Of ItemCount)
			Return _
				Function(ic) _
					ic.Stage IsNot Nothing AndAlso ic.Turbine IsNot Nothing AndAlso stage IsNot Nothing AndAlso item IsNot Nothing AndAlso
					ic.Item.Id = item.Id AndAlso ic.Stage.Id = stage.Id
		End Function

#End Region

#Region "Variables"

		Private _Count As Integer
		Private _CountIsDirty As Boolean
		Private _Item As Item
		Private ReadOnly _Turbine As Turbine
		Private ReadOnly _Stage As Stage

#End Region

#Region "Methods"

		''' <summary>
		''' New
		''' </summary>
		''' <param name="item"></param>
		''' <param name="turbine"></param>
		''' <param name="stage"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal item As Item, ByVal turbine As Turbine, ByVal stage As Stage)
			_Item = item
			_Turbine = turbine
			_Stage = stage
			_Deleted = item.Deleted OrElse turbine IsNot Nothing AndAlso turbine.Deleted
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <param name="item"></param>
		''' <param name="turbine"></param>
		''' <param name="stage"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As Case2TurbineMatrix2Case2ItemEntity, ByVal item As Item, ByVal turbine As Turbine,
		               ByVal stage As Stage)
			_Id = entity.Case2TurbineMatrix2Case2ItemId
			_Count = entity.Count
			_Item = item
			_Turbine = turbine
			_Stage = stage
			_Deleted = item.Deleted OrElse turbine IsNot Nothing AndAlso turbine.Deleted
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As Case2TurbineMatrix2Case2ItemEntity, ByVal item As Item) As Boolean
			Dim updated As Boolean = False
			If _Id <> entity.Case2TurbineMatrix2Case2ItemId Then
				_Id = entity.Case2TurbineMatrix2Case2ItemId
				updated = True
			End If
			If Not _CountIsDirty AndAlso _Count <> entity.Count Then
				_Count = entity.Count
				updated = True
			End If
			If Not _Item.Equals(item) Then
				_Item = item
				updated = True
			End If
			Return updated
		End Function

#End Region

#Region "Properties"

		''' <summary>
		''' RelationId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RelationId() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' IsDirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return MyBase.IsDirty Or
				       _CountIsDirty Or
				       _Item.InitialFailedIsDirty
			End Get
		End Property

		''' <summary>
		''' Deleted
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides Property Deleted() As Boolean
			Get
				Return MyBase.Deleted OrElse
				       _Turbine IsNot Nothing AndAlso Turbine.Deleted OrElse
				       _Item.Deleted
			End Get
			Set(ByVal value As Boolean)
				MyBase.Deleted = value
			End Set
		End Property

		''' <summary>
		''' Count
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Count() As Integer
			Get
				Return _Count
			End Get
			Set(ByVal value As Integer)
				If _Count <> value Then
					_Count = value
					_CountIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Item() As Item
			Get
				Return _Item
			End Get
		End Property

		''' <summary>
		''' Turbine
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Turbine() As Turbine
			Get
				Return _Turbine
			End Get
		End Property

		''' <summary>
		''' Stage
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Stage() As Stage
			Get
				Return _Stage
			End Get
		End Property

		''' <summary>
		''' InitialFailed
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property InitialFailed() As Boolean
			Get
				Return _Item.InitialFailed
			End Get
		End Property

#End Region
	End Class
End Namespace
