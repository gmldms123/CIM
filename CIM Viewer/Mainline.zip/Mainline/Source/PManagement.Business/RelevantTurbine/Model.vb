Imports PManagement.Business.Genericed

Namespace RelevantTurbine
	''' <summary>
	''' Model
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Model
		Inherits BaseClasses.Model

#Region "Variables"

		Private ReadOnly _Stages As New List(Of Stage)
		Private ReadOnly _Turbines As New List(Of Turbine)
		Private ReadOnly _Items As New List(Of Item)
		Private ReadOnly _ItemCounts As New List(Of ItemCount)
		Private _RootItem As Item

		'Variables used with find predicates
		Private _turbineSearchEntityCollection As EntityCollection(Of Case2TurbineMatrixEntity) = Nothing
		Private _stageToFind As Stage = Nothing

#End Region

#Region "Methods"

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			'_Stages.Clear() 'No reason for refresh stages. Keep state.
			_Turbines.Clear()
			_Items.Clear()
			_ItemCounts.Clear()
			_RootItem = Nothing
			OnDataChanged()
		End Sub

		''' <summary>
		''' Force redraw of screen contents
		''' </summary>
		''' <remarks></remarks>
		Public Sub ForceDataChanged()
			OnDataChanged()
		End Sub

		''' <summary>
		''' Inject (Stages)
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of StageEntity))
			Dim dataChanged As Boolean

			For i As Integer = 0 To ec.Count - 1
				Dim myEntity As StageEntity = ec(i)
				Dim myStage As Stage = _Stages.Find(Function(s) s.Id = myEntity.StageId)

				If myStage Is Nothing Then
					'Add
					_Stages.Add(New Stage(myEntity))
					dataChanged = True
				Else
					'Update
					dataChanged = dataChanged Or myStage.Update(myEntity)
				End If
			Next

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Inject (Turbines)
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of Case2TurbineMatrixEntity))
			Dim dataChanged As Boolean
			Dim entityWithLowestId As Case2TurbineMatrixEntity = Nothing

			For i As Integer = 0 To ec.Count - 1
				Dim myEntity As Case2TurbineMatrixEntity = ec(i)
				Dim myTurbine As Turbine = _Turbines.Find(Function(t) t.Id = myEntity.TurbineMatrixId)

				If entityWithLowestId Is Nothing OrElse entityWithLowestId.Case2TurbineMatrixId > myEntity.Case2TurbineMatrixId Then
					entityWithLowestId = myEntity
				End If

				If myTurbine Is Nothing Then
					'Add
					AddTurbine(New Turbine(myEntity), True)

					dataChanged = True
				Else
					'Update
					dataChanged = dataChanged Or myTurbine.Update(myEntity)
				End If
			Next

			' If no turbines are marked as failed we select the turbine with the lowest Case2TurbineMatrixId value.
			If entityWithLowestId IsNot Nothing Then
				Dim failedTurbine As Turbine = Nothing
				For Each turbine As Turbine In _Turbines
					If turbine.Relation = Turbine.Relations.Failed Then
						failedTurbine = turbine
					End If
				Next
				If failedTurbine Is Nothing Then
					For Each turbine As Turbine In _Turbines
						If turbine.TurbineId = entityWithLowestId.TurbineMatrix.Turbine.TurbineId Then
							turbine.Relation = Turbine.Relations.Failed
							turbine._RelationIsDirty = False
						End If
					Next
				End If
			End If

			_turbineSearchEntityCollection = ec
			dataChanged = dataChanged Or _Turbines.RemoveAll(New System.Predicate(Of Turbine)(AddressOf FindTurbineToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Inject (Items)
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of Case2ItemEntity))
			Dim dataChanged As Boolean

			Dim ItemWithLowestId As Case2ItemEntity = Nothing

			For i As Integer = 0 To ec.Count - 1
				Dim myEntity As Case2ItemEntity = ec(i)

				If ItemWithLowestId Is Nothing OrElse ItemWithLowestId.Case2ItemId > myEntity.Case2ItemId Then
					ItemWithLowestId = myEntity
				End If

				Dim myItem As Item = _Items.Find(Function(it) it.Id = Item.MapicsItem(myEntity.Item).ItemId)

				'Check for root item
				If myItem Is Nothing AndAlso _RootItem IsNot Nothing AndAlso Item.MapicsItem(myEntity.Item).ItemId = _RootItem.Id _
					Then myItem = _RootItem

				If myItem Is Nothing Then
					'Add item
					myItem = New Item(myEntity)

					'Root item
					If myItem.Root Then
						If _RootItem IsNot Nothing AndAlso _RootItem.RootIsDirty Then
							myItem.Root = False
						ElseIf _RootItem Is Nothing OrElse _RootItem IsNot Nothing AndAlso Not _RootItem.RootIsDirty Then
							_RootItem = myItem

							''Bugfix PT-1431. If myItem.HasRelatedTurbines then myItem is added later
							If Not myItem.HasRelatedTurbines Then
								_Items.Add(myItem)
							End If

						End If
					End If

					'Initial failed item
					If myItem.InitialFailed Then
						Dim _InitialFailedItem As Item = _Items.Find(Item.FailedPredicate)
						If _InitialFailedItem IsNot Nothing AndAlso _InitialFailedItem.InitialFailedIsDirty Then _
							myItem.InitialFailed = False
					End If

					If myItem.HasRelatedTurbines Then
						If myItem.InitialFailed Then
							_Items.Insert(0, myItem)
						Else
							_Items.Add(myItem)
						End If

						'Add ItemCount
						'For j As Integer = 0 To myEntity.Case2TurbineUnitType2Case2Item.Count - 1
						'	Dim entity As Case2TurbineMatrix2Case2ItemEntity = myEntity.Case2TurbineUnitType2Case2Item(j)

						'	Dim turbine As Turbine
						'	If entity.Case2TurbineUnitType IsNot Nothing Then
						'		turbine = _Turbines.Find(Function(t) t.Id = entity.Case2TurbineUnitType.TurbineMatrixId)
						'	End If
						'	'Dim stage As Stage = _Stages.Find(Function(s) s.Id = entity.StageId)
						'	_ItemCounts.Add(New ItemCount(entity, myItem, turbine, _Stages.Find(Function(s) s.Id = entity.StageId)))
						'Next
					End If

					dataChanged = True
				Else
					'Update
					dataChanged = dataChanged Or myItem.Update(myEntity)

					'Root item
					If myItem.Equals(_RootItem) AndAlso Not myItem.Root Then
						_RootItem = Nothing
						dataChanged = True
					ElseIf Not myItem.Equals(_RootItem) AndAlso myItem.Root Then
						If _RootItem.RootIsDirty Then
							myItem.Root = False
						Else
							_RootItem = myItem
						End If
						dataChanged = True
					End If

					If myItem.HasRelatedTurbines Then
						'Add or Update ItemCounts
						'     For j As Integer = 0 To myEntity.Case2TurbineUnitType2Case2Item.Count - 1
						'       Dim entity As Case2TurbineMatrix2Case2ItemEntity = myEntity.Case2TurbineUnitType2Case2Item(j)
						'       Dim myItemCount As ItemCount

						'       Dim turbine As Turbine
						'       If entity.Case2TurbineUnitType IsNot Nothing Then
						'         turbine = _Turbines.Find(Function(t) t.Id = entity.Case2TurbineUnitType.TurbineMatrixId)
						'       End If
						'Dim stage As Stage = _Stages.Find(Function(s) s.Id = entity.StageId)

						'       myItemCount = _ItemCounts.Find(Function(ic) ic.Stage IsNot Nothing AndAlso ic.Stage.Equals(stage) AndAlso ic.Turbine IsNot Nothing AndAlso ic.Turbine.Equals(turbine) AndAlso ic.Item.Equals(orgItem))

						'       If myItemCount Is Nothing Then
						'         'Add ItemCount
						'         _ItemCounts.Add(New ItemCount(entity, myItem, turbine, stage))
						'       Else
						'         'Update ItemCount
						'         dataChanged = dataChanged Or myItemCount.Update(entity, myItem)
						'       End If
						'     Next
					Else
						'Mark itemCounts as deleted
						For Each myStage As Stage In _Stages
							For Each myItemCount As ItemCount In _
								_ItemCounts.FindAll(RelevantTurbine.ItemCount.ItemCountsByStagePredicate(myStage, myItem))
								myItemCount.Deleted = True
								dataChanged = True
							Next
						Next
					End If
				End If
			Next

			' If no items are marked as InitialFailed, we select the one with the lowest id
			Dim InitialFailedItem As Item = Nothing
			For Each item As Item In _Items
				If item.InitialFailed Then
					InitialFailedItem = item
				End If
			Next
			If InitialFailedItem Is Nothing Then
				For Each item As Item In _Items
					If item.Id = ItemWithLowestId.ItemId Then
						item.InitialFailed = True
						item._InitialFailedIsDirty = False
					End If
				Next
			End If

			'TODO: Remove orphaned items and itemcounts
			'_itemSearchEntityCollection = ec
			'_stageToFind = stage
			'dataChanged = dataChanged Or _Items.RemoveAll(New Predicate(Of Item)(AddressOf FindItemToRemove)) > 0
			'dataChanged = dataChanged Or _ItemCounts.RemoveAll(New Predicate(Of ItemCount)(AddressOf FindItemCountToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' SetItemCount
		''' </summary>
		''' <param name="newCount"></param>
		''' <param name="count"></param>
		''' <remarks></remarks>
		Public Sub SetItemCount(ByVal newCount As Integer, ByVal count As ItemCount)
			count.Count = newCount
		End Sub

		''' <summary>
		''' SetItemCount
		''' </summary>
		''' <param name="newCount"></param>
		''' <param name="itemCounts"></param>
		''' <remarks></remarks>
		Public Sub SetItemCount(ByVal newCount As Integer, ByVal itemCounts As List(Of ItemCount))
			For Each myItemCount As ItemCount In itemCounts
				myItemCount.Count = newCount
			Next
		End Sub

		''' <summary>
		''' Add turbine
		''' </summary>
		''' <param name="turbinelist"></param>
		''' <remarks></remarks>
		Public Sub AddTurbine(ByVal turbinelist As List(Of Turbine))
			AddTurbine(turbinelist, False)
		End Sub

		''' <summary>
		''' Add turbine
		''' </summary>
		''' <param name="turbinelist"></param>
		''' <remarks></remarks>
		Private Sub AddTurbine(ByVal turbinelist As List(Of Turbine), ByVal suppressDataChanged As Boolean)
			If turbinelist.Count > 0 Then
				For i As Integer = 0 To turbinelist.Count - 1
					AddTurbine(turbinelist(i), True)
				Next
				If Not suppressDataChanged Then OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Add Turbine
		''' </summary>
		''' <param name="turbine"></param>
		''' <param name="suppressDataChanged"></param>
		''' <remarks></remarks>
		Private Sub AddTurbine(ByVal turbine As Turbine, ByVal suppressDataChanged As Boolean)
			Dim dataChanged As Boolean
			Dim myTurbine As Turbine = _Turbines.Find(Function(t) t.Id = turbine.Id)

			If myTurbine Is Nothing Then
				'Add item counts
				For Each myStage As Stage In _Stages
					Dim myItems As List(Of Item) = _Items.FindAll(Item.ItemsByStagePredicate(myStage, _ItemCounts, _Turbines.Count))
					For Each myItem As Item In myItems
						_ItemCounts.Add(New ItemCount(myItem, turbine, myStage))
					Next
				Next

				'Add turbine
				If turbine.Relation = Turbine.Relations.Failed Then
					_Turbines.Insert(_Turbines.FindAll(turbine.FailedWithDeletedPredicate).Count, turbine)
				Else
					_Turbines.Add(turbine)
				End If

				dataChanged = True
			Else
				'Initial failed
				If Not myTurbine.Relation = Turbine.Relations.Failed Then
					myTurbine.Relation = turbine.Relation
					dataChanged = True
				End If
				If myTurbine.Relation = Turbine.Relations.Failed AndAlso _Turbines.IndexOf(myTurbine) > 0 Then
					'Failed turbines must appear before related turbines
					_Turbines.Remove(myTurbine)
					_Turbines.Insert(_Turbines.FindAll(turbine.FailedWithDeletedPredicate).Count, myTurbine)
					dataChanged = True
				ElseIf myTurbine.Relation = Turbine.Relations.Related AndAlso _Turbines.IndexOf(myTurbine) = 0 Then
					'Move turbine
					_Turbines.Remove(myTurbine)
					_Turbines.Add(myTurbine)
					dataChanged = True
				End If

				'Undelete turbine
				If myTurbine.Deleted Then
					myTurbine.Deleted = False
					dataChanged = True
				End If
			End If

			If dataChanged AndAlso Not suppressDataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Remove turbine
		''' </summary>
		''' <param name="turbinelist"></param>
		''' <remarks></remarks>
		Public Sub RemoveTurbine(ByVal turbinelist As List(Of Turbine))
			RemoveTurbine(turbinelist, False)
		End Sub

		''' <summary>
		''' Remove turbine
		''' </summary>
		''' <param name="turbinelist"></param>
		''' <remarks></remarks>
		Private Sub RemoveTurbine(ByVal turbinelist As List(Of Turbine), ByVal suppressDataChanged As Boolean)
			If turbinelist.Count > 0 Then
				For Each turbine As Turbine In turbinelist
					RemoveTurbine(turbine, True)
				Next
				If Not suppressDataChanged Then OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Remove Turbine
		''' </summary>
		''' <param name="turbine"></param>
		''' <param name="suppressDataChanged"></param>
		''' <remarks></remarks>
		Private Sub RemoveTurbine(ByVal turbine As Turbine, ByVal suppressDataChanged As Boolean)
			Dim myTurbine As Turbine = _Turbines.Find(Function(t) t.Id = turbine.Id)

			If myTurbine.IsNew Then
				'Remove turbine/itemcounts from model as it has never been persisted to database
				_Turbines.Remove(myTurbine)
				_ItemCounts.RemoveAll(RelevantTurbine.ItemCount.ItemCountsByTurbinePredicate(myTurbine))
			Else
				'Mark turbine as deleted
				myTurbine.Relation = Turbine.Relations.Related
				myTurbine.Deleted = True
			End If

			If Not suppressDataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Add item
		''' </summary>
		''' <param name="itemlist"></param>
		''' <remarks></remarks>
		Public Sub AddItem(ByVal itemlist As List(Of Item), ByVal stage As Stage)
			If itemlist.Count > 0 Then
				For i As Integer = 0 To itemlist.Count - 1
					AddItem(itemlist(i), stage, True)
				Next
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Add Item
		''' </summary>
		''' <param name="item"></param>
		''' <param name="stage"></param>
		''' <param name="suppressDataChanged"></param>
		''' <remarks></remarks>
		Public Sub AddItem(ByVal item As Item, ByVal stage As Stage, ByVal suppressDataChanged As Boolean)
			Dim myItem As Item = _Items.Find(Function(it) it.Id = item.Id)

			'Check for root item
			If myItem Is Nothing AndAlso _RootItem IsNot Nothing AndAlso item.Id = _RootItem.Id Then
				myItem = _RootItem
				_Items.Add(myItem)
			End If

			If myItem Is Nothing Then
				'Add item
				myItem = item
				If myItem.InitialFailed Then
					_Items.Insert(0, myItem)
				Else
					_Items.Add(myItem)
				End If
			Else
				'Initial failed
				If Not myItem.InitialFailed Then myItem.InitialFailed = item.InitialFailed
				myItem.HasRelatedTurbines = item.HasRelatedTurbines
				If myItem.InitialFailed AndAlso _Items.IndexOf(myItem) > 0 Then
					'Failed item must appear as first item
					_Items.Remove(myItem)
					_Items.Insert(0, myItem)
				ElseIf Not myItem.InitialFailed AndAlso _Items.IndexOf(myItem) = 0 Then
					'Move item
					_Items.Remove(myItem)
					_Items.Add(myItem)
				End If

				'Undelete existing item
				myItem.Deleted = False
			End If

			Dim myItemCounts As List(Of ItemCount) =
			    	_ItemCounts.FindAll(RelevantTurbine.ItemCount.AllItemCountsByStagePredicate(stage, myItem))
			If myItemCounts.Count = 0 Then
				'Add item counts
				For Each myTurbine As Turbine In _Turbines
					_ItemCounts.Add(New ItemCount(myItem, myTurbine, stage))
				Next
				myItem.HasRelatedTurbines = True
			Else
				For Each count As ItemCount In myItemCounts
					count.Deleted = False
				Next
			End If

			If Not suppressDataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Remove item
		''' </summary>
		''' <param name="itemlist"></param>
		''' <param name="stage"></param>
		''' <remarks></remarks>
		Public Sub RemoveItem(ByVal itemlist As List(Of Item), ByVal stage As Stage)
			If itemlist.Count > 0 Then
				For Each item As Item In itemlist
					RemoveItem(item, stage, True)
				Next
				OnDataChanged()
			End If
		End Sub

		''' <summary>
		''' Remove Item
		''' </summary>
		''' <param name="item"></param>
		''' <param name="stage"></param>
		''' <param name="suppressDataChanged"></param>
		''' <remarks></remarks>
		Private Sub RemoveItem(ByVal item As Item, ByVal stage As Stage, ByVal suppressDataChanged As Boolean)
			Dim myItem As Item = _Items.Find(Function(it) it.Id = item.Id)

			If myItem.IsNew Then
				'If item has never been saved, just remove it from the model
				_Items.Remove(myItem)
				_ItemCounts.RemoveAll(RelevantTurbine.ItemCount.ItemCountsByStagePredicate(stage, myItem))
			Else
				'Remove new item counts
				Dim myItemCounts As List(Of ItemCount) =
				    	_ItemCounts.FindAll(RelevantTurbine.ItemCount.ItemCountsByStagePredicate(stage, myItem))
				For Each myItemCount As ItemCount In myItemCounts
					If myItemCount.IsNew Then
						_ItemCounts.Remove(myItemCount)
					Else
						myItemCount.Deleted = True
					End If
				Next

				'If no more non deleted itemcount exists, mark item as deleted
				If _ItemCounts.Find(RelevantTurbine.ItemCount.ItemCountsByItemPredicate(myItem)) Is Nothing Then
					If Not myItem.Root Then
						myItem.Deleted = True
					ElseIf myItem.Root Then
						myItem.HasRelatedTurbines = False
						_Items.Remove(myItem)
					End If
				End If
			End If

			If Not suppressDataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Change MK Version Expected
		''' </summary>
		''' <param name="value"></param>
		''' <param name="turbine"></param>
		''' <remarks></remarks>
		Public Sub ChangeMKVersionExpected(ByVal value As Short, ByVal turbine As Turbine)
			turbine.MKVersionExpected = value
		End Sub

		''' <summary>
		''' Change MK Version Actual
		''' </summary>
		''' <param name="value"></param>
		''' <param name="turbine"></param>
		''' <remarks></remarks>
		Public Sub ChangeMKVersionActuel(ByVal value As Short, ByVal turbine As Turbine)
			turbine.MKVersionActual = value
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Dim hmm As Boolean = False

				If RootItem IsNot Nothing Then
					hmm = RootItem.IsDirty
				End If


				Return _Turbines.Find(Predicate (Of Turbine).IsDirty) IsNot Nothing Or
				       _Items.Find(Predicate (Of Item).IsDirty) IsNot Nothing Or
				       _ItemCounts.Find(Predicate (Of ItemCount).IsDirty) IsNot Nothing Or hmm
			End Get
		End Property

		''' <summary>
		''' Stages
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Stages() As List(Of Stage)
			Get
				Return _Stages
			End Get
		End Property

		Public Property StageToFind() As Stage
			Get
				Return _stageToFind
			End Get
			Set(ByVal value As Stage)
				_stageToFind = value
			End Set
		End Property

		''' <summary>
		''' Turbines
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Turbines() As List(Of Turbine)
			Get
				Return _Turbines.FindAll(Predicate (Of Turbine).NotDeleted)
			End Get
		End Property

		''' <summary>
		''' Deleted Turbines
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedTurbines() As List(Of Turbine)
			Get
				Return _Turbines.FindAll(Predicate (Of Turbine).Deleted)
			End Get
		End Property

		''' <summary>
		''' Dirty Turbines
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DirtyTurbines() As List(Of Turbine)
			Get
				Return _Turbines.FindAll(Predicate (Of Turbine).IsDirty)
			End Get
		End Property

		''' <summary>
		''' Items
		''' </summary>
		''' <param name="stage"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Items(ByVal stage As Stage) As List(Of Item)
			Get
				' As of Version 4 of CIM Editor we do not care about stages and the relation between items and turbines
				Return _Items.FindAll(Predicate (Of Item).NotDeleted)
				'Return _Items.FindAll(RelevantTurbine.Item.ItemsByStagePredicate(stage, _ItemCounts, _Turbines.FindAll(Genericed.Predicate(Of Turbine).NotDeleted).Count)).FindAll(Genericed.Predicate(Of Item).NotDeleted)
			End Get
		End Property

		''' <summary>
		''' Deleted Items
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedItems() As List(Of Item)
			Get
				Return _Items.FindAll(Predicate (Of Item).Deleted)
			End Get
		End Property

		''' <summary>
		''' Dirty Items
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DirtyItems() As List(Of Item)
			Get
				Return _Items.FindAll(Predicate (Of Item).IsDirty)
			End Get
		End Property

		''' <summary>
		''' Old Items
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OldItems() As List(Of Item)
			Get
				Return _Items.FindAll(Predicate (Of Item).NotDeleted)
			End Get
		End Property

		''' <summary>
		''' ItemCount
		''' </summary>
		''' <param name="stage"></param>
		''' <param name="turbine"></param>
		''' <param name="item"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ItemCount(ByVal stage As Stage, ByVal turbine As Turbine, ByVal item As Item) As ItemCount
			Get
				' As of version 4 of Case Editor we do not care about stages and the relation between turbines and items
				Return _ItemCounts.Find(Function(ic) ic.Item.Equals(item))
				'Return _ItemCounts.Find(Function(ic) ic.Stage.Id.Equals(stage.Id) AndAlso ic.Turbine.Equals(turbine) AndAlso ic.Item.Equals(item))
			End Get
		End Property

		''' <summary>
		''' Dirty ItemCounts
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DirtyItemCounts() As List(Of ItemCount)
			Get
				Return _ItemCounts.FindAll(Predicate (Of ItemCount).IsDirty)
			End Get
		End Property

		''' <summary>
		''' DeletedItemCounts
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedItemCounts() As List(Of ItemCount)
			Get
				Return _ItemCounts.FindAll(Predicate (Of ItemCount).Deleted)
			End Get
		End Property

		''' <summary>
		''' Failed Turbines
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property FailedTurbines() As List(Of Turbine)
			Get
				Dim res As List(Of Turbine) = _Turbines.FindAll(Turbine.FailedPredicate)
				If res.Count = 0 AndAlso _Turbines.Count > 0 Then
					' pick the one with lowest id
					'res = _Turbines.FindAll(Turbine.LowestIdPredicate)
				End If
				Return res
			End Get
			Set(ByVal value As List(Of Turbine))
				For Each myTurbine As Turbine In value
					myTurbine.Relation = Turbine.Relations.Failed
				Next

				'Find old initial failed turbine
				Dim myOldFailedTurbines As List(Of Turbine) = _Turbines.FindAll(Turbine.FailedPredicate)

				'Add new failed turbine
				AddTurbine(value, True)

				'If other turbines are marked as failed, remove them
				If myOldFailedTurbines.Count > 0 Then RemoveTurbine(myOldFailedTurbines, True)

				OnDataChanged()
			End Set
		End Property

		''' <summary>
		''' Failed Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property FailedItem() As Item
			Get
				Return _Items.Find(Item.FailedPredicate)
			End Get
			Set(ByVal value As Item)
				'Set Initial Failed
				value.InitialFailed = True

				'If another item is marked as initial failed, remove it
				Dim myItem As Item = _Items.Find(Item.FailedPredicate)
				If myItem IsNot Nothing Then
					myItem.InitialFailed = False
					RemoveItem(myItem, _Stages(0), True)
				End If

				'Add new initial failed turbine
				AddItem(value, _Stages(0), False)
			End Set
		End Property

		''' <summary>
		''' Root Item
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property RootItem() As Item
			Get
				Return _RootItem
			End Get
			Set(ByVal value As Item)
				Dim dataChanged As Boolean
				'Dim tempItem As System.Collections.Generic.List(Of PManagement.Business.RelevantTurbine.Item) = _Items


				' Marker alle gamle items, s�ledes de fjernes ved save!
				For Each item_ As Item In _Items
					If item_.Root = True Then
						If item_.IsNew Then ' If new then its not in DB. Only remove from list
							'Remove item
							_Items.Remove(item_)
						Else _
' else not new, and must deleted from DB. Items marked with Deleted will be deleted when save button is pushed!
							'Mark item as deleted
							item_.Deleted = True
						End If
					End If
				Next

				'Check whether item already exists. => we dont need to get it from DB
				Dim myItem As Item = _Items.Find(Function(it) it.Id = value.Id)
				If myItem IsNot Nothing Then
					myItem.Root = True
					myItem.Deleted = False
					_RootItem = myItem
					dataChanged = True
				End If

				' If this is the first time a RootItem is being added.
				If myItem Is Nothing OrElse myItem.Id <> value.Id Then
					value.Root = True

					_RootItem = value
					'_RootItem.Deleted = True
					_Items.Add(_RootItem)
					' This is the missing line!
					dataChanged = True

				End If


				''Find existing root item
				'Dim myItem As Item = _RootItem
				'If myItem IsNot Nothing AndAlso myItem.Id <> value.Id Then
				'  'Mark old root item as not root item
				'  myItem.Root = False
				'  If _ItemCounts.FindAll(RelevantTurbine.ItemCount.ItemCountsByItemPredicate(myItem)).Count = 0 Then
				'    If myItem.IsNew Then
				'      'Remove item
				'      _Items.Remove(myItem)
				'    Else
				'      'Mark item as deleted
				'      myItem.Deleted = True
				'    End If
				'  End If
				'  dataChanged = True
				'End If

				''Check whether item already exists
				'myItem = _Items.Find(Function(it) it.Id = value.Id)
				'If myItem IsNot Nothing Then
				'  myItem.Root = True
				'  myItem.Deleted = False
				'  _RootItem = myItem
				'  dataChanged = True
				'End If

				'If myItem Is Nothing OrElse myItem.Id <> value.Id Then
				'  value.Root = True
				'  _RootItem = value
				'  dataChanged = True
				'End If

				If dataChanged Then OnDataChanged()
			End Set
		End Property

#End Region

#Region "Find Predicates"

		''' <summary>
		''' Find Turbine To Remove
		''' </summary>
		''' <param name="turbine"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindTurbineToRemove(ByVal turbine As Turbine) As Boolean
			Return _
				_turbineSearchEntityCollection.FindMatches(
					New PredicateExpression(Case2TurbineMatrixFields.TurbineMatrixId = turbine.Id)).Count = 0 And
				Not turbine.IsNew
		End Function

#End Region
	End Class
End Namespace
