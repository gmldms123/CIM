Namespace RelevantTurbine
	''' <summary>
	''' Stage
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Stage

#Region "Variables"

		Private ReadOnly _Id As Byte
		Private _Name As String

#End Region

#Region "Methods"

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As StageEntity)
			_Id = entity.StageId
			_Name = entity.Name
		End Sub


		Public Sub New(ByVal id As Byte, ByVal name As String)
			_Id = id
			_Name = name
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As StageEntity) As Boolean
			Dim updated As Boolean = False
			If _Name <> entity.Name Then
				_Name = entity.Name
				updated = True
			End If
			Return updated
		End Function

		''' <summary>
		''' ToString
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides Function ToString() As String
			Return _Name
		End Function

#End Region

#Region "Properties"

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Byte
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

#End Region
	End Class
End Namespace
