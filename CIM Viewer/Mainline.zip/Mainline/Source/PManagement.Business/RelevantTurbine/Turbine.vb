Imports PManagement.Business.BaseClasses

Namespace RelevantTurbine
	''' <summary>
	''' Turbine
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Turbine
		Inherits BaseObject

#Region "Constants"

		Public Const NOTAVAILABLE As String = "N/A"
		Public Const RotorDiameterUnit As String = "M"
		Public Const NominelPowerUnit As String = "kW"
		Public Const VoltageUnit As String = "V"
		Public Const FrequencyUnit As String = "Hz"
		Public Const SmallGeneratorUnit As String = "kW"

#End Region

#Region "Enums"

		''' <summary>
		''' Relations
		''' </summary>
		''' <remarks></remarks>
			Public Enum Relations
			Failed
			Related
		End Enum

#End Region

#Region "Predicates"

		Public Shared _
			FailedPredicate As Predicate(Of Turbine) = Function(t) Not t.Deleted AndAlso t.Relation = Relations.Failed

		Public Shared FailedWithDeletedPredicate As Predicate(Of Turbine) = Function(t) t.Relation = Relations.Failed

#End Region

#Region "Variables"

		Private ReadOnly _myId As Long = - 1
		Private _Relation As Relations = Relations.Related
		Friend _RelationIsDirty As Boolean

		'TurbineMKVersion
		Private _MKVersionExpected As Short
		Private _MKVersionExpectedIsDirty As Boolean
		Private _MKVersionActual As Short
		Private _MKVersionActualIsDirty As Boolean

		'TurbineMatrix
		Private _TurbineId As Nullable(Of Long)
		Private _Turbine As String
		Private _RotorDiameterId As Nullable(Of Long)
		Private _RotorDiameter As Decimal
		Private _NominelPowerId As Nullable(Of Long)
		Private _NominelPower As Integer
		Private _VoltageId As Nullable(Of Long)
		Private _Voltage As Integer
		Private _PowerRegulationId As Nullable(Of Long)
		Private _PowerRegulation As String
		Private _FrequencyId As Nullable(Of Long)
        Private _Frequency As String
		Private _SmallGeneratorId As Nullable(Of Long)
		Private _SmallGenerator As Integer
		Private _TemperatureVariantId As Nullable(Of Long)
		Private _TemperatureVariant As String
		Private _MarkVersionId As Nullable(Of Long)
		Private _MarkVersion As String
		Private _PlacementId As Nullable(Of Long)
		Private _Placement As String
		Private _ManufacturerId As Nullable(Of Long)
		Private _Manufacturer As String
		Private _OldId As Nullable(Of Long)
		Private _Old As String
		Private _Comment As String

#End Region

#Region "Methods"

		''' <summary>
		''' New (Old CIM Turbine)
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As OldCimturbineEntity)
			_myId = entity.OldCimturbineId
			_Turbine = entity.Name
		End Sub

		''' <summary>
		''' New (TurbineMatrix)
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As TurbineMatrixEntity)
			_myId = entity.TurbineMatrixId
			If entity.TurbineId.HasValue Then
				_TurbineId = entity.Turbine.TurbineId
				_Turbine = entity.Turbine.Turbine
			End If
			If entity.TurbineRotorDiameterId.HasValue Then
				_RotorDiameterId = entity.TurbineRotorDiameter.TurbineRotorDiameterId
				_RotorDiameter = entity.TurbineRotorDiameter.RotorDiameter
			End If
			If entity.TurbineNominelPowerId.HasValue Then
				_NominelPowerId = entity.TurbineNominelPower.TurbineNominelPowerId
				_NominelPower = entity.TurbineNominelPower.NominelPower
			End If
			If entity.TurbineVoltageId.HasValue Then
				_VoltageId = entity.TurbineVoltage.TurbineVoltageId
				_Voltage = entity.TurbineVoltage.Voltage
			End If
			If entity.TurbinePowerRegulationId.HasValue Then
				_PowerRegulationId = entity.TurbinePowerRegulation.TurbinePowerRegulationId
				_PowerRegulation = entity.TurbinePowerRegulation.PowerRegulation
			End If
			If entity.TurbineFrequencyId.HasValue Then
				_FrequencyId = entity.TurbineFrequency.TurbineFrequencyId
				_Frequency = entity.TurbineFrequency.Frequency
			End If
			If entity.TurbineSmallGeneratorId.HasValue Then
				_SmallGeneratorId = entity.TurbineSmallGenerator.TurbineSmallGeneratorId
				_SmallGenerator = entity.TurbineSmallGenerator.SmallGenerator
			End If
			If entity.TurbineTemperatureVariantId.HasValue Then
				_TemperatureVariantId = entity.TurbineTemperatureVariant.TurbineTemperatureVariantId
				_TemperatureVariant = entity.TurbineTemperatureVariant.TemperatureVariant
			End If
			If entity.TurbineMarkVersionId.HasValue Then
				_MarkVersionId = entity.TurbineMarkVersion.TurbineMarkVersionId
				_MarkVersion = entity.TurbineMarkVersion.MarkVersion
			End If
			If entity.TurbinePlacementId.HasValue Then
				_PlacementId = entity.TurbinePlacement.TurbinePlacementId
				_Placement = entity.TurbinePlacement.Placement
			End If
			If entity.TurbineManufacturerId.HasValue Then
				_ManufacturerId = entity.TurbineManufacturer.TurbineManufacturerId
				_Manufacturer = entity.TurbineManufacturer.Manufacturer
			End If
			_Comment = entity.Comment
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As Case2TurbineMatrixEntity)
			Me.New(entity.TurbineMatrix)
			_Id = entity.Case2TurbineMatrixId
			If entity.InitialFailed Then _Relation = Relations.Failed
			_MKVersionExpected = entity.MkversionExpected
			_MKVersionActual = entity.MkversionActual
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As Case2TurbineMatrixEntity) As Boolean
			Dim updated As Boolean
			'Relation Id
			If _Id <> entity.Case2TurbineMatrixId Then
				_Id = entity.Case2TurbineMatrixId
				updated = True
			End If
			'Initial Failed
			Select Case _Relation
				Case Relations.Failed
					If Not _RelationIsDirty AndAlso Not entity.InitialFailed Then
						_Relation = Relations.Related
						updated = True
					End If
				Case Relations.Related
					If Not _RelationIsDirty AndAlso entity.InitialFailed Then
						_Relation = Relations.Failed
						updated = True
					End If
				Case Else
					Throw New ApplicationException(String.Format("Relation type ""{0}"" not supported!", _Relation))
			End Select
			'MKVersionExpected
			If Not _MKVersionExpectedIsDirty AndAlso _MKVersionExpected <> entity.MkversionExpected Then
				_MKVersionExpected = entity.MkversionExpected
				updated = True
			End If
			'MKVersionActual
			If Not _MKVersionActualIsDirty AndAlso _MKVersionActual <> entity.MkversionActual Then
				_MKVersionActual = entity.MkversionActual
				updated = True
			End If
			'Turbine
			If Not _TurbineId.Equals(entity.TurbineMatrix.TurbineId) Then
				_TurbineId = entity.TurbineMatrix.TurbineId
				updated = True
			End If
			If entity.TurbineMatrix.Turbine IsNot Nothing AndAlso _Turbine <> entity.TurbineMatrix.Turbine.Turbine Then
				_Turbine = entity.TurbineMatrix.Turbine.Turbine
				updated = True
			End If
			'Rotor Diameter
			If Not _RotorDiameterId.Equals(entity.TurbineMatrix.TurbineRotorDiameterId) Then
				_RotorDiameterId = entity.TurbineMatrix.TurbineRotorDiameterId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbineRotorDiameter IsNot Nothing AndAlso
				_RotorDiameter <> entity.TurbineMatrix.TurbineRotorDiameter.RotorDiameter Then
				_RotorDiameter = entity.TurbineMatrix.TurbineRotorDiameter.RotorDiameter
				updated = True
			End If
			'Nominel Power
			If Not _NominelPowerId.Equals(entity.TurbineMatrix.TurbineNominelPowerId) Then
				_NominelPowerId = entity.TurbineMatrix.TurbineNominelPowerId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbineNominelPower IsNot Nothing AndAlso
				_NominelPower <> entity.TurbineMatrix.TurbineNominelPower.NominelPower Then
				_NominelPower = entity.TurbineMatrix.TurbineNominelPower.NominelPower
				updated = True
			End If
			'Voltage
			If Not _VoltageId.Equals(entity.TurbineMatrix.TurbineVoltageId) Then
				_VoltageId = entity.TurbineMatrix.TurbineVoltageId
				updated = True
			End If
			If entity.TurbineMatrix.TurbineVoltage IsNot Nothing AndAlso _Voltage <> entity.TurbineMatrix.TurbineVoltage.Voltage _
				Then
				_Voltage = entity.TurbineMatrix.TurbineVoltage.Voltage
				updated = True
			End If
			'Power Regulation
			If Not _PowerRegulationId.Equals(entity.TurbineMatrix.TurbinePowerRegulationId) Then
				_PowerRegulationId = entity.TurbineMatrix.TurbinePowerRegulationId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbinePowerRegulation IsNot Nothing AndAlso
				_PowerRegulation <> entity.TurbineMatrix.TurbinePowerRegulation.PowerRegulation Then
				_PowerRegulation = entity.TurbineMatrix.TurbinePowerRegulation.PowerRegulation
				updated = True
			End If
			'Frequency
			If Not _FrequencyId.Equals(entity.TurbineMatrix.TurbineFrequencyId) Then
				_FrequencyId = entity.TurbineMatrix.TurbineFrequencyId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbineFrequency IsNot Nothing AndAlso
				_Frequency <> entity.TurbineMatrix.TurbineFrequency.Frequency Then
				_Frequency = entity.TurbineMatrix.TurbineFrequency.Frequency
				updated = True
			End If
			'Small Generator
			If Not _SmallGeneratorId.Equals(entity.TurbineMatrix.TurbineSmallGeneratorId) Then
				_SmallGeneratorId = entity.TurbineMatrix.TurbineSmallGeneratorId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbineSmallGenerator IsNot Nothing AndAlso
				_SmallGenerator <> entity.TurbineMatrix.TurbineSmallGenerator.SmallGenerator Then
				_SmallGenerator = entity.TurbineMatrix.TurbineSmallGenerator.SmallGenerator
				updated = True
			End If
			'Temperature Variant
			If Not _TemperatureVariantId.Equals(entity.TurbineMatrix.TurbineTemperatureVariantId) Then
				_TemperatureVariantId = entity.TurbineMatrix.TurbineTemperatureVariantId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbineTemperatureVariant IsNot Nothing AndAlso
				_TemperatureVariant <> entity.TurbineMatrix.TurbineTemperatureVariant.TemperatureVariant Then
				_TemperatureVariant = entity.TurbineMatrix.TurbineTemperatureVariant.TemperatureVariant
				updated = True
			End If
			'Mark Version
			If Not _MarkVersionId.Equals(entity.TurbineMatrix.TurbineMarkVersionId) Then
				_MarkVersionId = entity.TurbineMatrix.TurbineMarkVersionId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbineMarkVersion IsNot Nothing AndAlso
				_MarkVersion <> entity.TurbineMatrix.TurbineMarkVersion.MarkVersion Then
				_MarkVersion = entity.TurbineMatrix.TurbineMarkVersion.MarkVersion
				updated = True
			End If
			'Placement
			If Not _PlacementId.Equals(entity.TurbineMatrix.TurbinePlacementId) Then
				_PlacementId = entity.TurbineMatrix.TurbinePlacementId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbinePlacement IsNot Nothing AndAlso
				_Placement <> entity.TurbineMatrix.TurbinePlacement.Placement Then
				_Placement = entity.TurbineMatrix.TurbinePlacement.Placement
				updated = True
			End If
			'Manufacturer
			If Not _ManufacturerId.Equals(entity.TurbineMatrix.TurbineManufacturerId) Then
				_ManufacturerId = entity.TurbineMatrix.TurbineManufacturerId
				updated = True
			End If
			If _
				entity.TurbineMatrix.TurbineManufacturer IsNot Nothing AndAlso
				_Manufacturer <> entity.TurbineMatrix.TurbineManufacturer.Manufacturer Then
				_Manufacturer = entity.TurbineMatrix.TurbineManufacturer.Manufacturer
				updated = True
			End If
			'Comment
			If _Comment <> entity.TurbineMatrix.Comment Then
				_Comment = entity.TurbineMatrix.Comment
				updated = True
			End If
			Return updated
		End Function

		''' <summary>
		''' ToString
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides Function ToString() As String
			If Not _TurbineId.HasValue And Turbine.Length > 0 Then
				'Old CIM Turbine info
				Return _Turbine
			Else
				Dim sb As New StringBuilder()

				If _TurbineId.HasValue Then sb.Append(_Turbine)

				If _PowerRegulationId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(_PowerRegulation)
				End If

				If _NominelPowerId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(_NominelPower, NominelPowerUnit))
				End If

				If _VoltageId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(_Voltage, VoltageUnit))
				End If

				If _FrequencyId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(_Frequency, FrequencyUnit))
				End If

				Return sb.ToString()
			End If
		End Function

		''' <summary>
		''' Description
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Description() As String
			Get
				Dim sb As New StringBuilder()

				If _RotorDiameterId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(_RotorDiameter, RotorDiameterUnit))
				End If

				If _SmallGeneratorId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(_SmallGenerator, SmallGeneratorUnit))
				End If

				If _TemperatureVariantId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(_TemperatureVariant)
				End If

				If _MarkVersionId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(_MarkVersion)
				End If

				If _PlacementId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(_Placement)
				End If

				If _ManufacturerId.HasValue Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(_Manufacturer)
				End If

				Return sb.ToString()
			End Get
		End Property

		''' <summary>
		''' LCDDescription
		''' </summary>
		''' <param name="Turbines">List of turbines with the same turbine property</param>
		''' <returns>Description as Lowest Common Denominator of properties</returns>
		''' <remarks></remarks>
		Public Shared Function LCDDescription(ByVal Turbines As List(Of Turbine)) As String
			Dim sb As New StringBuilder()
			If Turbines.Count > 0 AndAlso Turbines(0).TurbineId.HasValue Then
				'Throw argument exception if list of turbines contains multiple turbine types
				'If Turbines.FindAll(Function(t) t.Turbine = Turbines(0).Turbine).Count <> Turbines.Count Then Throw New ArgumentException("The list of turbines contains multiple turbine types!")

				If Turbines.FindAll(Function(t) t.Turbine = Turbines(0).Turbine).Count <> Turbines.Count Then
					sb.Append(String.Join("/", Turbines.Select(Function(t) t.Turbine).Distinct().ToArray()))
				Else
					sb.Append(Turbines(0).Turbine)
				End If

				If _
					Turbines(0).PowerRegulationId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.PowerRegulation = Turbines(0).PowerRegulation).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(Turbines(0).PowerRegulation)
				End If

				If _
					Turbines(0).NominelPowerId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.NominelPower = Turbines(0).NominelPower).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(Turbines(0).NominelPower, NominelPowerUnit))
				End If

				If _
					Turbines(0).VoltageId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.Voltage = Turbines(0).Voltage).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(Turbines(0).Voltage, VoltageUnit))
				End If

				If _
					Turbines(0).FrequencyId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.Frequency = Turbines(0).Frequency).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(Turbines(0).Frequency, FrequencyUnit))
				End If

				If _
					Turbines(0).RotorDiameterId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.RotorDiameter = Turbines(0).RotorDiameter).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(Turbines(0).RotorDiameter, RotorDiameterUnit))
				End If

				If _
					Turbines(0).SmallGeneratorId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.SmallGenerator = Turbines(0).SmallGenerator).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(String.Concat(Turbines(0).SmallGenerator, SmallGeneratorUnit))
				End If

				If _
					Turbines(0).TemperatureVariantId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.TemperatureVariant = Turbines(0).TemperatureVariant).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(Turbines(0).TemperatureVariant)
				End If

				If _
					Turbines(0).MarkVersionId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.MarkVersion = Turbines(0).MarkVersion).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(Turbines(0).MarkVersion)
				End If

				If _
					Turbines(0).PlacementId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.Placement = Turbines(0).Placement).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(Turbines(0).Placement)
				End If

				If _
					Turbines(0).ManufacturerId.HasValue AndAlso
					Turbines.FindAll(Function(t) t.Manufacturer = Turbines(0).Manufacturer).Count = Turbines.Count Then
					If sb.Length > 0 Then sb.Append("-")
					sb.Append(Turbines(0).Manufacturer)
				End If
			End If
			Return sb.ToString()
		End Function

#End Region

#Region "Properties"

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' RelationId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RelationId() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' IsDirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return MyBase.IsDirty Or
				       _RelationIsDirty Or
				       _MKVersionExpectedIsDirty Or
				       _MKVersionActualIsDirty
			End Get
		End Property

		''' <summary>
		''' Relation
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Relation() As Relations
			Get
				Return _Relation
			End Get
			Set(ByVal value As Relations)
				If _Relation <> value Then
					_Relation = value
					_RelationIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Mark Version Expected
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property MKVersionExpected() As Short
			Get
				Return _MKVersionExpected
			End Get
			Set(ByVal value As Short)
				If _MKVersionExpected <> value Then
					_MKVersionExpected = value
					_MKVersionExpectedIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' Mark Version Actual
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property MKVersionActual() As Short
			Get
				Return _MKVersionActual
			End Get
			Set(ByVal value As Short)
				If _MKVersionActual <> value Then
					_MKVersionActual = value
					_MKVersionActualIsDirty = True
				End If
			End Set
		End Property

		''' <summary>
		''' TurbineId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TurbineId() As Nullable(Of Long)
			Get
				Return _TurbineId
			End Get
		End Property

		''' <summary>
		''' Turbine
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Turbine() As String
			Get
				Return _Turbine
			End Get
		End Property

		''' <summary>
		''' Turbine Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TurbineDescriptive() As String
			Get
				If TurbineId.HasValue Then
					Return _Turbine
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' RotorDiameterId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RotorDiameterId() As Nullable(Of Long)
			Get
				Return _RotorDiameterId
			End Get
		End Property

		''' <summary>
		''' RotorDiameter
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RotorDiameter() As Decimal
			Get
				Return _RotorDiameter
			End Get
		End Property

		''' <summary>
		''' Rotor Diameter Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RotorDiameterDescriptive() As String
			Get
				If RotorDiameterId.HasValue Then
					Return _RotorDiameter.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' NominelPowerId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NominelPowerId() As Nullable(Of Long)
			Get
				Return _NominelPowerId
			End Get
		End Property

		''' <summary>
		''' NominelPower
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NominelPower() As Integer
			Get
				Return _NominelPower
			End Get
		End Property

		''' <summary>
		''' Nominel Power Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property NominelPowerDescriptive() As String
			Get
				If NominelPowerId.HasValue Then
					Return _NominelPower.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' VoltageId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property VoltageId() As Nullable(Of Long)
			Get
				Return _VoltageId
			End Get
		End Property

		''' <summary>
		''' Voltage
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Voltage() As Integer
			Get
				Return _Voltage
			End Get
		End Property

		''' <summary>
		''' Voltage Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property VoltageDescriptive() As String
			Get
				If VoltageId.HasValue Then
					Return _Voltage.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' PowerRegulationId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PowerRegulationId() As Nullable(Of Long)
			Get
				Return _PowerRegulationId
			End Get
		End Property

		''' <summary>
		''' PowerRegulation
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PowerRegulation() As String
			Get
				Return _PowerRegulation
			End Get
		End Property

		''' <summary>
		''' Power Regulation Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PowerRegulationDescriptive() As String
			Get
				If PowerRegulationId.HasValue Then
					Return _PowerRegulation.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' FrequencyId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property FrequencyId() As Nullable(Of Long)
			Get
				Return _FrequencyId
			End Get
		End Property

		''' <summary>
		''' Frequency
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
        Public ReadOnly Property Frequency() As String
            Get
                Return _Frequency
            End Get
        End Property

		''' <summary>
		''' Frequency Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property FrequencyDescriptive() As String
			Get
				If FrequencyId.HasValue Then
					Return _Frequency.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' SmallGeneratorId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SmallGeneratorId() As Nullable(Of Long)
			Get
				Return _SmallGeneratorId
			End Get
		End Property

		''' <summary>
		''' SmallGenerator
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SmallGenerator() As Integer
			Get
				Return _SmallGenerator
			End Get
		End Property

		''' <summary>
		''' Small Generator Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SmallGeneratorDescriptive() As String
			Get
				If SmallGeneratorId.HasValue Then
					Return _SmallGenerator.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' TemperatureVariantId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TemperatureVariantId() As Nullable(Of Long)
			Get
				Return _TemperatureVariantId
			End Get
		End Property

		''' <summary>
		''' TemperatureVariant
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TemperatureVariant() As String
			Get
				Return _TemperatureVariant
			End Get
		End Property

		''' <summary>
		''' Temperature Variant Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property TemperatureVariantDescriptive() As String
			Get
				If TemperatureVariantId.HasValue Then
					Return _TemperatureVariant.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' MarkVersionId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MarkVersionId() As Nullable(Of Long)
			Get
				Return _MarkVersionId
			End Get
		End Property

		''' <summary>
		''' MarkVersion
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MarkVersion() As String
			Get
				Return _MarkVersion
			End Get
		End Property

		''' <summary>
		''' Mark Version Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MarkVersionDescriptive() As String
			Get
				If MarkVersionId.HasValue Then
					Return _MarkVersion.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' PlacementId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PlacementId() As Nullable(Of Long)
			Get
				Return _PlacementId
			End Get
		End Property

		''' <summary>
		''' Placement
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Placement() As String
			Get
				Return _Placement
			End Get
		End Property

		''' <summary>
		''' Placement Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property PlacementDescriptive() As String
			Get
				If PlacementId.HasValue Then
					Return _Placement.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' ManufacturerId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ManufacturerId() As Nullable(Of Long)
			Get
				Return _ManufacturerId
			End Get
		End Property

		''' <summary>
		''' Manufacturer
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Manufacturer() As String
			Get
				Return _Manufacturer
			End Get
		End Property

		''' <summary>
		''' Manufacturer Descriptive Text
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ManufacturerDescriptive() As String
			Get
				If ManufacturerId.HasValue Then
					Return _Manufacturer.ToString()
				Else
					Return NOTAVAILABLE
				End If
			End Get
		End Property

		''' <summary>
		''' OldId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property OldId() As Nullable(Of Long)
			Get
				Return _OldId
			End Get
		End Property

		''' <summary>
		''' Old
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Old() As String
			Get
				Return _Old
			End Get
		End Property

		''' <summary>
		''' Comment
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Comment() As String
			Get
				Return _Comment
			End Get
		End Property

#End Region
	End Class
End Namespace
