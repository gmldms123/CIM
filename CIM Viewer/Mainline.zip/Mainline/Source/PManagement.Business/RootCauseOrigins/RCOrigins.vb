﻿Imports PManagement.Business.BaseClasses

Namespace RootCauseOrigins
	Public Class RootCauseOrigins
		Inherits BaseObject

		Friend Sub New()
		End Sub
	End Class
End Namespace