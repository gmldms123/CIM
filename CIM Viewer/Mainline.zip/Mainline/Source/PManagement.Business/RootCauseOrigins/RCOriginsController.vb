﻿'Imports System.Linq

Namespace RootCauseOrigins
	''' <summary>
	''' Manage all interaction with Finance report data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public Class RCOriginsController
		Protected _Environment As Environment
		Protected _Context As PmanContext

		Public Enum Selections
			RCOrigins
			Responsible
			PBU
		End Enum

		''' <summary>
		''' Initialize
		''' </summary>
		''' <remarks></remarks>
		Public Sub New(ByVal environment As Environment, ByVal context As PmanContext)
			_Environment = environment
			_Context = context
		End Sub

		''' <summary>
		''' Find List Items
		''' </summary>
		''' <param name="field"></param>
		''' <param name="rcorigins"></param>
		''' <param name="responsible"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property FindItems(ByVal field As Selections,
		                                   ByVal rcorigins As List(Of KeyValuePair(Of String, Double)),
		                                   ByVal responsible As List(Of KeyValuePair(Of String, Double))) _
			As List(Of KeyValuePair(Of String, Double))
			Get

				Dim li As New List(Of KeyValuePair(Of String, Double))
				'        li
				Return li
			End Get
		End Property

		Private ds As TypedRCOrigins

		Public Sub LoadRCOriginsFilterData()
			If (ds Is Nothing) Then
				Try
					Dim con As SqlConnection = New SqlConnection(_Environment.PManagement_ConnectionString)
					ds = New TypedRCOrigins
					Dim da As SqlDataAdapter = New SqlDataAdapter("select * from vwCIM_RCOrigins", con)
					da.Fill(ds, "vwCIM_RCOrigins")
				Catch ex As Exception
				End Try
			End If
		End Sub

		Public ReadOnly Property GetFilterData(ByVal field As Selections,
		                                       ByVal RCOrigins As List(Of KeyValuePair(Of String, Double)),
		                                       ByVal Responsible As List(Of KeyValuePair(Of String, Double))) _
			As IEnumerable(Of TypedRCOrigins.vwCIM_RCOriginsRow)
			Get
				LoadRCOriginsFilterData()

				Dim subquery As IEnumerable(Of TypedRCOrigins.vwCIM_RCOriginsRow) = New List(Of TypedRCOrigins.vwCIM_RCOriginsRow)
				Dim subresult As IEnumerable(Of TypedRCOrigins.vwCIM_RCOriginsRow)
				Dim result As IEnumerable(Of TypedRCOrigins.vwCIM_RCOriginsRow) = New List(Of TypedRCOrigins.vwCIM_RCOriginsRow)

				Dim index As Integer
				'        Dim _EController As New Business.Administration.SBUUploadTool.Controller(_Environment, _Context, asd)

				Try

					'RCOrigins
					If field = Selections.RCOrigins Then

						subresult = New List(Of TypedRCOrigins.vwCIM_RCOriginsRow)

						For index = 0 To RCOrigins.Count - 1
							subquery = (From w In result _
								Select w Distinct).ToList
						Next
						subresult = subresult.Union(subquery)
						result = subresult
					End If


					'Responsible
					If field = Selections.Responsible Then

						subresult = New List(Of TypedRCOrigins.vwCIM_RCOriginsRow)

						For index = 0 To RCOrigins.Count - 1
							subquery = (From w In result _
								Where (w.RCOriginsId = RCOrigins.Item(index).Value) _
								Select w Distinct).ToList
						Next
						subresult = subresult.Union(subquery)
						result = subresult
					End If

					'PBU
					If field = Selections.PBU Then

						subresult = New List(Of TypedRCOrigins.vwCIM_RCOriginsRow)

						For index = 0 To RCOrigins.Count - 1
							subquery = (From w In result _
								Where (w.RCOriginsId = RCOrigins.Item(index).Value _
								       And w.RCOriginsResponsibleId = Responsible.Item(index).Value) _
								Select w Distinct).ToList
						Next
						subresult = subresult.Union(subquery)
						result = subresult
					End If
				Catch ex As Exception
					Throw New ApplicationException("A filter operation failed. Please try again.")
				End Try
				Return result
			End Get
		End Property
	End Class
End Namespace

