﻿Namespace RootCauseOrigins
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Public Sub New()
		End Sub

		Public Overrides Sub Clear()
		End Sub

		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
			End Get
		End Property
	End Class
End Namespace
