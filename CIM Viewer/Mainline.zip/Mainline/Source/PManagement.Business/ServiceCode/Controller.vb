Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace ServiceCode
	''' <summary>
	''' Manage all interaction with relation data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model
		Private _changeLogService As IChangeLogService

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' Service Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ServiceCodes() As List(Of ServiceCode)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Try
						Dim ec As New EntityCollection(Of Case2ServiceCodeEntity)(New Case2ServiceCodeEntityFactory())
						Dim fb As New RelationPredicateBucket()
						If _Context.CaseId.HasValue Then fb.PredicateExpression.Add(Case2ServiceCodeFields.CaseId = _Context.CaseId)
						Dim pp As New PrefetchPath2(DirectCast(EntityType.Case2ServiceCodeEntity, Integer))
						pp.Add(Case2ServiceCodeEntity.PrefetchPathServiceCode).SubPath.Add(ServiceCodeEntity.PrefetchPathServiceGroup)
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Return _Model.ServiceCodes
			End Get
		End Property

		''' <summary>
		''' May Add Service Code
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddServiceCode() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_ServiceCodes_Add)
			End Get
		End Property

		''' <summary>
		''' May Remove Service Code
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveServiceCode() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_ServiceCodes_Remove)
			End Get
		End Property

		''' <summary>
		''' Add Service Code
		''' </summary>
		''' <param name="serviceCode"></param>
		''' <remarks></remarks>
		Public Sub AddServiceCode(ByRef serviceCode As ServiceCode)
			_Model.AddServiceCode(serviceCode)
		End Sub

		''' <summary>
		''' Remove Service Code
		''' </summary>
		''' <param name="serviceCode"></param>
		''' <remarks></remarks>
		Public Sub RemoveServiceCode(ByRef serviceCode As ServiceCode)
			_Model.RemoveServiceCode(serviceCode)
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			'Persist to database
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try

					'Service Codes to delete
					If _Model.DeletedServiceCodes.Count > 0 Then
						Dim fb As New RelationPredicateBucket()
						For Each ServiceCode As ServiceCode In _Model.DeletedServiceCodes
							fb.PredicateExpression.AddWithOr(Case2ServiceCodeFields.Case2ServiceCodeId = ServiceCode.RelationId)
						Next
						daa.StartTransaction(IsolationLevel.Serializable, "RelevantTurbineTransaction")
						daa.DeleteEntitiesDirectly(GetType(Case2ServiceCodeEntity), fb)
						Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
						                                                                _Context.UserParticipant.ParticipantId,
						                                                                ChangeTypeEnum.AnyChanges, String.Empty,
						                                                                String.Empty,
						                                                                [Enum].Format(GetType(AnyChangesEnum),
						                                                                              AnyChangesEnum.ServiceCodes, "d").
						                                                               	ToString)
						If (vs.GetErrors.Count > 0) Then
							Throw New Exception(vs.ToString())
						End If
					End If

					'Service Codes to save
					If _Model.DirtyServiceCodes.Count > 0 Then
						Dim ecServiceCode As New EntityCollection(Of Case2ServiceCodeEntity)(New Case2ServiceCodeEntityFactory())
						For Each serviceCode As ServiceCode In _Model.DirtyServiceCodes
							If Not serviceCode.Deleted Then
								Dim entity As Case2ServiceCodeEntity
								If serviceCode.IsNew Then
									entity = ecServiceCode.AddNew()
									entity.CaseId = _Context.CaseId.Value
									entity.ServiceCodeId = serviceCode.Id
								Else
									entity = New Case2ServiceCodeEntity(serviceCode.RelationId)
									daa.FetchEntity(entity)
									ecServiceCode.Add(entity)
								End If
							End If
						Next
						If ecServiceCode.Count > 0 Then
							daa.StartTransaction(IsolationLevel.Serializable, "RelevantTurbineTransaction")
							daa.SaveEntityCollection(ecServiceCode, False, False)
							Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
							                                                                _Context.UserParticipant.ParticipantId,
							                                                                ChangeTypeEnum.AnyChanges, String.Empty,
							                                                                String.Empty,
							                                                                [Enum].Format(GetType(AnyChangesEnum),
							                                                                              AnyChangesEnum.ServiceCodes, "d").
							                                                               	ToString)
							If (vs.GetErrors.Count > 0) Then
								Throw New Exception(vs.ToString())
							End If
						End If
					End If

					If daa.IsTransactionInProgress Then daa.Commit()
					Clear()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Catch
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw
				Finally
					daa.CloseConnection()
				End Try
			End Using
			Return New ValidationSummary()
		End Function

#Region "Add Service Code Window"

		''' <summary>
		''' Service Groups
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ServiceGroups() As List(Of ServiceGroup)
			Get
				Dim ec As New EntityCollection(Of ServiceGroupEntity)(New ServiceGroupEntityFactory())
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Try
						Dim fb As IRelationPredicateBucket =
						    	New RelationPredicateBucket(New PredicateExpression(ServiceGroupFields.Deleted = DBNull.Value))
						Dim pp As New PrefetchPath2(DirectCast(EntityType.ServiceGroupEntity, Integer))
						pp.Add(ServiceGroupEntity.PrefetchPathServiceCode, 0,
						       New PredicateExpression(ServiceCodeFields.Deleted = DBNull.Value))
						daa.FetchEntityCollection(ec, fb, pp)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Dim li As New List(Of ServiceGroup)
				For i As Integer = 0 To ec.Count - 1
					Dim serviceGroup As New ServiceGroup(ec(i))
					Dim serviceCodes As New List(Of ServiceCode)
					For j As Integer = 0 To ec(i).ServiceCode.Count - 1
						serviceCodes.Add(New ServiceCode(ec(i).ServiceCode(j)))
					Next
					serviceGroup.ServiceCodes = serviceCodes
					li.Add(serviceGroup)
				Next

				Return li
			End Get
		End Property

#End Region
	End Class
End Namespace
