Imports PManagement.Business.Genericed

Namespace ServiceCode
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Private ReadOnly _ServiceCodes As New List(Of ServiceCode)

		Private _searchEntityCollection As EntityCollection(Of Case2ServiceCodeEntity) = Nothing
		Private _idToFind As Long

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _ServiceCodes.Find(Predicate (Of ServiceCode).IsDirty) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_ServiceCodes.Clear()
			OnDataChanged()
		End Sub

		''' <summary>
		''' Service Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ServiceCodes() As List(Of ServiceCode)
			Get
				Return _ServiceCodes.FindAll(New System.Predicate(Of ServiceCode)(AddressOf FindServiceCode))
			End Get
		End Property

		''' <summary>
		''' Deleted Service Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedServiceCodes() As List(Of ServiceCode)
			Get
				Return _ServiceCodes.FindAll(Predicate (Of ServiceCode).Deleted)
			End Get
		End Property

		''' <summary>
		''' Dirty Service Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DirtyServiceCodes() As List(Of ServiceCode)
			Get
				Return _ServiceCodes.FindAll(Predicate (Of ServiceCode).IsDirty)
			End Get
		End Property

		''' <summary>
		''' Inject Service Codes
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByRef ec As EntityCollection(Of Case2ServiceCodeEntity))
			Dim dataChanged As Boolean = False

			For i As Integer = 0 To ec.Count - 1
				_idToFind = ec(i).ServiceCodeId
				Dim serviceCode As ServiceCode =
				    	_ServiceCodes.Find(New System.Predicate(Of ServiceCode)(AddressOf FindServiceCodeById))
				If serviceCode Is Nothing Then
					'Add
					serviceCode = New ServiceCode(ec(i))
					_ServiceCodes.Insert(i, serviceCode)
					dataChanged = True
				Else
					'Update
					dataChanged = dataChanged Or serviceCode.Update(ec(i))
				End If
			Next

			_searchEntityCollection = ec
			dataChanged = dataChanged Or
			              _ServiceCodes.RemoveAll(New System.Predicate(Of ServiceCode)(AddressOf FindServiceCodeToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Add Service Code
		''' </summary>
		''' <param name="serviceCode"></param>
		''' <remarks></remarks>
		Public Sub AddServiceCode(ByRef serviceCode As ServiceCode)
			_idToFind = serviceCode.Id
			Dim existingServiceCode As ServiceCode =
			    	_ServiceCodes.Find(New System.Predicate(Of ServiceCode)(AddressOf FindServiceCodeById))

			If existingServiceCode Is Nothing Then
				'Add Service Code
				existingServiceCode = serviceCode
				_ServiceCodes.Add(existingServiceCode)
			Else
				'Undelete Service Code
				existingServiceCode.Deleted = False
			End If

			OnDataChanged()
		End Sub

		''' <summary>
		''' Remove Service Code
		''' </summary>
		''' <param name="serviceCode"></param>
		''' <remarks></remarks>
		Public Sub RemoveServiceCode(ByRef serviceCode As ServiceCode)
			_idToFind = serviceCode.Id
			Dim existingServiceCode As ServiceCode =
			    	_ServiceCodes.Find(New System.Predicate(Of ServiceCode)(AddressOf FindServiceCodeById))
			If _ServiceCodes.Count > 1 Then
				If Equals(existingServiceCode.IsNew, True) Then
					'Remove Service Code From Model
					_ServiceCodes.Remove(existingServiceCode)
				Else
					'Mark Service Code As Deleted
					existingServiceCode.Deleted = True
				End If
			Else
				Const infoToUser As String = "You cannot remove the last Service Code item, there must be at least one"
				Throw New ApplicationException(infoToUser)
			End If

			OnDataChanged()
		End Sub

		''' <summary>
		''' Find Service Code
		''' </summary>
		''' <param name="serviceCode"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindServiceCode(ByVal serviceCode As ServiceCode) As Boolean
			Return Not serviceCode.Deleted
		End Function

		''' <summary>
		''' Find Service Code By Id
		''' </summary>
		''' <param name="serviceCode"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindServiceCodeById(ByVal serviceCode As ServiceCode) As Boolean
			Return Equals(serviceCode.Id, _idToFind)
		End Function

		''' <summary>
		''' Find Service Code To Remove
		''' </summary>
		''' <param name="serviceCode"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindServiceCodeToRemove(ByVal serviceCode As ServiceCode) As Boolean
			Return _
				_searchEntityCollection.FindMatches(New PredicateExpression(Case2ServiceCodeFields.ServiceCodeId = serviceCode.Id)).
					Count = 0 And
				Not serviceCode.IsNew
		End Function
	End Class
End Namespace
