Imports PManagement.Business.BaseClasses

Namespace ServiceCode
	Public NotInheritable Class ServiceCode
		Inherits BaseObject
		Private ReadOnly _myId As Long = - 1
		Private _ServiceCodeName As String = String.Empty
		Private _ServiceGroupName As String = String.Empty

		''' <summary>
		''' New (Raw Service Code)
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As ServiceCodeEntity)
			_myId = entity.ServiceCodeId
			_ServiceCodeName = entity.Name
			_ServiceGroupName = entity.ServiceGroup.Name
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByRef entity As Case2ServiceCodeEntity)
			_Id = entity.Case2ServiceCodeId
			_myId = entity.ServiceCodeId
			_ServiceCodeName = entity.ServiceCode.Name
			_ServiceGroupName = entity.ServiceCode.ServiceGroup.Name
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As Case2ServiceCodeEntity) As Boolean
			Dim updated As Boolean = False
			If Not Equals(_Id, entity.Case2ServiceCodeId) Then
				_Id = entity.Case2ServiceCodeId
				updated = True
			End If
			If Not Equals(_ServiceCodeName, entity.ServiceCode.Name) Then
				_ServiceCodeName = entity.ServiceCode.Name
				updated = True
			End If
			If Not Equals(_ServiceGroupName, entity.ServiceCode.ServiceGroup.Name) Then
				_ServiceGroupName = entity.ServiceCode.ServiceGroup.Name
				updated = True
			End If
			Return updated
		End Function

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' RelationId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RelationId() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Service Code Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ServiceCodeName() As String
			Get
				Return _ServiceCodeName
			End Get
		End Property

		''' <summary>
		''' Service Group Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ServiceGroupName() As String
			Get
				Return _ServiceGroupName
			End Get
		End Property
	End Class
End Namespace
