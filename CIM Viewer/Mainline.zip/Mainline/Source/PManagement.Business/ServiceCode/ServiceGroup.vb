Namespace ServiceCode
	Public NotInheritable Class ServiceGroup
		Private ReadOnly _Id As Long = - 1
		Private ReadOnly _Name As String = String.Empty
		Private _ServiceCodes As New List(Of ServiceCode)

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByRef entity As ServiceGroupEntity)
			_Id = entity.ServiceGroupId
			_Name = entity.Name
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Service Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property ServiceCodes() As List(Of ServiceCode)
			Get
				Return _ServiceCodes
			End Get
			Set(ByVal value As List(Of ServiceCode))
				_ServiceCodes = value
			End Set
		End Property
	End Class
End Namespace
