Imports PManagement.Business.BaseClasses

Namespace Supplier.ComponentType
	Public NotInheritable Class ComponentType
		Inherits BaseObject
		Implements IComparable(Of ComponentType)

#Region "Private Fields"

		Private ReadOnly _myId As Long = - 1
		Private _Name As String = String.Empty
		Private _Supplier As Supplier = Nothing
		Private _DeletedInRepository As Boolean
		Private _IsDirtyInRepository As Boolean

#End Region

#Region "Constructors"

		''' <summary>
		''' Initializes a new instance of the <see cref="ComponentType" /> class.
		''' </summary>
		Public Sub New()
		End Sub

		''' <summary>
		''' Initializes a new instance of the <see cref="ComponentType" /> class.
		''' </summary>
		''' <param name="name">The name.</param>
		Public Sub New(ByVal name As String)
			_Name = name
		End Sub

		Public Sub New(ByVal Original As ComponentType, ByVal supplier As Supplier)
			_myId = Original._myId
			_Id = Original.RelationId
			_Name = Original.Name
			_Supplier = supplier
		End Sub

		''' <summary>
		''' Initializes a new instance of the <see cref="ComponentType" /> class.
		''' </summary>
		''' <param name="entity">The entity.</param>
		Public Sub New(ByVal entity As ComponentTypeEntity)
			_myId = entity.ComponentTypeId
			_Name = entity.Name
		End Sub

		''' <summary>
		''' Initializes a new instance of the <see cref="ComponentType" /> class.
		''' </summary>
		''' <param name="entity">The entity.</param>
		Public Sub New(ByRef entity As Case2ComponentTypeEntity)
			_myId = entity.ComponentType.ComponentTypeId
			_Name = entity.ComponentType.Name
			_Id = entity.Case2ComponentTypeId
			If entity.Case2Supplier IsNot Nothing AndAlso entity.Case2Supplier.Supplier IsNot Nothing Then
				_Supplier = New Supplier(entity.Case2Supplier.Supplier)
			End If
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Name() As String
			Get
				Return _Name
			End Get
			Set(ByVal value As String)
				_IsDirtyInRepository = True
				_Name = value
			End Set
		End Property

		''' <summary>
		''' Supplier
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property Supplier() As Supplier
			Get
				Return _Supplier
			End Get
			Set(ByVal value As Supplier)
				_Supplier = value
			End Set
		End Property

		Public Property RelationId() As Long
			Get
				Return _Id
			End Get
			Set(ByVal value As Long)
				_Id = value
			End Set
		End Property

		''' <summary>
		''' Gets a value indicating whether this instance is new. Note: Relation IsNew, not ComponentType'Type'.
		''' </summary>
		''' <value><c>true</c> if this instance is new; otherwise, <c>false</c>.</value>
		Public Overrides ReadOnly Property IsNew() As Boolean
			Get
				Return _Id = - 1
				'And _myId = -1
			End Get
		End Property

		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return IsNewInRepository Or _IsDirtyInRepository Or Deleted
			End Get
		End Property

		''' <summary>
		''' Gets a value indicating whether this instance is new. Note: ComponentType 'Type' is new..
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property IsNewInRepository() As Boolean
			Get
				Return _myId = - 1
			End Get
		End Property

		''' <summary>
		''' Gets a value indicating whether this instance is to be deleted in the repository. 
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Property IsDeletedInRepository() As Boolean
			Get
				Return _DeletedInRepository
			End Get
			Set(ByVal value As Boolean)
				_DeletedInRepository = value
			End Set
		End Property

#End Region

#Region "Methods"

		''' <summary>
		''' Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
		''' </summary>
		''' <returns>
		''' A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
		''' </returns>
		Public Overrides Function ToString() As String
			Return Name
		End Function

		''' <summary>
		''' Compares to.
		''' </summary>
		''' <param name="other">The other.</param>
		''' <returns></returns>
		Public Function CompareTo(ByVal other As ComponentType) As Integer Implements IComparable(Of ComponentType).CompareTo
			Return String.Compare(Name, other.Name, False)
		End Function

#End Region
	End Class
End Namespace
