Imports PManagement.Framework
Imports PManagement.Business.CaseFacts
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults

Namespace Supplier.ComponentType
	''' <summary>
	''' Manage all interaction with relation data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _Model As Model

		Private _entityToFind As New Case2ComponentTypeEntity

#Region "Overrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' PmanContext Changed
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub ContextChanged()
			PmanTrace.WriteInfo("Base Controller", "ContextChanged")

			'Don't call Clear. DataChanged and Clear is called from Supplier
			'Clear()
		End Sub

		''' <summary>
		''' Initializes the specified environment.
		''' </summary>
		''' <param name="environment">The environment.</param>
		''' <param name="context">The PmanContext.</param>
		''' <param name="accesscontrol">The accesscontrol.</param>
		''' <param name="model">The model.</param>
		Public Overrides Sub Initialize(ByRef environment As Business.Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Gets the simple list of component types.
		''' </summary>
		''' <value>The component types.</value>
		Public ReadOnly Property ComponentTypes() As List(Of ComponentType)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Dim ec As New EntityCollection(Of ComponentTypeEntity)(New ComponentTypeEntityFactory())
					Dim fb As New RelationPredicateBucket()
					fb.PredicateExpression.Add(ComponentTypeFields.Deleted = DBNull.Value)

					Try
						daa.FetchEntityCollection(ec, fb)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.")
					Finally
						daa.CloseConnection()
					End Try
				End Using
				Return _Model.ComponentTypes
			End Get
		End Property

#End Region

#Region "Methods"

		''' <summary>
		''' Suppliers by the ComponentType.
		''' </summary>
		''' <param name="componentType">Type of the component.</param>
		''' <returns></returns>
		Public Function UniqueCaseNoByComponentType(ByRef componentType As ComponentType) As List(Of [Case])
			If componentType Is Nothing Then
				Return Nothing
			End If

			'Refacor when Case object exists
			Dim ec As New EntityCollection(Of Case2ComponentTypeEntity)(New Case2ComponentTypeEntityFactory())
			Dim list As New List(Of [Case])

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					Dim fb As New RelationPredicateBucket()
					fb.PredicateExpression.AddWithAnd(Case2ComponentTypeFields.ComponentTypeId = componentType.Id)
					Dim pp As New PrefetchPath2(DirectCast(EntityType.Case2ComponentTypeEntity, Integer))
					pp.Add(Case2ComponentTypeEntity.PrefetchPathCase)
					pp.Add(Case2ComponentTypeEntity.PrefetchPathComponentType)

					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathCreatedByParticipant)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathManagerParticipant)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathPhase)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathStandardTask)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathClaimStatus)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathStatus)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathPbu)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathTechnicalSpecialistParticipant)
					pp.Item(0).SubPath.Add(CaseEntity.PrefetchPathExecutionManagerParticipant)

					daa.FetchEntityCollection(ec, fb, pp)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Finally
					daa.CloseConnection()
				End Try
			End Using

			For Each entity As Case2ComponentTypeEntity In ec
				_entityToFind = entity
				If list.Find(New Predicate(Of [Case])(AddressOf FindCaseNo)) Is Nothing Then
					list.Add(New [Case](entity.Case))
				End If
			Next
			Return list
		End Function

		''' <summary>
		''' Deletes the component type on case no.
		''' </summary>
		''' <param name="componentType">Type of the component.</param>
		Public Sub DeleteComponentTypeOnCaseNo(ByRef componentType As ComponentType)
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					Dim fb As New RelationPredicateBucket()
					Dim ec As New EntityCollection(Of Case2ComponentTypeEntity)(New Case2ComponentTypeEntityFactory())
					Dim list As List(Of [Case]) = UniqueCaseNoByComponentType(componentType)

					For Each theCase As [Case] In list
						fb.PredicateExpression.AddWithOr(
							Case2ComponentTypeFields.CaseId = theCase.Id And Case2ComponentTypeFields.ComponentTypeId = componentType.Id)
					Next
					Dim pp As New PrefetchPath2(DirectCast(EntityType.Case2ComponentTypeEntity, Integer))
					daa.FetchEntityCollection(ec, fb, pp)

					daa.StartTransaction(IsolationLevel.Serializable, "ComponentTypeTransaction")

					daa.DeleteEntityCollection(ec)

					daa.Commit()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Finally
					daa.CloseConnection()
				End Try
			End Using
		End Sub

		''' <summary>
		''' Adds the type of the component.
		''' </summary>
		''' <param name="componentType">Type of the component.</param>
		Public Sub AddComponentType(ByRef componentType As ComponentType)
			_Model.AddComponentType(componentType)
		End Sub

		''' <summary>
		''' Existses the type of the component.
		''' </summary>
		''' <param name="ComponentTypeName">Name of the component type.</param>
		''' <returns></returns>
		Public Function ComponentTypeByName(ByVal componentTypeName As String) As ComponentType
			Return _Model.ComponentTypeByName(componentTypeName)
		End Function

		''' <summary>
		''' Removes the type of the component.
		''' </summary>
		''' <param name="ComponentType">Type of the component.</param>
		Public Sub RemoveComponentType(ByRef ComponentType As ComponentType)
			_Model.RemoveComponentType(ComponentType)
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			'Persist to database
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					daa.StartTransaction(IsolationLevel.Serializable, "ComponentTypeTransaction")

					'Save
					If _Model.DirtyComponentTypes.Count > 0 Then
						Dim ecComponentType As New EntityCollection(Of ComponentTypeEntity)(New ComponentTypeEntityFactory())
						For Each _ComponentType As ComponentType In _Model.DirtyComponentTypes
							If Not _ComponentType.IsDeletedInRepository Then
								Dim entity As ComponentTypeEntity
								If _ComponentType.IsNewInRepository Then
									entity = ecComponentType.AddNew()
									entity.Name = _ComponentType.Name
									entity.Created = Date.UtcNow()
									entity.CreatedBy = _Context.User
								Else 'Entity is updated.
									entity = New ComponentTypeEntity()
									entity.ComponentTypeId = _ComponentType.Id
									daa.FetchEntity(entity)
									entity.Name = _ComponentType.Name
									ecComponentType.Add(entity)
								End If
							End If
						Next
						If ecComponentType.Count > 0 Then daa.SaveEntityCollection(ecComponentType, False, False)
					End If

					'Delete
					If _Model.DeletedComponentTypes.Count > 0 Then
						Dim ecComponentType As New EntityCollection(Of ComponentTypeEntity)(New ComponentTypeEntityFactory())
						For Each ComponentType As ComponentType In _Model.DeletedComponentTypes
							DeleteComponentTypeOnCaseNo(ComponentType)
							Dim entity As ComponentTypeEntity
							entity = ecComponentType.AddNew()
							entity.ComponentTypeId = ComponentType.Id
							daa.FetchEntity(entity)
							'entity.Name = ComponentType.Name 'TODO: Should this be updated?
							entity.Deleted = Date.UtcNow()
							entity.DeletedBy = _Context.User
						Next
						If ecComponentType.Count > 0 Then daa.SaveEntityCollection(ecComponentType)
						'daa.DeleteEntityCollection(ecComponentType)
					End If

					daa.Commit()
					Clear()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Finally
					daa.CloseConnection()
				End Try
			End Using
			Return New ValidationSummary()
		End Function

		''' <summary>
		''' Finds the case no.
		''' </summary>
		''' <param name="item">The item.</param>
		''' <returns></returns>
		Private Function FindCaseNo(ByVal item As [Case]) As Boolean
			Return item.Id = _entityToFind.CaseId
		End Function

#End Region
	End Class
End Namespace
