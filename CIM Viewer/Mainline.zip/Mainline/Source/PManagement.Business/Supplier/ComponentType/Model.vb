Namespace Supplier.ComponentType
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

#Region "Private Fields"

		Private ReadOnly _ComponentTypes As New List(Of ComponentType)
		Private _comTypeToFind As ComponentType

#End Region

#Region "Overrides"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _ComponentTypes.Find(New Predicate(Of ComponentType)(AddressOf FindDirtyComponentTypes)) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_ComponentTypes.Clear()
			OnDataChanged()
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Gets the component types.
		''' </summary>
		''' <value>The component types.</value>
		Public ReadOnly Property ComponentTypes() As List(Of ComponentType)
			Get
				Return _ComponentTypes.FindAll(New Predicate(Of ComponentType)(AddressOf FindAllComponentType))
			End Get
		End Property

		''' <summary>
		''' Gets the deleted component types.
		''' </summary>
		''' <value>The deleted component types.</value>
		Public ReadOnly Property DeletedComponentTypes() As List(Of ComponentType)
			Get
				Return _ComponentTypes.FindAll(New Predicate(Of ComponentType)(AddressOf FindDeletedComponentTypesFromRepository))
			End Get
		End Property

		''' <summary>
		''' Gets the dirty component types.
		''' </summary>
		''' <value>The dirty component types.</value>
		Public ReadOnly Property DirtyComponentTypes() As List(Of ComponentType)
			Get
				Return _ComponentTypes.FindAll(New Predicate(Of ComponentType)(AddressOf FindDirtyComponentTypes))
			End Get
		End Property

#End Region

#Region "Methods"

		''' <summary>
		''' Injects ComponentType
		''' </summary>
		Public Sub Inject(ByRef ec As EntityCollection(Of ComponentTypeEntity))
			Dim dataChanged As Boolean = False

			For i As Integer = 0 To ec.Count - 1
				_comTypeToFind = New ComponentType(ec(i))
				Dim item As ComponentType = _ComponentTypes.Find(New Predicate(Of ComponentType)(AddressOf FindComponentTypeByName))
				If item Is Nothing Then
					'Add
					item = New ComponentType(ec(i))
					_ComponentTypes.Insert(i, item)
					dataChanged = True
				End If
			Next
			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Adds the type of the component.
		''' </summary>
		''' <param name="comType">Type of the COM.</param>
		Public Sub AddComponentType(ByRef comType As ComponentType)
			_comTypeToFind = comType
			Dim existingComponentType As ComponentType =
			    	_ComponentTypes.Find(New Predicate(Of ComponentType)(AddressOf FindComponentTypeByName))

			If existingComponentType Is Nothing Then
				'Add ComponentType
				existingComponentType = comType
				_ComponentTypes.Add(existingComponentType)
			Else
				'Undelete ComponentType
				existingComponentType.Deleted = False
			End If

			OnDataChanged()
		End Sub

		''' <summary>
		''' Existses the type of the component.
		''' </summary>
		''' <param name="ComponentTypeName">Name of the component type.</param>
		''' <returns></returns>
		Public Function ComponentTypeByName(ByVal componentTypeName As String) As ComponentType
			_comTypeToFind = New ComponentType(componentTypeName)
			Return _ComponentTypes.Find(New Predicate(Of ComponentType)(AddressOf FindComponentTypeByName))
		End Function

		''' <summary>
		''' Removes the type of the component from the repository.
		''' </summary>
		''' <param name="ComponentType">Type of the component.</param>
		Public Sub RemoveComponentType(ByRef componentType As ComponentType)
			componentType.IsDeletedInRepository = True
			OnDataChanged()
		End Sub

		''' <summary>
		''' Finds the type of the component.
		''' </summary>
		''' <param name="ComponentType">Type of the component.</param>
		''' <returns></returns>
		Private Function FindAllComponentType(ByVal ComponentType As ComponentType) As Boolean
			Return Not ComponentType.IsDeletedInRepository
		End Function

		''' <summary>
		''' Finds the name of the component type by.
		''' </summary>
		''' <param name="comType">Type of the COM.</param>
		''' <returns></returns>
		Private Function FindComponentTypeByName(ByVal comType As ComponentType) As Boolean
			Return String.Compare(comType.Name, _comTypeToFind.Name, True) = 0
		End Function

		Private Function FindDirtyComponentTypes(ByVal compType As ComponentType) As Boolean
			Return compType.IsDirty
		End Function

		Private Function FindDeletedComponentTypesFromRepository(ByVal compType As ComponentType) As Boolean
			Return compType.IsDeletedInRepository
		End Function

#End Region
	End Class
End Namespace
