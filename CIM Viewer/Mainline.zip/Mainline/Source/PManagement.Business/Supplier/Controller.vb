Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace Supplier
	''' <summary>
	''' Manage all interaction with relation data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _changeLogService As IChangeLogService
		Private _variousRelationIsDirty As Boolean
		Private _Model As Model

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty Or _variousRelationIsDirty
			End Get
		End Property

		Public Property VariousRelationIsDirty As Boolean
			Get
				Return _variousRelationIsDirty
			End Get
			Set(ByVal value As Boolean)
				_variousRelationIsDirty = value
			End Set
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Overrides Sub Initialize(ByRef environment As Business.Environment, ByRef context As PmanContext,
		                                ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			MyBase.Initialize(environment, context, accesscontrol, model)
			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		''' <summary>
		''' Item Categories
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ItemCategories() As List(Of ItemCategory)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Try
						Dim ecStage As New EntityCollection(Of StageEntity)(New StageEntityFactory())
						daa.FetchEntityCollection(ecStage, Nothing)
						_Model.Inject(ecStage)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Return _Model.ItemCategories
			End Get
		End Property

		''' <summary>
		''' Item Categories for a supplier
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ItemCategories(ByVal supplier As Supplier) As List(Of ItemCategory)
			Get
				Return _Model.ItemCategories(supplier)
			End Get
		End Property

		''' <summary>
		''' Service Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Suppliers() As List(Of Supplier)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Try
						Dim ec As New EntityCollection(Of Case2SupplierEntity)(New Case2SupplierEntityFactory())
						Dim fb As New RelationPredicateBucket()
						fb.PredicateExpression.AddWithAnd(Case2SupplierFields.CaseId = _Context.CaseId)
						Dim pp As New PrefetchPath2(DirectCast(EntityType.Case2SupplierEntity, Integer))
						pp.Add(Case2SupplierEntity.PrefetchPathSupplier)
						pp.Add(Case2SupplierEntity.PrefetchPathCase2Supplier2Stage)
						'.SubPath.Add(Case2Supplier2StageEntity.PrefetchPathStage)
						pp.Add(Case2SupplierEntity.PrefetchPathCase2ComponentType)
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Return _Model.Suppliers
			End Get
		End Property

		''' <summary>
		''' ComponentTypes on the case. Some linked to suppliers, some not.
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ComponentTypes() As List(Of ComponentType.ComponentType)
			Get
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Try
						Dim ec As New EntityCollection(Of Case2ComponentTypeEntity)(New Case2ComponentTypeEntityFactory())
						Dim fb As New RelationPredicateBucket()
						fb.PredicateExpression.AddWithAnd(Case2ComponentTypeFields.CaseId = _Context.CaseId)
						Dim pp As New PrefetchPath2(DirectCast(EntityType.Case2ComponentTypeEntity, Integer))
						pp.Add(Case2ComponentTypeEntity.PrefetchPathCase2Supplier).SubPath.Add(Case2SupplierEntity.PrefetchPathSupplier)
						pp.Add(Case2ComponentTypeEntity.PrefetchPathComponentType)
						daa.FetchEntityCollection(ec, fb, pp)
						_Model.Inject(ec)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Return _Model.ComponentTypes
			End Get
		End Property


		''' <summary>
		''' May Add Supplier Relation
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayAddSupplierRelation() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_SupplierRelations_Add)
			End Get
		End Property

		''' <summary>
		''' May Change Item Categories
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayChangeItemCategories() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_SupplierRelations_ChangeItemCategories)
			End Get
		End Property

		''' <summary>
		''' May Remove Supplier RelationCode
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property MayRemoveSupplierRelation() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_SupplierRelations_Remove)
			End Get
		End Property

		''' <summary>
		''' Gets a value indicating whether [may add component type].
		''' </summary>
		''' <value>
		''' <c>true</c> if [may add component type]; otherwise, <c>false</c>.
		''' </value>
		Public ReadOnly Property MayAddComponentType() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_ComponentType_Add)
			End Get
		End Property

		''' <summary>
		''' Gets a value indicating whether [may add component type].
		''' </summary>
		''' <value>
		''' <c>true</c> if [may add component type]; otherwise, <c>false</c>.
		''' </value>
		Public ReadOnly Property MayRemoveComponentType() As Boolean
			Get
				Return _AccessControl.OperationIsLegal(Permissions.Editor_ComponentType_Remove)
			End Get
		End Property

		''' <summary>
		''' Select Item Category
		''' </summary>
		''' <param name="selected"></param>
		''' <param name="supplier"></param>
		''' <param name="itemCategory"></param>
		''' <remarks></remarks>
		Public Sub SelectItemCategory(ByRef selected As Boolean, ByVal supplier As Supplier,
		                              ByVal itemCategory As ItemCategory)
			_Model.SelectItemCategory(selected, supplier, itemCategory)
		End Sub

		''' <summary>
		''' Add Supplier
		''' </summary>
		''' <param name="supplier"></param>
		''' <remarks></remarks>
		Public Sub AddSupplier(ByRef supplier As Supplier)
			_Model.AddSupplier(supplier)
		End Sub

		''' <summary>
		''' Add ComponentType
		''' </summary>
		''' <param name="componentType"></param>
		''' <remarks></remarks>
		Public Sub AddComponentType(ByRef componentType As ComponentType.ComponentType)
			_Model.AddComponentType(componentType)
		End Sub

		''' <summary>
		''' Remove Supplier
		''' </summary>
		''' <param name="supplier"></param>
		''' <remarks></remarks>
		Public Sub RemoveSupplier(ByRef supplier As Supplier)
			_Model.RemoveSupplier(supplier)
		End Sub

		''' <summary>
		''' Remove ComponentType
		''' </summary>
		''' <param name="componentType"></param>
		''' <remarks></remarks>
		Public Sub RemoveComponentType(ByRef componentType As ComponentType.ComponentType)
			_Model.RemoveComponentType(componentType)
		End Sub

		''' <summary>
		''' Save
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Dim validationSummary As New ValidationSummary()
			'Persist to database
			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				Try
					Dim updSupplier As New EntityCollection(Of Case2SupplierEntity)(New Case2SupplierEntityFactory())
					'Suppliers to update
					If _Model.UpdatedSuppliers.Count > 0 Then
						For Each supplier As Supplier In _Model.UpdatedSuppliers
							If Not supplier.Deleted Then
								Dim entity As Case2SupplierEntity = updSupplier.AddNew()
								entity.CaseId = _Context.CaseId.Value
								entity.SupplierId = supplier.Id
								entity.Case2SupplierId = supplier.RelationId
								supplier.Updated = False
							End If
						Next
						If updSupplier.Count > 0 Then
							For Each ec As Case2SupplierEntity In updSupplier
								Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
								filter.PredicateExpression.AddWithAnd(Case2SupplierFields.Case2SupplierId = ec.Case2SupplierId)
								daa.UpdateEntitiesDirectly(ec, filter)
							Next
						End If
					End If

					daa.StartTransaction(IsolationLevel.Serializable, "SupplierTransaction")

					Dim ecSupplier As New EntityCollection(Of Case2SupplierEntity)(New Case2SupplierEntityFactory())

					'Item Categories to delete
					If _Model.DeletedSelectedItemCategories.Count > 0 Then
						Dim fb As New RelationPredicateBucket()
						For Each selectedItemCategory As SelectedItemCategory In _Model.DeletedSelectedItemCategories
							Select Case selectedItemCategory.ItemCategory.Virtual
								Case ItemCategory.VirtualCategories.Failed
									If Not selectedItemCategory.Supplier.Deleted Then
										Dim supplierEntity As Case2SupplierEntity = FindSupplierById(ecSupplier, selectedItemCategory.Supplier.Id, daa)
										supplierEntity.FailedItem = False
									End If
								Case ItemCategory.VirtualCategories.Root
									If Not selectedItemCategory.Supplier.Deleted Then
										Dim supplierEntity As Case2SupplierEntity = FindSupplierById(ecSupplier, selectedItemCategory.Supplier.Id, daa)
										supplierEntity.RootItem = False
									End If
								Case Else
									fb.PredicateExpression.AddWithOr(
										Case2Supplier2StageFields.Case2Supplier2StageId = selectedItemCategory.RelationId)
							End Select
						Next
						If ecSupplier.Count > 0 Then daa.SaveEntityCollection(ecSupplier, True, False)
						If fb.PredicateExpression.Count > 0 Then daa.DeleteEntitiesDirectly(GetType(Case2Supplier2StageEntity), fb)
					End If

					'Suppliers to delete
					If _Model.DeletedSuppliers.Count > 0 Then
						Dim fb As New RelationPredicateBucket()
						For Each supplier As Supplier In _Model.DeletedSuppliers
							fb.PredicateExpression.AddWithOr(Case2SupplierFields.Case2SupplierId = supplier.RelationId)
						Next
						daa.DeleteEntitiesDirectly(GetType(Case2SupplierEntity), fb)
					End If

					'Suppliers to save
					If _Model.DirtySuppliers.Count > 0 Then
						For Each supplier As Supplier In _Model.DirtySuppliers
							If Not supplier.Deleted Then
								Dim entity As Case2SupplierEntity = ecSupplier.AddNew()
								entity.CaseId = _Context.CaseId.Value
								entity.SupplierId = supplier.Id
								supplier.Updated = False
							End If
						Next
						If ecSupplier.Count > 0 Then daa.SaveEntityCollection(ecSupplier, True, False)
					End If

					'Item Categories to save
					Dim ecItemCategories As New EntityCollection(Of Case2Supplier2StageEntity)(New Case2Supplier2StageEntityFactory())
					If _Model.DirtySelectedItemCategories.Count > 0 Then
						For Each selectedItemCategory As SelectedItemCategory In _Model.DirtySelectedItemCategories
							If Not selectedItemCategory.Deleted Then
								Dim c2s2s As Case2Supplier2StageEntity
								Select Case selectedItemCategory.ItemCategory.Virtual
									Case ItemCategory.VirtualCategories.Failed
										Dim supplierEntity As Case2SupplierEntity = FindSupplierById(ecSupplier, selectedItemCategory.Supplier.Id, daa)
										supplierEntity.FailedItem = True
									Case ItemCategory.VirtualCategories.Root
										Dim supplierEntity As Case2SupplierEntity = FindSupplierById(ecSupplier, selectedItemCategory.Supplier.Id, daa)
										supplierEntity.RootItem = True
									Case Else
										Dim supplierEntity As Case2SupplierEntity = FindSupplierById(ecSupplier, selectedItemCategory.Supplier.Id, daa)
										c2s2s = ecItemCategories.AddNew()
										c2s2s.Case2SupplierId = supplierEntity.Case2SupplierId
										c2s2s.StageId = selectedItemCategory.ItemCategory.Id
								End Select
							End If
						Next
						If ecSupplier.Count > 0 Then daa.SaveEntityCollection(ecSupplier, False, False)
						If ecItemCategories.Count > 0 Then daa.SaveEntityCollection(ecItemCategories, False, False)
					End If

					'ComponentTypes to delete
					If _Model.DeletedComponentTypes.Count > 0 Then
						Dim fb As New RelationPredicateBucket()
						For Each comptype As ComponentType.ComponentType In _Model.DeletedComponentTypes
							fb.PredicateExpression.AddWithOr(Case2ComponentTypeFields.Case2ComponentTypeId = comptype.RelationId)
						Next
						daa.DeleteEntitiesDirectly(GetType(Case2ComponentTypeEntity), fb)
					End If

					Dim ecComponentType As New EntityCollection(Of Case2ComponentTypeEntity)(New Case2ComponentTypeEntityFactory())

					'ComponentTypes to save
					If _Model.ComponentTypes.Count > 0 Then
						For Each component As ComponentType.ComponentType In _Model.ComponentTypes
							Dim componentID As Long = component.Id

							If Not component.Deleted AndAlso component.Id = - 1 Then
								Dim entComp As New ComponentTypeEntity()
								entComp.Name = component.Name
								daa.SaveEntity(entComp)
								componentID = entComp.ComponentTypeId
							End If

							If Not component.Deleted AndAlso component.IsNew Then
								Dim entity As Case2ComponentTypeEntity = ecComponentType.AddNew()
								entity.CaseId = _Context.CaseId.Value
								entity.ComponentTypeId = componentID
								If component.Supplier IsNot Nothing Then
									entity.SupplierLink = component.Supplier.RelationId
								End If
								'Supplier.Updated = False
							End If
						Next
						If ecComponentType.Count > 0 Then daa.SaveEntityCollection(ecComponentType, True, False)
					End If

					Dim vs As ValidationSummary = _changeLogService.HandleChangeLog(daa, _Context.CaseId.Value,
					                                                                _Context.UserParticipant.ParticipantId,
					                                                                ChangeTypeEnum.AnyChanges, String.Empty,
					                                                                String.Empty,
					                                                                [Enum].Format(GetType(AnyChangesEnum),
					                                                                              AnyChangesEnum.VariousRelations, "d") _
					                                                               	.ToString)
					validationSummary.AddValidationSummary(vs)

					daa.Commit()
					Clear()
				Catch ex As ORMQueryExecutionException
					If daa.IsTransactionInProgress Then daa.Rollback()
					Throw New ApplicationException("A database operation failed. Please try again.", ex)
				Finally
					daa.CloseConnection()
				End Try
			End Using
			Return validationSummary
		End Function

		''' <summary>
		''' Find Supplier
		''' </summary>
		''' <param name="ecSupplier"></param>
		''' <param name="supplierId"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSupplierById(ByRef ecSupplier As EntityCollection(Of Case2SupplierEntity),
		                                  ByRef supplierId As Long, ByRef daa As DataAccessAdapter) As Case2SupplierEntity
			Dim retVal As Case2SupplierEntity
			Dim indices As List(Of Integer) =
			    	ecSupplier.FindMatches(New PredicateExpression(SupplierFields.SupplierId = supplierId))
			If indices.Count = 1 Then
				retVal = ecSupplier(indices(0))
			Else
				Dim ec As New EntityCollection(Of Case2SupplierEntity)(New Case2SupplierEntityFactory())
				Dim _
					fb As _
						New RelationPredicateBucket(
							New PredicateExpression(
								Case2SupplierFields.CaseId = _Context.CaseId And Case2SupplierFields.SupplierId = supplierId))
				daa.CommandTimeOut = 120
				daa.FetchEntityCollection(ec, fb)
				retVal = ec(0)
				ecSupplier.Add(ec(0))
			End If
			Return retVal
		End Function

#Region "Add Supplier Window"

		''' <summary>
		''' Supplier Environments
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property SupplierEnvironments() As List(Of Environment)
			Get
				Dim ec As New EntityCollection(Of SupplierEnvironmentEntity)(New SupplierEnvironmentEntityFactory())
				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					Try
						daa.FetchEntityCollection(ec, Nothing)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Dim li As New List(Of Environment)
				For i As Integer = 0 To ec.Count - 1
					li.Add(New Environment(ec(i)))
				Next

				Return li
			End Get
		End Property

		''' <summary>
		''' Find Supplier
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="vendorId"></param>
		''' <param name="name"></param>
		''' <param name="maximumNumberOfItems"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property FindSupplier(ByVal environment As String, ByVal vendorId As String, ByVal name As String,
		                                      ByVal maximumNumberOfItems As Integer) As List(Of Supplier)
			Get
				Dim collectionToFill As New EntityCollection(Of SupplierEntity)(New SupplierEntityFactory())

				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Try
						Dim filterBucket As New RelationPredicateBucket()
						filterBucket.PredicateExpression.Add(SupplierFields.Deleted = DBNull.Value)
						If environment.Length > 0 Then
							filterBucket.PredicateExpression.AddWithAnd(SupplierFields.SupplierEnvironmentId = environment)
						End If
						If vendorId.Length > 0 Then
							filterBucket.PredicateExpression.AddWithAnd(SupplierFields.VendorId Mod String.Format("%{0}%", vendorId))
						End If
						If name.Length > 0 Then
							filterBucket.PredicateExpression.AddWithAnd(SupplierFields.Name Mod String.Format("%{0}%", name))
						End If

						daa.FetchEntityCollection(collectionToFill, filterBucket, maximumNumberOfItems)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Dim li As New List(Of Supplier)
				For i As Integer = 0 To collectionToFill.Count - 1
					li.Add(New Supplier(collectionToFill(i)))
				Next
				Return li
			End Get
		End Property

		''' <summary>
		''' Find Sub Supplier
		''' </summary>
		''' <param name="supplier"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property FindSubSupplier(ByVal supplier As Supplier) As List(Of Supplier)
			Get
				'if the virtual id is 0 then return an empty list
				If supplier.VirtualId = 0 Then
					Return New List(Of Supplier)
				End If

				Dim collectionToFill As New EntityCollection(Of SupplierEntity)(New SupplierEntityFactory())

				Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
					daa.CommandTimeOut = 120
					Try
						Dim filterBucket As IRelationPredicateBucket = New RelationPredicateBucket()
						filterBucket.PredicateExpression.Add(SupplierFields.SupplierId <> supplier.Id)
						filterBucket.PredicateExpression.Add(SupplierFields.VirtualId = supplier.VirtualId)
						filterBucket.PredicateExpression.Add(SupplierFields.Deleted = DBNull.Value)

						daa.FetchEntityCollection(collectionToFill, filterBucket)
					Catch ex As ORMQueryExecutionException
						Throw New ApplicationException("A database operation failed. Please try again.", ex)
					Finally
						daa.CloseConnection()
					End Try
				End Using

				Dim li As New List(Of Supplier)
				For i As Integer = 0 To collectionToFill.Count - 1
					li.Add(New Supplier(collectionToFill(i)))
				Next
				Return li
			End Get
		End Property

#End Region
	End Class
End Namespace
