Namespace Supplier
	Public NotInheritable Class Environment
		Private ReadOnly _Id As String = String.Empty
		Private ReadOnly _Name As String = String.Empty

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As SupplierEnvironmentEntity)
			_Id = entity.SupplierEnvironmentId
			_Name = entity.Name
		End Sub

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As String
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' ToString
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides Function ToString() As String
			Return _Name
		End Function
	End Class
End Namespace
