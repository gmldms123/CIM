Namespace Supplier
	Public NotInheritable Class ItemCategory
		Private ReadOnly _Id As Byte
		Private _Name As String = String.Empty
		Private ReadOnly _Virtual As VirtualCategories = Nothing

		''' <summary>
		''' Virtual Categories
		''' </summary>
		''' <remarks></remarks>
			Public Enum VirtualCategories
			Failed = 1
			Root = 2
		End Enum

		''' <summary>
		''' New (Virtual)
		''' </summary>
		''' <param name="category"></param>
		''' <remarks></remarks>
		Public Sub New(ByRef category As VirtualCategories)
			_Name = String.Concat([Enum].GetName(GetType(VirtualCategories), category), " Item")
			_Virtual = category
		End Sub

		''' <summary>
		''' New (Raw Stage)
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByRef entity As StageEntity)
			_Id = entity.StageId
			_Name = entity.Name
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByRef entity As StageEntity) As Boolean
			If Not Equals(_Name, entity.Name) Then
				_Name = entity.Name
			End If
			Return False
		End Function

		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Byte
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Virtual
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Virtual() As VirtualCategories
			Get
				Return _Virtual
			End Get
		End Property

		''' <summary>
		''' ToString
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides Function ToString() As String
			Return _Name
		End Function
	End Class
End Namespace
