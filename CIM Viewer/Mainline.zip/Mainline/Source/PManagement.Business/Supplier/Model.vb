
Imports PManagement.Business.Genericed

Namespace Supplier
	Public NotInheritable Class Model
		Inherits BaseClasses.Model

		Private ReadOnly _ItemCategories As New List(Of ItemCategory)
		Private ReadOnly _Suppliers As New List(Of Supplier)
		Private ReadOnly _SelectedItemCategories As New List(Of SelectedItemCategory)
		Private ReadOnly _ComponentTypes As New List(Of ComponentType.ComponentType)

		Private _SupplierToFind As Supplier
		Private _ItemCategoryToFind As ItemCategory
		Private _ComponentTypeToFind As ComponentType.ComponentType
		Private _searchEntityCollection As EntityCollection(Of Case2SupplierEntity) = Nothing
		Private _idToFind As Long
		Private _virtualIdToFind As Integer
		Private _stageIdToFind As Byte
		Private _categoryToFind As ItemCategory.VirtualCategories


		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Suppliers.Find(Predicate (Of Supplier).IsDirty) IsNot Nothing Or
				       _SelectedItemCategories.Find(Predicate (Of SelectedItemCategory).IsDirty) IsNot Nothing Or
				       _ComponentTypes.Find(Predicate (Of ComponentType.ComponentType).IsNew) IsNot Nothing
			End Get
		End Property

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_ItemCategories.Clear()
			_Suppliers.Clear()
			_SelectedItemCategories.Clear()
			_ComponentTypes.Clear()
			OnDataChanged()
		End Sub

		''' <summary>
		''' Item Categories
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ItemCategories() As List(Of ItemCategory)
			Get
				Return _ItemCategories
			End Get
		End Property

		''' <summary>
		''' Item Categories
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ItemCategories(ByVal supplier As Supplier) As List(Of ItemCategory)
			Get
				Dim retItemCategories As New List(Of ItemCategory)
				_SupplierToFind = supplier
				Dim selectedItemCategories As List(Of SelectedItemCategory) =
				    	_SelectedItemCategories.FindAll(
				    		New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplier))
				For Each sic As SelectedItemCategory In selectedItemCategories
					If Not sic.Deleted Then retItemCategories.Add(sic.ItemCategory)
				Next
				Return retItemCategories
			End Get
		End Property

		''' <summary>
		''' Deleted Selected Item Categories
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedSelectedItemCategories() As List(Of SelectedItemCategory)
			Get
				Return _SelectedItemCategories.FindAll(Predicate (Of SelectedItemCategory).Deleted)
			End Get
		End Property

		''' <summary>
		''' Dirty Selected Item Categories
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DirtySelectedItemCategories() As List(Of SelectedItemCategory)
			Get
				Return _SelectedItemCategories.FindAll(Predicate (Of SelectedItemCategory).IsDirty)
			End Get
		End Property

		''' <summary>
		''' Service Codes
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Suppliers() As List(Of Supplier)
			Get
				Return _Suppliers.FindAll(Predicate (Of Supplier).NotDeleted)
			End Get
		End Property

		''' <summary>
		''' Deleted Suppliers
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DeletedSuppliers() As List(Of Supplier)
			Get
				Return _Suppliers.FindAll(Predicate (Of Supplier).Deleted)
			End Get
		End Property

		''' <summary>
		''' Dirty Suppliers
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property DirtySuppliers() As List(Of Supplier)
			Get
				Return _Suppliers.FindAll(Predicate (Of Supplier).IsDirty)
			End Get
		End Property


		''' <summary>
		''' Gets the updated suppliers.
		''' </summary>
		''' <value>The updated suppliers.</value>
		Public ReadOnly Property UpdatedSuppliers() As List(Of Supplier)
			Get
				Return _Suppliers.FindAll(New System.Predicate(Of Supplier)(AddressOf FindUpdatedItem))
			End Get
		End Property

		Public ReadOnly Property ComponentTypes() As List(Of ComponentType.ComponentType)
			Get
				Return _ComponentTypes.FindAll(Predicate (Of ComponentType.ComponentType).NotDeleted)
			End Get
		End Property

		Public ReadOnly Property DeletedComponentTypes() As List(Of ComponentType.ComponentType)
			Get
				Return _ComponentTypes.FindAll(Predicate (Of ComponentType.ComponentType).Deleted)
			End Get
		End Property

		'Public ReadOnly Property UpdatedComponentTypes() As List(Of ComponentType.ComponentType)
		'  Get
		'    Return _ComponentTypes.FindAll(New Predicate(Of ComponentType.ComponentType)(AddressOf FindUpdatedComponentType))
		'  End Get
		'End Property


		''' <summary>
		''' Inject Item Categories
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByRef ec As EntityCollection(Of StageEntity))
			Dim dataChanged As Boolean = False
			Dim itemCategory As ItemCategory

			'Virtual Item Categories
			_categoryToFind = ItemCategory.VirtualCategories.Failed
			itemCategory = _ItemCategories.Find(New System.Predicate(Of ItemCategory)(AddressOf FindVirtualItemCategory))
			If itemCategory Is Nothing Then
				_ItemCategories.Add(New ItemCategory(ItemCategory.VirtualCategories.Failed))
				dataChanged = True
			End If
			_categoryToFind = ItemCategory.VirtualCategories.Root
			itemCategory = _ItemCategories.Find(New System.Predicate(Of ItemCategory)(AddressOf FindVirtualItemCategory))
			If itemCategory Is Nothing Then
				_ItemCategories.Add(New ItemCategory(ItemCategory.VirtualCategories.Root))
				dataChanged = True
			End If

			'Normal Item Categories
			For i As Integer = 0 To ec.Count - 1
				_stageIdToFind = ec(i).StageId
				itemCategory = _ItemCategories.Find(New System.Predicate(Of ItemCategory)(AddressOf FindItemCategoryById))
				If itemCategory Is Nothing Then
					'Add
					itemCategory = New ItemCategory(ec(i))
					_ItemCategories.Add(itemCategory)
					dataChanged = True
				Else
					'Update
					dataChanged = dataChanged Or itemCategory.Update(ec(i))
				End If
			Next

			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Inject Suppliers
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByRef ec As EntityCollection(Of Case2SupplierEntity))
			Dim dataChanged As Boolean = False

			For i As Integer = 0 To ec.Count - 1
				_idToFind = ec(i).SupplierId
				Dim supplier As Supplier = _Suppliers.Find(New System.Predicate(Of Supplier)(AddressOf FindSupplierById))
				If supplier Is Nothing Then
					'Add Supplier
					supplier = New Supplier(ec(i))
					_Suppliers.Insert(i, supplier)
					'Add Item Categories
					If ec(i).FailedItem Then
						_categoryToFind = ItemCategory.VirtualCategories.Failed
						_SelectedItemCategories.Add(New SelectedItemCategory(ec(i).Case2SupplierId, supplier,
						                                                     _ItemCategories.Find(
						                                                     	New System.Predicate(Of ItemCategory)(
						                                                     		AddressOf FindVirtualItemCategory))))
					End If
					If ec(i).RootItem Then
						_categoryToFind = ItemCategory.VirtualCategories.Root
						_SelectedItemCategories.Add(New SelectedItemCategory(ec(i).Case2SupplierId, supplier,
						                                                     _ItemCategories.Find(
						                                                     	New System.Predicate(Of ItemCategory)(
						                                                     		AddressOf FindVirtualItemCategory))))
					End If
					For Each entity As Case2Supplier2StageEntity In ec(i).Case2Supplier2Stage
						_stageIdToFind = entity.StageId
						_SelectedItemCategories.Add(New SelectedItemCategory(entity.Case2Supplier2StageId, supplier,
						                                                     _ItemCategories.Find(
						                                                     	New System.Predicate(Of ItemCategory)(
						                                                     		AddressOf FindItemCategoryById))))
					Next
					dataChanged = True
				Else
					'Update Supplier
					dataChanged = dataChanged Or supplier.Update(ec(i))
					'Add Missing Item Categories
					_SupplierToFind = supplier
					If ec(i).FailedItem Then
						_categoryToFind = ItemCategory.VirtualCategories.Failed
						_ItemCategoryToFind = _ItemCategories.Find(New System.Predicate(Of ItemCategory)(AddressOf FindVirtualItemCategory))
						Dim sic As SelectedItemCategory =
						    	_SelectedItemCategories.Find(
						    		New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplierAndItemCategory))
						If sic Is Nothing Then
							_SelectedItemCategories.Add(New SelectedItemCategory(ec(i).Case2SupplierId, supplier, _ItemCategoryToFind))
							dataChanged = True
						Else
							dataChanged = dataChanged Or sic.Update(ec(i))
						End If
					End If
					If ec(i).RootItem Then
						_categoryToFind = ItemCategory.VirtualCategories.Root
						_ItemCategoryToFind = _ItemCategories.Find(New System.Predicate(Of ItemCategory)(AddressOf FindVirtualItemCategory))
						Dim sic As SelectedItemCategory =
						    	_SelectedItemCategories.Find(
						    		New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplierAndItemCategory))
						If sic Is Nothing Then
							_SelectedItemCategories.Add(New SelectedItemCategory(ec(i).Case2SupplierId, supplier, _ItemCategoryToFind))
							dataChanged = True
						Else
							dataChanged = dataChanged Or sic.Update(ec(i))
						End If
					End If
					For Each entity As Case2Supplier2StageEntity In ec(i).Case2Supplier2Stage
						_stageIdToFind = entity.StageId
						_ItemCategoryToFind = _ItemCategories.Find(New System.Predicate(Of ItemCategory)(AddressOf FindItemCategoryById))
						Dim sic As SelectedItemCategory =
						    	_SelectedItemCategories.Find(
						    		New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplierAndItemCategory))
						If sic Is Nothing Then
							_SelectedItemCategories.Add(New SelectedItemCategory(entity.Case2Supplier2StageId, supplier, _ItemCategoryToFind))
							dataChanged = True
						Else
							dataChanged = dataChanged Or sic.Update(entity)
						End If
					Next
				End If
			Next

			_searchEntityCollection = ec
			dataChanged = dataChanged Or
			              _Suppliers.RemoveAll(New System.Predicate(Of Supplier)(AddressOf FindSupplierToRemove)) > 0

			If dataChanged Then OnDataChanged()
		End Sub


		''' <summary>
		''' Inject componenttypes
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByRef ec As EntityCollection(Of Case2ComponentTypeEntity))
			Dim dataChanged As Boolean = False
			Dim componentType As ComponentType.ComponentType

			'Normal
			For i As Integer = 0 To ec.Count - 1

				'_ComponentTypeToFind = New ComponentType.ComponentType(ec(i))
				_idToFind = ec(i).Case2ComponentTypeId
				componentType =
					_ComponentTypes.Find(New System.Predicate(Of ComponentType.ComponentType)(AddressOf FindComponentTypeId))
				If componentType Is Nothing Then
					'Add
					componentType = New ComponentType.ComponentType(ec(i))
					_ComponentTypes.Add(componentType)
					dataChanged = True
				Else
					'Update
					'dataChanged = dataChanged Or componentType.Update(ec(i))
				End If
			Next

			If dataChanged Then OnDataChanged()
		End Sub


		'''' <summary>
		'''' Updates the type of the supplier component.
		'''' </summary>
		'''' <param name="controller">The controller.</param>
		'Public Sub UpdateSupplierComponentType(ByRef controller As ComponentType.Controller)
		'  For Each supplier As Supplier In _Suppliers
		'    If (Not supplier.ComponentType Is Nothing) Then
		'      supplier.ComponentType = controller.ComponentTypeByName(supplier.ComponentType.Name)
		'    Else
		'      supplier.ComponentType = Nothing
		'    End If
		'  Next
		'End Sub

		''' <summary>
		''' Add Supplier
		''' </summary>
		''' <param name="supplier"></param>
		''' <remarks></remarks>
		Public Sub AddSupplier(ByRef supplier As Supplier)
			_virtualIdToFind = supplier.VirtualId
			'If the virtual id is 0, then this supplier has not been linked to other suppliers and the suppliers
			'unique id can be used instead of the virtual id.
			If (_virtualIdToFind = 0) Then
				_idToFind = supplier.Id
				_SupplierToFind = _Suppliers.Find(New System.Predicate(Of Supplier)(AddressOf FindSupplierById))
			Else
				_SupplierToFind = _Suppliers.Find(New System.Predicate(Of Supplier)(AddressOf FindSupplierByVirtualId))
			End If

			If _SupplierToFind Is Nothing Then
				'Add Supplier
				_SupplierToFind = supplier
				_Suppliers.Add(_SupplierToFind)
			Else
				'Undelete Supplier
				_SupplierToFind.Deleted = False
				For Each sic As SelectedItemCategory In _
					_SelectedItemCategories.FindAll(
						New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplier))
					sic.Deleted = False
				Next
			End If

			OnDataChanged()
		End Sub

		Public Sub AddComponentType(ByRef componentType As ComponentType.ComponentType)
			_idToFind = componentType.Id
			_ComponentTypeToFind =
				_ComponentTypes.Find(New System.Predicate(Of ComponentType.ComponentType)(AddressOf FindComponentType))
			If _ComponentTypeToFind Is Nothing Then
				_ComponentTypes.Add(componentType)
			End If
			OnDataChanged()
		End Sub

		''' <summary>
		''' Remove Supplier
		''' </summary>
		''' <param name="supplier"></param>
		''' <remarks></remarks>
		Public Sub RemoveSupplier(ByRef supplier As Supplier)
			_idToFind = supplier.Id
			_SupplierToFind = _Suppliers.Find(New System.Predicate(Of Supplier)(AddressOf FindSupplierById))
			If _SupplierToFind.IsNew Then
				'Remove Supplier
				_Suppliers.Remove(_SupplierToFind)
				'Remove Item Categories
				_SelectedItemCategories.RemoveAll(
					New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplier))
			Else
				'Mark Supplier As Deleted
				_SupplierToFind.Deleted = True
				For Each sic As SelectedItemCategory In _
					_SelectedItemCategories.FindAll(
						New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplier))
					If sic.IsNew Then
						'Remove Item Categories
						_SelectedItemCategories.Remove(sic)
					Else
						'Mark Item Categories As Deleted
						sic.Deleted = True
					End If
				Next

				For Each comp As ComponentType.ComponentType In _
					_ComponentTypes.FindAll(New System.Predicate(Of ComponentType.ComponentType)(AddressOf FindComponentTypeBySupplier))
					If comp.IsNew Then
						'Remove the componenttype
						_ComponentTypes.Remove(comp)
					Else
						'Mark the componenttype as deleted
						comp.Deleted = True
					End If
				Next

			End If
			OnDataChanged()
		End Sub

		''' <summary>
		''' Remove ComponentType
		''' </summary>
		''' <param name="componentType"></param>
		''' <remarks></remarks>
		Public Sub RemoveComponentType(ByRef componentType As ComponentType.ComponentType)
			_idToFind = componentType.RelationId
			_ComponentTypeToFind =
				_ComponentTypes.Find(New System.Predicate(Of ComponentType.ComponentType)(AddressOf FindComponentTypeId))
			If _ComponentTypeToFind.IsNew Then
				'Remove ComponentType
				_ComponentTypes.Remove(_ComponentTypeToFind)
			Else
				'Mark ComponentType As Deleted
				_ComponentTypeToFind.Deleted = True
			End If
			OnDataChanged()
		End Sub

		''' <summary>
		''' Select Item Category
		''' </summary>
		''' <param name="selected"></param>
		''' <param name="supplier"></param>
		''' <param name="itemCategory"></param>
		''' <remarks></remarks>
		Public Sub SelectItemCategory(ByRef selected As Boolean, ByVal supplier As Supplier,
		                              ByVal itemCategory As ItemCategory)
			_SupplierToFind = supplier
			_ItemCategoryToFind = itemCategory
			Dim existingSIC As SelectedItemCategory =
			    	_SelectedItemCategories.Find(
			    		New System.Predicate(Of SelectedItemCategory)(AddressOf FindSelectedItemCategoryBySupplierAndItemCategory))
			Select Case selected
				Case True
					If existingSIC Is Nothing Then
						_SelectedItemCategories.Add(New SelectedItemCategory(supplier, itemCategory))
					Else
						existingSIC.Deleted = False
					End If
				Case False
					If existingSIC.IsNew Then
						_SelectedItemCategories.Remove(existingSIC)
					Else
						existingSIC.Deleted = True
					End If
			End Select
		End Sub

		''' <summary>
		''' Find Item Category By Id
		''' </summary>
		''' <param name="itemCategory"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindItemCategoryById(ByVal itemCategory As ItemCategory) As Boolean
			Return Equals(itemCategory.Id, _stageIdToFind)
		End Function

		''' <summary>
		''' Find Virtual Item Category
		''' </summary>
		''' <param name="itemCategory"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindVirtualItemCategory(ByVal itemCategory As ItemCategory) As Boolean
			Return Equals(itemCategory.Virtual, _categoryToFind)
		End Function

		''' <summary>
		''' Find Selected Item Category By Supplier
		''' </summary>
		''' <param name="selecteditemCategory"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSelectedItemCategoryBySupplier(ByVal selecteditemCategory As SelectedItemCategory) As Boolean
			Return Equals(selecteditemCategory.Supplier, _SupplierToFind)
		End Function

		''' <summary>
		''' Find ComponentTypes by Supplier
		''' </summary>
		''' <param name="comp"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindComponentTypeBySupplier(ByVal comp As ComponentType.ComponentType) As Boolean
			Return Equals(comp.Supplier, _SupplierToFind)
		End Function

		''' <summary>
		''' Find Selected Item Category By Supplier And Item Category
		''' </summary>
		''' <param name="selecteditemCategory"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSelectedItemCategoryBySupplierAndItemCategory(ByVal selecteditemCategory As SelectedItemCategory) _
			As Boolean
			Return _
				Equals(selecteditemCategory.Supplier, _SupplierToFind) And
				Equals(selecteditemCategory.ItemCategory, _ItemCategoryToFind)
		End Function

		''' <summary>
		''' Find Supplier By Id
		''' </summary>
		''' <param name="supplier"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSupplierById(ByVal supplier As Supplier) As Boolean
			Return Equals(supplier.Id, _idToFind)
		End Function

		''' <summary>
		''' Find Supplier By Virtual Id
		''' </summary>
		''' <param name="supplier"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSupplierByVirtualId(ByVal supplier As Supplier) As Boolean
			Return Equals(supplier.VirtualId, _virtualIdToFind)
		End Function

		''' <summary>
		''' Finds the updated item.
		''' </summary>
		''' <param name="supplier">The supplier.</param>
		''' <returns></returns>
		Private Function FindUpdatedItem(ByVal supplier As Supplier) As Boolean
			Return supplier.Updated
		End Function

		'Private Function FindUpdatedComponentType(ByVal componenttype As ComponentType.ComponentType) As Boolean
		'  Return componenttype.isn
		'End Function

		''' <summary>
		''' Find Supplier To Remove
		''' </summary>
		''' <param name="supplier"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindSupplierToRemove(ByVal supplier As Supplier) As Boolean
			Return _
				_searchEntityCollection.FindMatches(New PredicateExpression(Case2SupplierFields.SupplierId = supplier.Id)).Count = 0 And
				Not supplier.IsNew
		End Function

		''' <summary>
		''' Find ComponentType By Id
		''' </summary>
		''' <param name="componentType"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function FindComponentTypeId(ByVal componentType As ComponentType.ComponentType) As Boolean
			Return componentType.RelationId = _idToFind
		End Function

		Private Function FindComponentType(ByVal componentType As ComponentType.ComponentType) As Boolean
			Return componentType.Id = _idToFind
		End Function
	End Class
End Namespace
