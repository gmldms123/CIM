Imports PManagement.Business.BaseClasses

Namespace Supplier
	Public NotInheritable Class SelectedItemCategory
		Inherits BaseObject

		Private ReadOnly _Supplier As Supplier = Nothing
		Private ReadOnly _ItemCategory As ItemCategory = Nothing

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New(ByRef supplier As Supplier, ByRef itemCategory As ItemCategory)
			_Supplier = supplier
			_ItemCategory = itemCategory
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <remarks></remarks>
		Public Sub New(ByRef relationId As Long, ByRef supplier As Supplier, ByRef itemCategory As ItemCategory)
			_Id = relationId
			_Supplier = supplier
			_ItemCategory = itemCategory
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As Case2SupplierEntity) As Boolean
			Dim updated As Boolean = False
			If Not Equals(entity.Case2SupplierId, _Id) Then
				_Id = entity.Case2SupplierId
				updated = True
			End If
			Return updated
		End Function

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As Case2Supplier2StageEntity) As Boolean
			Dim updated As Boolean = False
			If Not Equals(entity.Case2Supplier2StageId, _Id) Then
				_Id = entity.Case2Supplier2StageId
				updated = True
			End If
			Return updated
		End Function

		''' <summary>
		''' RelationId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RelationId() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' Supplier
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Supplier() As Supplier
			Get
				Return _Supplier
			End Get
		End Property

		''' <summary>
		''' Item Category
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property ItemCategory() As ItemCategory
			Get
				Return _ItemCategory
			End Get
		End Property
	End Class
End Namespace
