Imports PManagement.Business.BaseClasses

Namespace Supplier
	Public NotInheritable Class Supplier
		Inherits BaseObject

		Private ReadOnly _myId As Long = - 1
		Private ReadOnly _VirtualId As Integer = - 1
		Private _Name As String = String.Empty
		Private _Address As String = String.Empty
		Private _Phone As String = String.Empty
		Private _Email As String = String.Empty
		Private _IsUpdated As Boolean = False

		''' <summary>
		''' New (Raw Supplier)
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByVal entity As SupplierEntity)
			_myId = entity.SupplierId
			_VirtualId = entity.VirtualId
			_Name = entity.Name
			_Address = String.Format("{0}, {1}", entity.Address1.Trim, entity.Address2.Trim)
			_Phone = entity.Phone
			_Email = entity.Email
		End Sub

		''' <summary>
		''' New
		''' </summary>
		''' <param name="entity"></param>
		''' <remarks></remarks>
		Public Sub New(ByRef entity As Case2SupplierEntity)
			_myId = entity.SupplierId
			_Id = entity.Case2SupplierId
			_VirtualId = entity.Supplier.VirtualId
			_Name = entity.Supplier.Name
			_Address = String.Format("{0}, {1}", entity.Supplier.Address1.Trim, entity.Supplier.Address2.Trim)
			_Phone = entity.Supplier.Phone
			_Email = entity.Supplier.Email
		End Sub

		''' <summary>
		''' Update
		''' </summary>
		''' <param name="entity"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Function Update(ByVal entity As Case2SupplierEntity) As Boolean
			Dim updated As Boolean = False
			If Not Equals(_Id, entity.Case2SupplierId) Then
				_Id = entity.Case2SupplierId
				updated = True
			End If
			If Not Equals(_Name, entity.Supplier.Name) Then
				_Name = entity.Supplier.Name
				updated = True
			End If
			If Not Equals(_Address, String.Format("{0}, {1}", entity.Supplier.Address1.Trim, entity.Supplier.Address2.Trim)) Then
				_Address = String.Format("{0}, {1}", entity.Supplier.Address1.Trim, entity.Supplier.Address2.Trim)
				updated = True
			End If
			If Not Equals(_Phone, entity.Supplier.Phone) Then
				_Phone = entity.Supplier.Phone
				updated = True
			End If
			If Not Equals(_Email, entity.Supplier.Email) Then
				_Email = entity.Supplier.Email
				updated = True
			End If
			Return updated
		End Function

		''' <summary>
		''' Compare two suppliers by looking at the virtual-id
		''' </summary>
		''' <param name="Obj"></param>
		''' <returns>True, if the two virtual id's are equal or the virtual id is 0, false otherwise</returns>
		''' <remarks></remarks>
		Public Overloads Overrides Function Equals(ByVal Obj As Object) As Boolean
			If Not IsDBNull(Obj) Then
				Dim other As Supplier = CType(Obj, Supplier)
				Return ((Id = other.Id) Or (VirtualId = other.VirtualId And VirtualId <> 0))
			Else
				Return False
			End If
		End Function


		''' <summary>
		''' Id
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Id() As Long
			Get
				Return _myId
			End Get
		End Property

		''' <summary>
		''' RelationId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property RelationId() As Long
			Get
				Return _Id
			End Get
		End Property

		''' <summary>
		''' VirtualId
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property VirtualId() As Integer
			Get
				Return _VirtualId
			End Get
		End Property

		''' <summary>
		''' Name
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Name() As String
			Get
				Return _Name
			End Get
		End Property

		''' <summary>
		''' Address
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Address() As String
			Get
				Return _Address
			End Get
		End Property

		''' <summary>
		''' Phone
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Phone() As String
			Get
				Return _Phone
			End Get
		End Property

		''' <summary>
		''' Email
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Email() As String
			Get
				Return _Email
			End Get
		End Property

		''' <summary>
		''' Gets a value indicating whether this instance is updated.
		''' </summary>
		''' <value>
		''' <c>true</c> if this instance is updated; otherwise, <c>false</c>.
		''' </value>
		Public ReadOnly Property IsUpdated() As Boolean
			Get
				Return _IsUpdated
			End Get
		End Property

		''' <summary>
		''' Gets a value indicating whether this instance is dirty.
		''' </summary>
		''' <value><c>true</c> if this instance is dirty; otherwise, <c>false</c>.</value>
		Public Property Updated() As Boolean
			Get
				Return _IsUpdated
			End Get
			Set(ByVal value As Boolean)
				_IsUpdated = value
			End Set
		End Property
	End Class
End Namespace
