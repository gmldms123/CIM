Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ModelLayer.ChangeLog
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Framework.ValidationInfo
Imports PManagement.Framework.ValidationResults
Imports StructureMap

Namespace Timeline
	''' <summary>
	''' Manage all interaction with relation data model from viewers
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Controller
		Inherits BaseClasses.Controller

		Private _changeTypeService As IChangeTypeService

		Private _Model As Model

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Return _Model.IsDirty
			End Get
		End Property

		''' <summary>
		''' Finalize
		''' </summary>
		''' <remarks></remarks>
		Protected Overrides Sub Finalize()
			_Model = Nothing
			MyBase.Finalize()
		End Sub

		''' <summary>
		''' Initialize
		''' </summary>
		''' <param name="environment"></param>
		''' <param name="context"></param>
		''' <param name="accesscontrol"></param>
		''' <param name="model"></param>
		''' <remarks></remarks>
		Public Shadows Sub Initialize(ByRef environment As Environment, ByRef context As PmanContext,
		                              ByRef accesscontrol As AccessControl, ByVal model As Interfaces.Model)
			_Model = DirectCast(model, Model)
			_changeTypeService = ObjectFactory.GetInstance (Of IChangeTypeService)()
			MyBase.Initialize(environment, context, accesscontrol, model)
		End Sub

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			If _Model IsNot Nothing Then _Model.Clear()
		End Sub

		Public Function GetChangeLogCollection(ByVal caseId As Long, ByVal cutOffDate As DateTime) _
			As EntityCollection(Of ChangeLogEntity)
			Dim ec As New EntityCollection(Of ChangeLogEntity)

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				daa.CommandTimeOut = 120
				Dim _RelatedCIRsChangedType As IChangeType =_changeTypeService.GetChangeTypeByType(ChangeTypeEnum.RelatedCIRsChanged)
				Dim _AnyChangesChangedType As IChangeType = _changeTypeService.GetChangeTypeByType(ChangeTypeEnum.AnyChanges)
				Dim _KPIChangeType As IChangeType = _changeTypeService.GetChangeTypeByType(ChangeTypeEnum.KPIChange)
				Dim _KPICreateType As IChangeType = _changeTypeService.GetChangeTypeByType(ChangeTypeEnum.KPICreated)
                Dim _KPIDeleteType As IChangeType = _changeTypeService.GetChangeTypeByType(ChangeTypeEnum.KPIDeleted)


				Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
				filter.PredicateExpression.Add(ChangeLogFields.CaseId = caseId)
				filter.PredicateExpression.AddWithAnd(ChangeLogFields.Created >= cutOffDate)

				' These types of changes are never to be shown in the Timeline.
				filter.PredicateExpression.AddWithAnd(ChangeLogFields.ChangeTypeId <> _RelatedCIRsChangedType.ChangeTypeId)
				filter.PredicateExpression.AddWithAnd(ChangeLogFields.ChangeTypeId <> _AnyChangesChangedType.ChangeTypeId)
				filter.PredicateExpression.AddWithAnd(ChangeLogFields.ChangeTypeId <> _KPIChangeType.ChangeTypeId)
				filter.PredicateExpression.AddWithAnd(ChangeLogFields.ChangeTypeId <> _KPICreateType.ChangeTypeId)
				filter.PredicateExpression.AddWithAnd(ChangeLogFields.ChangeTypeId <> _KPIDeleteType.ChangeTypeId)

				Dim pp As New PrefetchPath2(DirectCast(EntityType.ChangeLogEntity, Integer))
				pp.Add(ChangeLogEntity.PrefetchPathParticipant)

				Try
					daa.FetchEntityCollection(ec, filter, pp)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try
			End Using

			Return ec
		End Function

		Public Function GetTimelineCollection(ByVal caseId As Long, ByVal cutOffDate As DateTime) _
			As EntityCollection(Of TimelineEntity)
			Dim ec As New EntityCollection(Of TimelineEntity)

			Using daa As New DataAccessAdapter(_Environment.PManagement_ConnectionString, True)
				daa.CommandTimeOut = 120
				Dim filter As IRelationPredicateBucket = New RelationPredicateBucket()
				filter.PredicateExpression.Add(TimelineFields.CaseId = _Context.CaseId.Value)
				filter.PredicateExpression.AddWithAnd(TimelineFields.Changed < cutOffDate)
				Dim pp As New PrefetchPath2(DirectCast(EntityType.TimelineEntity, Integer))
				pp.Add(TimelineEntity.PrefetchPathChangedByParticipant)

				Try
					daa.FetchEntityCollection(ec, filter, pp)
				Catch ex As ORMQueryExecutionException
					Throw New ApplicationException("A database operation failed. Please try again.")
				Finally
					daa.CloseConnection()
				End Try
			End Using

			Return ec
		End Function

		''' <summary>
		''' Retrieve Timelines
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Timeline() As TimeLineList
			Get
				'This cut off date is used to only get data from the old timeline table before this date and then get data from new ChangeLog table after this date.
				Dim cutOffDate As New DateTime(2010, 7, 17)

				Dim changeLogCollection As EntityCollection(Of ChangeLogEntity)
				changeLogCollection = GetChangeLogCollection(_Context.CaseId.Value, cutOffDate)
				_Model.Inject(changeLogCollection)

				Dim timelineCollection As EntityCollection(Of TimelineEntity)
				timelineCollection = GetTimelineCollection(_Context.CaseId.Value, cutOffDate)
				_Model.Inject(timelineCollection)

				Return _Model.Timelines()
			End Get
		End Property

		Public Overrides Function Save(Optional ByRef validatorInfo As ValidationInfo = Nothing,
		                               Optional ByVal backGround As BackgroundWorker = Nothing) As ValidationSummary
			Return New ValidationSummary()
		End Function
	End Class
End Namespace
