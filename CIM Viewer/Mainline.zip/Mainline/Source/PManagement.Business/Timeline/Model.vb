Imports PManagement.ModelLayer.Alert.Enums
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports StructureMap

Namespace Timeline
	''' <summary>
	''' Model
	''' </summary>
	''' <remarks></remarks>
		Public NotInheritable Class Model
		Inherits BaseClasses.Model

#Region "Variables"

		Private ReadOnly _tlList As New SortedList(Of Long, Timeline)
		Private ReadOnly _changeTypeService As IChangeTypeService = ObjectFactory.GetInstance (Of IChangeTypeService)()

#End Region

#Region "Methods"

		''' <summary>
		''' Clear object model
		''' </summary>
		''' <remarks></remarks>
		Public Overrides Sub Clear()
			_tlList.Clear()
			OnDataChanged()
		End Sub

		''' <summary>
		''' Inject
		''' </summary>
		''' <param name="ec"></param>
		''' <remarks></remarks>
		Public Sub Inject(ByVal ec As EntityCollection(Of ChangeLogEntity))
			Dim dataChanged As Boolean = False

			'Insert new timeline entries
			Dim changeTypeId As Long = _changeTypeService.GetChangeTypeByType(ChangeTypeEnum.RelatedCIRsChanged).ChangeTypeId
			For i As Integer = 0 To ec.Count - 1
				If Not ec(i).ChangeTypeId = changeTypeId Then
					If Not _tlList.ContainsKey(ec(i).ChangeLogId) Then
						Dim item As New Timeline(ec(i))
						_tlList.Add(item.Id, item)
						dataChanged = True
					End If
				End If
			Next
			If dataChanged Then OnDataChanged()
		End Sub

		Public Sub Inject(ByVal ec As EntityCollection(Of TimelineEntity))
			Dim dataChanged As Boolean = False

			'Insert new timeline entries
			For i As Integer = 0 To ec.Count - 1
				If Not _tlList.ContainsKey(ec(i).TimelineId) Then
					Dim item As New Timeline(ec(i).TimelineId, ec(i).Text, ec(i).Changed, ec(i).ChangedBy)
					_tlList.Add(item.Id, item)
					dataChanged = True
				End If
			Next
			If dataChanged Then OnDataChanged()
		End Sub

		''' <summary>
		''' Add
		''' </summary>
		''' <param name="item"></param>
		''' <remarks></remarks>
		Public Sub Add(ByVal item As Timeline)
			_tlList.Add(item.Id, item)
			OnDataChanged()
		End Sub

#End Region

#Region "Properties"

		''' <summary>
		''' Is model dirty
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Public Overrides ReadOnly Property IsDirty() As Boolean
			Get
				Dim _IsDirty As Boolean = False
				For Each item As Timeline In _tlList.Values
					_IsDirty = _IsDirty Or item.IsDirty
					If _IsDirty Then Exit For
				Next
				Return _IsDirty
			End Get
		End Property

		''' <summary>
		''' Timelines
		''' </summary>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Timelines() As TimeLineList
			Get
				Dim liItem As New TimeLineList
				For i As Integer = 0 To _tlList.Values.Count - 1
					liItem.Add(_tlList.Values(i))
				Next
				Return liItem.SortedByChangedDesc()
			End Get
		End Property

		''' <summary>
		''' Exists
		''' </summary>
		''' <param name="item"></param>
		''' <value></value>
		''' <returns></returns>
		''' <remarks></remarks>
		Public ReadOnly Property Exists(ByVal item As Timeline) As Boolean
			Get
				Return _tlList.ContainsKey(item.Id)
			End Get
		End Property

#End Region
	End Class
End Namespace