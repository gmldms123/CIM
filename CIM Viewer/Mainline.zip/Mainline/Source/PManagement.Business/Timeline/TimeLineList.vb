Namespace Timeline
	Public Class TimeLineList
		Inherits List(Of Timeline)

		Public Function SortedByChangedDesc() As TimeLineList
			Dim res As TimeLineList = New TimeLineList()
			res.AddRange(Me)

			res.Sort(New Comparison(Of Timeline)(AddressOf ChangedComparerDesc))

			Return res
		End Function

		Public Overrides Function ToString() As String
			Dim res As String = "TimeLineList: "

			For Each Item As Timeline In Me
				res = res + Item.ToString()
			Next

			Return res
		End Function

		Public Shared Function ChangedComparerDesc(ByVal tl1 As Timeline, ByVal tl2 As Timeline) As Integer
			Return tl2.Changed.CompareTo(tl1.Changed)
		End Function
	End Class
End NameSpace