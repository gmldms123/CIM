
Imports PManagement.ServiceLayer.Services.Interfaces.ChangeLog
Imports PManagement.Business.BaseClasses
Imports StructureMap

Namespace Timeline
	Public NotInheritable Class Timeline
		Inherits BaseObject
		'Private Shadows ReadOnly _Id As Long
		Private ReadOnly _Text As String
		Private ReadOnly _Changed As Date
		Private ReadOnly _ChangedBy As Long
		Private ReadOnly _changeLogService As IChangeLogService

		Public Sub New(ByVal entity As ChangeLogEntity)

			_Id = entity.ChangeLogId
			_Text = String.Empty
			_Changed = entity.Created
			_ChangedBy = entity.CreatedById

			'Me.new(entity.ChangeLogId, String.Empty, entity.Created, entity.CreatedById)  

			_changeLogService = ObjectFactory.GetInstance (Of IChangeLogService)()
			_Text = _changeLogService.GetText(entity.ChangeTypeId, entity.BeforeValue, entity.AfterValue, entity.AdditionalInfo)
		End Sub

		Public Sub New(ByVal id As Long, ByVal text As String, ByVal changed As DateTime, ByVal changedBy As Long)
			_Id = id
			_Text = text
			_Changed = changed
			_ChangedBy = changedBy
		End Sub

		Public ReadOnly Property Id() As Long
			Get
				Return _Id
			End Get
		End Property

		Public ReadOnly Property Text() As String
			Get
				Return _Text
			End Get
		End Property

		Public ReadOnly Property Changed() As Date
			Get
				Return _Changed
			End Get
		End Property

		Public ReadOnly Property ChangedBy() As Long
			Get
				Return _ChangedBy
			End Get
		End Property

		Public Overrides Function ToString() As String
			Return "(" + Id.ToString() + ":" + Changed.ToString + ")"
		End Function
	End Class
End Namespace
