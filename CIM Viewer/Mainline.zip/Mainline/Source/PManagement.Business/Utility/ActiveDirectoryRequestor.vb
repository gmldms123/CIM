﻿Imports System.DirectoryServices.AccountManagement

Public Class ActiveDirectoryRequestor

    Public Function Validate(domain As String, group As String, user As String) As Boolean

        'user = user + "@Vestas.net";
        'var foundUser = false;
        Using pc As New PrincipalContext(ContextType.Domain)
            Dim myGroup As GroupPrincipal = GroupPrincipal.FindByIdentity(pc, group)
            Using myGroup
                Dim result As IEnumerable(Of Principal) = From m In myGroup.GetMembers(True) Where m.UserPrincipalName.ToLower().Replace("@vestas.net", String.Empty) = user.ToLower Select m
                If result.Count() = 0 Then
                    Return False
                Else
                    Return True
                End If
            End Using
        End Using
        Return False
    End Function
End Class
