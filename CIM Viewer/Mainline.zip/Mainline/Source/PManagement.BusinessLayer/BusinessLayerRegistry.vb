﻿Imports PManagement.BusinessLayer.Services.Interfaces
Imports PManagement.BusinessLayer.Services.Implementations
Imports PManagement.BusinessLayer.Factories.Interfaces
Imports PManagement.BusinessLayer.Factories.Implementations
Imports StructureMap.Configuration.DSL

Public Class BusinessLayerRegistry
	Inherits Registry

	Public Sub New()
		ForRequestedType (Of IBusinessProcessLogicFactory)().TheDefaultIsConcreteType (Of BusinessProcessLogicFactory)().
			AsSingletons()
		ForRequestedType (Of IBusinessLogicService)().TheDefaultIsConcreteType (Of BusinessLogicService)().AsSingletons()
	End Sub
End Class
