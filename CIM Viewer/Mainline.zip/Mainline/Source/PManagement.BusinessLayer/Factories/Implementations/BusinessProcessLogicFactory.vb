Imports PManagement.BusinessLayer.Services.Implementations
Imports PManagement.ServiceLayer.Services.Interfaces
Imports PManagement.BusinessLayer.Services.Interfaces
Imports PManagement.BusinessLayer.Factories.Interfaces

Namespace Factories.Implementations
	Public Class BusinessProcessLogicFactory
		Implements IBusinessProcessLogicFactory
		Private res0 As IBusinessProcessLogicService
		Private res1 As IBusinessProcessLogicService
		Private res2 As IBusinessProcessLogicService
		Private res3 As IBusinessProcessLogicService
		Private ReadOnly _projectPlanTemplateService As IProjectPlanTemplateService
		Private ReadOnly _caseFactsStatusService As ICaseFactsStatusService
		Private ReadOnly _rcService As IRCService
		Private ReadOnly _rcOriginService As IRCOriginService

		Public Sub New(ByVal projectPlanTemplateService As IProjectPlanTemplateService,
		               ByVal caseFactsStatusService As ICaseFactsStatusService, ByVal rcService As IRCService,
		               ByVal rcOriginService As IRCOriginService)
			_projectPlanTemplateService = projectPlanTemplateService
			_caseFactsStatusService = caseFactsStatusService
			_rcService = rcService
			_rcOriginService = rcOriginService
		End Sub

		Public Function GetBusinessProcessLogicByBusinessProcessId(ByVal BusinessProcessId As Long) _
			As IBusinessProcessLogicService Implements IBusinessProcessLogicFactory.GetBusinessProcessLogicByBusinessProcessId

			Select Case BusinessProcessId
				Case 0
					If (res0 Is Nothing) Then
						res0 = New BusinessProcessLogicService0(_projectPlanTemplateService, _caseFactsStatusService)
					End If
					Return res0
				Case 1
					If (res1 Is Nothing) Then
						res1 = New BusinessProcessLogicService1(_projectPlanTemplateService, _caseFactsStatusService)
					End If
					Return res1
				Case 2
					If (res2 Is Nothing) Then
						res2 = New BusinessProcessLogicService2(_projectPlanTemplateService, _caseFactsStatusService)
					End If
					Return res2
				Case 3
					If (res3 Is Nothing) Then
						res3 = New BusinessProcessLogicService3(_projectPlanTemplateService, _caseFactsStatusService, _rcService,
						                                        _rcOriginService)
					End If
					Return res3
			End Select

			' Default
			Return Nothing
		End Function
	End Class
End Namespace