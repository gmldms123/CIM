﻿
Imports PManagement.BusinessLayer.Services.Interfaces

Namespace Factories.Interfaces
	Public Interface IBusinessProcessLogicFactory
		Function GetBusinessProcessLogicByBusinessProcessId(ByVal BusinessProcessId As Long) As IBusinessProcessLogicService
	End Interface
End Namespace