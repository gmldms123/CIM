Imports PManagement.BusinessLayer.Services.Interfaces

Namespace Services.Implementations
	Public Class BusinessLogicService
		Implements IBusinessLogicService

		Public Function GetIdOfBusinessProcessToUseForNewCases() As Integer _
			Implements IBusinessLogicService.GetIdOfBusinessProcessToUseForNewCases
			Return 3
		End Function
	End Class
End Namespace