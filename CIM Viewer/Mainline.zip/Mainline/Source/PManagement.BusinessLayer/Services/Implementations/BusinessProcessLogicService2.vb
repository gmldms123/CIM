
Imports PManagement.DataLayer
Imports PManagement.DataLayer.Interfaces
Imports PManagement.ServiceLayer.Services.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate
Imports PManagement.Framework.ValidationResults

Namespace Services.Implementations
	Public Class BusinessProcessLogicService2
		Inherits BusinessProcessLogicServiceBase

		Public Sub New(ByVal projectPlanTemplateService As IProjectPlanTemplateService,
		               ByVal caseFactsStatusService As ICaseFactsStatusService)
			MyBase.New(projectPlanTemplateService, caseFactsStatusService)
			Id = 2
		End Sub

		Public Overrides Function GetPhaseChangeValidation(ByVal phaseBefore As IPhase,
		                                                   ByVal standardTaskBefore As StandardTask,
		                                                   ByVal phaseAfter As IPhase, ByVal caseFactsModel As ICaseFactsModel) _
			As ValidationSummary
			Dim res As New ValidationSummary()
			Return res
		End Function

		Public Overrides Function GetStandardTaskChangeValidation(ByVal phase As IPhase,
		                                                          ByVal standardTaskBefore As StandardTask,
		                                                          ByVal standardTaskAfter As StandardTask,
		                                                          ByVal model As ICaseFactsModel) As ValidationSummary
			Dim res As New ValidationSummary()
			Return res
		End Function

		Public Overrides Function GetStatusChangeValidation(ByVal phase As IPhase, ByVal standardTask As StandardTask,
		                                                    ByVal statusBefore As ICaseFactsStatus,
		                                                    ByVal statusAfter As ICaseFactsStatus,
		                                                    ByVal model As ICaseFactsModel) As ValidationSummary
			Dim res As New ValidationSummary()
			Return res
		End Function

		Public Overrides Function GetCaseProcessProgressState(ByVal phaseAfter As IPhase,
		                                                      ByVal caseFactsModel As ICaseFactsModel) _
			As CaseProcessProgressState
			Dim initialStandardTask As StandardTask = GetInitialStandardTaskByPhase(phaseAfter.Id)
			GetInitialStatusByStandardTask(phaseAfter, initialStandardTask)

			Dim res As New CaseProcessProgressState(phaseAfter, initialStandardTask, caseFactsModel.Status)
			Return res
		End Function

		Public Overrides Function GetChangeValidation(ByVal phaseBefore As IPhase, ByVal standardTaskBefore As StandardTask,
		                                              ByVal statusBefore As ICaseFactsStatus, ByVal phaseAfter As IPhase,
		                                              ByVal standardTaskAfter As StandardTask,
		                                              ByVal statusAfter As ICaseFactsStatus,
		                                              ByVal caseFactsModel As ICaseFactsModel, ByVal res As ValidationSummary) _
			As ValidationSummary
			Throw New NotImplementedException()
		End Function
	End Class
End Namespace