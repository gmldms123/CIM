
Imports PManagement.Framework.Enums
Imports PManagement.DataLayer
Imports PManagement.DataLayer.Interfaces
Imports PManagement.ServiceLayer.Services.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate
Imports PManagement.Framework.ValidationResults
Imports PManagement.ModelLayer.RCOrigin

Namespace Services.Implementations
	Public Class BusinessProcessLogicService3
		Inherits BusinessProcessLogicServiceBase

		Private ReadOnly _rcService As IRCService
		Private ReadOnly _rcOriginService As IRCOriginService

		Public Sub New(ByVal projectPlanTemplateService As IProjectPlanTemplateService,
		               ByVal caseFactsStatusService As ICaseFactsStatusService, ByVal rcService As IRCService,
		               ByVal rcOriginService As IRCOriginService)
			MyBase.New(projectPlanTemplateService, caseFactsStatusService)
			_rcService = rcService
			_rcOriginService = rcOriginService
			Id = 3
		End Sub

		Public Overrides Function GetChangeValidation(ByVal phaseBefore As IPhase, ByVal standardTaskBefore As StandardTask,
		                                              ByVal statusBefore As ICaseFactsStatus, ByVal phaseAfter As IPhase,
		                                              ByVal standardTaskAfter As StandardTask,
		                                              ByVal statusAfter As ICaseFactsStatus,
		                                              ByVal caseFactsModel As ICaseFactsModel, ByVal res As ValidationSummary) _
			As ValidationSummary

			' Note: Zero-based
			Const indexOfPreparationProject As Integer = 0
			Const indexOfRcaProject As Integer = 1
			Const indexOfImprovementProject As Integer = 2
			Const indexOfImplementationProject As Integer = 3

			Dim phaseList As IPhaseList = _projectPlanTemplateService.GetPhases(Id)
			Const indexOfRcaUnderRcaProject As Integer = 2
			' Note - Gates are also present

			Const indexOfRcaPreparationUnderRcaProject As Integer = 0
			Const indexOfImprovementPreparationUnderImprovementProject As Integer = 0

			Dim tasksAfter As StandardTaskList = _projectPlanTemplateService.GetStandardTasksByPhase(Id, phaseAfter.Id)
			Dim indexOfStandardTask As Integer = tasksAfter.IndexOf(standardTaskAfter)

			Dim tasksBefore As StandardTaskList = _projectPlanTemplateService.GetStandardTasksByPhase(Id, phaseBefore.Id)
			Dim indexOfStandardTaskBefore As Integer = tasksBefore.IndexOf(standardTaskBefore)

			Dim movingToRcaProject As Boolean = phaseList.IndexOf(phaseAfter) = indexOfRcaProject
			Dim movingToImprovementProject As Boolean = phaseList.IndexOf(phaseAfter) = indexOfImprovementProject

			Dim movingToRcaRcaPreparation As Boolean = (movingToRcaProject) AndAlso
			                                           (indexOfStandardTask = indexOfRcaPreparationUnderRcaProject)
			Dim movingToImprovementPreparation As Boolean = (movingToImprovementProject) AndAlso
			                                                (indexOfStandardTask =
			                                                 indexOfImprovementPreparationUnderImprovementProject)

			Dim movingBeyondRcaProject As Boolean = phaseList.IndexOf(phaseAfter) > indexOfRcaProject
			Dim movingBeyondRcaProjectRcaPhase As Boolean = phaseList.IndexOf(phaseAfter) = indexOfRcaProject AndAlso
			                                                (indexOfStandardTask > indexOfRcaUnderRcaProject)

			'New
			Dim movingFromPreparationProject As Boolean = phaseList.IndexOf(phaseBefore) = indexOfPreparationProject
			Dim movingFromRcaProject As Boolean = phaseList.IndexOf(phaseBefore) = indexOfRcaProject
			Dim movingFromImprovementProject As Boolean = phaseList.IndexOf(phaseBefore) = indexOfImprovementProject
			Dim movingFromImplementationProject As Boolean = phaseList.IndexOf(phaseBefore) = indexOfImplementationProject

			'New
			Const indexOfRcaCompleteUnderRcaProject As Integer = 4
			' Note - Gates are also present
			Const indexOfPreparationCompleteUnderPreparationProject As Integer = 2
			' Note - Gates are also present
			Const indexOfImprovementCompletionUnderImprovementProject As Integer = 5
			' Note - Gates are also present
			Const indexOfImplementationUnderImplementationProject As Integer = 2
			' Note - Gates are also present

			Dim movingFromPreparationComplete As Boolean = (movingFromPreparationProject) AndAlso
			                                               (indexOfStandardTaskBefore =
			                                                indexOfPreparationCompleteUnderPreparationProject)
			Dim movingFromRcaRcaComplete As Boolean = (movingFromRcaProject) AndAlso
			                                          (indexOfStandardTaskBefore = indexOfRcaCompleteUnderRcaProject)
			Dim movingFromImprovementCompletetion As Boolean = (movingFromImprovementProject) AndAlso
			                                                   (indexOfStandardTaskBefore =
			                                                    indexOfImprovementCompletionUnderImprovementProject)
			Dim movingFromImplementationImplementation As Boolean = (movingFromImplementationProject) AndAlso
			                                                        (indexOfStandardTaskBefore =
			                                                         indexOfImplementationUnderImplementationProject)

			Dim isEitherProjectComplete As Boolean =
			    	movingFromPreparationComplete Or
			    	movingFromRcaRcaComplete Or
			    	movingFromImprovementCompletetion Or
			    	movingFromImplementationImplementation

			Dim isItTheSameProject As Boolean = (phaseList.IndexOf(phaseBefore) = phaseList.IndexOf(phaseAfter))

			'New
			If (Not isItTheSameProject) And Not (isEitherProjectComplete) Then
				Const formatString As String = "You cannot move into a new project before completing the current project"
				Dim infoToUserExecutionManager As String = String.Format(formatString)

				Dim viExecutionManager As New ValidationItem(ValidationResult.vrError, infoToUserExecutionManager)
				res.AddValidationItem(viExecutionManager)
			End If

			' Whenever we move to a phase/standardtask where the resulting status is Active, the Execution Manager must be specified
			If statusAfter.Id = _caseFactsStatusService.GetActiveStatus().Id Then

				Dim requireExecutionManager = True
				If (movingToRcaRcaPreparation) Or (movingToImprovementPreparation) Then
					requireExecutionManager = False
				End If

				If (requireExecutionManager) And (caseFactsModel.Case.ExecutionManager Is Nothing) Then
					Const formatString As String = "You need to add an Execution Manager when changing to status {0}"
					Dim infoToUserExecutionManager As String = String.Format(formatString, statusAfter.Name())

					Dim viExecutionManager As New ValidationItem(ValidationResult.vrError, infoToUserExecutionManager)
					res.AddValidationItem(viExecutionManager)
				End If
			End If

			' The technical specialist must be specified whenever we move to a phase/standardtask after the initial Phase
			If Not IsFirstPhase(phaseAfter) Then
				If caseFactsModel.Case.TechnicalSpecialist Is Nothing Then
					Dim item As ValidationItem = New ValidationItem(ValidationResult.vrError,
					                                                "You need to add a Technical Specialist when going into this project")
					res.AddValidationItem(item)
				End If
			End If

			' When project is moving beyond RCA a root cause must be filled.
			If movingBeyondRcaProject Or movingBeyondRcaProjectRcaPhase Then
				Dim rc As IRC = _rcService.GetRCByCaseId(caseFactsModel.Case.Id)
				Dim notInvestigatedOrigin As IRCOrigin = _rcOriginService.GetRCOriginByRCOrigin("Not investigated")
				ValidateThatRootCauseIsInvestigated(rc, notInvestigatedOrigin, res)
			End If

			Return res
		End Function

		' Create error in summary if root cause does not exist or origin is not investigated
		Public Sub ValidateThatRootCauseIsInvestigated(ByVal rootCause As IRC, ByVal notInvestigatedOrigin As IRCOrigin,
		                                               ByVal res As ValidationSummary)
			If rootCause Is Nothing OrElse rootCause.RCOrigin.Id = notInvestigatedOrigin.Id Then
				Dim item As ValidationItem = New ValidationItem(ValidationResult.vrError,
				                                                "You need to add Root Cause Origin when going to a project after RCA.")
				res.AddValidationItem(item)
			End If
		End Sub


		Public Overrides Function GetPhaseChangeValidation(ByVal phaseBefore As IPhase,
		                                                   ByVal standardTaskBefore As StandardTask,
		                                                   ByVal phaseAfter As IPhase, ByVal caseFactsModel As ICaseFactsModel) _
			As ValidationSummary
			Dim res As New ValidationSummary()
			Dim standardTaskAfter As StandardTask = GetInitialStandardTaskByPhase(phaseAfter.Id)
			Dim newStatus As ICaseFactsStatus = GetStatusIfChangingToPhaseStandardTask(phaseAfter, standardTaskAfter,
			                                                                           caseFactsModel, res)

			Return _
				GetChangeValidation(phaseBefore, standardTaskBefore, caseFactsModel.Status, phaseAfter, standardTaskAfter, newStatus,
				                    caseFactsModel, res)
		End Function

		Public Overrides Function GetStandardTaskChangeValidation(ByVal phase As IPhase,
		                                                          ByVal standardTaskBefore As StandardTask,
		                                                          ByVal standardTaskAfter As StandardTask,
		                                                          ByVal model As ICaseFactsModel) As ValidationSummary
			Dim res As New ValidationSummary()
			Dim newStatus As ICaseFactsStatus = GetStatusIfChangingToPhaseStandardTask(phase, standardTaskAfter, model, res)
			Return GetChangeValidation(phase, standardTaskBefore, model.Status, phase, standardTaskAfter, newStatus, model, res)
		End Function

		Public Overrides Function GetStatusChangeValidation(ByVal phase As IPhase, ByVal standardTask As StandardTask,
		                                                    ByVal statusBefore As ICaseFactsStatus,
		                                                    ByVal statusAfter As ICaseFactsStatus,
		                                                    ByVal model As ICaseFactsModel) As ValidationSummary
			Dim res As New ValidationSummary()
			Return GetChangeValidation(phase, standardTask, model.Status, phase, standardTask, statusAfter, model, res)
		End Function

		Public Overrides Function GetCaseProcessProgressState(ByVal phaseAfter As IPhase,
		                                                      ByVal caseFactsModel As ICaseFactsModel) _
			As CaseProcessProgressState
			Dim initialStandardTask As StandardTask = GetInitialStandardTaskByPhase(phaseAfter.Id)
			Dim status As ICaseFactsStatus = GetStatusIfChangingToPhaseStandardTask(phaseAfter, initialStandardTask,
			                                                                        caseFactsModel, New ValidationSummary())
			Dim res As New CaseProcessProgressState(phaseAfter, initialStandardTask, status)
			Return res
		End Function
	End Class
End Namespace
