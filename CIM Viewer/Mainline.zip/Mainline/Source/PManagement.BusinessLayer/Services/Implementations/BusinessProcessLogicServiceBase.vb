Imports PManagement.Framework.Enums
Imports PManagement.DataLayer
Imports PManagement.DataLayer.Interfaces
Imports PManagement.ServiceLayer.Services.Interfaces
Imports PManagement.BusinessLayer.Services.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate
Imports PManagement.Framework.ValidationResults

Namespace Services.Implementations
	Public MustInherit Class BusinessProcessLogicServiceBase
		Implements IBusinessProcessLogicService

		Private _Id As Integer
		Protected ReadOnly _projectPlanTemplateService As IProjectPlanTemplateService
		Protected ReadOnly _caseFactsStatusService As ICaseFactsStatusService

		Public Sub New(ByVal projectPlanTemplateService As IProjectPlanTemplateService,
		               ByVal caseFactsStatusService As ICaseFactsStatusService)
			_projectPlanTemplateService = projectPlanTemplateService
			_caseFactsStatusService = caseFactsStatusService
		End Sub

		Public Property Id() As Integer Implements IBusinessProcessLogicService.Id
			Get
				Return _Id
			End Get
			Protected Set(ByVal value As Integer)
				_Id = value
			End Set
		End Property

		Public Function GetAllPhases() As IPhaseList Implements IBusinessProcessLogicService.GetAllPhases
			Dim res = _projectPlanTemplateService.GetPhases(_Id)
			Return res
		End Function

		Public MustOverride Function GetPhaseChangeValidation(ByVal phaseBefore As IPhase,
		                                                      ByVal standardTaskBefore As StandardTask,
		                                                      ByVal phaseAfter As IPhase,
		                                                      ByVal caseFactsModel As ICaseFactsModel) As ValidationSummary _
			Implements IBusinessProcessLogicService_CaseProgressChange.GetPhaseChangeValidation

		Public MustOverride Function GetStandardTaskChangeValidation(ByVal phase As IPhase,
		                                                             ByVal standardTaskBefore As StandardTask,
		                                                             ByVal standardTaskAfter As StandardTask,
		                                                             ByVal model As ICaseFactsModel) As ValidationSummary _
			Implements IBusinessProcessLogicService_CaseProgressChange.GetStandardTaskChangeValidation

		Public MustOverride Function GetStatusChangeValidation(ByVal phase As IPhase, ByVal standardTask As StandardTask,
		                                                       ByVal statusBefore As ICaseFactsStatus,
		                                                       ByVal statusAfter As ICaseFactsStatus,
		                                                       ByVal model As ICaseFactsModel) As ValidationSummary _
			Implements IBusinessProcessLogicService_CaseProgressChange.GetStatusChangeValidation

		Public Function GetCaseProcessProgressState(ByVal phase As IPhase, ByVal standardTaskBefore As StandardTask,
		                                            ByVal standardTaskAfter As StandardTask, ByVal model As ICaseFactsModel) _
			As CaseProcessProgressState Implements IBusinessProcessLogicService_CaseProgressChange.GetCaseProcessProgressState
			Dim v As New ValidationSummary()
			Dim newStatus As ICaseFactsStatus = GetStatusIfChangingToPhaseStandardTask(phase, standardTaskAfter, model, v)
			Dim res As New CaseProcessProgressState(phase, standardTaskAfter, newStatus)
			Return res
		End Function

		Public Function GetCaseProcessProgressState(ByVal phase As IPhase, ByVal standardTask As StandardTask,
		                                            ByVal statusBefore As ICaseFactsStatus,
		                                            ByVal statusAfter As ICaseFactsStatus, ByVal model As ICaseFactsModel) _
			As CaseProcessProgressState Implements IBusinessProcessLogicService_CaseProgressChange.GetCaseProcessProgressState
			Dim res As New CaseProcessProgressState(phase, standardTask, statusAfter)
			Return res
		End Function

		Protected Function GetAllowedStatuses(ByVal phaseId As Long, ByVal standardtaskid As Long) _
			As List(Of ICaseFactsStatus)
			Dim allowedStatuses As List(Of ICaseFactsStatus) = _caseFactsStatusService.GetAllowedStatuses(phaseId, standardtaskid)
			Return allowedStatuses
		End Function

		Public Function GetInitialStandardTaskByPhase(ByVal phaseId As Long) As StandardTask _
			Implements IBusinessProcessLogicService.GetInitialStandardTaskByPhase
			Dim standardTasksInPhase As StandardTaskList = _projectPlanTemplateService.GetStandardTasksByPhase(_Id, phaseId)

			Dim orderedStandardTasks As IOrderedEnumerable(Of StandardTask) = From st_ In standardTasksInPhase Order By st_.Sort
			If (orderedStandardTasks.Count = 0) Then
				Const formatString As String = "For Business Process {0}, the Project with tech id {1} does not have any Phases. This Business Process is not configured correctly in database."
				Dim message As String = String.Format(formatString, _Id, phaseId)
				Throw New ArgumentOutOfRangeException(message)
			End If
			Dim firstStandardTask As StandardTask = orderedStandardTasks.First()

			Return firstStandardTask
		End Function

		Public MustOverride Function GetCaseProcessProgressState(ByVal phaseAfter As IPhase,
		                                                         ByVal caseFactsModel As ICaseFactsModel) _
			As CaseProcessProgressState Implements IBusinessProcessLogicService_CaseProgressChange.GetCaseProcessProgressState

		Public Function GetRelevantPhases(ByVal PhaseIdOfCurrentPhase As Long) As IPhaseList _
			Implements IBusinessProcessLogicService.GetRelevantPhases
			Dim all As IPhaseList = GetAllPhases()

			Return all
		End Function

		Public Function GetRelevantStandardTasks(ByVal phaseId As Long, ByVal standardTaskId As Long) As StandardTaskList _
			Implements IBusinessProcessLogicService.GetRelevantStandardTasks
			Dim allStandardTasksForPhase As StandardTaskList = _projectPlanTemplateService.GetStandardTasksByPhase(_Id, phaseId)

			Dim nonGates As IEnumerable(Of StandardTask) =
			    	From st As StandardTask In allStandardTasksForPhase Where (Not st.IsGate) Select st

			Dim nongateslist As New StandardTaskList(nonGates)

			Dim itemBefore As StandardTask = nongateslist.GetStandardTaskBefore(standardTaskId)
			Dim itemCurrent As StandardTask =
			    	(From st As StandardTask In nongateslist Where st.Id = standardTaskId Select st).FirstOrDefault
			Dim itemAfter As StandardTask = nongateslist.GetStandardTaskAfter(standardTaskId)

			Dim res As New StandardTaskList()
			If (itemBefore IsNot Nothing) Then
				res.Add(itemBefore)
			End If

			If (itemCurrent IsNot Nothing) Then
				res.Add(itemCurrent)
			End If

			If (itemAfter IsNot Nothing) Then
				res.Add(itemAfter)
			End If

			Return res
		End Function

		Public Function GetRelevantStatuses(ByVal phaseId As Long, ByVal standardTaskId As Long) As List(Of ICaseFactsStatus) _
			Implements IBusinessProcessLogicService.GetRelevantStatuses
			Dim res As List(Of ICaseFactsStatus) = _caseFactsStatusService.GetAllowedStatuses(phaseId, standardTaskId)
			Return res
		End Function

		Public Function GetInitialStatusByStandardTask(ByVal phase As IPhase, ByVal standardTask As StandardTask) _
			As ICaseFactsStatus
			Dim allowedStatuses As List(Of ICaseFactsStatus) = _caseFactsStatusService.GetAllowedStatuses(phase.Id,
			                                                                                              standardTask.Id)

			Dim status As ICaseFactsStatus = allowedStatuses.First()

			Return status
		End Function

		Public Function GetInitialStatusForNewCase() As ICaseFactsStatus _
			Implements IBusinessProcessLogicService.GetInitialStatusForNewCase
			Dim initialPhase As IPhase = GetInitialPhaseForNewCase()
			Dim initialStandardTask As StandardTask = GetInitialStandardTaskForNewCase()

			Dim res As ICaseFactsStatus = GetInitialStatusByStandardTask(initialPhase, initialStandardTask)

			Return res
		End Function

		Public Function GetReopenedCaseProcessProgressState(
		                                                    ByVal caseProcessProgressStateWhenAskedToReopen As _
		                                                   	CaseProcessProgressState) As CaseProcessProgressState _
			Implements IBusinessProcessLogicService.GetReopenedCaseProcessProgressState
			Return GetLatestPhaseBeforeThisWhereStandbyIsPossible(caseProcessProgressStateWhenAskedToReopen)
		End Function

		Private Function GetLatestPhaseBeforeThisWhereStandbyIsPossible(
		                                                                ByVal caseProcessProgressStateWhenAskedToReopen As _
		                                                               	CaseProcessProgressState) As CaseProcessProgressState
			Dim all As CaseProcessProgressList = _projectPlanTemplateService.CaseProcessProgressList(Id)

			Dim phase As IPhase = caseProcessProgressStateWhenAskedToReopen.Phase
			Dim standardTask As StandardTask = caseProcessProgressStateWhenAskedToReopen.StandardTask

			Dim currentIndex As Integer = all.GetItemByPhaseAndStandardTask(phase.Id, standardTask.Id)

			While Not all(currentIndex).AllowsStandbyStatus()
				currentIndex = currentIndex - 1
			End While

			Dim standbyStatus As ICaseFactsStatus = _caseFactsStatusService.GetStandbyStatus()

			Dim res As New CaseProcessProgressState(all(currentIndex).Phase, all(currentIndex).StandardTask, standbyStatus)
			Return res
		End Function

		Public Function GetLastPossibleCaseProcessProgressState() As CaseProcessProgressState _
			Implements IBusinessProcessLogicService.GetLastPossibleCaseProcessProgressState
			Dim phase As IPhase = GetAllPhases.Last()
			Dim stdTask As StandardTask = GetNonGateStandardTasksByPhase(phase.Id).Last
			Dim st As ICaseFactsStatus = GetAllowedStatuses(phase.Id, stdTask.Id).Last

			Dim res As New CaseProcessProgressState(phase, stdTask, st)
			Return res
		End Function

		Private Function GetNonGateStandardTasksByPhase(ByVal phaseId As Long) As IEnumerable(Of StandardTask)
			Dim standardTasksByPhase As StandardTaskList = _projectPlanTemplateService.GetStandardTasksByPhase(_Id, phaseId)
			Dim stdTasks As StandardTaskList = standardTasksByPhase.GetNonGateSubList()

			Return stdTasks
		End Function

		Public Function GetAllStandardTasks() As StandardTaskList Implements IBusinessProcessLogicService.GetAllStandardTasks
			Dim res = _projectPlanTemplateService.GetStandardTasks(_Id)
			Return res
		End Function

		Public Function GetBusinessProcessValidation(ByVal [case] As ICase) As ValidationSummary _
			Implements IBusinessProcessLogicService.GetBusinessProcessValidation
			Dim validationSummary As New ValidationSummary()
			If ([case].Phase Is Nothing) Then
				Const infoToUser As String = "This CIM Case did not have a Project. The default Project and Phase will be assigned by system."
				Dim vi As New ValidationItem(ValidationResult.vrWarning, infoToUser)
				validationSummary.AddValidationItem(vi)
			Else
				Dim allPhases As IPhaseList = GetAllPhases()
				If Not (allPhases.Contains([case].Phase)) Then
					Const infoToUser As String = "This CIM Case was assigned a Project which did not correspond to the assigned Business Process. The default Project and Phase will be assigned by system."
					Dim vi As New ValidationItem(ValidationResult.vrWarning, infoToUser)
					validationSummary.AddValidationItem(vi)
				End If
			End If

			If ([case].StandardTask Is Nothing) Then
				'[case].StandardTask = businessProcessLogicService.GetInitialStandardTaskByPhase([case].Phase.Id)
				Const infoToUser As String = "This CIM Case did not have an assigned Phase. The default Phase will be assigned by system."
				Dim vi As New ValidationItem(ValidationResult.vrWarning, infoToUser)
				validationSummary.AddValidationItem(vi)
			Else
				Dim allStandardTasks As StandardTaskList = GetAllStandardTasks()
				If Not (allStandardTasks.Contains([case].StandardTask)) Then
					Const formatString As String = "This CIM Case was assigned a Phase ({0}) which did not correspond to the assigned Business Process. The default Phase will be assigned by system."
					Dim infoToUser As String = String.Format(formatString, [case].StandardTask)
					Dim vi As New ValidationItem(ValidationResult.vrWarning, infoToUser)
					validationSummary.AddValidationItem(vi)
				End If
			End If

			Return validationSummary
		End Function

		Public Function MakeBusinessProcessCorrectiveActions(ByVal [case] As ICase) As ValidationSummary _
			Implements IBusinessProcessLogicService.MakeBusinessProcessCorrectiveActions
			Dim validationSummary As New ValidationSummary()

			If ([case].Phase Is Nothing) Then
				Dim _
					vi As _
						New ValidationItem(ValidationResult.vrWarning,
						                   "This CIM Case did not have a Project. The default Project and Phase has been assigned by system.")
				validationSummary.AddValidationItem(vi)

				[case].Phase = GetInitialPhaseForNewCase()
			Else
				Dim allPhases As IPhaseList = GetAllPhases()

				If Not (allPhases.Contains([case].Phase)) Then
					[case].Phase = GetInitialPhaseForNewCase()
					[case].StandardTask = GetInitialStandardTaskByPhase([case].Phase.Id)

					Const infoToUser As String = "This CIM Case was assigned a Project which did not correspond to the assigned Business Process. The default Project and Phase has been assigned by system."
					Dim vi As New ValidationItem(ValidationResult.vrWarning, infoToUser)
					validationSummary.AddValidationItem(vi)
				End If
			End If

			If ([case].StandardTask Is Nothing) Then
				Dim _
					vi As _
						New ValidationItem(ValidationResult.vrWarning,
						                   "This CIM Case did not have a Phase. The default Phase has been assigned by system.")
				validationSummary.AddValidationItem(vi)

				[case].StandardTask = GetInitialStandardTaskForNewCase()
			Else
				Dim allStandardTasks As StandardTaskList = GetAllStandardTasks()

				If Not (allStandardTasks.Contains([case].StandardTask)) Then
					[case].StandardTask = GetInitialStandardTaskByPhase([case].Phase.Id)

					Const infoToUser As String = "This CIM Case was assigned a Phase which did not correspond to the assigned Business Process. The default Phase has been assigned by system."
					Dim vi As New ValidationItem(ValidationResult.vrWarning, infoToUser)
					validationSummary.AddValidationItem(vi)
				End If
			End If

			Return validationSummary
		End Function

		Public Function GetInitialPhaseForNewCase() As IPhase _
			Implements IBusinessProcessLogicService.GetInitialPhaseForNewCase
			Dim pl As IPhaseList = GetAllPhases()

			Dim p As IPhase = (From p_ In pl Order By p_.Sort Select p_).First()

			Return p
		End Function

		Public Function GetInitialStandardTaskForNewCase() As StandardTask _
			Implements IBusinessProcessLogicService.GetInitialStandardTaskForNewCase
			Dim initialPhase As IPhase = GetInitialPhaseForNewCase()

			Dim firstStandardTask As StandardTask = GetInitialStandardTaskByPhase(initialPhase.Id)

			Return firstStandardTask
		End Function

		Protected Function IsFirstPhase(ByVal phase As IPhase) As Boolean
			Dim allPhases As IPhaseList = GetAllPhases()
			Return (allPhases.First().Id = phase.Id)
		End Function

		Public Function GetStatusIfChangingToPhaseStandardTask(ByVal phaseAfter As IPhase,
		                                                       ByVal standardTaskAfter As StandardTask,
		                                                       ByVal caseFactsModel As ICaseFactsModel,
		                                                       ByVal res As ValidationSummary) As ICaseFactsStatus

			Dim statusList As List(Of ICaseFactsStatus) = GetAllowedStatuses(phaseAfter.Id, standardTaskAfter.Id)

			' Is the current status one of the possible statuses after the change? 
			' If so, it's a keeper!
			If (statusList.Contains(caseFactsModel.Status)) Then
				Return caseFactsModel.Status
			End If

			' Otherwise warn, that we need to change the Ststus as a side effect.
			Dim newStatus As ICaseFactsStatus = GetInitialStatusByStandardTask(phaseAfter, standardTaskAfter)

			Const formatString As String = "The selected change requires the case to change status to {0}. This will be done automatically."

			Dim infoToUser As String = String.Format(formatString, newStatus.Name)

			Dim vi As New ValidationItem(ValidationResult.vrWarning, infoToUser)
			res.AddValidationItem(vi)

			Return newStatus
		End Function

		Public MustOverride Function GetChangeValidation(ByVal phaseBefore As IPhase, ByVal standardTaskBefore As StandardTask,
		                                                 ByVal statusBefore As ICaseFactsStatus, ByVal phaseAfter As IPhase,
		                                                 ByVal standardTaskAfter As StandardTask,
		                                                 ByVal statusAfter As ICaseFactsStatus,
		                                                 ByVal caseFactsModel As ICaseFactsModel,
		                                                 ByVal res As ValidationSummary) As ValidationSummary _
			Implements IBusinessProcessLogicService.GetChangeValidation
	End Class
End Namespace