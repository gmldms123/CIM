﻿Namespace Services.Interfaces
	Public Interface IBusinessLogicService
		Function GetIdOfBusinessProcessToUseForNewCases() As Integer
	End Interface
End Namespace