Imports PManagement.DataLayer.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate
Imports PManagement.Framework.ValidationResults

Namespace Services.Interfaces
	Public Interface IBusinessProcessLogicService
		Inherits IBusinessProcessLogicService_CaseCreation, IBusinessProcessLogicService_ReopeningCase,
		         IBusinessProcessLogicService_CaseProgressChange

		Property Id() As Integer

		Function GetAllPhases() As IPhaseList
		Function GetAllStandardTasks() As StandardTaskList
		Function GetBusinessProcessValidation(ByVal [case] As ICase) As ValidationSummary
		Function MakeBusinessProcessCorrectiveActions(ByVal [case] As ICase) As ValidationSummary
	End Interface
End Namespace