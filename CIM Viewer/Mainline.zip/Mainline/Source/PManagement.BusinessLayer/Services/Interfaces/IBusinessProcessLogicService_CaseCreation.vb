Imports PManagement.DataLayer.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate

Namespace Services.Interfaces
	Public Interface IBusinessProcessLogicService_CaseCreation
		Function GetInitialPhaseForNewCase() As IPhase
		Function GetInitialStandardTaskForNewCase() As StandardTask
		Function GetInitialStatusForNewCase() As ICaseFactsStatus

		Function GetInitialStandardTaskByPhase(ByVal phaseId As Long) As StandardTask

		Function GetRelevantPhases(ByVal PhaseIdOfCurrentPhase As Long) As IPhaseList
		Function GetRelevantStandardTasks(ByVal phaseId As Long, ByVal standardTaskId As Long) As StandardTaskList
		Function GetRelevantStatuses(ByVal phaseId As Long, ByVal standardTaskId As Long) As List(Of ICaseFactsStatus)
	End Interface
End NameSpace