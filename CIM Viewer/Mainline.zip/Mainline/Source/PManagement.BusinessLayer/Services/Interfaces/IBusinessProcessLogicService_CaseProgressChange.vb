Imports PManagement.DataLayer
Imports PManagement.DataLayer.Interfaces
Imports PManagement.DataLayer.ProjectPlanTemplate
Imports PManagement.Framework.ValidationResults

Namespace Services.Interfaces
	Public Interface IBusinessProcessLogicService_CaseProgressChange
		Function GetCaseProcessProgressState(ByVal phaseAfter As IPhase, ByVal caseFactsModel As ICaseFactsModel) _
			As CaseProcessProgressState

		Function GetLastPossibleCaseProcessProgressState() As CaseProcessProgressState

		Function GetPhaseChangeValidation(ByVal phaseBefore As IPhase, ByVal standardTaskBefore As StandardTask,
		                                  ByVal phaseAfter As IPhase, ByVal caseFactsModel As ICaseFactsModel) _
			As ValidationSummary

		Function GetStandardTaskChangeValidation(ByVal phase As IPhase, ByVal standardTaskBefore As StandardTask,
		                                         ByVal standardTaskAfter As StandardTask, ByVal model As ICaseFactsModel) _
			As ValidationSummary

		Function GetCaseProcessProgressState(ByVal phase As IPhase, ByVal standardTaskBefore As StandardTask,
		                                     ByVal standardTaskAfter As StandardTask, ByVal model As ICaseFactsModel) _
			As CaseProcessProgressState

		Function GetStatusChangeValidation(ByVal phase As IPhase, ByVal standardTask As StandardTask,
		                                   ByVal statusBefore As ICaseFactsStatus, ByVal statusAfter As ICaseFactsStatus,
		                                   ByVal model As ICaseFactsModel) As ValidationSummary

		Function GetCaseProcessProgressState(ByVal phase As IPhase, ByVal standardTask As StandardTask,
		                                     ByVal statusBefore As ICaseFactsStatus, ByVal statusAfter As ICaseFactsStatus,
		                                     ByVal model As ICaseFactsModel) As CaseProcessProgressState

		Function GetChangeValidation(ByVal phaseBefore As IPhase, ByVal standardTaskBefore As StandardTask,
		                             ByVal statusBefore As ICaseFactsStatus, ByVal phaseAfter As IPhase,
		                             ByVal standardTaskAfter As StandardTask, ByVal statusAfter As ICaseFactsStatus,
		                             ByVal caseFactsModel As ICaseFactsModel, ByVal res As ValidationSummary) _
			As ValidationSummary
	End Interface
End NameSpace