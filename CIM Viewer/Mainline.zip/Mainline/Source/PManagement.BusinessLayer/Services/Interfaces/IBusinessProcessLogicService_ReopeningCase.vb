Imports PManagement.DataLayer

Namespace Services.Interfaces
	Public Interface IBusinessProcessLogicService_ReopeningCase
		Function GetReopenedCaseProcessProgressState(
		                                             ByVal caseProcessProgressStateWhenAskedToReopen As _
		                                            	CaseProcessProgressState) As CaseProcessProgressState
	End Interface
End NameSpace