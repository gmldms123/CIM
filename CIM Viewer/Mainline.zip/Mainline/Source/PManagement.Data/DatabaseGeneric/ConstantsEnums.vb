﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System

Namespace PManagement.Data

	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertCategory.
	''' </summary>
	Public Enum AlertCategoryFieldIndex
		[AlertCategoryId]
		[Name]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertCategoryCriteria.
	''' </summary>
	Public Enum AlertCategoryCriteriaFieldIndex
		[AlertCategoryCriteriaId]
		[AlertConfigId]
		[AlertCategoryId]
		[Value]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertChangeTypeCriteria.
	''' </summary>
	Public Enum AlertChangeTypeCriteriaFieldIndex
		[AlertChangeTypeCriteriaId]
		[AlertConfigId]
		[ChangeTypeId]
		[Value]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertConfig.
	''' </summary>
	Public Enum AlertConfigFieldIndex
		[AlertConfigId]
		[AlertFrequencyId]
		[LastHandled]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertConfigCircount.
	''' </summary>
	Public Enum AlertConfigCircountFieldIndex
		[AlertConfigCircountId]
		[AlertConfigId]
		[Count]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertFrequency.
	''' </summary>
	Public Enum AlertFrequencyFieldIndex
		[AlertFrequencyId]
		[Name]
		[HandleDay]
		[HandleFrequency]
		[HandleTime]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertReceiver.
	''' </summary>
	Public Enum AlertReceiverFieldIndex
		[AlertReceiverId]
		[AlertConfigId]
		[Value]
		[AlertReceiverTypeId]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		[IsGroup]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertReceiverRoleType.
	''' </summary>
	Public Enum AlertReceiverRoleTypeFieldIndex
		[AlertReceiverRoleTypeId]
		[Name]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertReceiverType.
	''' </summary>
	Public Enum AlertReceiverTypeFieldIndex
		[AlertReceiverTypeId]
		[Name]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AlertServiceSettings.
	''' </summary>
	Public Enum AlertServiceSettingsFieldIndex
		[AlertServiceSettingId]
		[LastRun]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: AnyChanges.
	''' </summary>
	Public Enum AnyChangesFieldIndex
		[AnyChangesId]
		[WindowNo]
		[Description]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Brand.
	''' </summary>
	Public Enum BrandFieldIndex
		[BrandId]
		[Name]
		[InitialPortfolioId]
		[CaseStandbyTextUrl]
		[PortalUrl]
		[MasterMinorText]
		[SharepointNewsChannelId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Brand2DocumentTemplate.
	''' </summary>
	Public Enum Brand2DocumentTemplateFieldIndex
		[Brand2DocumentTemplateId]
		[BrandId]
		[PhaseId]
		[DocumentTemplateId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Brand2Feature.
	''' </summary>
	Public Enum Brand2FeatureFieldIndex
		[BrandId]
		[FeatureId]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Brand2StandardMilestone.
	''' </summary>
	Public Enum Brand2StandardMilestoneFieldIndex
		[Brand2StandardMilestoneId]
		[BrandId]
		[StandardMilestoneId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: BusinessProcess.
	''' </summary>
	Public Enum BusinessProcessFieldIndex
		[BusinessProcessId]
		[Description]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case.
	''' </summary>
	Public Enum CaseFieldIndex
		[CaseId]
		[BrandId]
		[CaseNo]
		[PhaseId]
		[StatusId]
		[ClaimStatusId]
		[Pbuid]
		[ProjectPortalId]
		[ManagerId]
		[Uplink]
		[Description]
		[Created]
		[CreatedById]
		[LastEdited]
		[LastEditedById]
		[StandbyText]
		[ConfirmedBySupplier]
		[HasProcessedMsprojectPlan]
		[StartDate]
		[FinishDate]
		[DurationHours]
		[PercentComplete]
		[SalesOption]
		[Platform]
		[ClosureDate]
		[ReopenDate]
		[TechnicalSpecialistId]
		[ExecutionManagerId]
		[ClosedForInvoicing]
		[PortfolioId]
		[BusinessProcessId]
		[StandardTaskId]
		[StandardTask_]
		[StateChangedDate]
		[CategoryId]
		[ComponentId]
		[PersonalSafetyId]
		[Bleeding]
		[SafetyAlert]
		[Dmsdocument]
		[ReferenceNumber]
		[Econumber]
		[ContainmentLeadId]
		[ProjectScopeId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2CaseBundle.
	''' </summary>
	Public Enum Case2CaseBundleFieldIndex
		[Case2CaseBundleId]
		[CaseBundleId]
		[CaseId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2ComponentType.
	''' </summary>
	Public Enum Case2ComponentTypeFieldIndex
		[Case2ComponentTypeId]
		[CaseId]
		[ComponentTypeId]
		[SupplierLink]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2Item.
	''' </summary>
	Public Enum Case2ItemFieldIndex
		[Case2ItemId]
		[CaseId]
		[ItemId]
		[Root]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2KPIRating.
	''' </summary>
	Public Enum Case2KPIRatingFieldIndex
		[Case2KPIRatingId]
		[CaseId]
		[KPIRatingId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2LogInfo.
	''' </summary>
	Public Enum Case2LogInfoFieldIndex
		[Case2LogInfoId]
		[CaseId]
		[LogInfoId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2Participant.
	''' </summary>
	Public Enum Case2ParticipantFieldIndex
		[Case2ParticipantId]
		[CaseId]
		[ParticipantId]
		[ParticipationTypeId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2Phase.
	''' </summary>
	Public Enum Case2PhaseFieldIndex
		[Case2PhaseId]
		[CaseId]
		[PhaseId]
		[Relevant]
		[Budget]
		[Realised]
		[StartDate]
		[DeadlineDate]
		[FinishDate]
		[DurationHours]
		[PercentComplete]
		[ScheduleComments]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2ReasonCode.
	''' </summary>
	Public Enum Case2ReasonCodeFieldIndex
		[Case2ReasonCodeId]
		[CaseId]
		[ReasonCodeId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2Sbu.
	''' </summary>
	Public Enum Case2SbuFieldIndex
		[Case2Sbuid]
		[CaseId]
		[Sbuid]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2ServiceCode.
	''' </summary>
	Public Enum Case2ServiceCodeFieldIndex
		[Case2ServiceCodeId]
		[CaseId]
		[ServiceCodeId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2Supplier.
	''' </summary>
	Public Enum Case2SupplierFieldIndex
		[Case2SupplierId]
		[CaseId]
		[SupplierId]
		[FailedItem]
		[RootItem]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2Supplier2Stage.
	''' </summary>
	Public Enum Case2Supplier2StageFieldIndex
		[Case2Supplier2StageId]
		[Case2SupplierId]
		[StageId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2System.
	''' </summary>
	Public Enum Case2SystemFieldIndex
		[Case2SystemId]
		[CaseId]
		[System]
		[SystemChecked]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2TurbineMatrix.
	''' </summary>
	Public Enum Case2TurbineMatrixFieldIndex
		[Case2TurbineMatrixId]
		[CaseId]
		[TurbineMatrixId]
		[InitialFailed]
		[MkversionExpected]
		[MkversionActual]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Case2TurbineMatrix2Case2Item.
	''' </summary>
	Public Enum Case2TurbineMatrix2Case2ItemFieldIndex
		[Case2TurbineMatrix2Case2ItemId]
		[Case2TurbineMatrixId]
		[Case2ItemId]
		[StageId]
		[Count]
		[InitialFailed]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: CaseBundle.
	''' </summary>
	Public Enum CaseBundleFieldIndex
		[CaseBundleId]
		[PhaseId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: CaseRelation.
	''' </summary>
	Public Enum CaseRelationFieldIndex
		[CaseRelationId]
		[Name]
		[DependencyWarning]
		[PhaseId]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Category.
	''' </summary>
	Public Enum CategoryFieldIndex
		[CategoryId]
		[Name]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ChangeLog.
	''' </summary>
	Public Enum ChangeLogFieldIndex
		[ChangeLogId]
		[CaseId]
		[BeforeValue]
		[AfterValue]
		[ChangeTypeId]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		[AdditionalInfo]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ChangeType.
	''' </summary>
	Public Enum ChangeTypeFieldIndex
		[ChangeTypeId]
		[Name]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Cir.
	''' </summary>
	Public Enum CirFieldIndex
		[Cirid]
		[CaseId]
		[ComponentFailureReportId]
		[TurbineNo]
		[ProcessedDate]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		[NewCir]
		[ReportTypeId]
		[Verified]
		[VerifiedBy]
		[Rejected]
		[RejectedBy]
		[DateOfInspection]
		[DateOfFailure]
		[SiteName]
		[ServiceReportNumber]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ClaimStatus.
	''' </summary>
	Public Enum ClaimStatusFieldIndex
		[ClaimStatusId]
		[Name]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Component.
	''' </summary>
	Public Enum ComponentFieldIndex
		[ComponentId]
		[Name]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ComponentType.
	''' </summary>
	Public Enum ComponentTypeFieldIndex
		[ComponentTypeId]
		[Name]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Control.
	''' </summary>
	Public Enum ControlFieldIndex
		[ControlId]
		[Name]
		[FriendlyName]
		[ModuleId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: CustomColumnsName.
	''' </summary>
	Public Enum CustomColumnsNameFieldIndex
		[CustomColumnsNameId]
		[PopulationlistId]
		[Name]
		[Order]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: CustomColumnsValue.
	''' </summary>
	Public Enum CustomColumnsValueFieldIndex
		[CustomColumnsValueId]
		[PopulationlistItemId]
		[CustomColumnsNameId]
		[Value]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Discussion.
	''' </summary>
	Public Enum DiscussionFieldIndex
		[DiscussionId]
		[CaseId]
		[ReplyToDiscussionId]
		[Name]
		[Description]
		[Created]
		[CreatedById]
		[Modified]
		[ModifiedById]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Document.
	''' </summary>
	Public Enum DocumentFieldIndex
		[DocumentId]
		[DocumentBinaryId]
		[DocumentClassificationId]
		[FileName]
		[FileSize]
		[FileDate]
		[Title]
		[Description]
		[Category]
		[LinkNo]
		[PictureHeight]
		[PictureWidth]
		[PictureDate]
		[Thumbnail]
		[TurbineNumber]
		[Created]
		[CreatedById]
		[Locked]
		[LockedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: DocumentBinary.
	''' </summary>
	Public Enum DocumentBinaryFieldIndex
		[DocumentBinaryId]
		[Document]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: DocumentClassification.
	''' </summary>
	Public Enum DocumentClassificationFieldIndex
		[DocumentClassificationId]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: DocumentStatus.
	''' </summary>
	Public Enum DocumentStatusFieldIndex
		[DocumentStatusId]
		[Name]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: DocumentTemplate.
	''' </summary>
	Public Enum DocumentTemplateFieldIndex
		[DocumentTemplateId]
		[DocumentBinaryId]
		[DocumentClassificationId]
		[Title]
		[FileName]
		[FileSize]
		[Thumbnail]
		[Version]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: DocumentVersion.
	''' </summary>
	Public Enum DocumentVersionFieldIndex
		[DocumentVersionId]
		[DocumentId]
		[Version]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Erpsystem.
	''' </summary>
	Public Enum ErpsystemFieldIndex
		[ErpsystemId]
		[Name]
		[Priority]
		[ReadOnly]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Feature.
	''' </summary>
	Public Enum FeatureFieldIndex
		[FeatureId]
		[Description]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Folder.
	''' </summary>
	Public Enum FolderFieldIndex
		[FolderId]
		[CaseId]
		[FolderTypeId]
		[Name]
		[ParentFolderId]
		[Sort]
		[Locked]
		[LockedBy]
		[Created]
		[CreatedBy]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Folder2Document.
	''' </summary>
	Public Enum Folder2DocumentFieldIndex
		[Folder2DocumentId]
		[FolderId]
		[DocumentId]
		[DocumentStatusId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: FolderType.
	''' </summary>
	Public Enum FolderTypeFieldIndex
		[FolderTypeId]
		[Name]
		[Description]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Help.
	''' </summary>
	Public Enum HelpFieldIndex
		[HelpId]
		[TopicId]
		[Text]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: InlineHelp.
	''' </summary>
	Public Enum InlineHelpFieldIndex
		[InlineHelpId]
		[BrandId]
		[ControlId]
		[SystemText]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: InlineHelpText.
	''' </summary>
	Public Enum InlineHelpTextFieldIndex
		[InlineHelpTextId]
		[InlineHelpId]
		[LanguageId]
		[LocalizedText]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Item.
	''' </summary>
	Public Enum ItemFieldIndex
		[ItemId]
		[ItemNo]
		[Description]
		[ErpsystemId]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		[ModifiedVersion]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ItemStatus.
	''' </summary>
	Public Enum ItemStatusFieldIndex
		[ItemStatusId]
		[PopulationListItemId]
		[ServiceTypeId]
		[ServiceMessage]
		[Planned]
		[Done]
		[PaidById]
		[SaptaskId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ItemSystemMapping.
	''' </summary>
	Public Enum ItemSystemMappingFieldIndex
		[MappingId]
		[ItemNo]
		[System]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ItemSystemMappingStagingTable.
	''' </summary>
	Public Enum ItemSystemMappingStagingTableFieldIndex
		[MappingId]
		[ItemNo]
		[System]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Language.
	''' </summary>
	Public Enum LanguageFieldIndex
		[LanguageId]
		[Name]
		[SaplanguageId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: LogInfo.
	''' </summary>
	Public Enum LogInfoFieldIndex
		[LogInfoId]
		[CtrlTypeId]
		[Release]
		[LogNo]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		[ModifiedVersion]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: LogInfo2LogTxt.
	''' </summary>
	Public Enum LogInfo2LogTxtFieldIndex
		[LogInfo2LogTxtId]
		[LogInfoId]
		[LogTxtId]
		[ModifiedVersion]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: LogTxt.
	''' </summary>
	Public Enum LogTxtFieldIndex
		[LogTxtId]
		[CtrlTypeId]
		[CtrlTypeText]
		[LogNo]
		[Text]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		[ModifiedVersion]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Milestone.
	''' </summary>
	Public Enum MilestoneFieldIndex
		[MilestoneId]
		[CaseId]
		[Description]
		[DeadlineDate]
		[ResponsiblePersonId]
		[FinishDate]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Module.
	''' </summary>
	Public Enum ModuleFieldIndex
		[ModuleId]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: News.
	''' </summary>
	Public Enum NewsFieldIndex
		[NewsId]
		[CaseId]
		[Name]
		[Description]
		[Created]
		[CreatedbyId]
		[Modified]
		[ModifiedById]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: News2Participant.
	''' </summary>
	Public Enum News2ParticipantFieldIndex
		[News2ParticipantId]
		[NewsId]
		[ParticipantId]
		[SendOn]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: OldCimturbine.
	''' </summary>
	Public Enum OldCimturbineFieldIndex
		[OldCimturbineId]
		[CaseId]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Participant.
	''' </summary>
	Public Enum ParticipantFieldIndex
		[ParticipantId]
		[VppersonId]
		[VestasInitials]
		[LoginInitials]
		[Phone]
		[Email]
		[HasLeft]
		[FormattedName]
		[DepartmentId]
		[SiteId]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		[Title]
		[Department]
		[BusinessUnitId]
		[BusinessUnit]
		[BusinessUnitShortName]
		[Sbuid]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Participant2Role.
	''' </summary>
	Public Enum Participant2RoleFieldIndex
		[Participant2RoleId]
		[ParticipantId]
		[RoleId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ParticipantLog.
	''' </summary>
	Public Enum ParticipantLogFieldIndex
		[ParticipantLogId]
		[ParticipantId]
		[Timestamp]
		[Platform]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ParticipationType.
	''' </summary>
	Public Enum ParticipationTypeFieldIndex
		[ParticipationTypeId]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Payee.
	''' </summary>
	Public Enum PayeeFieldIndex
		[PayeeId]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Pbu.
	''' </summary>
	Public Enum PbuFieldIndex
		[Pbuid]
		[Name]
		[ShortName]
		[VpdptId]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: PerformanceAction.
	''' </summary>
	Public Enum PerformanceActionFieldIndex
		[PerformanceActionId]
		[Name]
		[Description]
		[Enabled]
		[CreatedDateTime]
		[CreatedInitials]
		[DeletedDateTime]
		[DeletedInitials]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: PerformanceData.
	''' </summary>
	Public Enum PerformanceDataFieldIndex
		[PerformanceDataId]
		[PerformanceActionId]
		[Duration]
		[ComputerName]
		[IpAdress]
		[ConnectionType]
		[ProcessId]
		[MemoryUsage]
		[AvailableMemory]
		[TotalMemory]
		[CaseId]
		[RunningProcesses]
		[AdditionalInfo]
		[CreatedDateTime]
		[CreatedInitials]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: PerformanceUtilitySetting.
	''' </summary>
	Public Enum PerformanceUtilitySettingFieldIndex
		[PerformanceUtilitySettingId]
		[Name]
		[Value]
		[CreatedDateTime]
		[CreatedInitials]
		[DeletedDateTime]
		[DeletedInitials]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Permission.
	''' </summary>
	Public Enum PermissionFieldIndex
		[PermissionId]
		[Name]
		[Description]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: PersonalSafety.
	''' </summary>
	Public Enum PersonalSafetyFieldIndex
		[PersonalSafetyId]
		[Name]
		[Color]
		[Sort]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Phase.
	''' </summary>
	Public Enum PhaseFieldIndex
		[PhaseId]
		[BrandId]
		[Name]
		[Sort]
		[DeadlineInDays]
		[ProjectPlanVersionId]
		[MappingId]
		[AllowBundling]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		[Vissort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Phase2Status.
	''' </summary>
	Public Enum Phase2StatusFieldIndex
		[Phase2StatusId]
		[PhaseId]
		[StatusId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Platform.
	''' </summary>
	Public Enum PlatformFieldIndex
		[PlatformId]
		[Name]
		[Coordinator]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Populationlist.
	''' </summary>
	Public Enum PopulationlistFieldIndex
		[PopulationListId]
		[Version]
		[StateId]
		[Comment]
		[CaseId]
		[CreatedById]
		[Created]
		[PhaseId]
		[StatusId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: PopulationlistDocument.
	''' </summary>
	Public Enum PopulationlistDocumentFieldIndex
		[DocumentId]
		[PopulationListId]
		[FileName]
		[FileSize]
		[FileDate]
		[Locked]
		[LockedById]
		[DocumentClassificationId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: PopulationlistItem.
	''' </summary>
	Public Enum PopulationlistItemFieldIndex
		[PopulationlistItemId]
		[PopulationlistId]
		[UnitId]
		[UnitTypeId]
		[MarkVersion]
		[Sitename]
		[SbushortName]
		[SapwarrentyStart]
		[SapwarrentyEnd]
		[SapsubscriptionStart]
		[SapsubscriptionEnd]
		[Country]
		[ItemWtg]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Portfolio.
	''' </summary>
	Public Enum PortfolioFieldIndex
		[PortfolioId]
		[Name]
		[ManagerInitials]
		[ManagerName]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Project.
	''' </summary>
	Public Enum ProjectFieldIndex
		[ProjectId]
		[Name]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ProjectScope.
	''' </summary>
	Public Enum ProjectScopeFieldIndex
		[ProjectScopeId]
		[Name]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Rc.
	''' </summary>
	Public Enum RcFieldIndex
		[Rcid]
		[CaseId]
		[RcoriginId]
		[RcoriginResponsibleId]
		[RcoriginUnitId]
		[RccomponentOwnerId]
		[Accepted]
		[Comment]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: RccomponentOwner.
	''' </summary>
	Public Enum RccomponentOwnerFieldIndex
		[RccomponentOwnerId]
		[RccomponentOwner]
		[Created]
		[CreatedById]
		[Deleted]
		[DeletedById]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Rcorigin.
	''' </summary>
	Public Enum RcoriginFieldIndex
		[RcoriginId]
		[Rcorigin]
		[RcoriginTooltip]
		[Created]
		[CreatedById]
		[Deleted]
		[DeletedById]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: RcoriginRelation.
	''' </summary>
	Public Enum RcoriginRelationFieldIndex
		[RcoriginRelationId]
		[RcoriginId]
		[RcoriginResponsibleId]
		[RcoriginUnitId]
		[Created]
		[CreatedById]
		[Deleted]
		[DeletedById]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: RcoriginResponsible.
	''' </summary>
	Public Enum RcoriginResponsibleFieldIndex
		[RcoriginResponsibleId]
		[RcoriginResponsible]
		[Created]
		[CreatedById]
		[Deleted]
		[DeletedById]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: RcoriginUnit.
	''' </summary>
	Public Enum RcoriginUnitFieldIndex
		[RcoriginUnitId]
		[RcoriginUnit]
		[VpDptId]
		[IsSbu]
		[IsPbu]
		[Created]
		[CreatedById]
		[Deleted]
		[DeletedById]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ReasonCode.
	''' </summary>
	Public Enum ReasonCodeFieldIndex
		[ReasonCodeId]
		[ReasonCodeNo]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: RelatedCase.
	''' </summary>
	Public Enum RelatedCaseFieldIndex
		[RelatedCaseId]
		[CaseId]
		[CaseIdRelated]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: RelatedCase2CaseRelation.
	''' </summary>
	Public Enum RelatedCase2CaseRelationFieldIndex
		[RelatedCase2CaseRelationId]
		[RelatedCaseId]
		[CaseRelationId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: RelatedItem.
	''' </summary>
	Public Enum RelatedItemFieldIndex
		[RelatedItemId]
		[ItemId]
		[ItemIdRelated]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ReportType.
	''' </summary>
	Public Enum ReportTypeFieldIndex
		[ReportTypeId]
		[Name]
		[LanguageId]
		[ParentReportTypeId]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Role.
	''' </summary>
	Public Enum RoleFieldIndex
		[RoleId]
		[Name]
		[Description]
		[GrantToProjectManager]
		[GrantToTechnicalSpecialist]
		[GrantToExecutionManager]
		[GrantToCaseCreator]
		[GrantToPlatformManager]
		[GrantToProjectParticipant]
		[GrantToEveryone]
		[Created]
		[CreatedBy]
		[Updated]
		[UpdatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Role2Permission.
	''' </summary>
	Public Enum Role2PermissionFieldIndex
		[Role2PermissionId]
		[RoleId]
		[PermissionId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Sbu.
	''' </summary>
	Public Enum SbuFieldIndex
		[Sbuid]
		[Name]
		[ShortName]
		[VpdptId]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Sbuclone.
	''' </summary>
	Public Enum SbucloneFieldIndex
		[Sbuid]
		[Name]
		[ShortName]
		[VpdptId]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: SearchProfile.
	''' </summary>
	Public Enum SearchProfileFieldIndex
		[SearchProfileId]
		[UserId]
		[Name]
		[IsPublic]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: SearchProfileDetail.
	''' </summary>
	Public Enum SearchProfileDetailFieldIndex
		[SearchProfileDetailId]
		[SearchProfileId]
		[InputId]
		[Value]
		[InputType]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ServiceCode.
	''' </summary>
	Public Enum ServiceCodeFieldIndex
		[ServiceCodeId]
		[ServiceGroupId]
		[VdbserviceCodeId]
		[Name]
		[Sort]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ServiceGroup.
	''' </summary>
	Public Enum ServiceGroupFieldIndex
		[ServiceGroupId]
		[VdbmainGroupId]
		[Name]
		[Sort]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: ServiceType.
	''' </summary>
	Public Enum ServiceTypeFieldIndex
		[ServiceTypeId]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Stage.
	''' </summary>
	Public Enum StageFieldIndex
		[StageId]
		[Name]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: StandardFolder.
	''' </summary>
	Public Enum StandardFolderFieldIndex
		[StandardFolderId]
		[BrandId]
		[FolderTypeId]
		[Name]
		[ParentStandardFolderId]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: StandardMilestone.
	''' </summary>
	Public Enum StandardMilestoneFieldIndex
		[StandardMilestoneId]
		[DeadlineOffset]
		[Description]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: StandardTask.
	''' </summary>
	Public Enum StandardTaskFieldIndex
		[StandardTaskId]
		[BrandId]
		[Name]
		[TemplateVersion]
		[IsGate]
		[Sort]
		[PhaseId]
		[MappingId]
		[DeletedById]
		[Deleted]
		[Vissort]
		[CreatedById]
		[Created]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: StandardTask2Status.
	''' </summary>
	Public Enum StandardTask2StatusFieldIndex
		[StandardTask2StatusId]
		[StandardTaskId]
		[StatusId]
		[Sort]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: State.
	''' </summary>
	Public Enum StateFieldIndex
		[StateId]
		[Name]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Status.
	''' </summary>
	Public Enum StatusFieldIndex
		[StatusId]
		[Name]
		[Sort]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Supplier.
	''' </summary>
	Public Enum SupplierFieldIndex
		[SupplierId]
		[SupplierEnvironmentId]
		[VendorId]
		[VirtualId]
		[Name]
		[Address1]
		[Address2]
		[Phone]
		[Email]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		[ModifiedVersion]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: SupplierEnvironment.
	''' </summary>
	Public Enum SupplierEnvironmentFieldIndex
		[SupplierEnvironmentId]
		[Name]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: SystemDescription.
	''' </summary>
	Public Enum SystemDescriptionFieldIndex
		[System]
		[Description]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Task.
	''' </summary>
	Public Enum TaskFieldIndex
		[TaskId]
		[StandardTaskId]
		[Case2PhaseId]
		[StartDate]
		[FinishDate]
		[DurationHours]
		[PercentComplete]
		[ScheduleComments]
		[ResponsiblePersonId]
		[Description]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TaskMilestone.
	''' </summary>
	Public Enum TaskMilestoneFieldIndex
		[TaskMilestoneId]
		[TaskId]
		[Name]
		[FinishDate]
		[PercentComplete]
		[ScheduleComments]
		[ResponsiblePersonId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Timeline.
	''' </summary>
	Public Enum TimelineFieldIndex
		[TimelineId]
		[Text]
		[Changed]
		[ChangedBy]
		[CaseId]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Turbine.
	''' </summary>
	Public Enum TurbineFieldIndex
		[TurbineId]
		[Turbine]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineFrequency.
	''' </summary>
	Public Enum TurbineFrequencyFieldIndex
		[TurbineFrequencyId]
		[Frequency]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineManufacturer.
	''' </summary>
	Public Enum TurbineManufacturerFieldIndex
		[TurbineManufacturerId]
		[Manufacturer]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineMarkVersion.
	''' </summary>
	Public Enum TurbineMarkVersionFieldIndex
		[TurbineMarkVersionId]
		[MarkVersion]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineMatrix.
	''' </summary>
	Public Enum TurbineMatrixFieldIndex
		[TurbineMatrixId]
		[TurbineId]
		[TurbineRotorDiameterId]
		[TurbineNominelPowerId]
		[TurbineVoltageId]
		[TurbineFrequencyId]
		[TurbinePowerRegulationId]
		[TurbineSmallGeneratorId]
		[TurbineTemperatureVariantId]
		[TurbineMarkVersionId]
		[TurbinePlacementId]
		[TurbineManufacturerId]
		[TurbineOldId]
		[Comment]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineNominelPower.
	''' </summary>
	Public Enum TurbineNominelPowerFieldIndex
		[TurbineNominelPowerId]
		[NominelPower]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineOld.
	''' </summary>
	Public Enum TurbineOldFieldIndex
		[TurbineOldId]
		[Turbine]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbinePlacement.
	''' </summary>
	Public Enum TurbinePlacementFieldIndex
		[TurbinePlacementId]
		[Placement]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbinePowerRegulation.
	''' </summary>
	Public Enum TurbinePowerRegulationFieldIndex
		[TurbinePowerRegulationId]
		[PowerRegulation]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineRotorDiameter.
	''' </summary>
	Public Enum TurbineRotorDiameterFieldIndex
		[TurbineRotorDiameterId]
		[RotorDiameter]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineSmallGenerator.
	''' </summary>
	Public Enum TurbineSmallGeneratorFieldIndex
		[TurbineSmallGeneratorId]
		[SmallGenerator]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineTemperatureVariant.
	''' </summary>
	Public Enum TurbineTemperatureVariantFieldIndex
		[TurbineTemperatureVariantId]
		[TemperatureVariant]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: TurbineVoltage.
	''' </summary>
	Public Enum TurbineVoltageFieldIndex
		[TurbineVoltageId]
		[Voltage]
		[Created]
		[CreatedBy]
		[Deleted]
		[DeletedBy]
		AmountOfFields
	End Enum


	''' <summary>
	''' Index enum to fast-access EntityFields in the IEntityFields collection for the entity: Visits.
	''' </summary>
	Public Enum VisitsFieldIndex
		[VisitsId]
		[ParticipantId]
		[CaseId]
		[OpenCaseTimeStamp]
		[Environment]
		[CreatedById]
		[Created]
		[DeletedById]
		[Deleted]
		AmountOfFields
	End Enum


 
	''' <summary>
	''' Index Enum To fast-access TypedList Fields In the Columns collection of the Typed List: CaseNo2CaseIdUsingBrandId
	''' </summary>
	Public Enum CaseNo2CaseIdUsingBrandIdTypedListFieldIndex
		[CaseId]
		[ProjectPortalId]
		[BrandId]
		[CaseNo]
		AmountOfFields
	End Enum

 
	''' <summary>
	''' Index Enum To fast-access TypedList Fields In the Columns collection of the Typed List: ControlInlineHelpText
	''' </summary>
	Public Enum ControlInlineHelpTextTypedListFieldIndex
		[BrandId]
		[ModuleId]
		[ControlId]
		[ControlName]
		[ControlFriendlyName]
		[SystemText]
		[LanguageId]
		[LocalizedText]
		AmountOfFields
	End Enum

 
	''' <summary>
	''' Index Enum To fast-access TypedList Fields In the Columns collection of the Typed List: SearchResultCaseList
	''' </summary>
	Public Enum SearchResultCaseListTypedListFieldIndex
		[BrandId]
		[CaseId]
		[CaseNo]
		[Description]
		[CreatedById]
		[CreatedByVestasInitials]
		[CreatedBy]
		[ManagerId]
		[ManagerVestasInitials]
		[Manager]
		[PhaseId]
		[Phase]
		[StatusId]
		[Status]
		[ClaimStatusId]
		[ClaimStatus]
		AmountOfFields
	End Enum


	''' <summary>
	''' Enum definition for all the entity types defined in this namespace. Used by the entityfields factory.
	''' </summary>
	Public Enum EntityType
		AlertCategoryEntity
		AlertCategoryCriteriaEntity
		AlertChangeTypeCriteriaEntity
		AlertConfigEntity
		AlertConfigCircountEntity
		AlertFrequencyEntity
		AlertReceiverEntity
		AlertReceiverRoleTypeEntity
		AlertReceiverTypeEntity
		AlertServiceSettingsEntity
		AnyChangesEntity
		BrandEntity
		Brand2DocumentTemplateEntity
		Brand2FeatureEntity
		Brand2StandardMilestoneEntity
		BusinessProcessEntity
		CaseEntity
		Case2CaseBundleEntity
		Case2ComponentTypeEntity
		Case2ItemEntity
		Case2KPIRatingEntity
		Case2LogInfoEntity
		Case2ParticipantEntity
		Case2PhaseEntity
		Case2ReasonCodeEntity
		Case2SbuEntity
		Case2ServiceCodeEntity
		Case2SupplierEntity
		Case2Supplier2StageEntity
		Case2SystemEntity
		Case2TurbineMatrixEntity
		Case2TurbineMatrix2Case2ItemEntity
		CaseBundleEntity
		CaseRelationEntity
		CategoryEntity
		ChangeLogEntity
		ChangeTypeEntity
		CirEntity
		ClaimStatusEntity
		ComponentEntity
		ComponentTypeEntity
		ControlEntity
		CustomColumnsNameEntity
		CustomColumnsValueEntity
		DiscussionEntity
		DocumentEntity
		DocumentBinaryEntity
		DocumentClassificationEntity
		DocumentStatusEntity
		DocumentTemplateEntity
		DocumentVersionEntity
		ErpsystemEntity
		FeatureEntity
		FolderEntity
		Folder2DocumentEntity
		FolderTypeEntity
		HelpEntity
		InlineHelpEntity
		InlineHelpTextEntity
		ItemEntity
		ItemStatusEntity
		ItemSystemMappingEntity
		ItemSystemMappingStagingTableEntity
		LanguageEntity
		LogInfoEntity
		LogInfo2LogTxtEntity
		LogTxtEntity
		MilestoneEntity
		ModuleEntity
		NewsEntity
		News2ParticipantEntity
		OldCimturbineEntity
		ParticipantEntity
		Participant2RoleEntity
		ParticipantLogEntity
		ParticipationTypeEntity
		PayeeEntity
		PbuEntity
		PerformanceActionEntity
		PerformanceDataEntity
		PerformanceUtilitySettingEntity
		PermissionEntity
		PersonalSafetyEntity
		PhaseEntity
		Phase2StatusEntity
		PlatformEntity
		PopulationlistEntity
		PopulationlistDocumentEntity
		PopulationlistItemEntity
		PortfolioEntity
		ProjectEntity
		ProjectScopeEntity
		RcEntity
		RccomponentOwnerEntity
		RcoriginEntity
		RcoriginRelationEntity
		RcoriginResponsibleEntity
		RcoriginUnitEntity
		ReasonCodeEntity
		RelatedCaseEntity
		RelatedCase2CaseRelationEntity
		RelatedItemEntity
		ReportTypeEntity
		RoleEntity
		Role2PermissionEntity
		SbuEntity
		SbucloneEntity
		SearchProfileEntity
		SearchProfileDetailEntity
		ServiceCodeEntity
		ServiceGroupEntity
		ServiceTypeEntity
		StageEntity
		StandardFolderEntity
		StandardMilestoneEntity
		StandardTaskEntity
		StandardTask2StatusEntity
		StateEntity
		StatusEntity
		SupplierEntity
		SupplierEnvironmentEntity
		SystemDescriptionEntity
		TaskEntity
		TaskMilestoneEntity
		TimelineEntity
		TurbineEntity
		TurbineFrequencyEntity
		TurbineManufacturerEntity
		TurbineMarkVersionEntity
		TurbineMatrixEntity
		TurbineNominelPowerEntity
		TurbineOldEntity
		TurbinePlacementEntity
		TurbinePowerRegulationEntity
		TurbineRotorDiameterEntity
		TurbineSmallGeneratorEntity
		TurbineTemperatureVariantEntity
		TurbineVoltageEntity
		VisitsEntity
	End Enum




#Region "Custom ConstantsEnums Code"
	
	' __LLBLGENPRO_USER_CODE_REGION_START CustomUserConstants
	' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
End Namespace


