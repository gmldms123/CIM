﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 2.5
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates.NET20
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
#If Not CF Then
Imports System.Runtime.Serialization
#End If
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses
	''' <summary>Entity class which represents the entity 'AlertActionCriteria'.<br/><br/>
	''' </summary>
	<Serializable()> _
	Public Class AlertActionCriteriaEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"


		Private WithEvents _alertAction As AlertActionEntity
		Private WithEvents _alertConfig As AlertConfigEntity
		Private WithEvents _participant_ As ParticipantEntity
		Private WithEvents _participant As ParticipantEntity

		
		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name AlertAction</summary>
			Public Shared ReadOnly [AlertAction] As String = "AlertAction"
			''' <summary>Member name AlertConfig</summary>
			Public Shared ReadOnly [AlertConfig] As String = "AlertConfig"
			''' <summary>Member name Participant_</summary>
			Public Shared ReadOnly [Participant_] As String = "Participant_"
			''' <summary>Member name Participant</summary>
			Public Shared ReadOnly [Participant] As String = "Participant"



		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertActionCriteriaEntity")
			InitClassEmpty(Nothing, CreateFields())
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("AlertActionCriteriaEntity")
			SetName("AlertActionCriteriaEntity")
			InitClassEmpty(Nothing, fields)
		End Sub


		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this AlertActionCriteriaEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("AlertActionCriteriaEntity")
			InitClassEmpty(validator, CreateFields())
		End Sub
				

		''' <summary>CTor</summary>
		''' <param name="alertActionCriteriaId">PK value for AlertActionCriteria which data should be fetched into this AlertActionCriteria object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(alertActionCriteriaId As System.Int64)
			MyBase.New("AlertActionCriteriaEntity")
			InitClassEmpty(Nothing, CreateFields())
			Me.AlertActionCriteriaId = alertActionCriteriaId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="alertActionCriteriaId">PK value for AlertActionCriteria which data should be fetched into this AlertActionCriteria object</param>
		''' <param name="validator">The custom validator object for this AlertActionCriteriaEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(alertActionCriteriaId As System.Int64, validator As IValidator)
			MyBase.New("AlertActionCriteriaEntity")
			InitClassEmpty(validator, CreateFields())
			Me.AlertActionCriteriaId = alertActionCriteriaId
		End Sub
	

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then


				_alertAction = CType(info.GetValue("_alertAction", GetType(AlertActionEntity)), AlertActionEntity)
				If Not _alertAction Is Nothing Then
					AddHandler _alertAction.AfterSave, AddressOf OnEntityAfterSave
				End If
				_alertConfig = CType(info.GetValue("_alertConfig", GetType(AlertConfigEntity)), AlertConfigEntity)
				If Not _alertConfig Is Nothing Then
					AddHandler _alertConfig.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant_ = CType(info.GetValue("_participant_", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant_ Is Nothing Then
					AddHandler _participant_.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant = CType(info.GetValue("_participant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant Is Nothing Then
					AddHandler _participant.AfterSave, AddressOf OnEntityAfterSave
				End If

				MyBase.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, AlertActionCriteriaFieldIndex)

				Case AlertActionCriteriaFieldIndex.AlertConfigId
					DesetupSyncAlertConfig(True, False)
				Case AlertActionCriteriaFieldIndex.AlertActionId
					DesetupSyncAlertAction(True, False)

				Case AlertActionCriteriaFieldIndex.CreatedById
					DesetupSyncParticipant(True, False)

				Case AlertActionCriteriaFieldIndex.DeletedById
					DesetupSyncParticipant_(True, False)

				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub
		
		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntity2)
			Select Case propertyName
				Case "AlertAction"
					Me.AlertAction = CType(entity, AlertActionEntity)
				Case "AlertConfig"
					Me.AlertConfig = CType(entity, AlertConfigEntity)
				Case "Participant_"
					Me.Participant_ = CType(entity, ParticipantEntity)
				Case "Participant"
					Me.Participant = CType(entity, ParticipantEntity)



				Case Else

			End Select
		End Sub
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it
		''' will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			' use template trick To calculate the # of Single-sided / oneway relations. 
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))





				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Sub SetRelatedEntity(relatedEntity As IEntity2, fieldName As String)
			Select Case fieldName
				Case "AlertAction"
					SetupSyncAlertAction(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "AlertConfig"
					SetupSyncAlertConfig(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "Participant_"
					SetupSyncParticipant_(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "Participant"
					SetupSyncParticipant(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)


				Case Else

			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntity2, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "AlertAction"
					DesetupSyncAlertAction(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "AlertConfig"
					DesetupSyncAlertConfig(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "Participant_"
					DesetupSyncParticipant_(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "Participant"
					DesetupSyncParticipant(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)


				Case Else

			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). These
		''' entities will have to be persisted after this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()


			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields). These
		''' entities will have to be persisted before this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _alertAction Is Nothing Then
				toReturn.Add(_alertAction)
			End If
			If Not _alertConfig Is Nothing Then
				toReturn.Add(_alertConfig)
			End If
			If Not _participant_ Is Nothing Then
				toReturn.Add(_participant_)
			End If
			If Not _participant Is Nothing Then
				toReturn.Add(_participant)
			End If


			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. The contents of the ArrayList is
		''' used by the DataAccessAdapter to perform recursive saves. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Public Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()


			Return toReturn
		End Function



		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Public Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing


				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _alertAction
				End If
				info.AddValue("_alertAction", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _alertConfig
				End If
				info.AddValue("_alertConfig", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant_
				End If
				info.AddValue("_participant_", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant
				End If
				info.AddValue("_participant", entityValue)

			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub



		''' <summary>Returns true if the original value for the field with the fieldIndex passed in, read from the persistent storage was NULL, False otherwise.
		''' Should Not be used For testing If the current value Is NULL, use <see cref="TestCurrentFieldValueForNull"/> For that.</summary>
		''' <param name="fieldIndex">Index of the field to test if that field was NULL in the persistent storage</param>
		''' <returns>true if the field with the passed in index was NULL in the persistent storage, False otherwise</returns>
		Public  Function TestOriginalFieldValueForNull(fieldIndex As AlertActionCriteriaFieldIndex) As Boolean
			Return MyBase.Fields(CInt(fieldIndex)).IsNull
		End Function
		
		''' <summary>Returns True If the current value For the field With the fieldIndex passed In represents null/Not defined, False otherwise.
		''' Should Not be used For testing If the original value (read from the db) Is NULL</summary>
		''' <param name="fieldIndex">Index of the field To test If its currentvalue Is null/undefined</param>
		''' <returns>True If the field's value isn't defined yet, false otherwise</returns>
		Public  Function TestCurrentFieldValueForNull(fieldIndex As AlertActionCriteriaFieldIndex) As Boolean
			Return MyBase.CheckIfCurrentFieldValueIsNull(CInt(fieldIndex))
		End Function


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Public Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New AlertActionCriteriaRelations().GetAllRelations()
		End Function




		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'AlertAction' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoAlertAction() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'AlertConfig' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoAlertConfig() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertConfigFields.AlertConfigId, Nothing, ComparisonOperator.Equal, Me.AlertConfigId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'Participant' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.DeletedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'Participant' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function


		''' <summary>Creates entity fields Object For this entity. Used In constructor To setup this entity In a polymorphic scenario.</summary>
		Protected Overridable Function CreateFields() As IEntityFields2
			Return EntityFieldsFactory.CreateEntityFieldsObject(PManagement.Data.EntityType.AlertActionCriteriaEntity)
		End Function
				
		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(AlertActionCriteriaEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)


		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)


		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean


			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing


		End Sub
#End If
		''' <summary>
		''' Creates the ITypeDefaultValue instance used To provide Default values For value types which aren't of type nullable(of T)
		''' </summary>
		''' <returns></returns>
		Protected Overrides Function CreateTypeDefaultValueProvider() As ITypeDefaultValue 
			Return New TypeDefaultValue()
		End Function

		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Public Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("AlertAction", _alertAction)
			toReturn.Add("AlertConfig", _alertConfig)
			toReturn.Add("Participant_", _participant_)
			toReturn.Add("Participant", _participant)



			Return toReturn
		End Function
		
		''' <summary>Adds the internals To the active context. </summary>
		Protected Overrides Overloads Sub AddInternalsToContext()


		If Not _alertAction Is Nothing Then
				_alertAction.ActiveContext = MyBase.ActiveContext
			End If
		If Not _alertConfig Is Nothing Then
				_alertConfig.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participant_ Is Nothing Then
				_participant_.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participant Is Nothing Then
				_participant.ActiveContext = MyBase.ActiveContext
			End If


		End Sub

		''' <summary>Initializes the class members</summary>
		Protected Overridable Sub InitClassMembers()



			_alertAction = Nothing
			_alertConfig = Nothing
			_participant_ = Nothing
			_participant = Nothing

			PerformDependencyInjection()
			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()

			Dim fieldHashtable As Dictionary(Of String, String) = Nothing
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("AlertActionCriteriaId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("AlertConfigId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("AlertActionId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Value", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("DeletedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _alertAction</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncAlertAction(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _alertAction, AddressOf OnAlertActionPropertyChanged, "AlertAction", AlertActionCriteriaEntity.Relations.AlertActionEntityUsingAlertActionId, True, signalRelatedEntity, "AlertActionCriteria", resetFKFields, New Integer() { CInt(AlertActionCriteriaFieldIndex.AlertActionId) } )
			_alertAction = Nothing
		End Sub

		''' <summary>setups the sync logic for member _alertAction</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncAlertAction(relatedEntity As IEntity2)
			DesetupSyncAlertAction(True, True)
			_alertAction = CType(relatedEntity, AlertActionEntity)
			MyBase.PerformSetupSyncRelatedEntity( _alertAction, AddressOf OnAlertActionPropertyChanged, "AlertAction", AlertActionCriteriaEntity.Relations.AlertActionEntityUsingAlertActionId, True, New String() {  } )
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnAlertActionPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _alertConfig</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncAlertConfig(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _alertConfig, AddressOf OnAlertConfigPropertyChanged, "AlertConfig", AlertActionCriteriaEntity.Relations.AlertConfigEntityUsingAlertConfigId, True, signalRelatedEntity, "AlertActionCriteria", resetFKFields, New Integer() { CInt(AlertActionCriteriaFieldIndex.AlertConfigId) } )
			_alertConfig = Nothing
		End Sub

		''' <summary>setups the sync logic for member _alertConfig</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncAlertConfig(relatedEntity As IEntity2)
			DesetupSyncAlertConfig(True, True)
			_alertConfig = CType(relatedEntity, AlertConfigEntity)
			MyBase.PerformSetupSyncRelatedEntity( _alertConfig, AddressOf OnAlertConfigPropertyChanged, "AlertConfig", AlertActionCriteriaEntity.Relations.AlertConfigEntityUsingAlertConfigId, True, New String() {  } )
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnAlertConfigPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant_</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant_(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", AlertActionCriteriaEntity.Relations.ParticipantEntityUsingDeletedById, True, signalRelatedEntity, "AlertActionCriteria_", resetFKFields, New Integer() { CInt(AlertActionCriteriaFieldIndex.DeletedById) } )
			_participant_ = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant_</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant_(relatedEntity As IEntity2)
			DesetupSyncParticipant_(True, True)
			_participant_ = CType(relatedEntity, ParticipantEntity)
			MyBase.PerformSetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", AlertActionCriteriaEntity.Relations.ParticipantEntityUsingDeletedById, True, New String() {  } )
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipant_PropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", AlertActionCriteriaEntity.Relations.ParticipantEntityUsingCreatedById, True, signalRelatedEntity, "AlertActionCriteria", resetFKFields, New Integer() { CInt(AlertActionCriteriaFieldIndex.CreatedById) } )
			_participant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant(relatedEntity As IEntity2)
			DesetupSyncParticipant(True, True)
			_participant = CType(relatedEntity, ParticipantEntity)
			MyBase.PerformSetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", AlertActionCriteriaEntity.Relations.ParticipantEntityUsingCreatedById, True, New String() {  } )
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub


		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this AlertActionCriteriaEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Protected Overridable Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			MyBase.Fields = fields
			MyBase.IsNew = True
			MyBase.Validator = validator
			InitClassMembers()

			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As AlertActionCriteriaRelations
			Get	
				Return New AlertActionCriteriaRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property




		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'AlertAction' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathAlertAction() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(AlertActionEntityFactory))), _
					AlertActionCriteriaEntity.Relations.AlertActionEntityUsingAlertActionId, _
					CType(PManagement.Data.EntityType.AlertActionCriteriaEntity, Integer), CType(PManagement.Data.EntityType.AlertActionEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "AlertAction", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'AlertConfig' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathAlertConfig() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(AlertConfigEntityFactory))), _
					AlertActionCriteriaEntity.Relations.AlertConfigEntityUsingAlertConfigId, _
					CType(PManagement.Data.EntityType.AlertActionCriteriaEntity, Integer), CType(PManagement.Data.EntityType.AlertConfigEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "AlertConfig", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					AlertActionCriteriaEntity.Relations.ParticipantEntityUsingDeletedById, _
					CType(PManagement.Data.EntityType.AlertActionCriteriaEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					AlertActionCriteriaEntity.Relations.ParticipantEntityUsingCreatedById, _
					CType(PManagement.Data.EntityType.AlertActionCriteriaEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return AlertActionCriteriaEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return AlertActionCriteriaEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The AlertActionCriteriaId property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."AlertActionCriteriaId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [AlertActionCriteriaId]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.AlertActionCriteriaId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.AlertActionCriteriaId), value)
			End Set

		End Property

		''' <summary>The AlertConfigId property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."AlertConfigId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [AlertConfigId]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.AlertConfigId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.AlertConfigId), value)
			End Set
		End Property

		''' <summary>The AlertActionId property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."AlertActionId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [AlertActionId]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.AlertActionId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.AlertActionId), value)
			End Set
		End Property

		''' <summary>The Value property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."Value"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Value]() As System.String
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.Value), True), System.String)
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.Value), value)
			End Set
		End Property

		''' <summary>The CreatedById property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.CreatedById), value)
			End Set
		End Property

		''' <summary>The Created property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 23, 3, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.Created), value)
			End Set
		End Property

		''' <summary>The DeletedById property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."DeletedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.DeletedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.DeletedById), value)
			End Set
		End Property

		''' <summary>The Deleted property of the Entity AlertActionCriteria<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertActionCriteria"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 23, 3, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(AlertActionCriteriaFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(AlertActionCriteriaFieldIndex.Deleted), value)
			End Set
		End Property



		''' <summary>Gets / sets related entity of type 'AlertActionEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [AlertAction]() As AlertActionEntity
			Get
				Return _alertAction
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncAlertAction(value)
				Else
					If value Is Nothing Then
						If Not _alertAction Is Nothing Then
							_alertAction.UnsetRelatedEntity(Me, "AlertActionCriteria")
						End If
					Else
						CType(value, IEntity2).SetRelatedEntity(Me, "AlertActionCriteria")
					End If
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'AlertConfigEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [AlertConfig]() As AlertConfigEntity
			Get
				Return _alertConfig
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncAlertConfig(value)
				Else
					If value Is Nothing Then
						If Not _alertConfig Is Nothing Then
							_alertConfig.UnsetRelatedEntity(Me, "AlertActionCriteria")
						End If
					Else
						CType(value, IEntity2).SetRelatedEntity(Me, "AlertActionCriteria")
					End If
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [Participant_]() As ParticipantEntity
			Get
				Return _participant_
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant_(value)
				Else
					If value Is Nothing Then
						If Not _participant_ Is Nothing Then
							_participant_.UnsetRelatedEntity(Me, "AlertActionCriteria_")
						End If
					Else
						CType(value, IEntity2).SetRelatedEntity(Me, "AlertActionCriteria_")
					End If
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [Participant]() As ParticipantEntity
			Get
				Return _participant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant(value)
				Else
					If value Is Nothing Then
						If Not _participant Is Nothing Then
							_participant.UnsetRelatedEntity(Me, "AlertActionCriteria")
						End If
					Else
						CType(value, IEntity2).SetRelatedEntity(Me, "AlertActionCriteria")
					End If
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property
		
		''' <summary>Returns the EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.AlertActionCriteriaEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
