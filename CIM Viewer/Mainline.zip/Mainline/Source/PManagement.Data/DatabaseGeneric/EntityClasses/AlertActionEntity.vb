﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 2.5
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates.NET20
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
#If Not CF Then
Imports System.Runtime.Serialization
#End If
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses
	''' <summary>Entity class which represents the entity 'AlertAction'.<br/><br/>
	''' </summary>
	<Serializable()> _
	Public Class AlertActionEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _alertActionCriteria As EntityCollection(Of AlertActionCriteriaEntity)
		Private WithEvents _alertInput As EntityCollection(Of AlertInputEntity)
		Private WithEvents _alertConfigCollectionViaAlertActionCriteria As EntityCollection(Of AlertConfigEntity)
		Private WithEvents _caseCollectionViaAlertInput As EntityCollection(Of CaseEntity)
		Private WithEvents _participantCollectionViaAlertInput_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaAlertInput As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaAlertActionCriteria As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaAlertActionCriteria_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participant_ As ParticipantEntity
		Private WithEvents _participant As ParticipantEntity

		
		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Participant_</summary>
			Public Shared ReadOnly [Participant_] As String = "Participant_"
			''' <summary>Member name Participant</summary>
			Public Shared ReadOnly [Participant] As String = "Participant"
			''' <summary>Member name AlertActionCriteria</summary>
			Public Shared ReadOnly [AlertActionCriteria] As String  = "AlertActionCriteria"
			''' <summary>Member name AlertInput</summary>
			Public Shared ReadOnly [AlertInput] As String  = "AlertInput"
			''' <summary>Member name AlertConfigCollectionViaAlertActionCriteria</summary>
			Public Shared ReadOnly [AlertConfigCollectionViaAlertActionCriteria] As String  = "AlertConfigCollectionViaAlertActionCriteria"
			''' <summary>Member name CaseCollectionViaAlertInput</summary>
			Public Shared ReadOnly [CaseCollectionViaAlertInput] As String  = "CaseCollectionViaAlertInput"
			''' <summary>Member name ParticipantCollectionViaAlertInput_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaAlertInput_] As String  = "ParticipantCollectionViaAlertInput_"
			''' <summary>Member name ParticipantCollectionViaAlertInput</summary>
			Public Shared ReadOnly [ParticipantCollectionViaAlertInput] As String  = "ParticipantCollectionViaAlertInput"
			''' <summary>Member name ParticipantCollectionViaAlertActionCriteria</summary>
			Public Shared ReadOnly [ParticipantCollectionViaAlertActionCriteria] As String  = "ParticipantCollectionViaAlertActionCriteria"
			''' <summary>Member name ParticipantCollectionViaAlertActionCriteria_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaAlertActionCriteria_] As String  = "ParticipantCollectionViaAlertActionCriteria_"

		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertActionEntity")
			InitClassEmpty(Nothing, CreateFields())
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("AlertActionEntity")
			SetName("AlertActionEntity")
			InitClassEmpty(Nothing, fields)
		End Sub


		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this AlertActionEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("AlertActionEntity")
			InitClassEmpty(validator, CreateFields())
		End Sub
				

		''' <summary>CTor</summary>
		''' <param name="alertActionId">PK value for AlertAction which data should be fetched into this AlertAction object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(alertActionId As System.Int64)
			MyBase.New("AlertActionEntity")
			InitClassEmpty(Nothing, CreateFields())
			Me.AlertActionId = alertActionId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="alertActionId">PK value for AlertAction which data should be fetched into this AlertAction object</param>
		''' <param name="validator">The custom validator object for this AlertActionEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(alertActionId As System.Int64, validator As IValidator)
			MyBase.New("AlertActionEntity")
			InitClassEmpty(validator, CreateFields())
			Me.AlertActionId = alertActionId
		End Sub
	

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_alertActionCriteria = CType(info.GetValue("_alertActionCriteria", GetType(EntityCollection(Of AlertActionCriteriaEntity))), EntityCollection(Of AlertActionCriteriaEntity))
				_alertInput = CType(info.GetValue("_alertInput", GetType(EntityCollection(Of AlertInputEntity))), EntityCollection(Of AlertInputEntity))
				_alertConfigCollectionViaAlertActionCriteria = CType(info.GetValue("_alertConfigCollectionViaAlertActionCriteria", GetType(EntityCollection(Of AlertConfigEntity))), EntityCollection(Of AlertConfigEntity))
				_caseCollectionViaAlertInput = CType(info.GetValue("_caseCollectionViaAlertInput", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_participantCollectionViaAlertInput_ = CType(info.GetValue("_participantCollectionViaAlertInput_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaAlertInput = CType(info.GetValue("_participantCollectionViaAlertInput", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaAlertActionCriteria = CType(info.GetValue("_participantCollectionViaAlertActionCriteria", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaAlertActionCriteria_ = CType(info.GetValue("_participantCollectionViaAlertActionCriteria_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participant_ = CType(info.GetValue("_participant_", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant_ Is Nothing Then
					AddHandler _participant_.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant = CType(info.GetValue("_participant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant Is Nothing Then
					AddHandler _participant.AfterSave, AddressOf OnEntityAfterSave
				End If

				MyBase.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, AlertActionFieldIndex)


				Case AlertActionFieldIndex.CreatedById
					DesetupSyncParticipant(True, False)

				Case AlertActionFieldIndex.DeletedById
					DesetupSyncParticipant_(True, False)

				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub
		
		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntity2)
			Select Case propertyName
				Case "Participant_"
					Me.Participant_ = CType(entity, ParticipantEntity)
				Case "Participant"
					Me.Participant = CType(entity, ParticipantEntity)
				Case "AlertActionCriteria"
					Me.AlertActionCriteria.Add(CType(entity, AlertActionCriteriaEntity))
				Case "AlertInput"
					Me.AlertInput.Add(CType(entity, AlertInputEntity))
				Case "AlertConfigCollectionViaAlertActionCriteria"
					Me.AlertConfigCollectionViaAlertActionCriteria.IsReadOnly = False
					Me.AlertConfigCollectionViaAlertActionCriteria.Add(CType(entity, AlertConfigEntity))
					Me.AlertConfigCollectionViaAlertActionCriteria.IsReadOnly = True
				Case "CaseCollectionViaAlertInput"
					Me.CaseCollectionViaAlertInput.IsReadOnly = False
					Me.CaseCollectionViaAlertInput.Add(CType(entity, CaseEntity))
					Me.CaseCollectionViaAlertInput.IsReadOnly = True
				Case "ParticipantCollectionViaAlertInput_"
					Me.ParticipantCollectionViaAlertInput_.IsReadOnly = False
					Me.ParticipantCollectionViaAlertInput_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaAlertInput_.IsReadOnly = True
				Case "ParticipantCollectionViaAlertInput"
					Me.ParticipantCollectionViaAlertInput.IsReadOnly = False
					Me.ParticipantCollectionViaAlertInput.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaAlertInput.IsReadOnly = True
				Case "ParticipantCollectionViaAlertActionCriteria"
					Me.ParticipantCollectionViaAlertActionCriteria.IsReadOnly = False
					Me.ParticipantCollectionViaAlertActionCriteria.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaAlertActionCriteria.IsReadOnly = True
				Case "ParticipantCollectionViaAlertActionCriteria_"
					Me.ParticipantCollectionViaAlertActionCriteria_.IsReadOnly = False
					Me.ParticipantCollectionViaAlertActionCriteria_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaAlertActionCriteria_.IsReadOnly = True

				Case Else

			End Select
		End Sub
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it
		''' will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			' use template trick To calculate the # of Single-sided / oneway relations. 
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))



				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Sub SetRelatedEntity(relatedEntity As IEntity2, fieldName As String)
			Select Case fieldName
				Case "Participant_"
					SetupSyncParticipant_(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "Participant"
					SetupSyncParticipant(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "AlertActionCriteria"
					Me.AlertActionCriteria.Add(CType(relatedEntity, AlertActionCriteriaEntity))
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "AlertInput"
					Me.AlertInput.Add(CType(relatedEntity, AlertInputEntity))
					OnRelatedEntitySet(relatedEntity, fieldName)

				Case Else

			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntity2, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Participant_"
					DesetupSyncParticipant_(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "Participant"
					DesetupSyncParticipant(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "AlertActionCriteria"
					MyBase.PerformRelatedEntityRemoval(Me.AlertActionCriteria, relatedEntity, signalRelatedEntityManyToOne)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "AlertInput"
					MyBase.PerformRelatedEntityRemoval(Me.AlertInput, relatedEntity, signalRelatedEntityManyToOne)
					OnRelatedEntityUnset(relatedEntity, fieldName)

				Case Else

			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). These
		''' entities will have to be persisted after this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()


			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields). These
		''' entities will have to be persisted before this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _participant_ Is Nothing Then
				toReturn.Add(_participant_)
			End If
			If Not _participant Is Nothing Then
				toReturn.Add(_participant)
			End If


			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. The contents of the ArrayList is
		''' used by the DataAccessAdapter to perform recursive saves. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Public Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.AlertActionCriteria)
			toReturn.Add(Me.AlertInput)

			Return toReturn
		End Function



		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Public Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_alertActionCriteria Is Nothing)) AndAlso (_alertActionCriteria.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _alertActionCriteria 
				End If
				info.AddValue("_alertActionCriteria", value)
				value = Nothing 
				If (Not (_alertInput Is Nothing)) AndAlso (_alertInput.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _alertInput 
				End If
				info.AddValue("_alertInput", value)
				value = Nothing 
				If (Not (_alertConfigCollectionViaAlertActionCriteria Is Nothing)) AndAlso (_alertConfigCollectionViaAlertActionCriteria.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _alertConfigCollectionViaAlertActionCriteria 
				End If
				info.AddValue("_alertConfigCollectionViaAlertActionCriteria", value)
				value = Nothing 
				If (Not (_caseCollectionViaAlertInput Is Nothing)) AndAlso (_caseCollectionViaAlertInput.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _caseCollectionViaAlertInput 
				End If
				info.AddValue("_caseCollectionViaAlertInput", value)
				value = Nothing 
				If (Not (_participantCollectionViaAlertInput_ Is Nothing)) AndAlso (_participantCollectionViaAlertInput_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaAlertInput_ 
				End If
				info.AddValue("_participantCollectionViaAlertInput_", value)
				value = Nothing 
				If (Not (_participantCollectionViaAlertInput Is Nothing)) AndAlso (_participantCollectionViaAlertInput.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaAlertInput 
				End If
				info.AddValue("_participantCollectionViaAlertInput", value)
				value = Nothing 
				If (Not (_participantCollectionViaAlertActionCriteria Is Nothing)) AndAlso (_participantCollectionViaAlertActionCriteria.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaAlertActionCriteria 
				End If
				info.AddValue("_participantCollectionViaAlertActionCriteria", value)
				value = Nothing 
				If (Not (_participantCollectionViaAlertActionCriteria_ Is Nothing)) AndAlso (_participantCollectionViaAlertActionCriteria_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaAlertActionCriteria_ 
				End If
				info.AddValue("_participantCollectionViaAlertActionCriteria_", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant_
				End If
				info.AddValue("_participant_", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant
				End If
				info.AddValue("_participant", entityValue)

			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub



		''' <summary>Returns true if the original value for the field with the fieldIndex passed in, read from the persistent storage was NULL, False otherwise.
		''' Should Not be used For testing If the current value Is NULL, use <see cref="TestCurrentFieldValueForNull"/> For that.</summary>
		''' <param name="fieldIndex">Index of the field to test if that field was NULL in the persistent storage</param>
		''' <returns>true if the field with the passed in index was NULL in the persistent storage, False otherwise</returns>
		Public  Function TestOriginalFieldValueForNull(fieldIndex As AlertActionFieldIndex) As Boolean
			Return MyBase.Fields(CInt(fieldIndex)).IsNull
		End Function
		
		''' <summary>Returns True If the current value For the field With the fieldIndex passed In represents null/Not defined, False otherwise.
		''' Should Not be used For testing If the original value (read from the db) Is NULL</summary>
		''' <param name="fieldIndex">Index of the field To test If its currentvalue Is null/undefined</param>
		''' <returns>True If the field's value isn't defined yet, false otherwise</returns>
		Public  Function TestCurrentFieldValueForNull(fieldIndex As AlertActionFieldIndex) As Boolean
			Return MyBase.CheckIfCurrentFieldValueIsNull(CInt(fieldIndex))
		End Function


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Public Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New AlertActionRelations().GetAllRelations()
		End Function


		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'AlertActionCriteria' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoAlertActionCriteria() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionCriteriaFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'AlertInput' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoAlertInput() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertInputFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'AlertConfig' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoAlertConfigCollectionViaAlertActionCriteria() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId, "AlertActionEntity__", "AlertActionCriteria_", JoinHint.None)
			bucket.Relations.Add(AlertActionCriteriaEntity.Relations.AlertConfigEntityUsingAlertConfigId, "AlertActionCriteria_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId, "AlertActionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Case' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCaseCollectionViaAlertInput() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId, "AlertActionEntity__", "AlertInput_", JoinHint.None)
			bucket.Relations.Add(AlertInputEntity.Relations.CaseEntityUsingCaseId, "AlertInput_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId, "AlertActionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Participant' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaAlertInput_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId, "AlertActionEntity__", "AlertInput_", JoinHint.None)
			bucket.Relations.Add(AlertInputEntity.Relations.ParticipantEntityUsingDeletedById, "AlertInput_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId, "AlertActionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Participant' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaAlertInput() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId, "AlertActionEntity__", "AlertInput_", JoinHint.None)
			bucket.Relations.Add(AlertInputEntity.Relations.ParticipantEntityUsingCreatedById, "AlertInput_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId, "AlertActionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Participant' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaAlertActionCriteria() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId, "AlertActionEntity__", "AlertActionCriteria_", JoinHint.None)
			bucket.Relations.Add(AlertActionCriteriaEntity.Relations.ParticipantEntityUsingCreatedById, "AlertActionCriteria_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId, "AlertActionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Participant' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaAlertActionCriteria_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId, "AlertActionEntity__", "AlertActionCriteria_", JoinHint.None)
			bucket.Relations.Add(AlertActionCriteriaEntity.Relations.ParticipantEntityUsingDeletedById, "AlertActionCriteria_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertActionFields.AlertActionId, Nothing, ComparisonOperator.Equal, Me.AlertActionId, "AlertActionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'Participant' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.DeletedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'Participant' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function


		''' <summary>Creates entity fields Object For this entity. Used In constructor To setup this entity In a polymorphic scenario.</summary>
		Protected Overridable Function CreateFields() As IEntityFields2
			Return EntityFieldsFactory.CreateEntityFieldsObject(PManagement.Data.EntityType.AlertActionEntity)
		End Function
				
		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(AlertActionEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_alertActionCriteria)
			collectionsQueue.Enqueue(_alertInput)
			collectionsQueue.Enqueue(_alertConfigCollectionViaAlertActionCriteria)
			collectionsQueue.Enqueue(_caseCollectionViaAlertInput)
			collectionsQueue.Enqueue(_participantCollectionViaAlertInput_)
			collectionsQueue.Enqueue(_participantCollectionViaAlertInput)
			collectionsQueue.Enqueue(_participantCollectionViaAlertActionCriteria)
			collectionsQueue.Enqueue(_participantCollectionViaAlertActionCriteria_)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_alertActionCriteria = CType(collectionsQueue.Dequeue(), EntityCollection(Of AlertActionCriteriaEntity))
			_alertInput = CType(collectionsQueue.Dequeue(), EntityCollection(Of AlertInputEntity))
			_alertConfigCollectionViaAlertActionCriteria = CType(collectionsQueue.Dequeue(), EntityCollection(Of AlertConfigEntity))
			_caseCollectionViaAlertInput = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_participantCollectionViaAlertInput_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaAlertInput = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaAlertActionCriteria = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaAlertActionCriteria_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _alertActionCriteria Is Nothing) Then
				Return True
			End If
			If (Not _alertInput Is Nothing) Then
				Return True
			End If
			If (Not _alertConfigCollectionViaAlertActionCriteria Is Nothing) Then
				Return True
			End If
			If (Not _caseCollectionViaAlertInput Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaAlertInput_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaAlertInput Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaAlertActionCriteria Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaAlertActionCriteria_ Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of AlertActionCriteriaEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertActionCriteriaEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of AlertInputEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertInputEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of AlertConfigEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertConfigEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>
		''' Creates the ITypeDefaultValue instance used To provide Default values For value types which aren't of type nullable(of T)
		''' </summary>
		''' <returns></returns>
		Protected Overrides Function CreateTypeDefaultValueProvider() As ITypeDefaultValue 
			Return New TypeDefaultValue()
		End Function

		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Public Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Participant_", _participant_)
			toReturn.Add("Participant", _participant)
			toReturn.Add("AlertActionCriteria", _alertActionCriteria)
			toReturn.Add("AlertInput", _alertInput)
			toReturn.Add("AlertConfigCollectionViaAlertActionCriteria", _alertConfigCollectionViaAlertActionCriteria)
			toReturn.Add("CaseCollectionViaAlertInput", _caseCollectionViaAlertInput)
			toReturn.Add("ParticipantCollectionViaAlertInput_", _participantCollectionViaAlertInput_)
			toReturn.Add("ParticipantCollectionViaAlertInput", _participantCollectionViaAlertInput)
			toReturn.Add("ParticipantCollectionViaAlertActionCriteria", _participantCollectionViaAlertActionCriteria)
			toReturn.Add("ParticipantCollectionViaAlertActionCriteria_", _participantCollectionViaAlertActionCriteria_)

			Return toReturn
		End Function
		
		''' <summary>Adds the internals To the active context. </summary>
		Protected Overrides Overloads Sub AddInternalsToContext()
		If Not _alertActionCriteria Is Nothing Then
				_alertActionCriteria.ActiveContext = MyBase.ActiveContext
			End If
		If Not _alertInput Is Nothing Then
				_alertInput.ActiveContext = MyBase.ActiveContext
			End If
		If Not _alertConfigCollectionViaAlertActionCriteria Is Nothing Then
				_alertConfigCollectionViaAlertActionCriteria.ActiveContext = MyBase.ActiveContext
			End If
		If Not _caseCollectionViaAlertInput Is Nothing Then
				_caseCollectionViaAlertInput.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participantCollectionViaAlertInput_ Is Nothing Then
				_participantCollectionViaAlertInput_.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participantCollectionViaAlertInput Is Nothing Then
				_participantCollectionViaAlertInput.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participantCollectionViaAlertActionCriteria Is Nothing Then
				_participantCollectionViaAlertActionCriteria.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participantCollectionViaAlertActionCriteria_ Is Nothing Then
				_participantCollectionViaAlertActionCriteria_.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participant_ Is Nothing Then
				_participant_.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participant Is Nothing Then
				_participant.ActiveContext = MyBase.ActiveContext
			End If


		End Sub

		''' <summary>Initializes the class members</summary>
		Protected Overridable Sub InitClassMembers()

			_alertActionCriteria = Nothing
			_alertInput = Nothing
			_alertConfigCollectionViaAlertActionCriteria = Nothing
			_caseCollectionViaAlertInput = Nothing
			_participantCollectionViaAlertInput_ = Nothing
			_participantCollectionViaAlertInput = Nothing
			_participantCollectionViaAlertActionCriteria = Nothing
			_participantCollectionViaAlertActionCriteria_ = Nothing
			_participant_ = Nothing
			_participant = Nothing

			PerformDependencyInjection()
			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()

			Dim fieldHashtable As Dictionary(Of String, String) = Nothing
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("AlertActionId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Name", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("DeletedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _participant_</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant_(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", AlertActionEntity.Relations.ParticipantEntityUsingDeletedById, True, signalRelatedEntity, "AlertAction_", resetFKFields, New Integer() { CInt(AlertActionFieldIndex.DeletedById) } )
			_participant_ = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant_</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant_(relatedEntity As IEntity2)
			DesetupSyncParticipant_(True, True)
			_participant_ = CType(relatedEntity, ParticipantEntity)
			MyBase.PerformSetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", AlertActionEntity.Relations.ParticipantEntityUsingDeletedById, True, New String() {  } )
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipant_PropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", AlertActionEntity.Relations.ParticipantEntityUsingCreatedById, True, signalRelatedEntity, "AlertAction", resetFKFields, New Integer() { CInt(AlertActionFieldIndex.CreatedById) } )
			_participant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant(relatedEntity As IEntity2)
			DesetupSyncParticipant(True, True)
			_participant = CType(relatedEntity, ParticipantEntity)
			MyBase.PerformSetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", AlertActionEntity.Relations.ParticipantEntityUsingCreatedById, True, New String() {  } )
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub


		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this AlertActionEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Protected Overridable Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			MyBase.Fields = fields
			MyBase.IsNew = True
			MyBase.Validator = validator
			InitClassMembers()

			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As AlertActionRelations
			Get	
				Return New AlertActionRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'AlertActionCriteria' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathAlertActionCriteria() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of AlertActionCriteriaEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertActionCriteriaEntityFactory))), _
					AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId, _
					CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.AlertActionCriteriaEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "AlertActionCriteria", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'AlertInput' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathAlertInput() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of AlertInputEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertInputEntityFactory))), _
					AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId, _
					CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.AlertInputEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "AlertInput", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'AlertConfig' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathAlertConfigCollectionViaAlertActionCriteria() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId
				intermediateRelation.SetAliases(String.Empty, "AlertActionCriteria_")
				relations.Add(AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId, "AlertActionEntity__", "AlertActionCriteria_", JoinHint.None)
				relations.Add(AlertActionCriteriaEntity.Relations.AlertConfigEntityUsingAlertConfigId, "AlertActionCriteria_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of AlertConfigEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertConfigEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.AlertConfigEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "AlertConfigCollectionViaAlertActionCriteria", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCaseCollectionViaAlertInput() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId
				intermediateRelation.SetAliases(String.Empty, "AlertInput_")
				relations.Add(AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId, "AlertActionEntity__", "AlertInput_", JoinHint.None)
				relations.Add(AlertInputEntity.Relations.CaseEntityUsingCaseId, "AlertInput_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "CaseCollectionViaAlertInput", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaAlertInput_() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId
				intermediateRelation.SetAliases(String.Empty, "AlertInput_")
				relations.Add(AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId, "AlertActionEntity__", "AlertInput_", JoinHint.None)
				relations.Add(AlertInputEntity.Relations.ParticipantEntityUsingDeletedById, "AlertInput_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "ParticipantCollectionViaAlertInput_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaAlertInput() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId
				intermediateRelation.SetAliases(String.Empty, "AlertInput_")
				relations.Add(AlertActionEntity.Relations.AlertInputEntityUsingAlertActionId, "AlertActionEntity__", "AlertInput_", JoinHint.None)
				relations.Add(AlertInputEntity.Relations.ParticipantEntityUsingCreatedById, "AlertInput_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "ParticipantCollectionViaAlertInput", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaAlertActionCriteria() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId
				intermediateRelation.SetAliases(String.Empty, "AlertActionCriteria_")
				relations.Add(AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId, "AlertActionEntity__", "AlertActionCriteria_", JoinHint.None)
				relations.Add(AlertActionCriteriaEntity.Relations.ParticipantEntityUsingCreatedById, "AlertActionCriteria_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "ParticipantCollectionViaAlertActionCriteria", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaAlertActionCriteria_() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId
				intermediateRelation.SetAliases(String.Empty, "AlertActionCriteria_")
				relations.Add(AlertActionEntity.Relations.AlertActionCriteriaEntityUsingAlertActionId, "AlertActionEntity__", "AlertActionCriteria_", JoinHint.None)
				relations.Add(AlertActionCriteriaEntity.Relations.ParticipantEntityUsingDeletedById, "AlertActionCriteria_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "ParticipantCollectionViaAlertActionCriteria_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					AlertActionEntity.Relations.ParticipantEntityUsingDeletedById, _
					CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					AlertActionEntity.Relations.ParticipantEntityUsingCreatedById, _
					CType(PManagement.Data.EntityType.AlertActionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return AlertActionEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return AlertActionEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The AlertActionId property of the Entity AlertAction<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertAction"."AlertActionId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [AlertActionId]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertActionFieldIndex.AlertActionId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertActionFieldIndex.AlertActionId), value)
			End Set

		End Property

		''' <summary>The Name property of the Entity AlertAction<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertAction"."Name"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 200<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Name]() As System.String
			Get
				Return CType(GetValue(CInt(AlertActionFieldIndex.Name), True), System.String)
			End Get
			Set
				SetValue(CInt(AlertActionFieldIndex.Name), value)
			End Set
		End Property

		''' <summary>The CreatedById property of the Entity AlertAction<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertAction"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertActionFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertActionFieldIndex.CreatedById), value)
			End Set
		End Property

		''' <summary>The Created property of the Entity AlertAction<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertAction"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 23, 3, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(AlertActionFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(AlertActionFieldIndex.Created), value)
			End Set
		End Property

		''' <summary>The DeletedById property of the Entity AlertAction<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertAction"."DeletedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(AlertActionFieldIndex.DeletedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(AlertActionFieldIndex.DeletedById), value)
			End Set
		End Property

		''' <summary>The Deleted property of the Entity AlertAction<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "AlertAction"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 23, 3, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(AlertActionFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(AlertActionFieldIndex.Deleted), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'AlertActionCriteriaEntity' which are related to this entity via a relation of type '1:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(AlertActionCriteriaEntity))> _
		Public Overridable ReadOnly Property [AlertActionCriteria]() As EntityCollection(Of AlertActionCriteriaEntity)
			Get
				If _alertActionCriteria Is Nothing Then
					_alertActionCriteria = New EntityCollection(Of AlertActionCriteriaEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertActionCriteriaEntityFactory)))
					_alertActionCriteria.SetContainingEntityInfo(Me, "AlertAction")
				End If
				Return _alertActionCriteria
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'AlertInputEntity' which are related to this entity via a relation of type '1:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(AlertInputEntity))> _
		Public Overridable ReadOnly Property [AlertInput]() As EntityCollection(Of AlertInputEntity)
			Get
				If _alertInput Is Nothing Then
					_alertInput = New EntityCollection(Of AlertInputEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertInputEntityFactory)))
					_alertInput.SetContainingEntityInfo(Me, "AlertAction")
				End If
				Return _alertInput
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'AlertConfigEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(AlertConfigEntity))> _
		Public Overridable ReadOnly Property [AlertConfigCollectionViaAlertActionCriteria]() As EntityCollection(Of AlertConfigEntity)
			Get
				If _alertConfigCollectionViaAlertActionCriteria Is Nothing Then
					_alertConfigCollectionViaAlertActionCriteria = New EntityCollection(Of AlertConfigEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertConfigEntityFactory)))
					_alertConfigCollectionViaAlertActionCriteria.IsReadOnly = True
				End If
				Return _alertConfigCollectionViaAlertActionCriteria
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [CaseCollectionViaAlertInput]() As EntityCollection(Of CaseEntity)
			Get
				If _caseCollectionViaAlertInput Is Nothing Then
					_caseCollectionViaAlertInput = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_caseCollectionViaAlertInput.IsReadOnly = True
				End If
				Return _caseCollectionViaAlertInput
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaAlertInput_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaAlertInput_ Is Nothing Then
					_participantCollectionViaAlertInput_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaAlertInput_.IsReadOnly = True
				End If
				Return _participantCollectionViaAlertInput_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaAlertInput]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaAlertInput Is Nothing Then
					_participantCollectionViaAlertInput = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaAlertInput.IsReadOnly = True
				End If
				Return _participantCollectionViaAlertInput
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaAlertActionCriteria]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaAlertActionCriteria Is Nothing Then
					_participantCollectionViaAlertActionCriteria = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaAlertActionCriteria.IsReadOnly = True
				End If
				Return _participantCollectionViaAlertActionCriteria
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaAlertActionCriteria_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaAlertActionCriteria_ Is Nothing Then
					_participantCollectionViaAlertActionCriteria_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaAlertActionCriteria_.IsReadOnly = True
				End If
				Return _participantCollectionViaAlertActionCriteria_
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [Participant_]() As ParticipantEntity
			Get
				Return _participant_
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant_(value)
				Else
					If value Is Nothing Then
						If Not _participant_ Is Nothing Then
							_participant_.UnsetRelatedEntity(Me, "AlertAction_")
						End If
					Else
						CType(value, IEntity2).SetRelatedEntity(Me, "AlertAction_")
					End If
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [Participant]() As ParticipantEntity
			Get
				Return _participant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant(value)
				Else
					If value Is Nothing Then
						If Not _participant Is Nothing Then
							_participant.UnsetRelatedEntity(Me, "AlertAction")
						End If
					Else
						CType(value, IEntity2).SetRelatedEntity(Me, "AlertAction")
					End If
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property
		
		''' <summary>Returns the EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.AlertActionEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
