﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'AlertCategory'.<br/><br/></summary>
	<Serializable()> _
	Public Class AlertCategoryEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _alertCategoryCriteria As EntityCollection(Of AlertCategoryCriteriaEntity)
		Private WithEvents _alertConfigCollectionViaAlertCategoryCriteria As EntityCollection(Of AlertConfigEntity)
		Private WithEvents _participantCollectionViaAlertCategoryCriteria As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaAlertCategoryCriteria_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participant As ParticipantEntity
		Private WithEvents _participant_ As ParticipantEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Participant</summary>
			Public Shared ReadOnly [Participant] As String = "Participant"
			''' <summary>Member name Participant_</summary>
			Public Shared ReadOnly [Participant_] As String = "Participant_"
			''' <summary>Member name AlertCategoryCriteria</summary>
			Public Shared ReadOnly [AlertCategoryCriteria] As String  = "AlertCategoryCriteria"
			''' <summary>Member name AlertConfigCollectionViaAlertCategoryCriteria</summary>
			Public Shared ReadOnly [AlertConfigCollectionViaAlertCategoryCriteria] As String  = "AlertConfigCollectionViaAlertCategoryCriteria"
			''' <summary>Member name ParticipantCollectionViaAlertCategoryCriteria</summary>
			Public Shared ReadOnly [ParticipantCollectionViaAlertCategoryCriteria] As String  = "ParticipantCollectionViaAlertCategoryCriteria"
			''' <summary>Member name ParticipantCollectionViaAlertCategoryCriteria_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaAlertCategoryCriteria_] As String  = "ParticipantCollectionViaAlertCategoryCriteria_"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertCategoryEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("AlertCategoryEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this AlertCategoryEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("AlertCategoryEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="alertCategoryId">PK value for AlertCategory which data should be fetched into this AlertCategory object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(alertCategoryId As System.Int64)
			MyBase.New("AlertCategoryEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.AlertCategoryId = alertCategoryId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="alertCategoryId">PK value for AlertCategory which data should be fetched into this AlertCategory object</param>
		''' <param name="validator">The custom validator object for this AlertCategoryEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(alertCategoryId As System.Int64, validator As IValidator)
			MyBase.New("AlertCategoryEntity")
			InitClassEmpty(validator, Nothing)
			Me.AlertCategoryId = alertCategoryId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_alertCategoryCriteria = CType(info.GetValue("_alertCategoryCriteria", GetType(EntityCollection(Of AlertCategoryCriteriaEntity))), EntityCollection(Of AlertCategoryCriteriaEntity))
				_alertConfigCollectionViaAlertCategoryCriteria = CType(info.GetValue("_alertConfigCollectionViaAlertCategoryCriteria", GetType(EntityCollection(Of AlertConfigEntity))), EntityCollection(Of AlertConfigEntity))
				_participantCollectionViaAlertCategoryCriteria = CType(info.GetValue("_participantCollectionViaAlertCategoryCriteria", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaAlertCategoryCriteria_ = CType(info.GetValue("_participantCollectionViaAlertCategoryCriteria_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participant = CType(info.GetValue("_participant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant Is Nothing Then
					AddHandler _participant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant_ = CType(info.GetValue("_participant_", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant_ Is Nothing Then
					AddHandler _participant_.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, AlertCategoryFieldIndex)


				Case AlertCategoryFieldIndex.CreatedById
					DesetupSyncParticipant(True, False)

				Case AlertCategoryFieldIndex.DeletedById
					DesetupSyncParticipant_(True, False)

				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Participant"
					Me.Participant = CType(entity, ParticipantEntity)
				Case "Participant_"
					Me.Participant_ = CType(entity, ParticipantEntity)
				Case "AlertCategoryCriteria"
					Me.AlertCategoryCriteria.Add(CType(entity, AlertCategoryCriteriaEntity))
				Case "AlertConfigCollectionViaAlertCategoryCriteria"
					Me.AlertConfigCollectionViaAlertCategoryCriteria.IsReadOnly = False
					Me.AlertConfigCollectionViaAlertCategoryCriteria.Add(CType(entity, AlertConfigEntity))
					Me.AlertConfigCollectionViaAlertCategoryCriteria.IsReadOnly = True
				Case "ParticipantCollectionViaAlertCategoryCriteria"
					Me.ParticipantCollectionViaAlertCategoryCriteria.IsReadOnly = False
					Me.ParticipantCollectionViaAlertCategoryCriteria.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaAlertCategoryCriteria.IsReadOnly = True
				Case "ParticipantCollectionViaAlertCategoryCriteria_"
					Me.ParticipantCollectionViaAlertCategoryCriteria_.IsReadOnly = False
					Me.ParticipantCollectionViaAlertCategoryCriteria_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaAlertCategoryCriteria_.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return AlertCategoryEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Participant"
					toReturn.Add(AlertCategoryEntity.Relations.ParticipantEntityUsingCreatedById)
				Case "Participant_"
					toReturn.Add(AlertCategoryEntity.Relations.ParticipantEntityUsingDeletedById)
				Case "AlertCategoryCriteria"
					toReturn.Add(AlertCategoryEntity.Relations.AlertCategoryCriteriaEntityUsingAlertCategoryId)
				Case "AlertConfigCollectionViaAlertCategoryCriteria"
					toReturn.Add(AlertCategoryEntity.Relations.AlertCategoryCriteriaEntityUsingAlertCategoryId, "AlertCategoryEntity__", "AlertCategoryCriteria_", JoinHint.None)
					toReturn.Add(AlertCategoryCriteriaEntity.Relations.AlertConfigEntityUsingAlertConfigId, "AlertCategoryCriteria_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaAlertCategoryCriteria"
					toReturn.Add(AlertCategoryEntity.Relations.AlertCategoryCriteriaEntityUsingAlertCategoryId, "AlertCategoryEntity__", "AlertCategoryCriteria_", JoinHint.None)
					toReturn.Add(AlertCategoryCriteriaEntity.Relations.ParticipantEntityUsingCreatedById, "AlertCategoryCriteria_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaAlertCategoryCriteria_"
					toReturn.Add(AlertCategoryEntity.Relations.AlertCategoryCriteriaEntityUsingAlertCategoryId, "AlertCategoryEntity__", "AlertCategoryCriteria_", JoinHint.None)
					toReturn.Add(AlertCategoryCriteriaEntity.Relations.ParticipantEntityUsingDeletedById, "AlertCategoryCriteria_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Participant"
					SetupSyncParticipant(relatedEntity)
				Case "Participant_"
					SetupSyncParticipant_(relatedEntity)
				Case "AlertCategoryCriteria"
					Me.AlertCategoryCriteria.Add(CType(relatedEntity, AlertCategoryCriteriaEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Participant"
					DesetupSyncParticipant(False, True)
				Case "Participant_"
					DesetupSyncParticipant_(False, True)
				Case "AlertCategoryCriteria"
					Me.PerformRelatedEntityRemoval(Me.AlertCategoryCriteria, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _participant Is Nothing Then
				toReturn.Add(_participant)
			End If
			If Not _participant_ Is Nothing Then
				toReturn.Add(_participant_)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.AlertCategoryCriteria)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_alertCategoryCriteria Is Nothing)) AndAlso (_alertCategoryCriteria.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _alertCategoryCriteria 
				End If
				info.AddValue("_alertCategoryCriteria", value)
				value = Nothing 
				If (Not (_alertConfigCollectionViaAlertCategoryCriteria Is Nothing)) AndAlso (_alertConfigCollectionViaAlertCategoryCriteria.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _alertConfigCollectionViaAlertCategoryCriteria 
				End If
				info.AddValue("_alertConfigCollectionViaAlertCategoryCriteria", value)
				value = Nothing 
				If (Not (_participantCollectionViaAlertCategoryCriteria Is Nothing)) AndAlso (_participantCollectionViaAlertCategoryCriteria.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaAlertCategoryCriteria 
				End If
				info.AddValue("_participantCollectionViaAlertCategoryCriteria", value)
				value = Nothing 
				If (Not (_participantCollectionViaAlertCategoryCriteria_ Is Nothing)) AndAlso (_participantCollectionViaAlertCategoryCriteria_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaAlertCategoryCriteria_ 
				End If
				info.AddValue("_participantCollectionViaAlertCategoryCriteria_", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant
				End If
				info.AddValue("_participant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant_
				End If
				info.AddValue("_participant_", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New AlertCategoryRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'AlertCategoryCriteria' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoAlertCategoryCriteria() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertCategoryCriteriaFields.AlertCategoryId, Nothing, ComparisonOperator.Equal, Me.AlertCategoryId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'AlertConfig' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoAlertConfigCollectionViaAlertCategoryCriteria() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("AlertConfigCollectionViaAlertCategoryCriteria"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertCategoryFields.AlertCategoryId, Nothing, ComparisonOperator.Equal, Me.AlertCategoryId, "AlertCategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaAlertCategoryCriteria() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaAlertCategoryCriteria"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertCategoryFields.AlertCategoryId, Nothing, ComparisonOperator.Equal, Me.AlertCategoryId, "AlertCategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaAlertCategoryCriteria_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaAlertCategoryCriteria_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(AlertCategoryFields.AlertCategoryId, Nothing, ComparisonOperator.Equal, Me.AlertCategoryId, "AlertCategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.DeletedById))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(AlertCategoryEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_alertCategoryCriteria)
			collectionsQueue.Enqueue(_alertConfigCollectionViaAlertCategoryCriteria)
			collectionsQueue.Enqueue(_participantCollectionViaAlertCategoryCriteria)
			collectionsQueue.Enqueue(_participantCollectionViaAlertCategoryCriteria_)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_alertCategoryCriteria = CType(collectionsQueue.Dequeue(), EntityCollection(Of AlertCategoryCriteriaEntity))
			_alertConfigCollectionViaAlertCategoryCriteria = CType(collectionsQueue.Dequeue(), EntityCollection(Of AlertConfigEntity))
			_participantCollectionViaAlertCategoryCriteria = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaAlertCategoryCriteria_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _alertCategoryCriteria Is Nothing) Then
				Return True
			End If
			If (Not _alertConfigCollectionViaAlertCategoryCriteria Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaAlertCategoryCriteria Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaAlertCategoryCriteria_ Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of AlertCategoryCriteriaEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertCategoryCriteriaEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of AlertConfigEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertConfigEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Participant", _participant)
			toReturn.Add("Participant_", _participant_)
			toReturn.Add("AlertCategoryCriteria", _alertCategoryCriteria)
			toReturn.Add("AlertConfigCollectionViaAlertCategoryCriteria", _alertConfigCollectionViaAlertCategoryCriteria)
			toReturn.Add("ParticipantCollectionViaAlertCategoryCriteria", _participantCollectionViaAlertCategoryCriteria)
			toReturn.Add("ParticipantCollectionViaAlertCategoryCriteria_", _participantCollectionViaAlertCategoryCriteria_)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("AlertCategoryId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Name", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeletedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _participant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticAlertCategoryRelations.ParticipantEntityUsingCreatedByIdStatic, True, signalRelatedEntity, "AlertCategory", resetFKFields, New Integer() { CInt(AlertCategoryFieldIndex.CreatedById) } )
			_participant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant(relatedEntity As IEntityCore)
			If Not _participant Is relatedEntity Then
				DesetupSyncParticipant(True, True)
				_participant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticAlertCategoryRelations.ParticipantEntityUsingCreatedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant_</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant_(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticAlertCategoryRelations.ParticipantEntityUsingDeletedByIdStatic, True, signalRelatedEntity, "AlertCategory_", resetFKFields, New Integer() { CInt(AlertCategoryFieldIndex.DeletedById) } )
			_participant_ = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant_</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant_(relatedEntity As IEntityCore)
			If Not _participant_ Is relatedEntity Then
				DesetupSyncParticipant_(True, True)
				_participant_ = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticAlertCategoryRelations.ParticipantEntityUsingDeletedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipant_PropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this AlertCategoryEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As AlertCategoryRelations
			Get	
				Return New AlertCategoryRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'AlertCategoryCriteria'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathAlertCategoryCriteria() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of AlertCategoryCriteriaEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertCategoryCriteriaEntityFactory))), _
					CType(GetRelationsForField("AlertCategoryCriteria")(0), IEntityRelation), CType(PManagement.Data.EntityType.AlertCategoryEntity, Integer), CType(PManagement.Data.EntityType.AlertCategoryCriteriaEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "AlertCategoryCriteria", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'AlertConfig' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathAlertConfigCollectionViaAlertCategoryCriteria() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = AlertCategoryEntity.Relations.AlertCategoryCriteriaEntityUsingAlertCategoryId
				intermediateRelation.SetAliases(String.Empty, "AlertCategoryCriteria_")
				Return New PrefetchPathElement2( New EntityCollection(Of AlertConfigEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertConfigEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertCategoryEntity, Integer), CType(PManagement.Data.EntityType.AlertConfigEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("AlertConfigCollectionViaAlertCategoryCriteria"), Nothing, "AlertConfigCollectionViaAlertCategoryCriteria", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaAlertCategoryCriteria() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = AlertCategoryEntity.Relations.AlertCategoryCriteriaEntityUsingAlertCategoryId
				intermediateRelation.SetAliases(String.Empty, "AlertCategoryCriteria_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertCategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaAlertCategoryCriteria"), Nothing, "ParticipantCollectionViaAlertCategoryCriteria", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaAlertCategoryCriteria_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = AlertCategoryEntity.Relations.AlertCategoryCriteriaEntityUsingAlertCategoryId
				intermediateRelation.SetAliases(String.Empty, "AlertCategoryCriteria_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.AlertCategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaAlertCategoryCriteria_"), Nothing, "ParticipantCollectionViaAlertCategoryCriteria_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant")(0), IEntityRelation), CType(PManagement.Data.EntityType.AlertCategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant_")(0), IEntityRelation), CType(PManagement.Data.EntityType.AlertCategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return AlertCategoryEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return AlertCategoryEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The AlertCategoryId property of the Entity AlertCategory<br/><br/></summary>
		''' <remarks> Mapped on  table field: "AlertCategory"."AlertCategoryId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [AlertCategoryId]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertCategoryFieldIndex.AlertCategoryId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertCategoryFieldIndex.AlertCategoryId), value)
			End Set
		End Property
		''' <summary>The Name property of the Entity AlertCategory<br/><br/></summary>
		''' <remarks> Mapped on  table field: "AlertCategory"."Name"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 200<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Name]() As System.String
			Get
				Return CType(GetValue(CInt(AlertCategoryFieldIndex.Name), True), System.String)
			End Get
			Set
				SetValue(CInt(AlertCategoryFieldIndex.Name), value)
			End Set
		End Property
		''' <summary>The CreatedById property of the Entity AlertCategory<br/><br/></summary>
		''' <remarks> Mapped on  table field: "AlertCategory"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(AlertCategoryFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(AlertCategoryFieldIndex.CreatedById), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity AlertCategory<br/><br/></summary>
		''' <remarks> Mapped on  table field: "AlertCategory"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(AlertCategoryFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(AlertCategoryFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The DeletedById property of the Entity AlertCategory<br/><br/></summary>
		''' <remarks> Mapped on  table field: "AlertCategory"."DeletedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(AlertCategoryFieldIndex.DeletedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(AlertCategoryFieldIndex.DeletedById), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity AlertCategory<br/><br/></summary>
		''' <remarks> Mapped on  table field: "AlertCategory"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(AlertCategoryFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(AlertCategoryFieldIndex.Deleted), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'AlertCategoryCriteriaEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(AlertCategoryCriteriaEntity))> _
		Public Overridable ReadOnly Property [AlertCategoryCriteria]() As EntityCollection(Of AlertCategoryCriteriaEntity)
			Get
				If _alertCategoryCriteria Is Nothing Then
					_alertCategoryCriteria = New EntityCollection(Of AlertCategoryCriteriaEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertCategoryCriteriaEntityFactory)))
					_alertCategoryCriteria.ActiveContext = Me.ActiveContext
					_alertCategoryCriteria.SetContainingEntityInfo(Me, "AlertCategory")
				End If
				Return _alertCategoryCriteria
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'AlertConfigEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(AlertConfigEntity))> _
		Public Overridable ReadOnly Property [AlertConfigCollectionViaAlertCategoryCriteria]() As EntityCollection(Of AlertConfigEntity)
			Get
				If _alertConfigCollectionViaAlertCategoryCriteria Is Nothing Then
					_alertConfigCollectionViaAlertCategoryCriteria = New EntityCollection(Of AlertConfigEntity)(EntityFactoryCache2.GetEntityFactory(GetType(AlertConfigEntityFactory)))
					_alertConfigCollectionViaAlertCategoryCriteria.ActiveContext = Me.ActiveContext
					_alertConfigCollectionViaAlertCategoryCriteria.IsReadOnly = True
					CType(_alertConfigCollectionViaAlertCategoryCriteria, IEntityCollectionCore).IsForMN = True
				End If
				Return _alertConfigCollectionViaAlertCategoryCriteria
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaAlertCategoryCriteria]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaAlertCategoryCriteria Is Nothing Then
					_participantCollectionViaAlertCategoryCriteria = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaAlertCategoryCriteria.ActiveContext = Me.ActiveContext
					_participantCollectionViaAlertCategoryCriteria.IsReadOnly = True
					CType(_participantCollectionViaAlertCategoryCriteria, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaAlertCategoryCriteria
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaAlertCategoryCriteria_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaAlertCategoryCriteria_ Is Nothing Then
					_participantCollectionViaAlertCategoryCriteria_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaAlertCategoryCriteria_.ActiveContext = Me.ActiveContext
					_participantCollectionViaAlertCategoryCriteria_.IsReadOnly = True
					CType(_participantCollectionViaAlertCategoryCriteria_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaAlertCategoryCriteria_
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant]() As ParticipantEntity
			Get
				Return _participant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "AlertCategory", "Participant", _participant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant_]() As ParticipantEntity
			Get
				Return _participant_
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant_(value)
				Else
					SetSingleRelatedEntityNavigator(value, "AlertCategory_", "Participant_", _participant_, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.AlertCategoryEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
