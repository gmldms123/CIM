﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'Brand'.<br/><br/></summary>
	<Serializable()> _
	Public Class BrandEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _brand2DocumentTemplate As EntityCollection(Of Brand2DocumentTemplateEntity)
		Private WithEvents _brand2Feature As EntityCollection(Of Brand2FeatureEntity)
		Private WithEvents _brand2StandardMilestone As EntityCollection(Of Brand2StandardMilestoneEntity)
		Private WithEvents _case As EntityCollection(Of CaseEntity)
		Private WithEvents _inlineHelp As EntityCollection(Of InlineHelpEntity)
		Private WithEvents _phase As EntityCollection(Of PhaseEntity)
		Private WithEvents _standardFolder As EntityCollection(Of StandardFolderEntity)
		Private WithEvents _standardTask As EntityCollection(Of StandardTaskEntity)
		Private WithEvents _businessProcessCollectionViaCase As EntityCollection(Of BusinessProcessEntity)
		Private WithEvents _caseCollectionViaCase As EntityCollection(Of CaseEntity)
		Private WithEvents _categoryCollectionViaCase As EntityCollection(Of CategoryEntity)
		Private WithEvents _claimStatusCollectionViaCase As EntityCollection(Of ClaimStatusEntity)
		Private WithEvents _componentCollectionViaCase As EntityCollection(Of ComponentEntity)
		Private WithEvents _controlCollectionViaInlineHelp As EntityCollection(Of ControlEntity)
		Private WithEvents _documentTemplateCollectionViaBrand2DocumentTemplate As EntityCollection(Of DocumentTemplateEntity)
		Private WithEvents _featureCollectionViaBrand2Feature As EntityCollection(Of FeatureEntity)
		Private WithEvents _folderTypeCollectionViaStandardFolder As EntityCollection(Of FolderTypeEntity)
		Private WithEvents _participantCollectionViaCase As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase__ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase___ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase____ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase_____ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaPhase As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaPhase_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaStandardTask As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaStandardTask_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _pbuCollectionViaCase As EntityCollection(Of PbuEntity)
		Private WithEvents _personalSafetyCollectionViaCase As EntityCollection(Of PersonalSafetyEntity)
		Private WithEvents _phaseCollectionViaBrand2DocumentTemplate As EntityCollection(Of PhaseEntity)
		Private WithEvents _phaseCollectionViaCase As EntityCollection(Of PhaseEntity)
		Private WithEvents _phaseCollectionViaStandardTask As EntityCollection(Of PhaseEntity)
		Private WithEvents _platformCollectionViaCase As EntityCollection(Of PlatformEntity)
		Private WithEvents _portfolioCollectionViaCase As EntityCollection(Of PortfolioEntity)
		Private WithEvents _projectScopeCollectionViaCase As EntityCollection(Of ProjectScopeEntity)
		Private WithEvents _standardFolderCollectionViaStandardFolder As EntityCollection(Of StandardFolderEntity)
		Private WithEvents _standardMilestoneCollectionViaBrand2StandardMilestone As EntityCollection(Of StandardMilestoneEntity)
		Private WithEvents _standardTaskCollectionViaCase As EntityCollection(Of StandardTaskEntity)
		Private WithEvents _statusCollectionViaCase As EntityCollection(Of StatusEntity)

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Brand2DocumentTemplate</summary>
			Public Shared ReadOnly [Brand2DocumentTemplate] As String  = "Brand2DocumentTemplate"
			''' <summary>Member name Brand2Feature</summary>
			Public Shared ReadOnly [Brand2Feature] As String  = "Brand2Feature"
			''' <summary>Member name Brand2StandardMilestone</summary>
			Public Shared ReadOnly [Brand2StandardMilestone] As String  = "Brand2StandardMilestone"
			''' <summary>Member name Case</summary>
			Public Shared ReadOnly [Case] As String  = "Case"
			''' <summary>Member name InlineHelp</summary>
			Public Shared ReadOnly [InlineHelp] As String  = "InlineHelp"
			''' <summary>Member name Phase</summary>
			Public Shared ReadOnly [Phase] As String  = "Phase"
			''' <summary>Member name StandardFolder</summary>
			Public Shared ReadOnly [StandardFolder] As String  = "StandardFolder"
			''' <summary>Member name StandardTask</summary>
			Public Shared ReadOnly [StandardTask] As String  = "StandardTask"
			''' <summary>Member name BusinessProcessCollectionViaCase</summary>
			Public Shared ReadOnly [BusinessProcessCollectionViaCase] As String  = "BusinessProcessCollectionViaCase"
			''' <summary>Member name CaseCollectionViaCase</summary>
			Public Shared ReadOnly [CaseCollectionViaCase] As String  = "CaseCollectionViaCase"
			''' <summary>Member name CategoryCollectionViaCase</summary>
			Public Shared ReadOnly [CategoryCollectionViaCase] As String  = "CategoryCollectionViaCase"
			''' <summary>Member name ClaimStatusCollectionViaCase</summary>
			Public Shared ReadOnly [ClaimStatusCollectionViaCase] As String  = "ClaimStatusCollectionViaCase"
			''' <summary>Member name ComponentCollectionViaCase</summary>
			Public Shared ReadOnly [ComponentCollectionViaCase] As String  = "ComponentCollectionViaCase"
			''' <summary>Member name ControlCollectionViaInlineHelp</summary>
			Public Shared ReadOnly [ControlCollectionViaInlineHelp] As String  = "ControlCollectionViaInlineHelp"
			''' <summary>Member name DocumentTemplateCollectionViaBrand2DocumentTemplate</summary>
			Public Shared ReadOnly [DocumentTemplateCollectionViaBrand2DocumentTemplate] As String  = "DocumentTemplateCollectionViaBrand2DocumentTemplate"
			''' <summary>Member name FeatureCollectionViaBrand2Feature</summary>
			Public Shared ReadOnly [FeatureCollectionViaBrand2Feature] As String  = "FeatureCollectionViaBrand2Feature"
			''' <summary>Member name FolderTypeCollectionViaStandardFolder</summary>
			Public Shared ReadOnly [FolderTypeCollectionViaStandardFolder] As String  = "FolderTypeCollectionViaStandardFolder"
			''' <summary>Member name ParticipantCollectionViaCase</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase] As String  = "ParticipantCollectionViaCase"
			''' <summary>Member name ParticipantCollectionViaCase_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase_] As String  = "ParticipantCollectionViaCase_"
			''' <summary>Member name ParticipantCollectionViaCase__</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase__] As String  = "ParticipantCollectionViaCase__"
			''' <summary>Member name ParticipantCollectionViaCase___</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase___] As String  = "ParticipantCollectionViaCase___"
			''' <summary>Member name ParticipantCollectionViaCase____</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase____] As String  = "ParticipantCollectionViaCase____"
			''' <summary>Member name ParticipantCollectionViaCase_____</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase_____] As String  = "ParticipantCollectionViaCase_____"
			''' <summary>Member name ParticipantCollectionViaPhase</summary>
			Public Shared ReadOnly [ParticipantCollectionViaPhase] As String  = "ParticipantCollectionViaPhase"
			''' <summary>Member name ParticipantCollectionViaPhase_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaPhase_] As String  = "ParticipantCollectionViaPhase_"
			''' <summary>Member name ParticipantCollectionViaStandardTask</summary>
			Public Shared ReadOnly [ParticipantCollectionViaStandardTask] As String  = "ParticipantCollectionViaStandardTask"
			''' <summary>Member name ParticipantCollectionViaStandardTask_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaStandardTask_] As String  = "ParticipantCollectionViaStandardTask_"
			''' <summary>Member name PbuCollectionViaCase</summary>
			Public Shared ReadOnly [PbuCollectionViaCase] As String  = "PbuCollectionViaCase"
			''' <summary>Member name PersonalSafetyCollectionViaCase</summary>
			Public Shared ReadOnly [PersonalSafetyCollectionViaCase] As String  = "PersonalSafetyCollectionViaCase"
			''' <summary>Member name PhaseCollectionViaBrand2DocumentTemplate</summary>
			Public Shared ReadOnly [PhaseCollectionViaBrand2DocumentTemplate] As String  = "PhaseCollectionViaBrand2DocumentTemplate"
			''' <summary>Member name PhaseCollectionViaCase</summary>
			Public Shared ReadOnly [PhaseCollectionViaCase] As String  = "PhaseCollectionViaCase"
			''' <summary>Member name PhaseCollectionViaStandardTask</summary>
			Public Shared ReadOnly [PhaseCollectionViaStandardTask] As String  = "PhaseCollectionViaStandardTask"
			''' <summary>Member name PlatformCollectionViaCase</summary>
			Public Shared ReadOnly [PlatformCollectionViaCase] As String  = "PlatformCollectionViaCase"
			''' <summary>Member name PortfolioCollectionViaCase</summary>
			Public Shared ReadOnly [PortfolioCollectionViaCase] As String  = "PortfolioCollectionViaCase"
			''' <summary>Member name ProjectScopeCollectionViaCase</summary>
			Public Shared ReadOnly [ProjectScopeCollectionViaCase] As String  = "ProjectScopeCollectionViaCase"
			''' <summary>Member name StandardFolderCollectionViaStandardFolder</summary>
			Public Shared ReadOnly [StandardFolderCollectionViaStandardFolder] As String  = "StandardFolderCollectionViaStandardFolder"
			''' <summary>Member name StandardMilestoneCollectionViaBrand2StandardMilestone</summary>
			Public Shared ReadOnly [StandardMilestoneCollectionViaBrand2StandardMilestone] As String  = "StandardMilestoneCollectionViaBrand2StandardMilestone"
			''' <summary>Member name StandardTaskCollectionViaCase</summary>
			Public Shared ReadOnly [StandardTaskCollectionViaCase] As String  = "StandardTaskCollectionViaCase"
			''' <summary>Member name StatusCollectionViaCase</summary>
			Public Shared ReadOnly [StatusCollectionViaCase] As String  = "StatusCollectionViaCase"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("BrandEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("BrandEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this BrandEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("BrandEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="brandId">PK value for Brand which data should be fetched into this Brand object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(brandId As System.Int64)
			MyBase.New("BrandEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.BrandId = brandId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="brandId">PK value for Brand which data should be fetched into this Brand object</param>
		''' <param name="validator">The custom validator object for this BrandEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(brandId As System.Int64, validator As IValidator)
			MyBase.New("BrandEntity")
			InitClassEmpty(validator, Nothing)
			Me.BrandId = brandId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_brand2DocumentTemplate = CType(info.GetValue("_brand2DocumentTemplate", GetType(EntityCollection(Of Brand2DocumentTemplateEntity))), EntityCollection(Of Brand2DocumentTemplateEntity))
				_brand2Feature = CType(info.GetValue("_brand2Feature", GetType(EntityCollection(Of Brand2FeatureEntity))), EntityCollection(Of Brand2FeatureEntity))
				_brand2StandardMilestone = CType(info.GetValue("_brand2StandardMilestone", GetType(EntityCollection(Of Brand2StandardMilestoneEntity))), EntityCollection(Of Brand2StandardMilestoneEntity))
				_case = CType(info.GetValue("_case", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_inlineHelp = CType(info.GetValue("_inlineHelp", GetType(EntityCollection(Of InlineHelpEntity))), EntityCollection(Of InlineHelpEntity))
				_phase = CType(info.GetValue("_phase", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_standardFolder = CType(info.GetValue("_standardFolder", GetType(EntityCollection(Of StandardFolderEntity))), EntityCollection(Of StandardFolderEntity))
				_standardTask = CType(info.GetValue("_standardTask", GetType(EntityCollection(Of StandardTaskEntity))), EntityCollection(Of StandardTaskEntity))
				_businessProcessCollectionViaCase = CType(info.GetValue("_businessProcessCollectionViaCase", GetType(EntityCollection(Of BusinessProcessEntity))), EntityCollection(Of BusinessProcessEntity))
				_caseCollectionViaCase = CType(info.GetValue("_caseCollectionViaCase", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_categoryCollectionViaCase = CType(info.GetValue("_categoryCollectionViaCase", GetType(EntityCollection(Of CategoryEntity))), EntityCollection(Of CategoryEntity))
				_claimStatusCollectionViaCase = CType(info.GetValue("_claimStatusCollectionViaCase", GetType(EntityCollection(Of ClaimStatusEntity))), EntityCollection(Of ClaimStatusEntity))
				_componentCollectionViaCase = CType(info.GetValue("_componentCollectionViaCase", GetType(EntityCollection(Of ComponentEntity))), EntityCollection(Of ComponentEntity))
				_controlCollectionViaInlineHelp = CType(info.GetValue("_controlCollectionViaInlineHelp", GetType(EntityCollection(Of ControlEntity))), EntityCollection(Of ControlEntity))
				_documentTemplateCollectionViaBrand2DocumentTemplate = CType(info.GetValue("_documentTemplateCollectionViaBrand2DocumentTemplate", GetType(EntityCollection(Of DocumentTemplateEntity))), EntityCollection(Of DocumentTemplateEntity))
				_featureCollectionViaBrand2Feature = CType(info.GetValue("_featureCollectionViaBrand2Feature", GetType(EntityCollection(Of FeatureEntity))), EntityCollection(Of FeatureEntity))
				_folderTypeCollectionViaStandardFolder = CType(info.GetValue("_folderTypeCollectionViaStandardFolder", GetType(EntityCollection(Of FolderTypeEntity))), EntityCollection(Of FolderTypeEntity))
				_participantCollectionViaCase = CType(info.GetValue("_participantCollectionViaCase", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase_ = CType(info.GetValue("_participantCollectionViaCase_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase__ = CType(info.GetValue("_participantCollectionViaCase__", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase___ = CType(info.GetValue("_participantCollectionViaCase___", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase____ = CType(info.GetValue("_participantCollectionViaCase____", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase_____ = CType(info.GetValue("_participantCollectionViaCase_____", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaPhase = CType(info.GetValue("_participantCollectionViaPhase", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaPhase_ = CType(info.GetValue("_participantCollectionViaPhase_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaStandardTask = CType(info.GetValue("_participantCollectionViaStandardTask", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaStandardTask_ = CType(info.GetValue("_participantCollectionViaStandardTask_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_pbuCollectionViaCase = CType(info.GetValue("_pbuCollectionViaCase", GetType(EntityCollection(Of PbuEntity))), EntityCollection(Of PbuEntity))
				_personalSafetyCollectionViaCase = CType(info.GetValue("_personalSafetyCollectionViaCase", GetType(EntityCollection(Of PersonalSafetyEntity))), EntityCollection(Of PersonalSafetyEntity))
				_phaseCollectionViaBrand2DocumentTemplate = CType(info.GetValue("_phaseCollectionViaBrand2DocumentTemplate", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_phaseCollectionViaCase = CType(info.GetValue("_phaseCollectionViaCase", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_phaseCollectionViaStandardTask = CType(info.GetValue("_phaseCollectionViaStandardTask", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_platformCollectionViaCase = CType(info.GetValue("_platformCollectionViaCase", GetType(EntityCollection(Of PlatformEntity))), EntityCollection(Of PlatformEntity))
				_portfolioCollectionViaCase = CType(info.GetValue("_portfolioCollectionViaCase", GetType(EntityCollection(Of PortfolioEntity))), EntityCollection(Of PortfolioEntity))
				_projectScopeCollectionViaCase = CType(info.GetValue("_projectScopeCollectionViaCase", GetType(EntityCollection(Of ProjectScopeEntity))), EntityCollection(Of ProjectScopeEntity))
				_standardFolderCollectionViaStandardFolder = CType(info.GetValue("_standardFolderCollectionViaStandardFolder", GetType(EntityCollection(Of StandardFolderEntity))), EntityCollection(Of StandardFolderEntity))
				_standardMilestoneCollectionViaBrand2StandardMilestone = CType(info.GetValue("_standardMilestoneCollectionViaBrand2StandardMilestone", GetType(EntityCollection(Of StandardMilestoneEntity))), EntityCollection(Of StandardMilestoneEntity))
				_standardTaskCollectionViaCase = CType(info.GetValue("_standardTaskCollectionViaCase", GetType(EntityCollection(Of StandardTaskEntity))), EntityCollection(Of StandardTaskEntity))
				_statusCollectionViaCase = CType(info.GetValue("_statusCollectionViaCase", GetType(EntityCollection(Of StatusEntity))), EntityCollection(Of StatusEntity))
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub



		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Brand2DocumentTemplate"
					Me.Brand2DocumentTemplate.Add(CType(entity, Brand2DocumentTemplateEntity))
				Case "Brand2Feature"
					Me.Brand2Feature.Add(CType(entity, Brand2FeatureEntity))
				Case "Brand2StandardMilestone"
					Me.Brand2StandardMilestone.Add(CType(entity, Brand2StandardMilestoneEntity))
				Case "Case"
					Me.Case.Add(CType(entity, CaseEntity))
				Case "InlineHelp"
					Me.InlineHelp.Add(CType(entity, InlineHelpEntity))
				Case "Phase"
					Me.Phase.Add(CType(entity, PhaseEntity))
				Case "StandardFolder"
					Me.StandardFolder.Add(CType(entity, StandardFolderEntity))
				Case "StandardTask"
					Me.StandardTask.Add(CType(entity, StandardTaskEntity))
				Case "BusinessProcessCollectionViaCase"
					Me.BusinessProcessCollectionViaCase.IsReadOnly = False
					Me.BusinessProcessCollectionViaCase.Add(CType(entity, BusinessProcessEntity))
					Me.BusinessProcessCollectionViaCase.IsReadOnly = True
				Case "CaseCollectionViaCase"
					Me.CaseCollectionViaCase.IsReadOnly = False
					Me.CaseCollectionViaCase.Add(CType(entity, CaseEntity))
					Me.CaseCollectionViaCase.IsReadOnly = True
				Case "CategoryCollectionViaCase"
					Me.CategoryCollectionViaCase.IsReadOnly = False
					Me.CategoryCollectionViaCase.Add(CType(entity, CategoryEntity))
					Me.CategoryCollectionViaCase.IsReadOnly = True
				Case "ClaimStatusCollectionViaCase"
					Me.ClaimStatusCollectionViaCase.IsReadOnly = False
					Me.ClaimStatusCollectionViaCase.Add(CType(entity, ClaimStatusEntity))
					Me.ClaimStatusCollectionViaCase.IsReadOnly = True
				Case "ComponentCollectionViaCase"
					Me.ComponentCollectionViaCase.IsReadOnly = False
					Me.ComponentCollectionViaCase.Add(CType(entity, ComponentEntity))
					Me.ComponentCollectionViaCase.IsReadOnly = True
				Case "ControlCollectionViaInlineHelp"
					Me.ControlCollectionViaInlineHelp.IsReadOnly = False
					Me.ControlCollectionViaInlineHelp.Add(CType(entity, ControlEntity))
					Me.ControlCollectionViaInlineHelp.IsReadOnly = True
				Case "DocumentTemplateCollectionViaBrand2DocumentTemplate"
					Me.DocumentTemplateCollectionViaBrand2DocumentTemplate.IsReadOnly = False
					Me.DocumentTemplateCollectionViaBrand2DocumentTemplate.Add(CType(entity, DocumentTemplateEntity))
					Me.DocumentTemplateCollectionViaBrand2DocumentTemplate.IsReadOnly = True
				Case "FeatureCollectionViaBrand2Feature"
					Me.FeatureCollectionViaBrand2Feature.IsReadOnly = False
					Me.FeatureCollectionViaBrand2Feature.Add(CType(entity, FeatureEntity))
					Me.FeatureCollectionViaBrand2Feature.IsReadOnly = True
				Case "FolderTypeCollectionViaStandardFolder"
					Me.FolderTypeCollectionViaStandardFolder.IsReadOnly = False
					Me.FolderTypeCollectionViaStandardFolder.Add(CType(entity, FolderTypeEntity))
					Me.FolderTypeCollectionViaStandardFolder.IsReadOnly = True
				Case "ParticipantCollectionViaCase"
					Me.ParticipantCollectionViaCase.IsReadOnly = False
					Me.ParticipantCollectionViaCase.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase.IsReadOnly = True
				Case "ParticipantCollectionViaCase_"
					Me.ParticipantCollectionViaCase_.IsReadOnly = False
					Me.ParticipantCollectionViaCase_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase_.IsReadOnly = True
				Case "ParticipantCollectionViaCase__"
					Me.ParticipantCollectionViaCase__.IsReadOnly = False
					Me.ParticipantCollectionViaCase__.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase__.IsReadOnly = True
				Case "ParticipantCollectionViaCase___"
					Me.ParticipantCollectionViaCase___.IsReadOnly = False
					Me.ParticipantCollectionViaCase___.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase___.IsReadOnly = True
				Case "ParticipantCollectionViaCase____"
					Me.ParticipantCollectionViaCase____.IsReadOnly = False
					Me.ParticipantCollectionViaCase____.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase____.IsReadOnly = True
				Case "ParticipantCollectionViaCase_____"
					Me.ParticipantCollectionViaCase_____.IsReadOnly = False
					Me.ParticipantCollectionViaCase_____.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase_____.IsReadOnly = True
				Case "ParticipantCollectionViaPhase"
					Me.ParticipantCollectionViaPhase.IsReadOnly = False
					Me.ParticipantCollectionViaPhase.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaPhase.IsReadOnly = True
				Case "ParticipantCollectionViaPhase_"
					Me.ParticipantCollectionViaPhase_.IsReadOnly = False
					Me.ParticipantCollectionViaPhase_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaPhase_.IsReadOnly = True
				Case "ParticipantCollectionViaStandardTask"
					Me.ParticipantCollectionViaStandardTask.IsReadOnly = False
					Me.ParticipantCollectionViaStandardTask.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaStandardTask.IsReadOnly = True
				Case "ParticipantCollectionViaStandardTask_"
					Me.ParticipantCollectionViaStandardTask_.IsReadOnly = False
					Me.ParticipantCollectionViaStandardTask_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaStandardTask_.IsReadOnly = True
				Case "PbuCollectionViaCase"
					Me.PbuCollectionViaCase.IsReadOnly = False
					Me.PbuCollectionViaCase.Add(CType(entity, PbuEntity))
					Me.PbuCollectionViaCase.IsReadOnly = True
				Case "PersonalSafetyCollectionViaCase"
					Me.PersonalSafetyCollectionViaCase.IsReadOnly = False
					Me.PersonalSafetyCollectionViaCase.Add(CType(entity, PersonalSafetyEntity))
					Me.PersonalSafetyCollectionViaCase.IsReadOnly = True
				Case "PhaseCollectionViaBrand2DocumentTemplate"
					Me.PhaseCollectionViaBrand2DocumentTemplate.IsReadOnly = False
					Me.PhaseCollectionViaBrand2DocumentTemplate.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaBrand2DocumentTemplate.IsReadOnly = True
				Case "PhaseCollectionViaCase"
					Me.PhaseCollectionViaCase.IsReadOnly = False
					Me.PhaseCollectionViaCase.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaCase.IsReadOnly = True
				Case "PhaseCollectionViaStandardTask"
					Me.PhaseCollectionViaStandardTask.IsReadOnly = False
					Me.PhaseCollectionViaStandardTask.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaStandardTask.IsReadOnly = True
				Case "PlatformCollectionViaCase"
					Me.PlatformCollectionViaCase.IsReadOnly = False
					Me.PlatformCollectionViaCase.Add(CType(entity, PlatformEntity))
					Me.PlatformCollectionViaCase.IsReadOnly = True
				Case "PortfolioCollectionViaCase"
					Me.PortfolioCollectionViaCase.IsReadOnly = False
					Me.PortfolioCollectionViaCase.Add(CType(entity, PortfolioEntity))
					Me.PortfolioCollectionViaCase.IsReadOnly = True
				Case "ProjectScopeCollectionViaCase"
					Me.ProjectScopeCollectionViaCase.IsReadOnly = False
					Me.ProjectScopeCollectionViaCase.Add(CType(entity, ProjectScopeEntity))
					Me.ProjectScopeCollectionViaCase.IsReadOnly = True
				Case "StandardFolderCollectionViaStandardFolder"
					Me.StandardFolderCollectionViaStandardFolder.IsReadOnly = False
					Me.StandardFolderCollectionViaStandardFolder.Add(CType(entity, StandardFolderEntity))
					Me.StandardFolderCollectionViaStandardFolder.IsReadOnly = True
				Case "StandardMilestoneCollectionViaBrand2StandardMilestone"
					Me.StandardMilestoneCollectionViaBrand2StandardMilestone.IsReadOnly = False
					Me.StandardMilestoneCollectionViaBrand2StandardMilestone.Add(CType(entity, StandardMilestoneEntity))
					Me.StandardMilestoneCollectionViaBrand2StandardMilestone.IsReadOnly = True
				Case "StandardTaskCollectionViaCase"
					Me.StandardTaskCollectionViaCase.IsReadOnly = False
					Me.StandardTaskCollectionViaCase.Add(CType(entity, StandardTaskEntity))
					Me.StandardTaskCollectionViaCase.IsReadOnly = True
				Case "StatusCollectionViaCase"
					Me.StatusCollectionViaCase.IsReadOnly = False
					Me.StatusCollectionViaCase.Add(CType(entity, StatusEntity))
					Me.StatusCollectionViaCase.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return BrandEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Brand2DocumentTemplate"
					toReturn.Add(BrandEntity.Relations.Brand2DocumentTemplateEntityUsingBrandId)
				Case "Brand2Feature"
					toReturn.Add(BrandEntity.Relations.Brand2FeatureEntityUsingBrandId)
				Case "Brand2StandardMilestone"
					toReturn.Add(BrandEntity.Relations.Brand2StandardMilestoneEntityUsingBrandId)
				Case "Case"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId)
				Case "InlineHelp"
					toReturn.Add(BrandEntity.Relations.InlineHelpEntityUsingBrandId)
				Case "Phase"
					toReturn.Add(BrandEntity.Relations.PhaseEntityUsingBrandId)
				Case "StandardFolder"
					toReturn.Add(BrandEntity.Relations.StandardFolderEntityUsingBrandId)
				Case "StandardTask"
					toReturn.Add(BrandEntity.Relations.StandardTaskEntityUsingBrandId)
				Case "BusinessProcessCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.BusinessProcessEntityUsingBusinessProcessId, "Case_", String.Empty, JoinHint.None)
				Case "CaseCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "Case_", String.Empty, JoinHint.None)
				Case "CategoryCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.CategoryEntityUsingCategoryId, "Case_", String.Empty, JoinHint.None)
				Case "ClaimStatusCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ClaimStatusEntityUsingClaimStatusId, "Case_", String.Empty, JoinHint.None)
				Case "ComponentCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ComponentEntityUsingComponentId, "Case_", String.Empty, JoinHint.None)
				Case "ControlCollectionViaInlineHelp"
					toReturn.Add(BrandEntity.Relations.InlineHelpEntityUsingBrandId, "BrandEntity__", "InlineHelp_", JoinHint.None)
					toReturn.Add(InlineHelpEntity.Relations.ControlEntityUsingControlId, "InlineHelp_", String.Empty, JoinHint.None)
				Case "DocumentTemplateCollectionViaBrand2DocumentTemplate"
					toReturn.Add(BrandEntity.Relations.Brand2DocumentTemplateEntityUsingBrandId, "BrandEntity__", "Brand2DocumentTemplate_", JoinHint.None)
					toReturn.Add(Brand2DocumentTemplateEntity.Relations.DocumentTemplateEntityUsingDocumentTemplateId, "Brand2DocumentTemplate_", String.Empty, JoinHint.None)
				Case "FeatureCollectionViaBrand2Feature"
					toReturn.Add(BrandEntity.Relations.Brand2FeatureEntityUsingBrandId, "BrandEntity__", "Brand2Feature_", JoinHint.None)
					toReturn.Add(Brand2FeatureEntity.Relations.FeatureEntityUsingFeatureId, "Brand2Feature_", String.Empty, JoinHint.None)
				Case "FolderTypeCollectionViaStandardFolder"
					toReturn.Add(BrandEntity.Relations.StandardFolderEntityUsingBrandId, "BrandEntity__", "StandardFolder_", JoinHint.None)
					toReturn.Add(StandardFolderEntity.Relations.FolderTypeEntityUsingFolderTypeId, "StandardFolder_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingManagerId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase_"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingCreatedById, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase__"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingLastEditedById, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase___"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingTechnicalSpecialistId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase____"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingExecutionManagerId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase_____"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingContainmentLeadId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaPhase"
					toReturn.Add(BrandEntity.Relations.PhaseEntityUsingBrandId, "BrandEntity__", "Phase_", JoinHint.None)
					toReturn.Add(PhaseEntity.Relations.ParticipantEntityUsingCreatedById, "Phase_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaPhase_"
					toReturn.Add(BrandEntity.Relations.PhaseEntityUsingBrandId, "BrandEntity__", "Phase_", JoinHint.None)
					toReturn.Add(PhaseEntity.Relations.ParticipantEntityUsingDeletedById, "Phase_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaStandardTask"
					toReturn.Add(BrandEntity.Relations.StandardTaskEntityUsingBrandId, "BrandEntity__", "StandardTask_", JoinHint.None)
					toReturn.Add(StandardTaskEntity.Relations.ParticipantEntityUsingCreatedById, "StandardTask_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaStandardTask_"
					toReturn.Add(BrandEntity.Relations.StandardTaskEntityUsingBrandId, "BrandEntity__", "StandardTask_", JoinHint.None)
					toReturn.Add(StandardTaskEntity.Relations.ParticipantEntityUsingDeletedById, "StandardTask_", String.Empty, JoinHint.None)
				Case "PbuCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PbuEntityUsingPbuid, "Case_", String.Empty, JoinHint.None)
				Case "PersonalSafetyCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PersonalSafetyEntityUsingPersonalSafetyId, "Case_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaBrand2DocumentTemplate"
					toReturn.Add(BrandEntity.Relations.Brand2DocumentTemplateEntityUsingBrandId, "BrandEntity__", "Brand2DocumentTemplate_", JoinHint.None)
					toReturn.Add(Brand2DocumentTemplateEntity.Relations.PhaseEntityUsingPhaseId, "Brand2DocumentTemplate_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PhaseEntityUsingPhaseId, "Case_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaStandardTask"
					toReturn.Add(BrandEntity.Relations.StandardTaskEntityUsingBrandId, "BrandEntity__", "StandardTask_", JoinHint.None)
					toReturn.Add(StandardTaskEntity.Relations.PhaseEntityUsingPhaseId, "StandardTask_", String.Empty, JoinHint.None)
				Case "PlatformCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PlatformEntityUsingPlatform, "Case_", String.Empty, JoinHint.None)
				Case "PortfolioCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PortfolioEntityUsingPortfolioId, "Case_", String.Empty, JoinHint.None)
				Case "ProjectScopeCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ProjectScopeEntityUsingProjectScopeId, "Case_", String.Empty, JoinHint.None)
				Case "StandardFolderCollectionViaStandardFolder"
					toReturn.Add(BrandEntity.Relations.StandardFolderEntityUsingBrandId, "BrandEntity__", "StandardFolder_", JoinHint.None)
					toReturn.Add(StandardFolderEntity.Relations.StandardFolderEntityUsingParentStandardFolderId, "StandardFolder_", String.Empty, JoinHint.None)
				Case "StandardMilestoneCollectionViaBrand2StandardMilestone"
					toReturn.Add(BrandEntity.Relations.Brand2StandardMilestoneEntityUsingBrandId, "BrandEntity__", "Brand2StandardMilestone_", JoinHint.None)
					toReturn.Add(Brand2StandardMilestoneEntity.Relations.StandardMilestoneEntityUsingStandardMilestoneId, "Brand2StandardMilestone_", String.Empty, JoinHint.None)
				Case "StandardTaskCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.StandardTaskEntityUsingStandardTaskId, "Case_", String.Empty, JoinHint.None)
				Case "StatusCollectionViaCase"
					toReturn.Add(BrandEntity.Relations.CaseEntityUsingBrandId, "BrandEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.StatusEntityUsingStatusId, "Case_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Brand2DocumentTemplate"
					Me.Brand2DocumentTemplate.Add(CType(relatedEntity, Brand2DocumentTemplateEntity))
				Case "Brand2Feature"
					Me.Brand2Feature.Add(CType(relatedEntity, Brand2FeatureEntity))
				Case "Brand2StandardMilestone"
					Me.Brand2StandardMilestone.Add(CType(relatedEntity, Brand2StandardMilestoneEntity))
				Case "Case"
					Me.Case.Add(CType(relatedEntity, CaseEntity))
				Case "InlineHelp"
					Me.InlineHelp.Add(CType(relatedEntity, InlineHelpEntity))
				Case "Phase"
					Me.Phase.Add(CType(relatedEntity, PhaseEntity))
				Case "StandardFolder"
					Me.StandardFolder.Add(CType(relatedEntity, StandardFolderEntity))
				Case "StandardTask"
					Me.StandardTask.Add(CType(relatedEntity, StandardTaskEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Brand2DocumentTemplate"
					Me.PerformRelatedEntityRemoval(Me.Brand2DocumentTemplate, relatedEntity, signalRelatedEntityManyToOne)
				Case "Brand2Feature"
					Me.PerformRelatedEntityRemoval(Me.Brand2Feature, relatedEntity, signalRelatedEntityManyToOne)
				Case "Brand2StandardMilestone"
					Me.PerformRelatedEntityRemoval(Me.Brand2StandardMilestone, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case"
					Me.PerformRelatedEntityRemoval(Me.Case, relatedEntity, signalRelatedEntityManyToOne)
				Case "InlineHelp"
					Me.PerformRelatedEntityRemoval(Me.InlineHelp, relatedEntity, signalRelatedEntityManyToOne)
				Case "Phase"
					Me.PerformRelatedEntityRemoval(Me.Phase, relatedEntity, signalRelatedEntityManyToOne)
				Case "StandardFolder"
					Me.PerformRelatedEntityRemoval(Me.StandardFolder, relatedEntity, signalRelatedEntityManyToOne)
				Case "StandardTask"
					Me.PerformRelatedEntityRemoval(Me.StandardTask, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Brand2DocumentTemplate)
			toReturn.Add(Me.Brand2Feature)
			toReturn.Add(Me.Brand2StandardMilestone)
			toReturn.Add(Me.Case)
			toReturn.Add(Me.InlineHelp)
			toReturn.Add(Me.Phase)
			toReturn.Add(Me.StandardFolder)
			toReturn.Add(Me.StandardTask)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_brand2DocumentTemplate Is Nothing)) AndAlso (_brand2DocumentTemplate.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brand2DocumentTemplate 
				End If
				info.AddValue("_brand2DocumentTemplate", value)
				value = Nothing 
				If (Not (_brand2Feature Is Nothing)) AndAlso (_brand2Feature.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brand2Feature 
				End If
				info.AddValue("_brand2Feature", value)
				value = Nothing 
				If (Not (_brand2StandardMilestone Is Nothing)) AndAlso (_brand2StandardMilestone.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brand2StandardMilestone 
				End If
				info.AddValue("_brand2StandardMilestone", value)
				value = Nothing 
				If (Not (_case Is Nothing)) AndAlso (_case.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case 
				End If
				info.AddValue("_case", value)
				value = Nothing 
				If (Not (_inlineHelp Is Nothing)) AndAlso (_inlineHelp.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _inlineHelp 
				End If
				info.AddValue("_inlineHelp", value)
				value = Nothing 
				If (Not (_phase Is Nothing)) AndAlso (_phase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phase 
				End If
				info.AddValue("_phase", value)
				value = Nothing 
				If (Not (_standardFolder Is Nothing)) AndAlso (_standardFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardFolder 
				End If
				info.AddValue("_standardFolder", value)
				value = Nothing 
				If (Not (_standardTask Is Nothing)) AndAlso (_standardTask.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardTask 
				End If
				info.AddValue("_standardTask", value)
				value = Nothing 
				If (Not (_businessProcessCollectionViaCase Is Nothing)) AndAlso (_businessProcessCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _businessProcessCollectionViaCase 
				End If
				info.AddValue("_businessProcessCollectionViaCase", value)
				value = Nothing 
				If (Not (_caseCollectionViaCase Is Nothing)) AndAlso (_caseCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _caseCollectionViaCase 
				End If
				info.AddValue("_caseCollectionViaCase", value)
				value = Nothing 
				If (Not (_categoryCollectionViaCase Is Nothing)) AndAlso (_categoryCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _categoryCollectionViaCase 
				End If
				info.AddValue("_categoryCollectionViaCase", value)
				value = Nothing 
				If (Not (_claimStatusCollectionViaCase Is Nothing)) AndAlso (_claimStatusCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _claimStatusCollectionViaCase 
				End If
				info.AddValue("_claimStatusCollectionViaCase", value)
				value = Nothing 
				If (Not (_componentCollectionViaCase Is Nothing)) AndAlso (_componentCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _componentCollectionViaCase 
				End If
				info.AddValue("_componentCollectionViaCase", value)
				value = Nothing 
				If (Not (_controlCollectionViaInlineHelp Is Nothing)) AndAlso (_controlCollectionViaInlineHelp.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _controlCollectionViaInlineHelp 
				End If
				info.AddValue("_controlCollectionViaInlineHelp", value)
				value = Nothing 
				If (Not (_documentTemplateCollectionViaBrand2DocumentTemplate Is Nothing)) AndAlso (_documentTemplateCollectionViaBrand2DocumentTemplate.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _documentTemplateCollectionViaBrand2DocumentTemplate 
				End If
				info.AddValue("_documentTemplateCollectionViaBrand2DocumentTemplate", value)
				value = Nothing 
				If (Not (_featureCollectionViaBrand2Feature Is Nothing)) AndAlso (_featureCollectionViaBrand2Feature.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _featureCollectionViaBrand2Feature 
				End If
				info.AddValue("_featureCollectionViaBrand2Feature", value)
				value = Nothing 
				If (Not (_folderTypeCollectionViaStandardFolder Is Nothing)) AndAlso (_folderTypeCollectionViaStandardFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _folderTypeCollectionViaStandardFolder 
				End If
				info.AddValue("_folderTypeCollectionViaStandardFolder", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase Is Nothing)) AndAlso (_participantCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase 
				End If
				info.AddValue("_participantCollectionViaCase", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase_ Is Nothing)) AndAlso (_participantCollectionViaCase_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase_ 
				End If
				info.AddValue("_participantCollectionViaCase_", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase__ Is Nothing)) AndAlso (_participantCollectionViaCase__.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase__ 
				End If
				info.AddValue("_participantCollectionViaCase__", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase___ Is Nothing)) AndAlso (_participantCollectionViaCase___.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase___ 
				End If
				info.AddValue("_participantCollectionViaCase___", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase____ Is Nothing)) AndAlso (_participantCollectionViaCase____.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase____ 
				End If
				info.AddValue("_participantCollectionViaCase____", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase_____ Is Nothing)) AndAlso (_participantCollectionViaCase_____.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase_____ 
				End If
				info.AddValue("_participantCollectionViaCase_____", value)
				value = Nothing 
				If (Not (_participantCollectionViaPhase Is Nothing)) AndAlso (_participantCollectionViaPhase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaPhase 
				End If
				info.AddValue("_participantCollectionViaPhase", value)
				value = Nothing 
				If (Not (_participantCollectionViaPhase_ Is Nothing)) AndAlso (_participantCollectionViaPhase_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaPhase_ 
				End If
				info.AddValue("_participantCollectionViaPhase_", value)
				value = Nothing 
				If (Not (_participantCollectionViaStandardTask Is Nothing)) AndAlso (_participantCollectionViaStandardTask.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaStandardTask 
				End If
				info.AddValue("_participantCollectionViaStandardTask", value)
				value = Nothing 
				If (Not (_participantCollectionViaStandardTask_ Is Nothing)) AndAlso (_participantCollectionViaStandardTask_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaStandardTask_ 
				End If
				info.AddValue("_participantCollectionViaStandardTask_", value)
				value = Nothing 
				If (Not (_pbuCollectionViaCase Is Nothing)) AndAlso (_pbuCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _pbuCollectionViaCase 
				End If
				info.AddValue("_pbuCollectionViaCase", value)
				value = Nothing 
				If (Not (_personalSafetyCollectionViaCase Is Nothing)) AndAlso (_personalSafetyCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _personalSafetyCollectionViaCase 
				End If
				info.AddValue("_personalSafetyCollectionViaCase", value)
				value = Nothing 
				If (Not (_phaseCollectionViaBrand2DocumentTemplate Is Nothing)) AndAlso (_phaseCollectionViaBrand2DocumentTemplate.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaBrand2DocumentTemplate 
				End If
				info.AddValue("_phaseCollectionViaBrand2DocumentTemplate", value)
				value = Nothing 
				If (Not (_phaseCollectionViaCase Is Nothing)) AndAlso (_phaseCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaCase 
				End If
				info.AddValue("_phaseCollectionViaCase", value)
				value = Nothing 
				If (Not (_phaseCollectionViaStandardTask Is Nothing)) AndAlso (_phaseCollectionViaStandardTask.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaStandardTask 
				End If
				info.AddValue("_phaseCollectionViaStandardTask", value)
				value = Nothing 
				If (Not (_platformCollectionViaCase Is Nothing)) AndAlso (_platformCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _platformCollectionViaCase 
				End If
				info.AddValue("_platformCollectionViaCase", value)
				value = Nothing 
				If (Not (_portfolioCollectionViaCase Is Nothing)) AndAlso (_portfolioCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _portfolioCollectionViaCase 
				End If
				info.AddValue("_portfolioCollectionViaCase", value)
				value = Nothing 
				If (Not (_projectScopeCollectionViaCase Is Nothing)) AndAlso (_projectScopeCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _projectScopeCollectionViaCase 
				End If
				info.AddValue("_projectScopeCollectionViaCase", value)
				value = Nothing 
				If (Not (_standardFolderCollectionViaStandardFolder Is Nothing)) AndAlso (_standardFolderCollectionViaStandardFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardFolderCollectionViaStandardFolder 
				End If
				info.AddValue("_standardFolderCollectionViaStandardFolder", value)
				value = Nothing 
				If (Not (_standardMilestoneCollectionViaBrand2StandardMilestone Is Nothing)) AndAlso (_standardMilestoneCollectionViaBrand2StandardMilestone.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardMilestoneCollectionViaBrand2StandardMilestone 
				End If
				info.AddValue("_standardMilestoneCollectionViaBrand2StandardMilestone", value)
				value = Nothing 
				If (Not (_standardTaskCollectionViaCase Is Nothing)) AndAlso (_standardTaskCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardTaskCollectionViaCase 
				End If
				info.AddValue("_standardTaskCollectionViaCase", value)
				value = Nothing 
				If (Not (_statusCollectionViaCase Is Nothing)) AndAlso (_statusCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _statusCollectionViaCase 
				End If
				info.AddValue("_statusCollectionViaCase", value)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New BrandRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand2DocumentTemplate' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrand2DocumentTemplate() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Brand2DocumentTemplateFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand2Feature' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrand2Feature() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Brand2FeatureFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand2StandardMilestone' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrand2StandardMilestone() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Brand2StandardMilestoneFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'InlineHelp' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoInlineHelp() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(InlineHelpFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PhaseFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardFolder' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardFolderFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardTask' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardTask() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardTaskFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'BusinessProcess' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBusinessProcessCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BusinessProcessCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCaseCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CaseCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Category' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCategoryCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CategoryCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ClaimStatus' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoClaimStatusCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ClaimStatusCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Component' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoComponentCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ComponentCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Control' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoControlCollectionViaInlineHelp() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ControlCollectionViaInlineHelp"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'DocumentTemplate' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentTemplateCollectionViaBrand2DocumentTemplate() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("DocumentTemplateCollectionViaBrand2DocumentTemplate"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Feature' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFeatureCollectionViaBrand2Feature() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("FeatureCollectionViaBrand2Feature"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'FolderType' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolderTypeCollectionViaStandardFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("FolderTypeCollectionViaStandardFolder"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase__() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase__"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase___() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase___"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase____() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase____"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase_____() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase_____"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaPhase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaPhase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaPhase_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaPhase_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaStandardTask() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaStandardTask"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaStandardTask_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaStandardTask_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Pbu' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPbuCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PbuCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'PersonalSafety' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPersonalSafetyCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PersonalSafetyCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaBrand2DocumentTemplate() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaBrand2DocumentTemplate"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaStandardTask() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaStandardTask"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Platform' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPlatformCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PlatformCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Portfolio' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPortfolioCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PortfolioCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ProjectScope' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoProjectScopeCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ProjectScopeCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardFolder' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardFolderCollectionViaStandardFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StandardFolderCollectionViaStandardFolder"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardMilestone' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardMilestoneCollectionViaBrand2StandardMilestone() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StandardMilestoneCollectionViaBrand2StandardMilestone"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardTask' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardTaskCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StandardTaskCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Status' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStatusCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StatusCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId, "BrandEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_brand2DocumentTemplate)
			collectionsQueue.Enqueue(_brand2Feature)
			collectionsQueue.Enqueue(_brand2StandardMilestone)
			collectionsQueue.Enqueue(_case)
			collectionsQueue.Enqueue(_inlineHelp)
			collectionsQueue.Enqueue(_phase)
			collectionsQueue.Enqueue(_standardFolder)
			collectionsQueue.Enqueue(_standardTask)
			collectionsQueue.Enqueue(_businessProcessCollectionViaCase)
			collectionsQueue.Enqueue(_caseCollectionViaCase)
			collectionsQueue.Enqueue(_categoryCollectionViaCase)
			collectionsQueue.Enqueue(_claimStatusCollectionViaCase)
			collectionsQueue.Enqueue(_componentCollectionViaCase)
			collectionsQueue.Enqueue(_controlCollectionViaInlineHelp)
			collectionsQueue.Enqueue(_documentTemplateCollectionViaBrand2DocumentTemplate)
			collectionsQueue.Enqueue(_featureCollectionViaBrand2Feature)
			collectionsQueue.Enqueue(_folderTypeCollectionViaStandardFolder)
			collectionsQueue.Enqueue(_participantCollectionViaCase)
			collectionsQueue.Enqueue(_participantCollectionViaCase_)
			collectionsQueue.Enqueue(_participantCollectionViaCase__)
			collectionsQueue.Enqueue(_participantCollectionViaCase___)
			collectionsQueue.Enqueue(_participantCollectionViaCase____)
			collectionsQueue.Enqueue(_participantCollectionViaCase_____)
			collectionsQueue.Enqueue(_participantCollectionViaPhase)
			collectionsQueue.Enqueue(_participantCollectionViaPhase_)
			collectionsQueue.Enqueue(_participantCollectionViaStandardTask)
			collectionsQueue.Enqueue(_participantCollectionViaStandardTask_)
			collectionsQueue.Enqueue(_pbuCollectionViaCase)
			collectionsQueue.Enqueue(_personalSafetyCollectionViaCase)
			collectionsQueue.Enqueue(_phaseCollectionViaBrand2DocumentTemplate)
			collectionsQueue.Enqueue(_phaseCollectionViaCase)
			collectionsQueue.Enqueue(_phaseCollectionViaStandardTask)
			collectionsQueue.Enqueue(_platformCollectionViaCase)
			collectionsQueue.Enqueue(_portfolioCollectionViaCase)
			collectionsQueue.Enqueue(_projectScopeCollectionViaCase)
			collectionsQueue.Enqueue(_standardFolderCollectionViaStandardFolder)
			collectionsQueue.Enqueue(_standardMilestoneCollectionViaBrand2StandardMilestone)
			collectionsQueue.Enqueue(_standardTaskCollectionViaCase)
			collectionsQueue.Enqueue(_statusCollectionViaCase)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_brand2DocumentTemplate = CType(collectionsQueue.Dequeue(), EntityCollection(Of Brand2DocumentTemplateEntity))
			_brand2Feature = CType(collectionsQueue.Dequeue(), EntityCollection(Of Brand2FeatureEntity))
			_brand2StandardMilestone = CType(collectionsQueue.Dequeue(), EntityCollection(Of Brand2StandardMilestoneEntity))
			_case = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_inlineHelp = CType(collectionsQueue.Dequeue(), EntityCollection(Of InlineHelpEntity))
			_phase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_standardFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardFolderEntity))
			_standardTask = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardTaskEntity))
			_businessProcessCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of BusinessProcessEntity))
			_caseCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_categoryCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of CategoryEntity))
			_claimStatusCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ClaimStatusEntity))
			_componentCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ComponentEntity))
			_controlCollectionViaInlineHelp = CType(collectionsQueue.Dequeue(), EntityCollection(Of ControlEntity))
			_documentTemplateCollectionViaBrand2DocumentTemplate = CType(collectionsQueue.Dequeue(), EntityCollection(Of DocumentTemplateEntity))
			_featureCollectionViaBrand2Feature = CType(collectionsQueue.Dequeue(), EntityCollection(Of FeatureEntity))
			_folderTypeCollectionViaStandardFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of FolderTypeEntity))
			_participantCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase__ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase___ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase____ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase_____ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaPhase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaPhase_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaStandardTask = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaStandardTask_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_pbuCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PbuEntity))
			_personalSafetyCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PersonalSafetyEntity))
			_phaseCollectionViaBrand2DocumentTemplate = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_phaseCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_phaseCollectionViaStandardTask = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_platformCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PlatformEntity))
			_portfolioCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PortfolioEntity))
			_projectScopeCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ProjectScopeEntity))
			_standardFolderCollectionViaStandardFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardFolderEntity))
			_standardMilestoneCollectionViaBrand2StandardMilestone = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardMilestoneEntity))
			_standardTaskCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardTaskEntity))
			_statusCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of StatusEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _brand2DocumentTemplate Is Nothing) Then
				Return True
			End If
			If (Not _brand2Feature Is Nothing) Then
				Return True
			End If
			If (Not _brand2StandardMilestone Is Nothing) Then
				Return True
			End If
			If (Not _case Is Nothing) Then
				Return True
			End If
			If (Not _inlineHelp Is Nothing) Then
				Return True
			End If
			If (Not _phase Is Nothing) Then
				Return True
			End If
			If (Not _standardFolder Is Nothing) Then
				Return True
			End If
			If (Not _standardTask Is Nothing) Then
				Return True
			End If
			If (Not _businessProcessCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _caseCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _categoryCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _claimStatusCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _componentCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _controlCollectionViaInlineHelp Is Nothing) Then
				Return True
			End If
			If (Not _documentTemplateCollectionViaBrand2DocumentTemplate Is Nothing) Then
				Return True
			End If
			If (Not _featureCollectionViaBrand2Feature Is Nothing) Then
				Return True
			End If
			If (Not _folderTypeCollectionViaStandardFolder Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase__ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase___ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase____ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase_____ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaPhase Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaPhase_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaStandardTask Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaStandardTask_ Is Nothing) Then
				Return True
			End If
			If (Not _pbuCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _personalSafetyCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaBrand2DocumentTemplate Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaStandardTask Is Nothing) Then
				Return True
			End If
			If (Not _platformCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _portfolioCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _projectScopeCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _standardFolderCollectionViaStandardFolder Is Nothing) Then
				Return True
			End If
			If (Not _standardMilestoneCollectionViaBrand2StandardMilestone Is Nothing) Then
				Return True
			End If
			If (Not _standardTaskCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _statusCollectionViaCase Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Brand2DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2DocumentTemplateEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Brand2FeatureEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2FeatureEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Brand2StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2StandardMilestoneEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of InlineHelpEntity)(EntityFactoryCache2.GetEntityFactory(GetType(InlineHelpEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CategoryEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ControlEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ControlEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentTemplateEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of FeatureEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FeatureEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardMilestoneEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Brand2DocumentTemplate", _brand2DocumentTemplate)
			toReturn.Add("Brand2Feature", _brand2Feature)
			toReturn.Add("Brand2StandardMilestone", _brand2StandardMilestone)
			toReturn.Add("Case", _case)
			toReturn.Add("InlineHelp", _inlineHelp)
			toReturn.Add("Phase", _phase)
			toReturn.Add("StandardFolder", _standardFolder)
			toReturn.Add("StandardTask", _standardTask)
			toReturn.Add("BusinessProcessCollectionViaCase", _businessProcessCollectionViaCase)
			toReturn.Add("CaseCollectionViaCase", _caseCollectionViaCase)
			toReturn.Add("CategoryCollectionViaCase", _categoryCollectionViaCase)
			toReturn.Add("ClaimStatusCollectionViaCase", _claimStatusCollectionViaCase)
			toReturn.Add("ComponentCollectionViaCase", _componentCollectionViaCase)
			toReturn.Add("ControlCollectionViaInlineHelp", _controlCollectionViaInlineHelp)
			toReturn.Add("DocumentTemplateCollectionViaBrand2DocumentTemplate", _documentTemplateCollectionViaBrand2DocumentTemplate)
			toReturn.Add("FeatureCollectionViaBrand2Feature", _featureCollectionViaBrand2Feature)
			toReturn.Add("FolderTypeCollectionViaStandardFolder", _folderTypeCollectionViaStandardFolder)
			toReturn.Add("ParticipantCollectionViaCase", _participantCollectionViaCase)
			toReturn.Add("ParticipantCollectionViaCase_", _participantCollectionViaCase_)
			toReturn.Add("ParticipantCollectionViaCase__", _participantCollectionViaCase__)
			toReturn.Add("ParticipantCollectionViaCase___", _participantCollectionViaCase___)
			toReturn.Add("ParticipantCollectionViaCase____", _participantCollectionViaCase____)
			toReturn.Add("ParticipantCollectionViaCase_____", _participantCollectionViaCase_____)
			toReturn.Add("ParticipantCollectionViaPhase", _participantCollectionViaPhase)
			toReturn.Add("ParticipantCollectionViaPhase_", _participantCollectionViaPhase_)
			toReturn.Add("ParticipantCollectionViaStandardTask", _participantCollectionViaStandardTask)
			toReturn.Add("ParticipantCollectionViaStandardTask_", _participantCollectionViaStandardTask_)
			toReturn.Add("PbuCollectionViaCase", _pbuCollectionViaCase)
			toReturn.Add("PersonalSafetyCollectionViaCase", _personalSafetyCollectionViaCase)
			toReturn.Add("PhaseCollectionViaBrand2DocumentTemplate", _phaseCollectionViaBrand2DocumentTemplate)
			toReturn.Add("PhaseCollectionViaCase", _phaseCollectionViaCase)
			toReturn.Add("PhaseCollectionViaStandardTask", _phaseCollectionViaStandardTask)
			toReturn.Add("PlatformCollectionViaCase", _platformCollectionViaCase)
			toReturn.Add("PortfolioCollectionViaCase", _portfolioCollectionViaCase)
			toReturn.Add("ProjectScopeCollectionViaCase", _projectScopeCollectionViaCase)
			toReturn.Add("StandardFolderCollectionViaStandardFolder", _standardFolderCollectionViaStandardFolder)
			toReturn.Add("StandardMilestoneCollectionViaBrand2StandardMilestone", _standardMilestoneCollectionViaBrand2StandardMilestone)
			toReturn.Add("StandardTaskCollectionViaCase", _standardTaskCollectionViaCase)
			toReturn.Add("StatusCollectionViaCase", _statusCollectionViaCase)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("BrandId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Name", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("InitialPortfolioId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CaseStandbyTextUrl", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PortalUrl", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("MasterMinorText", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("SharepointNewsChannelId", fieldHashtable)
		End Sub





		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this BrandEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As BrandRelations
			Get	
				Return New BrandRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand2DocumentTemplate'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrand2DocumentTemplate() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Brand2DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2DocumentTemplateEntityFactory))), _
					CType(GetRelationsForField("Brand2DocumentTemplate")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.Brand2DocumentTemplateEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Brand2DocumentTemplate", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand2Feature'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrand2Feature() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Brand2FeatureEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2FeatureEntityFactory))), _
					CType(GetRelationsForField("Brand2Feature")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.Brand2FeatureEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Brand2Feature", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand2StandardMilestone'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrand2StandardMilestone() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Brand2StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2StandardMilestoneEntityFactory))), _
					CType(GetRelationsForField("Brand2StandardMilestone")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.Brand2StandardMilestoneEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Brand2StandardMilestone", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					CType(GetRelationsForField("Case")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'InlineHelp'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathInlineHelp() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of InlineHelpEntity)(EntityFactoryCache2.GetEntityFactory(GetType(InlineHelpEntityFactory))), _
					CType(GetRelationsForField("InlineHelp")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.InlineHelpEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "InlineHelp", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					CType(GetRelationsForField("Phase")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Phase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardFolder'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardFolder() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory))), _
					CType(GetRelationsForField("StandardFolder")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "StandardFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardTask'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardTask() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory))), _
					CType(GetRelationsForField("StandardTask")(0), IEntityRelation), CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.StandardTaskEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "StandardTask", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'BusinessProcess' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBusinessProcessCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.BusinessProcessEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BusinessProcessCollectionViaCase"), Nothing, "BusinessProcessCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCaseCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CaseCollectionViaCase"), Nothing, "CaseCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Category' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCategoryCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of CategoryEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.CategoryEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CategoryCollectionViaCase"), Nothing, "CategoryCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ClaimStatus' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathClaimStatusCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ClaimStatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ClaimStatusCollectionViaCase"), Nothing, "ClaimStatusCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Component' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathComponentCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ComponentEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ComponentCollectionViaCase"), Nothing, "ComponentCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Control' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathControlCollectionViaInlineHelp() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.InlineHelpEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "InlineHelp_")
				Return New PrefetchPathElement2( New EntityCollection(Of ControlEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ControlEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ControlEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ControlCollectionViaInlineHelp"), Nothing, "ControlCollectionViaInlineHelp", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentTemplate' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentTemplateCollectionViaBrand2DocumentTemplate() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.Brand2DocumentTemplateEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Brand2DocumentTemplate_")
				Return New PrefetchPathElement2( New EntityCollection(Of DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentTemplateEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.DocumentTemplateEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("DocumentTemplateCollectionViaBrand2DocumentTemplate"), Nothing, "DocumentTemplateCollectionViaBrand2DocumentTemplate", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Feature' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFeatureCollectionViaBrand2Feature() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.Brand2FeatureEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Brand2Feature_")
				Return New PrefetchPathElement2( New EntityCollection(Of FeatureEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FeatureEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.FeatureEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("FeatureCollectionViaBrand2Feature"), Nothing, "FeatureCollectionViaBrand2Feature", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'FolderType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolderTypeCollectionViaStandardFolder() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.StandardFolderEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "StandardFolder_")
				Return New PrefetchPathElement2( New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.FolderTypeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("FolderTypeCollectionViaStandardFolder"), Nothing, "FolderTypeCollectionViaStandardFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase"), Nothing, "ParticipantCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase_"), Nothing, "ParticipantCollectionViaCase_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase__() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase__"), Nothing, "ParticipantCollectionViaCase__", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase___() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase___"), Nothing, "ParticipantCollectionViaCase___", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase____() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase____"), Nothing, "ParticipantCollectionViaCase____", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase_____() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase_____"), Nothing, "ParticipantCollectionViaCase_____", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaPhase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.PhaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Phase_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaPhase"), Nothing, "ParticipantCollectionViaPhase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaPhase_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.PhaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Phase_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaPhase_"), Nothing, "ParticipantCollectionViaPhase_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaStandardTask() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.StandardTaskEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "StandardTask_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaStandardTask"), Nothing, "ParticipantCollectionViaStandardTask", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaStandardTask_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.StandardTaskEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "StandardTask_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaStandardTask_"), Nothing, "ParticipantCollectionViaStandardTask_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Pbu' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPbuCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PbuEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PbuCollectionViaCase"), Nothing, "PbuCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'PersonalSafety' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPersonalSafetyCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PersonalSafetyEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PersonalSafetyCollectionViaCase"), Nothing, "PersonalSafetyCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaBrand2DocumentTemplate() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.Brand2DocumentTemplateEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Brand2DocumentTemplate_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaBrand2DocumentTemplate"), Nothing, "PhaseCollectionViaBrand2DocumentTemplate", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaCase"), Nothing, "PhaseCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaStandardTask() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.StandardTaskEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "StandardTask_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaStandardTask"), Nothing, "PhaseCollectionViaStandardTask", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Platform' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPlatformCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PlatformEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PlatformCollectionViaCase"), Nothing, "PlatformCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Portfolio' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPortfolioCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.PortfolioEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PortfolioCollectionViaCase"), Nothing, "PortfolioCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ProjectScope' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathProjectScopeCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.ProjectScopeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ProjectScopeCollectionViaCase"), Nothing, "ProjectScopeCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardFolder' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardFolderCollectionViaStandardFolder() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.StandardFolderEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "StandardFolder_")
				Return New PrefetchPathElement2( New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StandardFolderCollectionViaStandardFolder"), Nothing, "StandardFolderCollectionViaStandardFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardMilestone' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardMilestoneCollectionViaBrand2StandardMilestone() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.Brand2StandardMilestoneEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Brand2StandardMilestone_")
				Return New PrefetchPathElement2( New EntityCollection(Of StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardMilestoneEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.StandardMilestoneEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StandardMilestoneCollectionViaBrand2StandardMilestone"), Nothing, "StandardMilestoneCollectionViaBrand2StandardMilestone", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardTask' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardTaskCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.StandardTaskEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StandardTaskCollectionViaCase"), Nothing, "StandardTaskCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Status' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStatusCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = BrandEntity.Relations.CaseEntityUsingBrandId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.BrandEntity, Integer), CType(PManagement.Data.EntityType.StatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StatusCollectionViaCase"), Nothing, "StatusCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property



		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return BrandEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return BrandEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The BrandId property of the Entity Brand<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Brand"."BrandId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [BrandId]() As System.Int64
			Get
				Return CType(GetValue(CInt(BrandFieldIndex.BrandId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(BrandFieldIndex.BrandId), value)
			End Set
		End Property
		''' <summary>The Name property of the Entity Brand<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Brand"."Name"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Name]() As System.String
			Get
				Return CType(GetValue(CInt(BrandFieldIndex.Name), True), System.String)
			End Get
			Set
				SetValue(CInt(BrandFieldIndex.Name), value)
			End Set
		End Property
		''' <summary>The InitialPortfolioId property of the Entity Brand<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Brand"."InitialPortfolioId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [InitialPortfolioId]() As System.Int64
			Get
				Return CType(GetValue(CInt(BrandFieldIndex.InitialPortfolioId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(BrandFieldIndex.InitialPortfolioId), value)
			End Set
		End Property
		''' <summary>The CaseStandbyTextUrl property of the Entity Brand<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Brand"."CaseStandbyTextURL"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 1000<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [CaseStandbyTextUrl]() As System.String
			Get
				Return CType(GetValue(CInt(BrandFieldIndex.CaseStandbyTextUrl), True), System.String)
			End Get
			Set
				SetValue(CInt(BrandFieldIndex.CaseStandbyTextUrl), value)
			End Set
		End Property
		''' <summary>The PortalUrl property of the Entity Brand<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Brand"."PortalURL"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 1000<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [PortalUrl]() As System.String
			Get
				Return CType(GetValue(CInt(BrandFieldIndex.PortalUrl), True), System.String)
			End Get
			Set
				SetValue(CInt(BrandFieldIndex.PortalUrl), value)
			End Set
		End Property
		''' <summary>The MasterMinorText property of the Entity Brand<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Brand"."MasterMinorText"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [MasterMinorText]() As System.String
			Get
				Return CType(GetValue(CInt(BrandFieldIndex.MasterMinorText), True), System.String)
			End Get
			Set
				SetValue(CInt(BrandFieldIndex.MasterMinorText), value)
			End Set
		End Property
		''' <summary>The SharepointNewsChannelId property of the Entity Brand<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Brand"."Sharepoint_NewsChannelID"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [SharepointNewsChannelId]() As System.Int64
			Get
				Return CType(GetValue(CInt(BrandFieldIndex.SharepointNewsChannelId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(BrandFieldIndex.SharepointNewsChannelId), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Brand2DocumentTemplateEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Brand2DocumentTemplateEntity))> _
		Public Overridable ReadOnly Property [Brand2DocumentTemplate]() As EntityCollection(Of Brand2DocumentTemplateEntity)
			Get
				If _brand2DocumentTemplate Is Nothing Then
					_brand2DocumentTemplate = New EntityCollection(Of Brand2DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2DocumentTemplateEntityFactory)))
					_brand2DocumentTemplate.ActiveContext = Me.ActiveContext
					_brand2DocumentTemplate.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _brand2DocumentTemplate
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Brand2FeatureEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Brand2FeatureEntity))> _
		Public Overridable ReadOnly Property [Brand2Feature]() As EntityCollection(Of Brand2FeatureEntity)
			Get
				If _brand2Feature Is Nothing Then
					_brand2Feature = New EntityCollection(Of Brand2FeatureEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2FeatureEntityFactory)))
					_brand2Feature.ActiveContext = Me.ActiveContext
					_brand2Feature.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _brand2Feature
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Brand2StandardMilestoneEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Brand2StandardMilestoneEntity))> _
		Public Overridable ReadOnly Property [Brand2StandardMilestone]() As EntityCollection(Of Brand2StandardMilestoneEntity)
			Get
				If _brand2StandardMilestone Is Nothing Then
					_brand2StandardMilestone = New EntityCollection(Of Brand2StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2StandardMilestoneEntityFactory)))
					_brand2StandardMilestone.ActiveContext = Me.ActiveContext
					_brand2StandardMilestone.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _brand2StandardMilestone
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [Case]() As EntityCollection(Of CaseEntity)
			Get
				If _case Is Nothing Then
					_case = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_case.ActiveContext = Me.ActiveContext
					_case.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _case
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'InlineHelpEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(InlineHelpEntity))> _
		Public Overridable ReadOnly Property [InlineHelp]() As EntityCollection(Of InlineHelpEntity)
			Get
				If _inlineHelp Is Nothing Then
					_inlineHelp = New EntityCollection(Of InlineHelpEntity)(EntityFactoryCache2.GetEntityFactory(GetType(InlineHelpEntityFactory)))
					_inlineHelp.ActiveContext = Me.ActiveContext
					_inlineHelp.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _inlineHelp
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [Phase]() As EntityCollection(Of PhaseEntity)
			Get
				If _phase Is Nothing Then
					_phase = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phase.ActiveContext = Me.ActiveContext
					_phase.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _phase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardFolderEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardFolderEntity))> _
		Public Overridable ReadOnly Property [StandardFolder]() As EntityCollection(Of StandardFolderEntity)
			Get
				If _standardFolder Is Nothing Then
					_standardFolder = New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory)))
					_standardFolder.ActiveContext = Me.ActiveContext
					_standardFolder.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _standardFolder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardTaskEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardTaskEntity))> _
		Public Overridable ReadOnly Property [StandardTask]() As EntityCollection(Of StandardTaskEntity)
			Get
				If _standardTask Is Nothing Then
					_standardTask = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
					_standardTask.ActiveContext = Me.ActiveContext
					_standardTask.SetContainingEntityInfo(Me, "Brand")
				End If
				Return _standardTask
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BusinessProcessEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BusinessProcessEntity))> _
		Public Overridable ReadOnly Property [BusinessProcessCollectionViaCase]() As EntityCollection(Of BusinessProcessEntity)
			Get
				If _businessProcessCollectionViaCase Is Nothing Then
					_businessProcessCollectionViaCase = New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory)))
					_businessProcessCollectionViaCase.ActiveContext = Me.ActiveContext
					_businessProcessCollectionViaCase.IsReadOnly = True
					CType(_businessProcessCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _businessProcessCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [CaseCollectionViaCase]() As EntityCollection(Of CaseEntity)
			Get
				If _caseCollectionViaCase Is Nothing Then
					_caseCollectionViaCase = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_caseCollectionViaCase.ActiveContext = Me.ActiveContext
					_caseCollectionViaCase.IsReadOnly = True
					CType(_caseCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _caseCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CategoryEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CategoryEntity))> _
		Public Overridable ReadOnly Property [CategoryCollectionViaCase]() As EntityCollection(Of CategoryEntity)
			Get
				If _categoryCollectionViaCase Is Nothing Then
					_categoryCollectionViaCase = New EntityCollection(Of CategoryEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory)))
					_categoryCollectionViaCase.ActiveContext = Me.ActiveContext
					_categoryCollectionViaCase.IsReadOnly = True
					CType(_categoryCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _categoryCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ClaimStatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ClaimStatusEntity))> _
		Public Overridable ReadOnly Property [ClaimStatusCollectionViaCase]() As EntityCollection(Of ClaimStatusEntity)
			Get
				If _claimStatusCollectionViaCase Is Nothing Then
					_claimStatusCollectionViaCase = New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory)))
					_claimStatusCollectionViaCase.ActiveContext = Me.ActiveContext
					_claimStatusCollectionViaCase.IsReadOnly = True
					CType(_claimStatusCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _claimStatusCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ComponentEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ComponentEntity))> _
		Public Overridable ReadOnly Property [ComponentCollectionViaCase]() As EntityCollection(Of ComponentEntity)
			Get
				If _componentCollectionViaCase Is Nothing Then
					_componentCollectionViaCase = New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory)))
					_componentCollectionViaCase.ActiveContext = Me.ActiveContext
					_componentCollectionViaCase.IsReadOnly = True
					CType(_componentCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _componentCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ControlEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ControlEntity))> _
		Public Overridable ReadOnly Property [ControlCollectionViaInlineHelp]() As EntityCollection(Of ControlEntity)
			Get
				If _controlCollectionViaInlineHelp Is Nothing Then
					_controlCollectionViaInlineHelp = New EntityCollection(Of ControlEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ControlEntityFactory)))
					_controlCollectionViaInlineHelp.ActiveContext = Me.ActiveContext
					_controlCollectionViaInlineHelp.IsReadOnly = True
					CType(_controlCollectionViaInlineHelp, IEntityCollectionCore).IsForMN = True
				End If
				Return _controlCollectionViaInlineHelp
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'DocumentTemplateEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(DocumentTemplateEntity))> _
		Public Overridable ReadOnly Property [DocumentTemplateCollectionViaBrand2DocumentTemplate]() As EntityCollection(Of DocumentTemplateEntity)
			Get
				If _documentTemplateCollectionViaBrand2DocumentTemplate Is Nothing Then
					_documentTemplateCollectionViaBrand2DocumentTemplate = New EntityCollection(Of DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentTemplateEntityFactory)))
					_documentTemplateCollectionViaBrand2DocumentTemplate.ActiveContext = Me.ActiveContext
					_documentTemplateCollectionViaBrand2DocumentTemplate.IsReadOnly = True
					CType(_documentTemplateCollectionViaBrand2DocumentTemplate, IEntityCollectionCore).IsForMN = True
				End If
				Return _documentTemplateCollectionViaBrand2DocumentTemplate
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'FeatureEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(FeatureEntity))> _
		Public Overridable ReadOnly Property [FeatureCollectionViaBrand2Feature]() As EntityCollection(Of FeatureEntity)
			Get
				If _featureCollectionViaBrand2Feature Is Nothing Then
					_featureCollectionViaBrand2Feature = New EntityCollection(Of FeatureEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FeatureEntityFactory)))
					_featureCollectionViaBrand2Feature.ActiveContext = Me.ActiveContext
					_featureCollectionViaBrand2Feature.IsReadOnly = True
					CType(_featureCollectionViaBrand2Feature, IEntityCollectionCore).IsForMN = True
				End If
				Return _featureCollectionViaBrand2Feature
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'FolderTypeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(FolderTypeEntity))> _
		Public Overridable ReadOnly Property [FolderTypeCollectionViaStandardFolder]() As EntityCollection(Of FolderTypeEntity)
			Get
				If _folderTypeCollectionViaStandardFolder Is Nothing Then
					_folderTypeCollectionViaStandardFolder = New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory)))
					_folderTypeCollectionViaStandardFolder.ActiveContext = Me.ActiveContext
					_folderTypeCollectionViaStandardFolder.IsReadOnly = True
					CType(_folderTypeCollectionViaStandardFolder, IEntityCollectionCore).IsForMN = True
				End If
				Return _folderTypeCollectionViaStandardFolder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase Is Nothing Then
					_participantCollectionViaCase = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase.IsReadOnly = True
					CType(_participantCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase_ Is Nothing Then
					_participantCollectionViaCase_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase_.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase_.IsReadOnly = True
					CType(_participantCollectionViaCase_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase__]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase__ Is Nothing Then
					_participantCollectionViaCase__ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase__.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase__.IsReadOnly = True
					CType(_participantCollectionViaCase__, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase__
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase___]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase___ Is Nothing Then
					_participantCollectionViaCase___ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase___.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase___.IsReadOnly = True
					CType(_participantCollectionViaCase___, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase___
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase____]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase____ Is Nothing Then
					_participantCollectionViaCase____ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase____.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase____.IsReadOnly = True
					CType(_participantCollectionViaCase____, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase____
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase_____]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase_____ Is Nothing Then
					_participantCollectionViaCase_____ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase_____.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase_____.IsReadOnly = True
					CType(_participantCollectionViaCase_____, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase_____
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaPhase]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaPhase Is Nothing Then
					_participantCollectionViaPhase = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaPhase.ActiveContext = Me.ActiveContext
					_participantCollectionViaPhase.IsReadOnly = True
					CType(_participantCollectionViaPhase, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaPhase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaPhase_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaPhase_ Is Nothing Then
					_participantCollectionViaPhase_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaPhase_.ActiveContext = Me.ActiveContext
					_participantCollectionViaPhase_.IsReadOnly = True
					CType(_participantCollectionViaPhase_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaPhase_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaStandardTask]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaStandardTask Is Nothing Then
					_participantCollectionViaStandardTask = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaStandardTask.ActiveContext = Me.ActiveContext
					_participantCollectionViaStandardTask.IsReadOnly = True
					CType(_participantCollectionViaStandardTask, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaStandardTask
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaStandardTask_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaStandardTask_ Is Nothing Then
					_participantCollectionViaStandardTask_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaStandardTask_.ActiveContext = Me.ActiveContext
					_participantCollectionViaStandardTask_.IsReadOnly = True
					CType(_participantCollectionViaStandardTask_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaStandardTask_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PbuEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PbuEntity))> _
		Public Overridable ReadOnly Property [PbuCollectionViaCase]() As EntityCollection(Of PbuEntity)
			Get
				If _pbuCollectionViaCase Is Nothing Then
					_pbuCollectionViaCase = New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory)))
					_pbuCollectionViaCase.ActiveContext = Me.ActiveContext
					_pbuCollectionViaCase.IsReadOnly = True
					CType(_pbuCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _pbuCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PersonalSafetyEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PersonalSafetyEntity))> _
		Public Overridable ReadOnly Property [PersonalSafetyCollectionViaCase]() As EntityCollection(Of PersonalSafetyEntity)
			Get
				If _personalSafetyCollectionViaCase Is Nothing Then
					_personalSafetyCollectionViaCase = New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory)))
					_personalSafetyCollectionViaCase.ActiveContext = Me.ActiveContext
					_personalSafetyCollectionViaCase.IsReadOnly = True
					CType(_personalSafetyCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _personalSafetyCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaBrand2DocumentTemplate]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaBrand2DocumentTemplate Is Nothing Then
					_phaseCollectionViaBrand2DocumentTemplate = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaBrand2DocumentTemplate.ActiveContext = Me.ActiveContext
					_phaseCollectionViaBrand2DocumentTemplate.IsReadOnly = True
					CType(_phaseCollectionViaBrand2DocumentTemplate, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaBrand2DocumentTemplate
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaCase]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaCase Is Nothing Then
					_phaseCollectionViaCase = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaCase.ActiveContext = Me.ActiveContext
					_phaseCollectionViaCase.IsReadOnly = True
					CType(_phaseCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaStandardTask]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaStandardTask Is Nothing Then
					_phaseCollectionViaStandardTask = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaStandardTask.ActiveContext = Me.ActiveContext
					_phaseCollectionViaStandardTask.IsReadOnly = True
					CType(_phaseCollectionViaStandardTask, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaStandardTask
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PlatformEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PlatformEntity))> _
		Public Overridable ReadOnly Property [PlatformCollectionViaCase]() As EntityCollection(Of PlatformEntity)
			Get
				If _platformCollectionViaCase Is Nothing Then
					_platformCollectionViaCase = New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory)))
					_platformCollectionViaCase.ActiveContext = Me.ActiveContext
					_platformCollectionViaCase.IsReadOnly = True
					CType(_platformCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _platformCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PortfolioEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PortfolioEntity))> _
		Public Overridable ReadOnly Property [PortfolioCollectionViaCase]() As EntityCollection(Of PortfolioEntity)
			Get
				If _portfolioCollectionViaCase Is Nothing Then
					_portfolioCollectionViaCase = New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory)))
					_portfolioCollectionViaCase.ActiveContext = Me.ActiveContext
					_portfolioCollectionViaCase.IsReadOnly = True
					CType(_portfolioCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _portfolioCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ProjectScopeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ProjectScopeEntity))> _
		Public Overridable ReadOnly Property [ProjectScopeCollectionViaCase]() As EntityCollection(Of ProjectScopeEntity)
			Get
				If _projectScopeCollectionViaCase Is Nothing Then
					_projectScopeCollectionViaCase = New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory)))
					_projectScopeCollectionViaCase.ActiveContext = Me.ActiveContext
					_projectScopeCollectionViaCase.IsReadOnly = True
					CType(_projectScopeCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _projectScopeCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardFolderEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardFolderEntity))> _
		Public Overridable ReadOnly Property [StandardFolderCollectionViaStandardFolder]() As EntityCollection(Of StandardFolderEntity)
			Get
				If _standardFolderCollectionViaStandardFolder Is Nothing Then
					_standardFolderCollectionViaStandardFolder = New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory)))
					_standardFolderCollectionViaStandardFolder.ActiveContext = Me.ActiveContext
					_standardFolderCollectionViaStandardFolder.IsReadOnly = True
					CType(_standardFolderCollectionViaStandardFolder, IEntityCollectionCore).IsForMN = True
				End If
				Return _standardFolderCollectionViaStandardFolder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardMilestoneEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardMilestoneEntity))> _
		Public Overridable ReadOnly Property [StandardMilestoneCollectionViaBrand2StandardMilestone]() As EntityCollection(Of StandardMilestoneEntity)
			Get
				If _standardMilestoneCollectionViaBrand2StandardMilestone Is Nothing Then
					_standardMilestoneCollectionViaBrand2StandardMilestone = New EntityCollection(Of StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardMilestoneEntityFactory)))
					_standardMilestoneCollectionViaBrand2StandardMilestone.ActiveContext = Me.ActiveContext
					_standardMilestoneCollectionViaBrand2StandardMilestone.IsReadOnly = True
					CType(_standardMilestoneCollectionViaBrand2StandardMilestone, IEntityCollectionCore).IsForMN = True
				End If
				Return _standardMilestoneCollectionViaBrand2StandardMilestone
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardTaskEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardTaskEntity))> _
		Public Overridable ReadOnly Property [StandardTaskCollectionViaCase]() As EntityCollection(Of StandardTaskEntity)
			Get
				If _standardTaskCollectionViaCase Is Nothing Then
					_standardTaskCollectionViaCase = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
					_standardTaskCollectionViaCase.ActiveContext = Me.ActiveContext
					_standardTaskCollectionViaCase.IsReadOnly = True
					CType(_standardTaskCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _standardTaskCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StatusEntity))> _
		Public Overridable ReadOnly Property [StatusCollectionViaCase]() As EntityCollection(Of StatusEntity)
			Get
				If _statusCollectionViaCase Is Nothing Then
					_statusCollectionViaCase = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
					_statusCollectionViaCase.ActiveContext = Me.ActiveContext
					_statusCollectionViaCase.IsReadOnly = True
					CType(_statusCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _statusCollectionViaCase
			End Get
		End Property


	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.BrandEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
