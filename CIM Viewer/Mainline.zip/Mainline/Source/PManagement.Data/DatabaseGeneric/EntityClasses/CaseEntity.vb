﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'Case'.<br/><br/></summary>
	<Serializable()> _
	Public Class CaseEntity 
		Inherits CommonEntityBase

    ' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
    ' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _childCase As EntityCollection(Of CaseEntity)
		Private WithEvents _case2CaseBundle As EntityCollection(Of Case2CaseBundleEntity)
		Private WithEvents _case2ComponentType As EntityCollection(Of Case2ComponentTypeEntity)
		Private WithEvents _case2Item As EntityCollection(Of Case2ItemEntity)
		Private WithEvents _case2LogInfo As EntityCollection(Of Case2LogInfoEntity)
		Private WithEvents _case2Participant As EntityCollection(Of Case2ParticipantEntity)
		Private WithEvents _case2Phase As EntityCollection(Of Case2PhaseEntity)
		Private WithEvents _case2ReasonCode As EntityCollection(Of Case2ReasonCodeEntity)
		Private WithEvents _case2Sbu As EntityCollection(Of Case2SbuEntity)
		Private WithEvents _case2ServiceCode As EntityCollection(Of Case2ServiceCodeEntity)
		Private WithEvents _case2Supplier As EntityCollection(Of Case2SupplierEntity)
		Private WithEvents _case2System As EntityCollection(Of Case2SystemEntity)
		Private WithEvents _case2TurbineUnitType As EntityCollection(Of Case2TurbineMatrixEntity)
		Private WithEvents _changeLog As EntityCollection(Of ChangeLogEntity)
		Private WithEvents _cir As EntityCollection(Of CirEntity)
		Private WithEvents _discussion As EntityCollection(Of DiscussionEntity)
		Private WithEvents _folder As EntityCollection(Of FolderEntity)
		Private WithEvents _milestone As EntityCollection(Of MilestoneEntity)
		Private WithEvents _news As EntityCollection(Of NewsEntity)
		Private WithEvents _oldCimturbine As EntityCollection(Of OldCimturbineEntity)
		Private WithEvents _populationlist As EntityCollection(Of PopulationlistEntity)
		Private WithEvents _rc As EntityCollection(Of RcEntity)
		Private WithEvents _relatedCase As EntityCollection(Of RelatedCaseEntity)
		Private WithEvents _relatedCase_ As EntityCollection(Of RelatedCaseEntity)
		Private WithEvents _timeline As EntityCollection(Of TimelineEntity)
		Private WithEvents _visits As EntityCollection(Of VisitsEntity)
		Private WithEvents _brandCollectionViaCase As EntityCollection(Of BrandEntity)
		Private WithEvents _businessProcessCollectionViaCase As EntityCollection(Of BusinessProcessEntity)
		Private WithEvents _case2SupplierCollectionViaCase2ComponentType As EntityCollection(Of Case2SupplierEntity)
		Private WithEvents _caseBundleCollectionViaCase2CaseBundle As EntityCollection(Of CaseBundleEntity)
		Private WithEvents _categoryCollectionViaCase As EntityCollection(Of CategoryEntity)
		Private WithEvents _changeTypeCollectionViaChangeLog As EntityCollection(Of ChangeTypeEntity)
		Private WithEvents _claimStatusCollectionViaCase As EntityCollection(Of ClaimStatusEntity)
		Private WithEvents _componentCollectionViaCase As EntityCollection(Of ComponentEntity)
		Private WithEvents _componentTypeCollectionViaCase2ComponentType As EntityCollection(Of ComponentTypeEntity)
		Private WithEvents _discussionCollectionViaDiscussion As EntityCollection(Of DiscussionEntity)
		Private WithEvents _folderCollectionViaFolder As EntityCollection(Of FolderEntity)
		Private WithEvents _folderTypeCollectionViaFolder As EntityCollection(Of FolderTypeEntity)
		Private WithEvents _itemCollectionViaCase2Item As EntityCollection(Of ItemEntity)
		Private WithEvents _logInfoCollectionViaCase2LogInfo As EntityCollection(Of LogInfoEntity)
		Private WithEvents _participantCollectionViaCase As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase__ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase___ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase____ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase_____ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase2Participant As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaChangeLog As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaChangeLog_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCir As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCir_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaDiscussion As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaDiscussion_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaFolder As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaFolder_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaMilestone As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaNews As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaNews_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaPopulationlist As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaRc As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaRc_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaTimeline As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaVisits As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaVisits_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participationTypeCollectionViaCase2Participant As EntityCollection(Of ParticipationTypeEntity)
		Private WithEvents _pbuCollectionViaCase As EntityCollection(Of PbuEntity)
		Private WithEvents _personalSafetyCollectionViaCase As EntityCollection(Of PersonalSafetyEntity)
		Private WithEvents _phaseCollectionViaCase As EntityCollection(Of PhaseEntity)
		Private WithEvents _phaseCollectionViaCase2Phase As EntityCollection(Of PhaseEntity)
		Private WithEvents _phaseCollectionViaPopulationlist As EntityCollection(Of PhaseEntity)
		Private WithEvents _platformCollectionViaCase As EntityCollection(Of PlatformEntity)
		Private WithEvents _portfolioCollectionViaCase As EntityCollection(Of PortfolioEntity)
		Private WithEvents _projectScopeCollectionViaCase As EntityCollection(Of ProjectScopeEntity)
		Private WithEvents _rccomponentOwnerCollectionViaRc As EntityCollection(Of RccomponentOwnerEntity)
		Private WithEvents _rcoriginCollectionViaRc As EntityCollection(Of RcoriginEntity)
		Private WithEvents _rcoriginResponsibleCollectionViaRc As EntityCollection(Of RcoriginResponsibleEntity)
		Private WithEvents _rcoriginUnitCollectionViaRc As EntityCollection(Of RcoriginUnitEntity)
		Private WithEvents _reasonCodeCollectionViaCase2ReasonCode As EntityCollection(Of ReasonCodeEntity)
		Private WithEvents _reportTypeCollectionViaCir As EntityCollection(Of ReportTypeEntity)
		Private WithEvents _sbuCollectionViaCase2Sbu As EntityCollection(Of SbuEntity)
		Private WithEvents _serviceCodeCollectionViaCase2ServiceCode As EntityCollection(Of ServiceCodeEntity)
		Private WithEvents _standardTaskCollectionViaCase As EntityCollection(Of StandardTaskEntity)
		Private WithEvents _stateCollectionViaPopulationlist As EntityCollection(Of StateEntity)
		Private WithEvents _statusCollectionViaCase As EntityCollection(Of StatusEntity)
		Private WithEvents _statusCollectionViaPopulationlist As EntityCollection(Of StatusEntity)
		Private WithEvents _supplierCollectionViaCase2Supplier As EntityCollection(Of SupplierEntity)
		Private WithEvents _systemDescriptionCollectionViaCase2System As EntityCollection(Of SystemDescriptionEntity)
		Private WithEvents _turbineMatrixCollectionViaCase2TurbineUnitType As EntityCollection(Of TurbineMatrixEntity)
		Private WithEvents _brand As BrandEntity
		Private WithEvents _businessProcess As BusinessProcessEntity
		Private WithEvents _parentCase As CaseEntity
		Private WithEvents _category As CategoryEntity
		Private WithEvents _claimStatus As ClaimStatusEntity
		Private WithEvents _component As ComponentEntity
		Private WithEvents _createdByParticipant As ParticipantEntity
		Private WithEvents _executionManagerParticipant As ParticipantEntity
		Private WithEvents _lastEditedByParticipant As ParticipantEntity
		Private WithEvents _managerParticipant As ParticipantEntity
		Private WithEvents _participant As ParticipantEntity
		Private WithEvents _technicalSpecialistParticipant As ParticipantEntity
		Private WithEvents _pbu As PbuEntity
		Private WithEvents _personalSafety As PersonalSafetyEntity
		Private WithEvents _phase As PhaseEntity
		Private WithEvents _platform_ As PlatformEntity
		Private WithEvents _portfolio As PortfolioEntity
		Private WithEvents _projectScope As ProjectScopeEntity
		Private WithEvents _standardTask As StandardTaskEntity
		Private WithEvents _status As StatusEntity

    ' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
    ' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Brand</summary>
			Public Shared ReadOnly [Brand] As String = "Brand"
			''' <summary>Member name BusinessProcess</summary>
			Public Shared ReadOnly [BusinessProcess] As String = "BusinessProcess"
			''' <summary>Member name ParentCase</summary>
			Public Shared ReadOnly [ParentCase] As String = "ParentCase"
			''' <summary>Member name Category</summary>
			Public Shared ReadOnly [Category] As String = "Category"
			''' <summary>Member name ClaimStatus</summary>
			Public Shared ReadOnly [ClaimStatus] As String = "ClaimStatus"
			''' <summary>Member name Component</summary>
			Public Shared ReadOnly [Component] As String = "Component"
			''' <summary>Member name CreatedByParticipant</summary>
			Public Shared ReadOnly [CreatedByParticipant] As String = "CreatedByParticipant"
			''' <summary>Member name ExecutionManagerParticipant</summary>
			Public Shared ReadOnly [ExecutionManagerParticipant] As String = "ExecutionManagerParticipant"
			''' <summary>Member name LastEditedByParticipant</summary>
			Public Shared ReadOnly [LastEditedByParticipant] As String = "LastEditedByParticipant"
			''' <summary>Member name ManagerParticipant</summary>
			Public Shared ReadOnly [ManagerParticipant] As String = "ManagerParticipant"
			''' <summary>Member name Participant</summary>
			Public Shared ReadOnly [Participant] As String = "Participant"
			''' <summary>Member name TechnicalSpecialistParticipant</summary>
			Public Shared ReadOnly [TechnicalSpecialistParticipant] As String = "TechnicalSpecialistParticipant"
			''' <summary>Member name Pbu</summary>
			Public Shared ReadOnly [Pbu] As String = "Pbu"
			''' <summary>Member name PersonalSafety</summary>
			Public Shared ReadOnly [PersonalSafety] As String = "PersonalSafety"
			''' <summary>Member name Phase</summary>
			Public Shared ReadOnly [Phase] As String = "Phase"
			''' <summary>Member name Platform_</summary>
			Public Shared ReadOnly [Platform_] As String = "Platform_"
			''' <summary>Member name Portfolio</summary>
			Public Shared ReadOnly [Portfolio] As String = "Portfolio"
			''' <summary>Member name ProjectScope</summary>
			Public Shared ReadOnly [ProjectScope] As String = "ProjectScope"
			''' <summary>Member name StandardTask</summary>
			Public Shared ReadOnly [StandardTask] As String = "StandardTask"
			''' <summary>Member name Status</summary>
			Public Shared ReadOnly [Status] As String = "Status"
			''' <summary>Member name ChildCase</summary>
			Public Shared ReadOnly [ChildCase] As String  = "ChildCase"
			''' <summary>Member name Case2CaseBundle</summary>
			Public Shared ReadOnly [Case2CaseBundle] As String  = "Case2CaseBundle"
			''' <summary>Member name Case2ComponentType</summary>
			Public Shared ReadOnly [Case2ComponentType] As String  = "Case2ComponentType"
			''' <summary>Member name Case2Item</summary>
			Public Shared ReadOnly [Case2Item] As String  = "Case2Item"
			''' <summary>Member name Case2LogInfo</summary>
			Public Shared ReadOnly [Case2LogInfo] As String  = "Case2LogInfo"
			''' <summary>Member name Case2Participant</summary>
			Public Shared ReadOnly [Case2Participant] As String  = "Case2Participant"
			''' <summary>Member name Case2Phase</summary>
			Public Shared ReadOnly [Case2Phase] As String  = "Case2Phase"
			''' <summary>Member name Case2ReasonCode</summary>
			Public Shared ReadOnly [Case2ReasonCode] As String  = "Case2ReasonCode"
			''' <summary>Member name Case2Sbu</summary>
			Public Shared ReadOnly [Case2Sbu] As String  = "Case2Sbu"
			''' <summary>Member name Case2ServiceCode</summary>
			Public Shared ReadOnly [Case2ServiceCode] As String  = "Case2ServiceCode"
			''' <summary>Member name Case2Supplier</summary>
			Public Shared ReadOnly [Case2Supplier] As String  = "Case2Supplier"
			''' <summary>Member name Case2System</summary>
			Public Shared ReadOnly [Case2System] As String  = "Case2System"
			''' <summary>Member name Case2TurbineUnitType</summary>
			Public Shared ReadOnly [Case2TurbineUnitType] As String  = "Case2TurbineUnitType"
			''' <summary>Member name ChangeLog</summary>
			Public Shared ReadOnly [ChangeLog] As String  = "ChangeLog"
			''' <summary>Member name Cir</summary>
			Public Shared ReadOnly [Cir] As String  = "Cir"
			''' <summary>Member name Discussion</summary>
			Public Shared ReadOnly [Discussion] As String  = "Discussion"
			''' <summary>Member name Folder</summary>
			Public Shared ReadOnly [Folder] As String  = "Folder"
			''' <summary>Member name Milestone</summary>
			Public Shared ReadOnly [Milestone] As String  = "Milestone"
			''' <summary>Member name News</summary>
			Public Shared ReadOnly [News] As String  = "News"
			''' <summary>Member name OldCimturbine</summary>
			Public Shared ReadOnly [OldCimturbine] As String  = "OldCimturbine"
			''' <summary>Member name Populationlist</summary>
			Public Shared ReadOnly [Populationlist] As String  = "Populationlist"
			''' <summary>Member name Rc</summary>
			Public Shared ReadOnly [Rc] As String  = "Rc"
			''' <summary>Member name RelatedCase</summary>
			Public Shared ReadOnly [RelatedCase] As String  = "RelatedCase"
			''' <summary>Member name RelatedCase_</summary>
			Public Shared ReadOnly [RelatedCase_] As String  = "RelatedCase_"
			''' <summary>Member name Timeline</summary>
			Public Shared ReadOnly [Timeline] As String  = "Timeline"
			''' <summary>Member name Visits</summary>
			Public Shared ReadOnly [Visits] As String  = "Visits"
			''' <summary>Member name BrandCollectionViaCase</summary>
			Public Shared ReadOnly [BrandCollectionViaCase] As String  = "BrandCollectionViaCase"
			''' <summary>Member name BusinessProcessCollectionViaCase</summary>
			Public Shared ReadOnly [BusinessProcessCollectionViaCase] As String  = "BusinessProcessCollectionViaCase"
			''' <summary>Member name Case2SupplierCollectionViaCase2ComponentType</summary>
			Public Shared ReadOnly [Case2SupplierCollectionViaCase2ComponentType] As String  = "Case2SupplierCollectionViaCase2ComponentType"
			''' <summary>Member name CaseBundleCollectionViaCase2CaseBundle</summary>
			Public Shared ReadOnly [CaseBundleCollectionViaCase2CaseBundle] As String  = "CaseBundleCollectionViaCase2CaseBundle"
			''' <summary>Member name CategoryCollectionViaCase</summary>
			Public Shared ReadOnly [CategoryCollectionViaCase] As String  = "CategoryCollectionViaCase"
			''' <summary>Member name ChangeTypeCollectionViaChangeLog</summary>
			Public Shared ReadOnly [ChangeTypeCollectionViaChangeLog] As String  = "ChangeTypeCollectionViaChangeLog"
			''' <summary>Member name ClaimStatusCollectionViaCase</summary>
			Public Shared ReadOnly [ClaimStatusCollectionViaCase] As String  = "ClaimStatusCollectionViaCase"
			''' <summary>Member name ComponentCollectionViaCase</summary>
			Public Shared ReadOnly [ComponentCollectionViaCase] As String  = "ComponentCollectionViaCase"
			''' <summary>Member name ComponentTypeCollectionViaCase2ComponentType</summary>
			Public Shared ReadOnly [ComponentTypeCollectionViaCase2ComponentType] As String  = "ComponentTypeCollectionViaCase2ComponentType"
			''' <summary>Member name DiscussionCollectionViaDiscussion</summary>
			Public Shared ReadOnly [DiscussionCollectionViaDiscussion] As String  = "DiscussionCollectionViaDiscussion"
			''' <summary>Member name FolderCollectionViaFolder</summary>
			Public Shared ReadOnly [FolderCollectionViaFolder] As String  = "FolderCollectionViaFolder"
			''' <summary>Member name FolderTypeCollectionViaFolder</summary>
			Public Shared ReadOnly [FolderTypeCollectionViaFolder] As String  = "FolderTypeCollectionViaFolder"
			''' <summary>Member name ItemCollectionViaCase2Item</summary>
			Public Shared ReadOnly [ItemCollectionViaCase2Item] As String  = "ItemCollectionViaCase2Item"
			''' <summary>Member name LogInfoCollectionViaCase2LogInfo</summary>
			Public Shared ReadOnly [LogInfoCollectionViaCase2LogInfo] As String  = "LogInfoCollectionViaCase2LogInfo"
			''' <summary>Member name ParticipantCollectionViaCase</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase] As String  = "ParticipantCollectionViaCase"
			''' <summary>Member name ParticipantCollectionViaCase_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase_] As String  = "ParticipantCollectionViaCase_"
			''' <summary>Member name ParticipantCollectionViaCase__</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase__] As String  = "ParticipantCollectionViaCase__"
			''' <summary>Member name ParticipantCollectionViaCase___</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase___] As String  = "ParticipantCollectionViaCase___"
			''' <summary>Member name ParticipantCollectionViaCase____</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase____] As String  = "ParticipantCollectionViaCase____"
			''' <summary>Member name ParticipantCollectionViaCase_____</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase_____] As String  = "ParticipantCollectionViaCase_____"
			''' <summary>Member name ParticipantCollectionViaCase2Participant</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase2Participant] As String  = "ParticipantCollectionViaCase2Participant"
			''' <summary>Member name ParticipantCollectionViaChangeLog</summary>
			Public Shared ReadOnly [ParticipantCollectionViaChangeLog] As String  = "ParticipantCollectionViaChangeLog"
			''' <summary>Member name ParticipantCollectionViaChangeLog_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaChangeLog_] As String  = "ParticipantCollectionViaChangeLog_"
			''' <summary>Member name ParticipantCollectionViaCir</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCir] As String  = "ParticipantCollectionViaCir"
			''' <summary>Member name ParticipantCollectionViaCir_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCir_] As String  = "ParticipantCollectionViaCir_"
			''' <summary>Member name ParticipantCollectionViaDiscussion</summary>
			Public Shared ReadOnly [ParticipantCollectionViaDiscussion] As String  = "ParticipantCollectionViaDiscussion"
			''' <summary>Member name ParticipantCollectionViaDiscussion_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaDiscussion_] As String  = "ParticipantCollectionViaDiscussion_"
			''' <summary>Member name ParticipantCollectionViaFolder</summary>
			Public Shared ReadOnly [ParticipantCollectionViaFolder] As String  = "ParticipantCollectionViaFolder"
			''' <summary>Member name ParticipantCollectionViaFolder_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaFolder_] As String  = "ParticipantCollectionViaFolder_"
			''' <summary>Member name ParticipantCollectionViaMilestone</summary>
			Public Shared ReadOnly [ParticipantCollectionViaMilestone] As String  = "ParticipantCollectionViaMilestone"
			''' <summary>Member name ParticipantCollectionViaNews</summary>
			Public Shared ReadOnly [ParticipantCollectionViaNews] As String  = "ParticipantCollectionViaNews"
			''' <summary>Member name ParticipantCollectionViaNews_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaNews_] As String  = "ParticipantCollectionViaNews_"
			''' <summary>Member name ParticipantCollectionViaPopulationlist</summary>
			Public Shared ReadOnly [ParticipantCollectionViaPopulationlist] As String  = "ParticipantCollectionViaPopulationlist"
			''' <summary>Member name ParticipantCollectionViaRc</summary>
			Public Shared ReadOnly [ParticipantCollectionViaRc] As String  = "ParticipantCollectionViaRc"
			''' <summary>Member name ParticipantCollectionViaRc_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaRc_] As String  = "ParticipantCollectionViaRc_"
			''' <summary>Member name ParticipantCollectionViaTimeline</summary>
			Public Shared ReadOnly [ParticipantCollectionViaTimeline] As String  = "ParticipantCollectionViaTimeline"
			''' <summary>Member name ParticipantCollectionViaVisits</summary>
			Public Shared ReadOnly [ParticipantCollectionViaVisits] As String  = "ParticipantCollectionViaVisits"
			''' <summary>Member name ParticipantCollectionViaVisits_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaVisits_] As String  = "ParticipantCollectionViaVisits_"
			''' <summary>Member name ParticipationTypeCollectionViaCase2Participant</summary>
			Public Shared ReadOnly [ParticipationTypeCollectionViaCase2Participant] As String  = "ParticipationTypeCollectionViaCase2Participant"
			''' <summary>Member name PbuCollectionViaCase</summary>
			Public Shared ReadOnly [PbuCollectionViaCase] As String  = "PbuCollectionViaCase"
			''' <summary>Member name PersonalSafetyCollectionViaCase</summary>
			Public Shared ReadOnly [PersonalSafetyCollectionViaCase] As String  = "PersonalSafetyCollectionViaCase"
			''' <summary>Member name PhaseCollectionViaCase</summary>
			Public Shared ReadOnly [PhaseCollectionViaCase] As String  = "PhaseCollectionViaCase"
			''' <summary>Member name PhaseCollectionViaCase2Phase</summary>
			Public Shared ReadOnly [PhaseCollectionViaCase2Phase] As String  = "PhaseCollectionViaCase2Phase"
			''' <summary>Member name PhaseCollectionViaPopulationlist</summary>
			Public Shared ReadOnly [PhaseCollectionViaPopulationlist] As String  = "PhaseCollectionViaPopulationlist"
			''' <summary>Member name PlatformCollectionViaCase</summary>
			Public Shared ReadOnly [PlatformCollectionViaCase] As String  = "PlatformCollectionViaCase"
			''' <summary>Member name PortfolioCollectionViaCase</summary>
			Public Shared ReadOnly [PortfolioCollectionViaCase] As String  = "PortfolioCollectionViaCase"
			''' <summary>Member name ProjectScopeCollectionViaCase</summary>
			Public Shared ReadOnly [ProjectScopeCollectionViaCase] As String  = "ProjectScopeCollectionViaCase"
			''' <summary>Member name RccomponentOwnerCollectionViaRc</summary>
			Public Shared ReadOnly [RccomponentOwnerCollectionViaRc] As String  = "RccomponentOwnerCollectionViaRc"
			''' <summary>Member name RcoriginCollectionViaRc</summary>
			Public Shared ReadOnly [RcoriginCollectionViaRc] As String  = "RcoriginCollectionViaRc"
			''' <summary>Member name RcoriginResponsibleCollectionViaRc</summary>
			Public Shared ReadOnly [RcoriginResponsibleCollectionViaRc] As String  = "RcoriginResponsibleCollectionViaRc"
			''' <summary>Member name RcoriginUnitCollectionViaRc</summary>
			Public Shared ReadOnly [RcoriginUnitCollectionViaRc] As String  = "RcoriginUnitCollectionViaRc"
			''' <summary>Member name ReasonCodeCollectionViaCase2ReasonCode</summary>
			Public Shared ReadOnly [ReasonCodeCollectionViaCase2ReasonCode] As String  = "ReasonCodeCollectionViaCase2ReasonCode"
			''' <summary>Member name ReportTypeCollectionViaCir</summary>
			Public Shared ReadOnly [ReportTypeCollectionViaCir] As String  = "ReportTypeCollectionViaCir"
			''' <summary>Member name SbuCollectionViaCase2Sbu</summary>
			Public Shared ReadOnly [SbuCollectionViaCase2Sbu] As String  = "SbuCollectionViaCase2Sbu"
			''' <summary>Member name ServiceCodeCollectionViaCase2ServiceCode</summary>
			Public Shared ReadOnly [ServiceCodeCollectionViaCase2ServiceCode] As String  = "ServiceCodeCollectionViaCase2ServiceCode"
			''' <summary>Member name StandardTaskCollectionViaCase</summary>
			Public Shared ReadOnly [StandardTaskCollectionViaCase] As String  = "StandardTaskCollectionViaCase"
			''' <summary>Member name StateCollectionViaPopulationlist</summary>
			Public Shared ReadOnly [StateCollectionViaPopulationlist] As String  = "StateCollectionViaPopulationlist"
			''' <summary>Member name StatusCollectionViaCase</summary>
			Public Shared ReadOnly [StatusCollectionViaCase] As String  = "StatusCollectionViaCase"
			''' <summary>Member name StatusCollectionViaPopulationlist</summary>
			Public Shared ReadOnly [StatusCollectionViaPopulationlist] As String  = "StatusCollectionViaPopulationlist"
			''' <summary>Member name SupplierCollectionViaCase2Supplier</summary>
			Public Shared ReadOnly [SupplierCollectionViaCase2Supplier] As String  = "SupplierCollectionViaCase2Supplier"
			''' <summary>Member name SystemDescriptionCollectionViaCase2System</summary>
			Public Shared ReadOnly [SystemDescriptionCollectionViaCase2System] As String  = "SystemDescriptionCollectionViaCase2System"
			''' <summary>Member name TurbineMatrixCollectionViaCase2TurbineUnitType</summary>
			Public Shared ReadOnly [TurbineMatrixCollectionViaCase2TurbineUnitType] As String  = "TurbineMatrixCollectionViaCase2TurbineUnitType"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CaseEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("CaseEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this CaseEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("CaseEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="caseId">PK value for Case which data should be fetched into this Case object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(caseId As System.Int64)
			MyBase.New("CaseEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.CaseId = caseId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="caseId">PK value for Case which data should be fetched into this Case object</param>
		''' <param name="validator">The custom validator object for this CaseEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(caseId As System.Int64, validator As IValidator)
			MyBase.New("CaseEntity")
			InitClassEmpty(validator, Nothing)
			Me.CaseId = caseId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_childCase = CType(info.GetValue("_childCase", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_case2CaseBundle = CType(info.GetValue("_case2CaseBundle", GetType(EntityCollection(Of Case2CaseBundleEntity))), EntityCollection(Of Case2CaseBundleEntity))
				_case2ComponentType = CType(info.GetValue("_case2ComponentType", GetType(EntityCollection(Of Case2ComponentTypeEntity))), EntityCollection(Of Case2ComponentTypeEntity))
				_case2Item = CType(info.GetValue("_case2Item", GetType(EntityCollection(Of Case2ItemEntity))), EntityCollection(Of Case2ItemEntity))
				_case2LogInfo = CType(info.GetValue("_case2LogInfo", GetType(EntityCollection(Of Case2LogInfoEntity))), EntityCollection(Of Case2LogInfoEntity))
				_case2Participant = CType(info.GetValue("_case2Participant", GetType(EntityCollection(Of Case2ParticipantEntity))), EntityCollection(Of Case2ParticipantEntity))
				_case2Phase = CType(info.GetValue("_case2Phase", GetType(EntityCollection(Of Case2PhaseEntity))), EntityCollection(Of Case2PhaseEntity))
				_case2ReasonCode = CType(info.GetValue("_case2ReasonCode", GetType(EntityCollection(Of Case2ReasonCodeEntity))), EntityCollection(Of Case2ReasonCodeEntity))
				_case2Sbu = CType(info.GetValue("_case2Sbu", GetType(EntityCollection(Of Case2SbuEntity))), EntityCollection(Of Case2SbuEntity))
				_case2ServiceCode = CType(info.GetValue("_case2ServiceCode", GetType(EntityCollection(Of Case2ServiceCodeEntity))), EntityCollection(Of Case2ServiceCodeEntity))
				_case2Supplier = CType(info.GetValue("_case2Supplier", GetType(EntityCollection(Of Case2SupplierEntity))), EntityCollection(Of Case2SupplierEntity))
				_case2System = CType(info.GetValue("_case2System", GetType(EntityCollection(Of Case2SystemEntity))), EntityCollection(Of Case2SystemEntity))
				_case2TurbineUnitType = CType(info.GetValue("_case2TurbineUnitType", GetType(EntityCollection(Of Case2TurbineMatrixEntity))), EntityCollection(Of Case2TurbineMatrixEntity))
				_changeLog = CType(info.GetValue("_changeLog", GetType(EntityCollection(Of ChangeLogEntity))), EntityCollection(Of ChangeLogEntity))
				_cir = CType(info.GetValue("_cir", GetType(EntityCollection(Of CirEntity))), EntityCollection(Of CirEntity))
				_discussion = CType(info.GetValue("_discussion", GetType(EntityCollection(Of DiscussionEntity))), EntityCollection(Of DiscussionEntity))
				_folder = CType(info.GetValue("_folder", GetType(EntityCollection(Of FolderEntity))), EntityCollection(Of FolderEntity))
				_milestone = CType(info.GetValue("_milestone", GetType(EntityCollection(Of MilestoneEntity))), EntityCollection(Of MilestoneEntity))
				_news = CType(info.GetValue("_news", GetType(EntityCollection(Of NewsEntity))), EntityCollection(Of NewsEntity))
				_oldCimturbine = CType(info.GetValue("_oldCimturbine", GetType(EntityCollection(Of OldCimturbineEntity))), EntityCollection(Of OldCimturbineEntity))
				_populationlist = CType(info.GetValue("_populationlist", GetType(EntityCollection(Of PopulationlistEntity))), EntityCollection(Of PopulationlistEntity))
				_rc = CType(info.GetValue("_rc", GetType(EntityCollection(Of RcEntity))), EntityCollection(Of RcEntity))
				_relatedCase = CType(info.GetValue("_relatedCase", GetType(EntityCollection(Of RelatedCaseEntity))), EntityCollection(Of RelatedCaseEntity))
				_relatedCase_ = CType(info.GetValue("_relatedCase_", GetType(EntityCollection(Of RelatedCaseEntity))), EntityCollection(Of RelatedCaseEntity))
				_timeline = CType(info.GetValue("_timeline", GetType(EntityCollection(Of TimelineEntity))), EntityCollection(Of TimelineEntity))
				_visits = CType(info.GetValue("_visits", GetType(EntityCollection(Of VisitsEntity))), EntityCollection(Of VisitsEntity))
				_brandCollectionViaCase = CType(info.GetValue("_brandCollectionViaCase", GetType(EntityCollection(Of BrandEntity))), EntityCollection(Of BrandEntity))
				_businessProcessCollectionViaCase = CType(info.GetValue("_businessProcessCollectionViaCase", GetType(EntityCollection(Of BusinessProcessEntity))), EntityCollection(Of BusinessProcessEntity))
				_case2SupplierCollectionViaCase2ComponentType = CType(info.GetValue("_case2SupplierCollectionViaCase2ComponentType", GetType(EntityCollection(Of Case2SupplierEntity))), EntityCollection(Of Case2SupplierEntity))
				_caseBundleCollectionViaCase2CaseBundle = CType(info.GetValue("_caseBundleCollectionViaCase2CaseBundle", GetType(EntityCollection(Of CaseBundleEntity))), EntityCollection(Of CaseBundleEntity))
				_categoryCollectionViaCase = CType(info.GetValue("_categoryCollectionViaCase", GetType(EntityCollection(Of CategoryEntity))), EntityCollection(Of CategoryEntity))
				_changeTypeCollectionViaChangeLog = CType(info.GetValue("_changeTypeCollectionViaChangeLog", GetType(EntityCollection(Of ChangeTypeEntity))), EntityCollection(Of ChangeTypeEntity))
				_claimStatusCollectionViaCase = CType(info.GetValue("_claimStatusCollectionViaCase", GetType(EntityCollection(Of ClaimStatusEntity))), EntityCollection(Of ClaimStatusEntity))
				_componentCollectionViaCase = CType(info.GetValue("_componentCollectionViaCase", GetType(EntityCollection(Of ComponentEntity))), EntityCollection(Of ComponentEntity))
				_componentTypeCollectionViaCase2ComponentType = CType(info.GetValue("_componentTypeCollectionViaCase2ComponentType", GetType(EntityCollection(Of ComponentTypeEntity))), EntityCollection(Of ComponentTypeEntity))
				_discussionCollectionViaDiscussion = CType(info.GetValue("_discussionCollectionViaDiscussion", GetType(EntityCollection(Of DiscussionEntity))), EntityCollection(Of DiscussionEntity))
				_folderCollectionViaFolder = CType(info.GetValue("_folderCollectionViaFolder", GetType(EntityCollection(Of FolderEntity))), EntityCollection(Of FolderEntity))
				_folderTypeCollectionViaFolder = CType(info.GetValue("_folderTypeCollectionViaFolder", GetType(EntityCollection(Of FolderTypeEntity))), EntityCollection(Of FolderTypeEntity))
				_itemCollectionViaCase2Item = CType(info.GetValue("_itemCollectionViaCase2Item", GetType(EntityCollection(Of ItemEntity))), EntityCollection(Of ItemEntity))
				_logInfoCollectionViaCase2LogInfo = CType(info.GetValue("_logInfoCollectionViaCase2LogInfo", GetType(EntityCollection(Of LogInfoEntity))), EntityCollection(Of LogInfoEntity))
				_participantCollectionViaCase = CType(info.GetValue("_participantCollectionViaCase", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase_ = CType(info.GetValue("_participantCollectionViaCase_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase__ = CType(info.GetValue("_participantCollectionViaCase__", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase___ = CType(info.GetValue("_participantCollectionViaCase___", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase____ = CType(info.GetValue("_participantCollectionViaCase____", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase_____ = CType(info.GetValue("_participantCollectionViaCase_____", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase2Participant = CType(info.GetValue("_participantCollectionViaCase2Participant", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaChangeLog = CType(info.GetValue("_participantCollectionViaChangeLog", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaChangeLog_ = CType(info.GetValue("_participantCollectionViaChangeLog_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCir = CType(info.GetValue("_participantCollectionViaCir", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCir_ = CType(info.GetValue("_participantCollectionViaCir_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaDiscussion = CType(info.GetValue("_participantCollectionViaDiscussion", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaDiscussion_ = CType(info.GetValue("_participantCollectionViaDiscussion_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaFolder = CType(info.GetValue("_participantCollectionViaFolder", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaFolder_ = CType(info.GetValue("_participantCollectionViaFolder_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaMilestone = CType(info.GetValue("_participantCollectionViaMilestone", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaNews = CType(info.GetValue("_participantCollectionViaNews", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaNews_ = CType(info.GetValue("_participantCollectionViaNews_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaPopulationlist = CType(info.GetValue("_participantCollectionViaPopulationlist", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaRc = CType(info.GetValue("_participantCollectionViaRc", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaRc_ = CType(info.GetValue("_participantCollectionViaRc_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaTimeline = CType(info.GetValue("_participantCollectionViaTimeline", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaVisits = CType(info.GetValue("_participantCollectionViaVisits", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaVisits_ = CType(info.GetValue("_participantCollectionViaVisits_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participationTypeCollectionViaCase2Participant = CType(info.GetValue("_participationTypeCollectionViaCase2Participant", GetType(EntityCollection(Of ParticipationTypeEntity))), EntityCollection(Of ParticipationTypeEntity))
				_pbuCollectionViaCase = CType(info.GetValue("_pbuCollectionViaCase", GetType(EntityCollection(Of PbuEntity))), EntityCollection(Of PbuEntity))
				_personalSafetyCollectionViaCase = CType(info.GetValue("_personalSafetyCollectionViaCase", GetType(EntityCollection(Of PersonalSafetyEntity))), EntityCollection(Of PersonalSafetyEntity))
				_phaseCollectionViaCase = CType(info.GetValue("_phaseCollectionViaCase", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_phaseCollectionViaCase2Phase = CType(info.GetValue("_phaseCollectionViaCase2Phase", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_phaseCollectionViaPopulationlist = CType(info.GetValue("_phaseCollectionViaPopulationlist", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_platformCollectionViaCase = CType(info.GetValue("_platformCollectionViaCase", GetType(EntityCollection(Of PlatformEntity))), EntityCollection(Of PlatformEntity))
				_portfolioCollectionViaCase = CType(info.GetValue("_portfolioCollectionViaCase", GetType(EntityCollection(Of PortfolioEntity))), EntityCollection(Of PortfolioEntity))
				_projectScopeCollectionViaCase = CType(info.GetValue("_projectScopeCollectionViaCase", GetType(EntityCollection(Of ProjectScopeEntity))), EntityCollection(Of ProjectScopeEntity))
				_rccomponentOwnerCollectionViaRc = CType(info.GetValue("_rccomponentOwnerCollectionViaRc", GetType(EntityCollection(Of RccomponentOwnerEntity))), EntityCollection(Of RccomponentOwnerEntity))
				_rcoriginCollectionViaRc = CType(info.GetValue("_rcoriginCollectionViaRc", GetType(EntityCollection(Of RcoriginEntity))), EntityCollection(Of RcoriginEntity))
				_rcoriginResponsibleCollectionViaRc = CType(info.GetValue("_rcoriginResponsibleCollectionViaRc", GetType(EntityCollection(Of RcoriginResponsibleEntity))), EntityCollection(Of RcoriginResponsibleEntity))
				_rcoriginUnitCollectionViaRc = CType(info.GetValue("_rcoriginUnitCollectionViaRc", GetType(EntityCollection(Of RcoriginUnitEntity))), EntityCollection(Of RcoriginUnitEntity))
				_reasonCodeCollectionViaCase2ReasonCode = CType(info.GetValue("_reasonCodeCollectionViaCase2ReasonCode", GetType(EntityCollection(Of ReasonCodeEntity))), EntityCollection(Of ReasonCodeEntity))
				_reportTypeCollectionViaCir = CType(info.GetValue("_reportTypeCollectionViaCir", GetType(EntityCollection(Of ReportTypeEntity))), EntityCollection(Of ReportTypeEntity))
				_sbuCollectionViaCase2Sbu = CType(info.GetValue("_sbuCollectionViaCase2Sbu", GetType(EntityCollection(Of SbuEntity))), EntityCollection(Of SbuEntity))
				_serviceCodeCollectionViaCase2ServiceCode = CType(info.GetValue("_serviceCodeCollectionViaCase2ServiceCode", GetType(EntityCollection(Of ServiceCodeEntity))), EntityCollection(Of ServiceCodeEntity))
				_standardTaskCollectionViaCase = CType(info.GetValue("_standardTaskCollectionViaCase", GetType(EntityCollection(Of StandardTaskEntity))), EntityCollection(Of StandardTaskEntity))
				_stateCollectionViaPopulationlist = CType(info.GetValue("_stateCollectionViaPopulationlist", GetType(EntityCollection(Of StateEntity))), EntityCollection(Of StateEntity))
				_statusCollectionViaCase = CType(info.GetValue("_statusCollectionViaCase", GetType(EntityCollection(Of StatusEntity))), EntityCollection(Of StatusEntity))
				_statusCollectionViaPopulationlist = CType(info.GetValue("_statusCollectionViaPopulationlist", GetType(EntityCollection(Of StatusEntity))), EntityCollection(Of StatusEntity))
				_supplierCollectionViaCase2Supplier = CType(info.GetValue("_supplierCollectionViaCase2Supplier", GetType(EntityCollection(Of SupplierEntity))), EntityCollection(Of SupplierEntity))
				_systemDescriptionCollectionViaCase2System = CType(info.GetValue("_systemDescriptionCollectionViaCase2System", GetType(EntityCollection(Of SystemDescriptionEntity))), EntityCollection(Of SystemDescriptionEntity))
				_turbineMatrixCollectionViaCase2TurbineUnitType = CType(info.GetValue("_turbineMatrixCollectionViaCase2TurbineUnitType", GetType(EntityCollection(Of TurbineMatrixEntity))), EntityCollection(Of TurbineMatrixEntity))
				_brand = CType(info.GetValue("_brand", GetType(BrandEntity)), BrandEntity)
				If Not _brand Is Nothing Then
					AddHandler _brand.AfterSave, AddressOf OnEntityAfterSave
				End If
				_businessProcess = CType(info.GetValue("_businessProcess", GetType(BusinessProcessEntity)), BusinessProcessEntity)
				If Not _businessProcess Is Nothing Then
					AddHandler _businessProcess.AfterSave, AddressOf OnEntityAfterSave
				End If
				_parentCase = CType(info.GetValue("_parentCase", GetType(CaseEntity)), CaseEntity)
				If Not _parentCase Is Nothing Then
					AddHandler _parentCase.AfterSave, AddressOf OnEntityAfterSave
				End If
				_category = CType(info.GetValue("_category", GetType(CategoryEntity)), CategoryEntity)
				If Not _category Is Nothing Then
					AddHandler _category.AfterSave, AddressOf OnEntityAfterSave
				End If
				_claimStatus = CType(info.GetValue("_claimStatus", GetType(ClaimStatusEntity)), ClaimStatusEntity)
				If Not _claimStatus Is Nothing Then
					AddHandler _claimStatus.AfterSave, AddressOf OnEntityAfterSave
				End If
				_component = CType(info.GetValue("_component", GetType(ComponentEntity)), ComponentEntity)
				If Not _component Is Nothing Then
					AddHandler _component.AfterSave, AddressOf OnEntityAfterSave
				End If
				_createdByParticipant = CType(info.GetValue("_createdByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _createdByParticipant Is Nothing Then
					AddHandler _createdByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_executionManagerParticipant = CType(info.GetValue("_executionManagerParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _executionManagerParticipant Is Nothing Then
					AddHandler _executionManagerParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_lastEditedByParticipant = CType(info.GetValue("_lastEditedByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _lastEditedByParticipant Is Nothing Then
					AddHandler _lastEditedByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_managerParticipant = CType(info.GetValue("_managerParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _managerParticipant Is Nothing Then
					AddHandler _managerParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant = CType(info.GetValue("_participant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant Is Nothing Then
					AddHandler _participant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_technicalSpecialistParticipant = CType(info.GetValue("_technicalSpecialistParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _technicalSpecialistParticipant Is Nothing Then
					AddHandler _technicalSpecialistParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_pbu = CType(info.GetValue("_pbu", GetType(PbuEntity)), PbuEntity)
				If Not _pbu Is Nothing Then
					AddHandler _pbu.AfterSave, AddressOf OnEntityAfterSave
				End If
				_personalSafety = CType(info.GetValue("_personalSafety", GetType(PersonalSafetyEntity)), PersonalSafetyEntity)
				If Not _personalSafety Is Nothing Then
					AddHandler _personalSafety.AfterSave, AddressOf OnEntityAfterSave
				End If
				_phase = CType(info.GetValue("_phase", GetType(PhaseEntity)), PhaseEntity)
				If Not _phase Is Nothing Then
					AddHandler _phase.AfterSave, AddressOf OnEntityAfterSave
				End If
				_platform_ = CType(info.GetValue("_platform_", GetType(PlatformEntity)), PlatformEntity)
				If Not _platform_ Is Nothing Then
					AddHandler _platform_.AfterSave, AddressOf OnEntityAfterSave
				End If
				_portfolio = CType(info.GetValue("_portfolio", GetType(PortfolioEntity)), PortfolioEntity)
				If Not _portfolio Is Nothing Then
					AddHandler _portfolio.AfterSave, AddressOf OnEntityAfterSave
				End If
				_projectScope = CType(info.GetValue("_projectScope", GetType(ProjectScopeEntity)), ProjectScopeEntity)
				If Not _projectScope Is Nothing Then
					AddHandler _projectScope.AfterSave, AddressOf OnEntityAfterSave
				End If
				_standardTask = CType(info.GetValue("_standardTask", GetType(StandardTaskEntity)), StandardTaskEntity)
				If Not _standardTask Is Nothing Then
					AddHandler _standardTask.AfterSave, AddressOf OnEntityAfterSave
				End If
				_status = CType(info.GetValue("_status", GetType(StatusEntity)), StatusEntity)
				If Not _status Is Nothing Then
					AddHandler _status.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
      ' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
      ' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, CaseFieldIndex)

				Case CaseFieldIndex.BrandId
					DesetupSyncBrand(True, False)

				Case CaseFieldIndex.PhaseId
					DesetupSyncPhase(True, False)
				Case CaseFieldIndex.StatusId
					DesetupSyncStatus(True, False)
				Case CaseFieldIndex.ClaimStatusId
					DesetupSyncClaimStatus(True, False)
				Case CaseFieldIndex.Pbuid
					DesetupSyncPbu(True, False)

				Case CaseFieldIndex.ManagerId
					DesetupSyncManagerParticipant(True, False)
				Case CaseFieldIndex.Uplink
					DesetupSyncParentCase(True, False)


				Case CaseFieldIndex.CreatedById
					DesetupSyncCreatedByParticipant(True, False)

				Case CaseFieldIndex.LastEditedById
					DesetupSyncLastEditedByParticipant(True, False)








				Case CaseFieldIndex.Platform
					DesetupSyncPlatform_(True, False)


				Case CaseFieldIndex.TechnicalSpecialistId
					DesetupSyncTechnicalSpecialistParticipant(True, False)
				Case CaseFieldIndex.ExecutionManagerId
					DesetupSyncExecutionManagerParticipant(True, False)

				Case CaseFieldIndex.PortfolioId
					DesetupSyncPortfolio(True, False)
				Case CaseFieldIndex.BusinessProcessId
					DesetupSyncBusinessProcess(True, False)
				Case CaseFieldIndex.StandardTaskId
					DesetupSyncStandardTask(True, False)


				Case CaseFieldIndex.CategoryId
					DesetupSyncCategory(True, False)
				Case CaseFieldIndex.ComponentId
					DesetupSyncComponent(True, False)
				Case CaseFieldIndex.PersonalSafetyId
					DesetupSyncPersonalSafety(True, False)





				Case CaseFieldIndex.ContainmentLeadId
					DesetupSyncParticipant(True, False)
				Case CaseFieldIndex.ProjectScopeId
					DesetupSyncProjectScope(True, False)
				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Brand"
					Me.Brand = CType(entity, BrandEntity)
				Case "BusinessProcess"
					Me.BusinessProcess = CType(entity, BusinessProcessEntity)
				Case "ParentCase"
					Me.ParentCase = CType(entity, CaseEntity)
				Case "Category"
					Me.Category = CType(entity, CategoryEntity)
				Case "ClaimStatus"
					Me.ClaimStatus = CType(entity, ClaimStatusEntity)
				Case "Component"
					Me.Component = CType(entity, ComponentEntity)
				Case "CreatedByParticipant"
					Me.CreatedByParticipant = CType(entity, ParticipantEntity)
				Case "ExecutionManagerParticipant"
					Me.ExecutionManagerParticipant = CType(entity, ParticipantEntity)
				Case "LastEditedByParticipant"
					Me.LastEditedByParticipant = CType(entity, ParticipantEntity)
				Case "ManagerParticipant"
					Me.ManagerParticipant = CType(entity, ParticipantEntity)
				Case "Participant"
					Me.Participant = CType(entity, ParticipantEntity)
				Case "TechnicalSpecialistParticipant"
					Me.TechnicalSpecialistParticipant = CType(entity, ParticipantEntity)
				Case "Pbu"
					Me.Pbu = CType(entity, PbuEntity)
				Case "PersonalSafety"
					Me.PersonalSafety = CType(entity, PersonalSafetyEntity)
				Case "Phase"
					Me.Phase = CType(entity, PhaseEntity)
				Case "Platform_"
					Me.Platform_ = CType(entity, PlatformEntity)
				Case "Portfolio"
					Me.Portfolio = CType(entity, PortfolioEntity)
				Case "ProjectScope"
					Me.ProjectScope = CType(entity, ProjectScopeEntity)
				Case "StandardTask"
					Me.StandardTask = CType(entity, StandardTaskEntity)
				Case "Status"
					Me.Status = CType(entity, StatusEntity)
				Case "ChildCase"
					Me.ChildCase.Add(CType(entity, CaseEntity))
				Case "Case2CaseBundle"
					Me.Case2CaseBundle.Add(CType(entity, Case2CaseBundleEntity))
				Case "Case2ComponentType"
					Me.Case2ComponentType.Add(CType(entity, Case2ComponentTypeEntity))
				Case "Case2Item"
					Me.Case2Item.Add(CType(entity, Case2ItemEntity))
				Case "Case2LogInfo"
					Me.Case2LogInfo.Add(CType(entity, Case2LogInfoEntity))
				Case "Case2Participant"
					Me.Case2Participant.Add(CType(entity, Case2ParticipantEntity))
				Case "Case2Phase"
					Me.Case2Phase.Add(CType(entity, Case2PhaseEntity))
				Case "Case2ReasonCode"
					Me.Case2ReasonCode.Add(CType(entity, Case2ReasonCodeEntity))
				Case "Case2Sbu"
					Me.Case2Sbu.Add(CType(entity, Case2SbuEntity))
				Case "Case2ServiceCode"
					Me.Case2ServiceCode.Add(CType(entity, Case2ServiceCodeEntity))
				Case "Case2Supplier"
					Me.Case2Supplier.Add(CType(entity, Case2SupplierEntity))
				Case "Case2System"
					Me.Case2System.Add(CType(entity, Case2SystemEntity))
				Case "Case2TurbineUnitType"
					Me.Case2TurbineUnitType.Add(CType(entity, Case2TurbineMatrixEntity))
				Case "ChangeLog"
					Me.ChangeLog.Add(CType(entity, ChangeLogEntity))
				Case "Cir"
					Me.Cir.Add(CType(entity, CirEntity))
				Case "Discussion"
					Me.Discussion.Add(CType(entity, DiscussionEntity))
				Case "Folder"
					Me.Folder.Add(CType(entity, FolderEntity))
				Case "Milestone"
					Me.Milestone.Add(CType(entity, MilestoneEntity))
				Case "News"
					Me.News.Add(CType(entity, NewsEntity))
				Case "OldCimturbine"
					Me.OldCimturbine.Add(CType(entity, OldCimturbineEntity))
				Case "Populationlist"
					Me.Populationlist.Add(CType(entity, PopulationlistEntity))
				Case "Rc"
					Me.Rc.Add(CType(entity, RcEntity))
				Case "RelatedCase"
					Me.RelatedCase.Add(CType(entity, RelatedCaseEntity))
				Case "RelatedCase_"
					Me.RelatedCase_.Add(CType(entity, RelatedCaseEntity))
				Case "Timeline"
					Me.Timeline.Add(CType(entity, TimelineEntity))
				Case "Visits"
					Me.Visits.Add(CType(entity, VisitsEntity))
				Case "BrandCollectionViaCase"
					Me.BrandCollectionViaCase.IsReadOnly = False
					Me.BrandCollectionViaCase.Add(CType(entity, BrandEntity))
					Me.BrandCollectionViaCase.IsReadOnly = True
				Case "BusinessProcessCollectionViaCase"
					Me.BusinessProcessCollectionViaCase.IsReadOnly = False
					Me.BusinessProcessCollectionViaCase.Add(CType(entity, BusinessProcessEntity))
					Me.BusinessProcessCollectionViaCase.IsReadOnly = True
				Case "Case2SupplierCollectionViaCase2ComponentType"
					Me.Case2SupplierCollectionViaCase2ComponentType.IsReadOnly = False
					Me.Case2SupplierCollectionViaCase2ComponentType.Add(CType(entity, Case2SupplierEntity))
					Me.Case2SupplierCollectionViaCase2ComponentType.IsReadOnly = True
				Case "CaseBundleCollectionViaCase2CaseBundle"
					Me.CaseBundleCollectionViaCase2CaseBundle.IsReadOnly = False
					Me.CaseBundleCollectionViaCase2CaseBundle.Add(CType(entity, CaseBundleEntity))
					Me.CaseBundleCollectionViaCase2CaseBundle.IsReadOnly = True
				Case "CategoryCollectionViaCase"
					Me.CategoryCollectionViaCase.IsReadOnly = False
					Me.CategoryCollectionViaCase.Add(CType(entity, CategoryEntity))
					Me.CategoryCollectionViaCase.IsReadOnly = True
				Case "ChangeTypeCollectionViaChangeLog"
					Me.ChangeTypeCollectionViaChangeLog.IsReadOnly = False
					Me.ChangeTypeCollectionViaChangeLog.Add(CType(entity, ChangeTypeEntity))
					Me.ChangeTypeCollectionViaChangeLog.IsReadOnly = True
				Case "ClaimStatusCollectionViaCase"
					Me.ClaimStatusCollectionViaCase.IsReadOnly = False
					Me.ClaimStatusCollectionViaCase.Add(CType(entity, ClaimStatusEntity))
					Me.ClaimStatusCollectionViaCase.IsReadOnly = True
				Case "ComponentCollectionViaCase"
					Me.ComponentCollectionViaCase.IsReadOnly = False
					Me.ComponentCollectionViaCase.Add(CType(entity, ComponentEntity))
					Me.ComponentCollectionViaCase.IsReadOnly = True
				Case "ComponentTypeCollectionViaCase2ComponentType"
					Me.ComponentTypeCollectionViaCase2ComponentType.IsReadOnly = False
					Me.ComponentTypeCollectionViaCase2ComponentType.Add(CType(entity, ComponentTypeEntity))
					Me.ComponentTypeCollectionViaCase2ComponentType.IsReadOnly = True
				Case "DiscussionCollectionViaDiscussion"
					Me.DiscussionCollectionViaDiscussion.IsReadOnly = False
					Me.DiscussionCollectionViaDiscussion.Add(CType(entity, DiscussionEntity))
					Me.DiscussionCollectionViaDiscussion.IsReadOnly = True
				Case "FolderCollectionViaFolder"
					Me.FolderCollectionViaFolder.IsReadOnly = False
					Me.FolderCollectionViaFolder.Add(CType(entity, FolderEntity))
					Me.FolderCollectionViaFolder.IsReadOnly = True
				Case "FolderTypeCollectionViaFolder"
					Me.FolderTypeCollectionViaFolder.IsReadOnly = False
					Me.FolderTypeCollectionViaFolder.Add(CType(entity, FolderTypeEntity))
					Me.FolderTypeCollectionViaFolder.IsReadOnly = True
				Case "ItemCollectionViaCase2Item"
					Me.ItemCollectionViaCase2Item.IsReadOnly = False
					Me.ItemCollectionViaCase2Item.Add(CType(entity, ItemEntity))
					Me.ItemCollectionViaCase2Item.IsReadOnly = True
				Case "LogInfoCollectionViaCase2LogInfo"
					Me.LogInfoCollectionViaCase2LogInfo.IsReadOnly = False
					Me.LogInfoCollectionViaCase2LogInfo.Add(CType(entity, LogInfoEntity))
					Me.LogInfoCollectionViaCase2LogInfo.IsReadOnly = True
				Case "ParticipantCollectionViaCase"
					Me.ParticipantCollectionViaCase.IsReadOnly = False
					Me.ParticipantCollectionViaCase.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase.IsReadOnly = True
				Case "ParticipantCollectionViaCase_"
					Me.ParticipantCollectionViaCase_.IsReadOnly = False
					Me.ParticipantCollectionViaCase_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase_.IsReadOnly = True
				Case "ParticipantCollectionViaCase__"
					Me.ParticipantCollectionViaCase__.IsReadOnly = False
					Me.ParticipantCollectionViaCase__.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase__.IsReadOnly = True
				Case "ParticipantCollectionViaCase___"
					Me.ParticipantCollectionViaCase___.IsReadOnly = False
					Me.ParticipantCollectionViaCase___.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase___.IsReadOnly = True
				Case "ParticipantCollectionViaCase____"
					Me.ParticipantCollectionViaCase____.IsReadOnly = False
					Me.ParticipantCollectionViaCase____.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase____.IsReadOnly = True
				Case "ParticipantCollectionViaCase_____"
					Me.ParticipantCollectionViaCase_____.IsReadOnly = False
					Me.ParticipantCollectionViaCase_____.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase_____.IsReadOnly = True
				Case "ParticipantCollectionViaCase2Participant"
					Me.ParticipantCollectionViaCase2Participant.IsReadOnly = False
					Me.ParticipantCollectionViaCase2Participant.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase2Participant.IsReadOnly = True
				Case "ParticipantCollectionViaChangeLog"
					Me.ParticipantCollectionViaChangeLog.IsReadOnly = False
					Me.ParticipantCollectionViaChangeLog.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaChangeLog.IsReadOnly = True
				Case "ParticipantCollectionViaChangeLog_"
					Me.ParticipantCollectionViaChangeLog_.IsReadOnly = False
					Me.ParticipantCollectionViaChangeLog_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaChangeLog_.IsReadOnly = True
				Case "ParticipantCollectionViaCir"
					Me.ParticipantCollectionViaCir.IsReadOnly = False
					Me.ParticipantCollectionViaCir.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCir.IsReadOnly = True
				Case "ParticipantCollectionViaCir_"
					Me.ParticipantCollectionViaCir_.IsReadOnly = False
					Me.ParticipantCollectionViaCir_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCir_.IsReadOnly = True
				Case "ParticipantCollectionViaDiscussion"
					Me.ParticipantCollectionViaDiscussion.IsReadOnly = False
					Me.ParticipantCollectionViaDiscussion.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaDiscussion.IsReadOnly = True
				Case "ParticipantCollectionViaDiscussion_"
					Me.ParticipantCollectionViaDiscussion_.IsReadOnly = False
					Me.ParticipantCollectionViaDiscussion_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaDiscussion_.IsReadOnly = True
				Case "ParticipantCollectionViaFolder"
					Me.ParticipantCollectionViaFolder.IsReadOnly = False
					Me.ParticipantCollectionViaFolder.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaFolder.IsReadOnly = True
				Case "ParticipantCollectionViaFolder_"
					Me.ParticipantCollectionViaFolder_.IsReadOnly = False
					Me.ParticipantCollectionViaFolder_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaFolder_.IsReadOnly = True
				Case "ParticipantCollectionViaMilestone"
					Me.ParticipantCollectionViaMilestone.IsReadOnly = False
					Me.ParticipantCollectionViaMilestone.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaMilestone.IsReadOnly = True
				Case "ParticipantCollectionViaNews"
					Me.ParticipantCollectionViaNews.IsReadOnly = False
					Me.ParticipantCollectionViaNews.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaNews.IsReadOnly = True
				Case "ParticipantCollectionViaNews_"
					Me.ParticipantCollectionViaNews_.IsReadOnly = False
					Me.ParticipantCollectionViaNews_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaNews_.IsReadOnly = True
				Case "ParticipantCollectionViaPopulationlist"
					Me.ParticipantCollectionViaPopulationlist.IsReadOnly = False
					Me.ParticipantCollectionViaPopulationlist.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaPopulationlist.IsReadOnly = True
				Case "ParticipantCollectionViaRc"
					Me.ParticipantCollectionViaRc.IsReadOnly = False
					Me.ParticipantCollectionViaRc.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaRc.IsReadOnly = True
				Case "ParticipantCollectionViaRc_"
					Me.ParticipantCollectionViaRc_.IsReadOnly = False
					Me.ParticipantCollectionViaRc_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaRc_.IsReadOnly = True
				Case "ParticipantCollectionViaTimeline"
					Me.ParticipantCollectionViaTimeline.IsReadOnly = False
					Me.ParticipantCollectionViaTimeline.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaTimeline.IsReadOnly = True
				Case "ParticipantCollectionViaVisits"
					Me.ParticipantCollectionViaVisits.IsReadOnly = False
					Me.ParticipantCollectionViaVisits.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaVisits.IsReadOnly = True
				Case "ParticipantCollectionViaVisits_"
					Me.ParticipantCollectionViaVisits_.IsReadOnly = False
					Me.ParticipantCollectionViaVisits_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaVisits_.IsReadOnly = True
				Case "ParticipationTypeCollectionViaCase2Participant"
					Me.ParticipationTypeCollectionViaCase2Participant.IsReadOnly = False
					Me.ParticipationTypeCollectionViaCase2Participant.Add(CType(entity, ParticipationTypeEntity))
					Me.ParticipationTypeCollectionViaCase2Participant.IsReadOnly = True
				Case "PbuCollectionViaCase"
					Me.PbuCollectionViaCase.IsReadOnly = False
					Me.PbuCollectionViaCase.Add(CType(entity, PbuEntity))
					Me.PbuCollectionViaCase.IsReadOnly = True
				Case "PersonalSafetyCollectionViaCase"
					Me.PersonalSafetyCollectionViaCase.IsReadOnly = False
					Me.PersonalSafetyCollectionViaCase.Add(CType(entity, PersonalSafetyEntity))
					Me.PersonalSafetyCollectionViaCase.IsReadOnly = True
				Case "PhaseCollectionViaCase"
					Me.PhaseCollectionViaCase.IsReadOnly = False
					Me.PhaseCollectionViaCase.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaCase.IsReadOnly = True
				Case "PhaseCollectionViaCase2Phase"
					Me.PhaseCollectionViaCase2Phase.IsReadOnly = False
					Me.PhaseCollectionViaCase2Phase.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaCase2Phase.IsReadOnly = True
				Case "PhaseCollectionViaPopulationlist"
					Me.PhaseCollectionViaPopulationlist.IsReadOnly = False
					Me.PhaseCollectionViaPopulationlist.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaPopulationlist.IsReadOnly = True
				Case "PlatformCollectionViaCase"
					Me.PlatformCollectionViaCase.IsReadOnly = False
					Me.PlatformCollectionViaCase.Add(CType(entity, PlatformEntity))
					Me.PlatformCollectionViaCase.IsReadOnly = True
				Case "PortfolioCollectionViaCase"
					Me.PortfolioCollectionViaCase.IsReadOnly = False
					Me.PortfolioCollectionViaCase.Add(CType(entity, PortfolioEntity))
					Me.PortfolioCollectionViaCase.IsReadOnly = True
				Case "ProjectScopeCollectionViaCase"
					Me.ProjectScopeCollectionViaCase.IsReadOnly = False
					Me.ProjectScopeCollectionViaCase.Add(CType(entity, ProjectScopeEntity))
					Me.ProjectScopeCollectionViaCase.IsReadOnly = True
				Case "RccomponentOwnerCollectionViaRc"
					Me.RccomponentOwnerCollectionViaRc.IsReadOnly = False
					Me.RccomponentOwnerCollectionViaRc.Add(CType(entity, RccomponentOwnerEntity))
					Me.RccomponentOwnerCollectionViaRc.IsReadOnly = True
				Case "RcoriginCollectionViaRc"
					Me.RcoriginCollectionViaRc.IsReadOnly = False
					Me.RcoriginCollectionViaRc.Add(CType(entity, RcoriginEntity))
					Me.RcoriginCollectionViaRc.IsReadOnly = True
				Case "RcoriginResponsibleCollectionViaRc"
					Me.RcoriginResponsibleCollectionViaRc.IsReadOnly = False
					Me.RcoriginResponsibleCollectionViaRc.Add(CType(entity, RcoriginResponsibleEntity))
					Me.RcoriginResponsibleCollectionViaRc.IsReadOnly = True
				Case "RcoriginUnitCollectionViaRc"
					Me.RcoriginUnitCollectionViaRc.IsReadOnly = False
					Me.RcoriginUnitCollectionViaRc.Add(CType(entity, RcoriginUnitEntity))
					Me.RcoriginUnitCollectionViaRc.IsReadOnly = True
				Case "ReasonCodeCollectionViaCase2ReasonCode"
					Me.ReasonCodeCollectionViaCase2ReasonCode.IsReadOnly = False
					Me.ReasonCodeCollectionViaCase2ReasonCode.Add(CType(entity, ReasonCodeEntity))
					Me.ReasonCodeCollectionViaCase2ReasonCode.IsReadOnly = True
				Case "ReportTypeCollectionViaCir"
					Me.ReportTypeCollectionViaCir.IsReadOnly = False
					Me.ReportTypeCollectionViaCir.Add(CType(entity, ReportTypeEntity))
					Me.ReportTypeCollectionViaCir.IsReadOnly = True
				Case "SbuCollectionViaCase2Sbu"
					Me.SbuCollectionViaCase2Sbu.IsReadOnly = False
					Me.SbuCollectionViaCase2Sbu.Add(CType(entity, SbuEntity))
					Me.SbuCollectionViaCase2Sbu.IsReadOnly = True
				Case "ServiceCodeCollectionViaCase2ServiceCode"
					Me.ServiceCodeCollectionViaCase2ServiceCode.IsReadOnly = False
					Me.ServiceCodeCollectionViaCase2ServiceCode.Add(CType(entity, ServiceCodeEntity))
					Me.ServiceCodeCollectionViaCase2ServiceCode.IsReadOnly = True
				Case "StandardTaskCollectionViaCase"
					Me.StandardTaskCollectionViaCase.IsReadOnly = False
					Me.StandardTaskCollectionViaCase.Add(CType(entity, StandardTaskEntity))
					Me.StandardTaskCollectionViaCase.IsReadOnly = True
				Case "StateCollectionViaPopulationlist"
					Me.StateCollectionViaPopulationlist.IsReadOnly = False
					Me.StateCollectionViaPopulationlist.Add(CType(entity, StateEntity))
					Me.StateCollectionViaPopulationlist.IsReadOnly = True
				Case "StatusCollectionViaCase"
					Me.StatusCollectionViaCase.IsReadOnly = False
					Me.StatusCollectionViaCase.Add(CType(entity, StatusEntity))
					Me.StatusCollectionViaCase.IsReadOnly = True
				Case "StatusCollectionViaPopulationlist"
					Me.StatusCollectionViaPopulationlist.IsReadOnly = False
					Me.StatusCollectionViaPopulationlist.Add(CType(entity, StatusEntity))
					Me.StatusCollectionViaPopulationlist.IsReadOnly = True
				Case "SupplierCollectionViaCase2Supplier"
					Me.SupplierCollectionViaCase2Supplier.IsReadOnly = False
					Me.SupplierCollectionViaCase2Supplier.Add(CType(entity, SupplierEntity))
					Me.SupplierCollectionViaCase2Supplier.IsReadOnly = True
				Case "SystemDescriptionCollectionViaCase2System"
					Me.SystemDescriptionCollectionViaCase2System.IsReadOnly = False
					Me.SystemDescriptionCollectionViaCase2System.Add(CType(entity, SystemDescriptionEntity))
					Me.SystemDescriptionCollectionViaCase2System.IsReadOnly = True
				Case "TurbineMatrixCollectionViaCase2TurbineUnitType"
					Me.TurbineMatrixCollectionViaCase2TurbineUnitType.IsReadOnly = False
					Me.TurbineMatrixCollectionViaCase2TurbineUnitType.Add(CType(entity, TurbineMatrixEntity))
					Me.TurbineMatrixCollectionViaCase2TurbineUnitType.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return CaseEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Brand"
					toReturn.Add(CaseEntity.Relations.BrandEntityUsingBrandId)
				Case "BusinessProcess"
					toReturn.Add(CaseEntity.Relations.BusinessProcessEntityUsingBusinessProcessId)
				Case "ParentCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingCaseIdUplink)
				Case "Category"
					toReturn.Add(CaseEntity.Relations.CategoryEntityUsingCategoryId)
				Case "ClaimStatus"
					toReturn.Add(CaseEntity.Relations.ClaimStatusEntityUsingClaimStatusId)
				Case "Component"
					toReturn.Add(CaseEntity.Relations.ComponentEntityUsingComponentId)
				Case "CreatedByParticipant"
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingCreatedById)
				Case "ExecutionManagerParticipant"
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingExecutionManagerId)
				Case "LastEditedByParticipant"
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingLastEditedById)
				Case "ManagerParticipant"
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingManagerId)
				Case "Participant"
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingContainmentLeadId)
				Case "TechnicalSpecialistParticipant"
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingTechnicalSpecialistId)
				Case "Pbu"
					toReturn.Add(CaseEntity.Relations.PbuEntityUsingPbuid)
				Case "PersonalSafety"
					toReturn.Add(CaseEntity.Relations.PersonalSafetyEntityUsingPersonalSafetyId)
				Case "Phase"
					toReturn.Add(CaseEntity.Relations.PhaseEntityUsingPhaseId)
				Case "Platform_"
					toReturn.Add(CaseEntity.Relations.PlatformEntityUsingPlatform)
				Case "Portfolio"
					toReturn.Add(CaseEntity.Relations.PortfolioEntityUsingPortfolioId)
				Case "ProjectScope"
					toReturn.Add(CaseEntity.Relations.ProjectScopeEntityUsingProjectScopeId)
				Case "StandardTask"
					toReturn.Add(CaseEntity.Relations.StandardTaskEntityUsingStandardTaskId)
				Case "Status"
					toReturn.Add(CaseEntity.Relations.StatusEntityUsingStatusId)
				Case "ChildCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink)
				Case "Case2CaseBundle"
					toReturn.Add(CaseEntity.Relations.Case2CaseBundleEntityUsingCaseId)
				Case "Case2ComponentType"
					toReturn.Add(CaseEntity.Relations.Case2ComponentTypeEntityUsingCaseId)
				Case "Case2Item"
					toReturn.Add(CaseEntity.Relations.Case2ItemEntityUsingCaseId)
				Case "Case2LogInfo"
					toReturn.Add(CaseEntity.Relations.Case2LogInfoEntityUsingCaseId)
				Case "Case2Participant"
					toReturn.Add(CaseEntity.Relations.Case2ParticipantEntityUsingCaseId)
				Case "Case2Phase"
					toReturn.Add(CaseEntity.Relations.Case2PhaseEntityUsingCaseId)
				Case "Case2ReasonCode"
					toReturn.Add(CaseEntity.Relations.Case2ReasonCodeEntityUsingCaseId)
				Case "Case2Sbu"
					toReturn.Add(CaseEntity.Relations.Case2SbuEntityUsingCaseId)
				Case "Case2ServiceCode"
					toReturn.Add(CaseEntity.Relations.Case2ServiceCodeEntityUsingCaseId)
				Case "Case2Supplier"
					toReturn.Add(CaseEntity.Relations.Case2SupplierEntityUsingCaseId)
				Case "Case2System"
					toReturn.Add(CaseEntity.Relations.Case2SystemEntityUsingCaseId)
				Case "Case2TurbineUnitType"
					toReturn.Add(CaseEntity.Relations.Case2TurbineMatrixEntityUsingCaseId)
				Case "ChangeLog"
					toReturn.Add(CaseEntity.Relations.ChangeLogEntityUsingCaseId)
				Case "Cir"
					toReturn.Add(CaseEntity.Relations.CirEntityUsingCaseId)
				Case "Discussion"
					toReturn.Add(CaseEntity.Relations.DiscussionEntityUsingCaseId)
				Case "Folder"
					toReturn.Add(CaseEntity.Relations.FolderEntityUsingCaseId)
				Case "Milestone"
					toReturn.Add(CaseEntity.Relations.MilestoneEntityUsingCaseId)
				Case "News"
					toReturn.Add(CaseEntity.Relations.NewsEntityUsingCaseId)
				Case "OldCimturbine"
					toReturn.Add(CaseEntity.Relations.OldCimturbineEntityUsingCaseId)
				Case "Populationlist"
					toReturn.Add(CaseEntity.Relations.PopulationlistEntityUsingCaseId)
				Case "Rc"
					toReturn.Add(CaseEntity.Relations.RcEntityUsingCaseId)
				Case "RelatedCase"
					toReturn.Add(CaseEntity.Relations.RelatedCaseEntityUsingCaseId)
				Case "RelatedCase_"
					toReturn.Add(CaseEntity.Relations.RelatedCaseEntityUsingCaseIdRelated)
				Case "Timeline"
					toReturn.Add(CaseEntity.Relations.TimelineEntityUsingCaseId)
				Case "Visits"
					toReturn.Add(CaseEntity.Relations.VisitsEntityUsingCaseId)
				Case "BrandCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.BrandEntityUsingBrandId, "Case_", String.Empty, JoinHint.None)
				Case "BusinessProcessCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.BusinessProcessEntityUsingBusinessProcessId, "Case_", String.Empty, JoinHint.None)
				Case "Case2SupplierCollectionViaCase2ComponentType"
					toReturn.Add(CaseEntity.Relations.Case2ComponentTypeEntityUsingCaseId, "CaseEntity__", "Case2ComponentType_", JoinHint.None)
					toReturn.Add(Case2ComponentTypeEntity.Relations.Case2SupplierEntityUsingSupplierLink, "Case2ComponentType_", String.Empty, JoinHint.None)
				Case "CaseBundleCollectionViaCase2CaseBundle"
					toReturn.Add(CaseEntity.Relations.Case2CaseBundleEntityUsingCaseId, "CaseEntity__", "Case2CaseBundle_", JoinHint.None)
					toReturn.Add(Case2CaseBundleEntity.Relations.CaseBundleEntityUsingCaseBundleId, "Case2CaseBundle_", String.Empty, JoinHint.None)
				Case "CategoryCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.CategoryEntityUsingCategoryId, "Case_", String.Empty, JoinHint.None)
				Case "ChangeTypeCollectionViaChangeLog"
					toReturn.Add(CaseEntity.Relations.ChangeLogEntityUsingCaseId, "CaseEntity__", "ChangeLog_", JoinHint.None)
					toReturn.Add(ChangeLogEntity.Relations.ChangeTypeEntityUsingChangeTypeId, "ChangeLog_", String.Empty, JoinHint.None)
				Case "ClaimStatusCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ClaimStatusEntityUsingClaimStatusId, "Case_", String.Empty, JoinHint.None)
				Case "ComponentCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ComponentEntityUsingComponentId, "Case_", String.Empty, JoinHint.None)
				Case "ComponentTypeCollectionViaCase2ComponentType"
					toReturn.Add(CaseEntity.Relations.Case2ComponentTypeEntityUsingCaseId, "CaseEntity__", "Case2ComponentType_", JoinHint.None)
					toReturn.Add(Case2ComponentTypeEntity.Relations.ComponentTypeEntityUsingComponentTypeId, "Case2ComponentType_", String.Empty, JoinHint.None)
				Case "DiscussionCollectionViaDiscussion"
					toReturn.Add(CaseEntity.Relations.DiscussionEntityUsingCaseId, "CaseEntity__", "Discussion_", JoinHint.None)
					toReturn.Add(DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId, "Discussion_", String.Empty, JoinHint.None)
				Case "FolderCollectionViaFolder"
					toReturn.Add(CaseEntity.Relations.FolderEntityUsingCaseId, "CaseEntity__", "Folder_", JoinHint.None)
					toReturn.Add(FolderEntity.Relations.FolderEntityUsingParentFolderId, "Folder_", String.Empty, JoinHint.None)
				Case "FolderTypeCollectionViaFolder"
					toReturn.Add(CaseEntity.Relations.FolderEntityUsingCaseId, "CaseEntity__", "Folder_", JoinHint.None)
					toReturn.Add(FolderEntity.Relations.FolderTypeEntityUsingFolderTypeId, "Folder_", String.Empty, JoinHint.None)
				Case "ItemCollectionViaCase2Item"
					toReturn.Add(CaseEntity.Relations.Case2ItemEntityUsingCaseId, "CaseEntity__", "Case2Item_", JoinHint.None)
					toReturn.Add(Case2ItemEntity.Relations.ItemEntityUsingItemId, "Case2Item_", String.Empty, JoinHint.None)
				Case "LogInfoCollectionViaCase2LogInfo"
					toReturn.Add(CaseEntity.Relations.Case2LogInfoEntityUsingCaseId, "CaseEntity__", "Case2LogInfo_", JoinHint.None)
					toReturn.Add(Case2LogInfoEntity.Relations.LogInfoEntityUsingLogInfoId, "Case2LogInfo_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingManagerId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase_"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingCreatedById, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase__"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingLastEditedById, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase___"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingTechnicalSpecialistId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase____"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingExecutionManagerId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase_____"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingContainmentLeadId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase2Participant"
					toReturn.Add(CaseEntity.Relations.Case2ParticipantEntityUsingCaseId, "CaseEntity__", "Case2Participant_", JoinHint.None)
					toReturn.Add(Case2ParticipantEntity.Relations.ParticipantEntityUsingParticipantId, "Case2Participant_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaChangeLog"
					toReturn.Add(CaseEntity.Relations.ChangeLogEntityUsingCaseId, "CaseEntity__", "ChangeLog_", JoinHint.None)
					toReturn.Add(ChangeLogEntity.Relations.ParticipantEntityUsingCreatedById, "ChangeLog_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaChangeLog_"
					toReturn.Add(CaseEntity.Relations.ChangeLogEntityUsingCaseId, "CaseEntity__", "ChangeLog_", JoinHint.None)
					toReturn.Add(ChangeLogEntity.Relations.ParticipantEntityUsingDeletedById, "ChangeLog_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCir"
					toReturn.Add(CaseEntity.Relations.CirEntityUsingCaseId, "CaseEntity__", "Cir_", JoinHint.None)
					toReturn.Add(CirEntity.Relations.ParticipantEntityUsingVerifiedBy, "Cir_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCir_"
					toReturn.Add(CaseEntity.Relations.CirEntityUsingCaseId, "CaseEntity__", "Cir_", JoinHint.None)
					toReturn.Add(CirEntity.Relations.ParticipantEntityUsingRejectedBy, "Cir_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaDiscussion"
					toReturn.Add(CaseEntity.Relations.DiscussionEntityUsingCaseId, "CaseEntity__", "Discussion_", JoinHint.None)
					toReturn.Add(DiscussionEntity.Relations.ParticipantEntityUsingModifiedById, "Discussion_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaDiscussion_"
					toReturn.Add(CaseEntity.Relations.DiscussionEntityUsingCaseId, "CaseEntity__", "Discussion_", JoinHint.None)
					toReturn.Add(DiscussionEntity.Relations.ParticipantEntityUsingCreatedById, "Discussion_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaFolder"
					toReturn.Add(CaseEntity.Relations.FolderEntityUsingCaseId, "CaseEntity__", "Folder_", JoinHint.None)
					toReturn.Add(FolderEntity.Relations.ParticipantEntityUsingLockedBy, "Folder_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaFolder_"
					toReturn.Add(CaseEntity.Relations.FolderEntityUsingCaseId, "CaseEntity__", "Folder_", JoinHint.None)
					toReturn.Add(FolderEntity.Relations.ParticipantEntityUsingCreatedBy, "Folder_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaMilestone"
					toReturn.Add(CaseEntity.Relations.MilestoneEntityUsingCaseId, "CaseEntity__", "Milestone_", JoinHint.None)
					toReturn.Add(MilestoneEntity.Relations.ParticipantEntityUsingResponsiblePersonId, "Milestone_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaNews"
					toReturn.Add(CaseEntity.Relations.NewsEntityUsingCaseId, "CaseEntity__", "News_", JoinHint.None)
					toReturn.Add(NewsEntity.Relations.ParticipantEntityUsingCreatedbyId, "News_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaNews_"
					toReturn.Add(CaseEntity.Relations.NewsEntityUsingCaseId, "CaseEntity__", "News_", JoinHint.None)
					toReturn.Add(NewsEntity.Relations.ParticipantEntityUsingModifiedById, "News_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaPopulationlist"
					toReturn.Add(CaseEntity.Relations.PopulationlistEntityUsingCaseId, "CaseEntity__", "Populationlist_", JoinHint.None)
					toReturn.Add(PopulationlistEntity.Relations.ParticipantEntityUsingCreatedById, "Populationlist_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaRc"
					toReturn.Add(CaseEntity.Relations.RcEntityUsingCaseId, "CaseEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.ParticipantEntityUsingCreatedById, "Rc_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaRc_"
					toReturn.Add(CaseEntity.Relations.RcEntityUsingCaseId, "CaseEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.ParticipantEntityUsingDeletedById, "Rc_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaTimeline"
					toReturn.Add(CaseEntity.Relations.TimelineEntityUsingCaseId, "CaseEntity__", "Timeline_", JoinHint.None)
					toReturn.Add(TimelineEntity.Relations.ParticipantEntityUsingChangedBy, "Timeline_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaVisits"
					toReturn.Add(CaseEntity.Relations.VisitsEntityUsingCaseId, "CaseEntity__", "Visits_", JoinHint.None)
					toReturn.Add(VisitsEntity.Relations.ParticipantEntityUsingCreatedById, "Visits_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaVisits_"
					toReturn.Add(CaseEntity.Relations.VisitsEntityUsingCaseId, "CaseEntity__", "Visits_", JoinHint.None)
					toReturn.Add(VisitsEntity.Relations.ParticipantEntityUsingDeletedById, "Visits_", String.Empty, JoinHint.None)
				Case "ParticipationTypeCollectionViaCase2Participant"
					toReturn.Add(CaseEntity.Relations.Case2ParticipantEntityUsingCaseId, "CaseEntity__", "Case2Participant_", JoinHint.None)
					toReturn.Add(Case2ParticipantEntity.Relations.ParticipationTypeEntityUsingParticipationTypeId, "Case2Participant_", String.Empty, JoinHint.None)
				Case "PbuCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PbuEntityUsingPbuid, "Case_", String.Empty, JoinHint.None)
				Case "PersonalSafetyCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PersonalSafetyEntityUsingPersonalSafetyId, "Case_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PhaseEntityUsingPhaseId, "Case_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaCase2Phase"
					toReturn.Add(CaseEntity.Relations.Case2PhaseEntityUsingCaseId, "CaseEntity__", "Case2Phase_", JoinHint.None)
					toReturn.Add(Case2PhaseEntity.Relations.PhaseEntityUsingPhaseId, "Case2Phase_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaPopulationlist"
					toReturn.Add(CaseEntity.Relations.PopulationlistEntityUsingCaseId, "CaseEntity__", "Populationlist_", JoinHint.None)
					toReturn.Add(PopulationlistEntity.Relations.PhaseEntityUsingPhaseId, "Populationlist_", String.Empty, JoinHint.None)
				Case "PlatformCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PlatformEntityUsingPlatform, "Case_", String.Empty, JoinHint.None)
				Case "PortfolioCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PortfolioEntityUsingPortfolioId, "Case_", String.Empty, JoinHint.None)
				Case "ProjectScopeCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ProjectScopeEntityUsingProjectScopeId, "Case_", String.Empty, JoinHint.None)
				Case "RccomponentOwnerCollectionViaRc"
					toReturn.Add(CaseEntity.Relations.RcEntityUsingCaseId, "CaseEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.RccomponentOwnerEntityUsingRccomponentOwnerId, "Rc_", String.Empty, JoinHint.None)
				Case "RcoriginCollectionViaRc"
					toReturn.Add(CaseEntity.Relations.RcEntityUsingCaseId, "CaseEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.RcoriginEntityUsingRcoriginId, "Rc_", String.Empty, JoinHint.None)
				Case "RcoriginResponsibleCollectionViaRc"
					toReturn.Add(CaseEntity.Relations.RcEntityUsingCaseId, "CaseEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.RcoriginResponsibleEntityUsingRcoriginResponsibleId, "Rc_", String.Empty, JoinHint.None)
				Case "RcoriginUnitCollectionViaRc"
					toReturn.Add(CaseEntity.Relations.RcEntityUsingCaseId, "CaseEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.RcoriginUnitEntityUsingRcoriginUnitId, "Rc_", String.Empty, JoinHint.None)
				Case "ReasonCodeCollectionViaCase2ReasonCode"
					toReturn.Add(CaseEntity.Relations.Case2ReasonCodeEntityUsingCaseId, "CaseEntity__", "Case2ReasonCode_", JoinHint.None)
					toReturn.Add(Case2ReasonCodeEntity.Relations.ReasonCodeEntityUsingReasonCodeId, "Case2ReasonCode_", String.Empty, JoinHint.None)
				Case "ReportTypeCollectionViaCir"
					toReturn.Add(CaseEntity.Relations.CirEntityUsingCaseId, "CaseEntity__", "Cir_", JoinHint.None)
					toReturn.Add(CirEntity.Relations.ReportTypeEntityUsingReportTypeId, "Cir_", String.Empty, JoinHint.None)
				Case "SbuCollectionViaCase2Sbu"
					toReturn.Add(CaseEntity.Relations.Case2SbuEntityUsingCaseId, "CaseEntity__", "Case2Sbu_", JoinHint.None)
					toReturn.Add(Case2SbuEntity.Relations.SbuEntityUsingSbuid, "Case2Sbu_", String.Empty, JoinHint.None)
				Case "ServiceCodeCollectionViaCase2ServiceCode"
					toReturn.Add(CaseEntity.Relations.Case2ServiceCodeEntityUsingCaseId, "CaseEntity__", "Case2ServiceCode_", JoinHint.None)
					toReturn.Add(Case2ServiceCodeEntity.Relations.ServiceCodeEntityUsingServiceCodeId, "Case2ServiceCode_", String.Empty, JoinHint.None)
				Case "StandardTaskCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.StandardTaskEntityUsingStandardTaskId, "Case_", String.Empty, JoinHint.None)
				Case "StateCollectionViaPopulationlist"
					toReturn.Add(CaseEntity.Relations.PopulationlistEntityUsingCaseId, "CaseEntity__", "Populationlist_", JoinHint.None)
					toReturn.Add(PopulationlistEntity.Relations.StateEntityUsingStateId, "Populationlist_", String.Empty, JoinHint.None)
				Case "StatusCollectionViaCase"
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "CaseEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.StatusEntityUsingStatusId, "Case_", String.Empty, JoinHint.None)
				Case "StatusCollectionViaPopulationlist"
					toReturn.Add(CaseEntity.Relations.PopulationlistEntityUsingCaseId, "CaseEntity__", "Populationlist_", JoinHint.None)
					toReturn.Add(PopulationlistEntity.Relations.StatusEntityUsingStatusId, "Populationlist_", String.Empty, JoinHint.None)
				Case "SupplierCollectionViaCase2Supplier"
					toReturn.Add(CaseEntity.Relations.Case2SupplierEntityUsingCaseId, "CaseEntity__", "Case2Supplier_", JoinHint.None)
					toReturn.Add(Case2SupplierEntity.Relations.SupplierEntityUsingSupplierId, "Case2Supplier_", String.Empty, JoinHint.None)
				Case "SystemDescriptionCollectionViaCase2System"
					toReturn.Add(CaseEntity.Relations.Case2SystemEntityUsingCaseId, "CaseEntity__", "Case2System_", JoinHint.None)
					toReturn.Add(Case2SystemEntity.Relations.SystemDescriptionEntityUsingSystem, "Case2System_", String.Empty, JoinHint.None)
				Case "TurbineMatrixCollectionViaCase2TurbineUnitType"
					toReturn.Add(CaseEntity.Relations.Case2TurbineMatrixEntityUsingCaseId, "CaseEntity__", "Case2TurbineMatrix_", JoinHint.None)
					toReturn.Add(Case2TurbineMatrixEntity.Relations.TurbineMatrixEntityUsingTurbineMatrixId, "Case2TurbineMatrix_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Brand"
					SetupSyncBrand(relatedEntity)
				Case "BusinessProcess"
					SetupSyncBusinessProcess(relatedEntity)
				Case "ParentCase"
					SetupSyncParentCase(relatedEntity)
				Case "Category"
					SetupSyncCategory(relatedEntity)
				Case "ClaimStatus"
					SetupSyncClaimStatus(relatedEntity)
				Case "Component"
					SetupSyncComponent(relatedEntity)
				Case "CreatedByParticipant"
					SetupSyncCreatedByParticipant(relatedEntity)
				Case "ExecutionManagerParticipant"
					SetupSyncExecutionManagerParticipant(relatedEntity)
				Case "LastEditedByParticipant"
					SetupSyncLastEditedByParticipant(relatedEntity)
				Case "ManagerParticipant"
					SetupSyncManagerParticipant(relatedEntity)
				Case "Participant"
					SetupSyncParticipant(relatedEntity)
				Case "TechnicalSpecialistParticipant"
					SetupSyncTechnicalSpecialistParticipant(relatedEntity)
				Case "Pbu"
					SetupSyncPbu(relatedEntity)
				Case "PersonalSafety"
					SetupSyncPersonalSafety(relatedEntity)
				Case "Phase"
					SetupSyncPhase(relatedEntity)
				Case "Platform_"
					SetupSyncPlatform_(relatedEntity)
				Case "Portfolio"
					SetupSyncPortfolio(relatedEntity)
				Case "ProjectScope"
					SetupSyncProjectScope(relatedEntity)
				Case "StandardTask"
					SetupSyncStandardTask(relatedEntity)
				Case "Status"
					SetupSyncStatus(relatedEntity)
				Case "ChildCase"
					Me.ChildCase.Add(CType(relatedEntity, CaseEntity))
				Case "Case2CaseBundle"
					Me.Case2CaseBundle.Add(CType(relatedEntity, Case2CaseBundleEntity))
				Case "Case2ComponentType"
					Me.Case2ComponentType.Add(CType(relatedEntity, Case2ComponentTypeEntity))
				Case "Case2Item"
					Me.Case2Item.Add(CType(relatedEntity, Case2ItemEntity))
				Case "Case2LogInfo"
					Me.Case2LogInfo.Add(CType(relatedEntity, Case2LogInfoEntity))
				Case "Case2Participant"
					Me.Case2Participant.Add(CType(relatedEntity, Case2ParticipantEntity))
				Case "Case2Phase"
					Me.Case2Phase.Add(CType(relatedEntity, Case2PhaseEntity))
				Case "Case2ReasonCode"
					Me.Case2ReasonCode.Add(CType(relatedEntity, Case2ReasonCodeEntity))
				Case "Case2Sbu"
					Me.Case2Sbu.Add(CType(relatedEntity, Case2SbuEntity))
				Case "Case2ServiceCode"
					Me.Case2ServiceCode.Add(CType(relatedEntity, Case2ServiceCodeEntity))
				Case "Case2Supplier"
					Me.Case2Supplier.Add(CType(relatedEntity, Case2SupplierEntity))
				Case "Case2System"
					Me.Case2System.Add(CType(relatedEntity, Case2SystemEntity))
				Case "Case2TurbineUnitType"
					Me.Case2TurbineUnitType.Add(CType(relatedEntity, Case2TurbineMatrixEntity))
				Case "ChangeLog"
					Me.ChangeLog.Add(CType(relatedEntity, ChangeLogEntity))
				Case "Cir"
					Me.Cir.Add(CType(relatedEntity, CirEntity))
				Case "Discussion"
					Me.Discussion.Add(CType(relatedEntity, DiscussionEntity))
				Case "Folder"
					Me.Folder.Add(CType(relatedEntity, FolderEntity))
				Case "Milestone"
					Me.Milestone.Add(CType(relatedEntity, MilestoneEntity))
				Case "News"
					Me.News.Add(CType(relatedEntity, NewsEntity))
				Case "OldCimturbine"
					Me.OldCimturbine.Add(CType(relatedEntity, OldCimturbineEntity))
				Case "Populationlist"
					Me.Populationlist.Add(CType(relatedEntity, PopulationlistEntity))
				Case "Rc"
					Me.Rc.Add(CType(relatedEntity, RcEntity))
				Case "RelatedCase"
					Me.RelatedCase.Add(CType(relatedEntity, RelatedCaseEntity))
				Case "RelatedCase_"
					Me.RelatedCase_.Add(CType(relatedEntity, RelatedCaseEntity))
				Case "Timeline"
					Me.Timeline.Add(CType(relatedEntity, TimelineEntity))
				Case "Visits"
					Me.Visits.Add(CType(relatedEntity, VisitsEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Brand"
					DesetupSyncBrand(False, True)
				Case "BusinessProcess"
					DesetupSyncBusinessProcess(False, True)
				Case "ParentCase"
					DesetupSyncParentCase(False, True)
				Case "Category"
					DesetupSyncCategory(False, True)
				Case "ClaimStatus"
					DesetupSyncClaimStatus(False, True)
				Case "Component"
					DesetupSyncComponent(False, True)
				Case "CreatedByParticipant"
					DesetupSyncCreatedByParticipant(False, True)
				Case "ExecutionManagerParticipant"
					DesetupSyncExecutionManagerParticipant(False, True)
				Case "LastEditedByParticipant"
					DesetupSyncLastEditedByParticipant(False, True)
				Case "ManagerParticipant"
					DesetupSyncManagerParticipant(False, True)
				Case "Participant"
					DesetupSyncParticipant(False, True)
				Case "TechnicalSpecialistParticipant"
					DesetupSyncTechnicalSpecialistParticipant(False, True)
				Case "Pbu"
					DesetupSyncPbu(False, True)
				Case "PersonalSafety"
					DesetupSyncPersonalSafety(False, True)
				Case "Phase"
					DesetupSyncPhase(False, True)
				Case "Platform_"
					DesetupSyncPlatform_(False, True)
				Case "Portfolio"
					DesetupSyncPortfolio(False, True)
				Case "ProjectScope"
					DesetupSyncProjectScope(False, True)
				Case "StandardTask"
					DesetupSyncStandardTask(False, True)
				Case "Status"
					DesetupSyncStatus(False, True)
				Case "ChildCase"
					Me.PerformRelatedEntityRemoval(Me.ChildCase, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2CaseBundle"
					Me.PerformRelatedEntityRemoval(Me.Case2CaseBundle, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2ComponentType"
					Me.PerformRelatedEntityRemoval(Me.Case2ComponentType, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2Item"
					Me.PerformRelatedEntityRemoval(Me.Case2Item, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2LogInfo"
					Me.PerformRelatedEntityRemoval(Me.Case2LogInfo, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2Participant"
					Me.PerformRelatedEntityRemoval(Me.Case2Participant, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2Phase"
					Me.PerformRelatedEntityRemoval(Me.Case2Phase, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2ReasonCode"
					Me.PerformRelatedEntityRemoval(Me.Case2ReasonCode, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2Sbu"
					Me.PerformRelatedEntityRemoval(Me.Case2Sbu, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2ServiceCode"
					Me.PerformRelatedEntityRemoval(Me.Case2ServiceCode, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2Supplier"
					Me.PerformRelatedEntityRemoval(Me.Case2Supplier, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2System"
					Me.PerformRelatedEntityRemoval(Me.Case2System, relatedEntity, signalRelatedEntityManyToOne)
				Case "Case2TurbineUnitType"
					Me.PerformRelatedEntityRemoval(Me.Case2TurbineUnitType, relatedEntity, signalRelatedEntityManyToOne)
				Case "ChangeLog"
					Me.PerformRelatedEntityRemoval(Me.ChangeLog, relatedEntity, signalRelatedEntityManyToOne)
				Case "Cir"
					Me.PerformRelatedEntityRemoval(Me.Cir, relatedEntity, signalRelatedEntityManyToOne)
				Case "Discussion"
					Me.PerformRelatedEntityRemoval(Me.Discussion, relatedEntity, signalRelatedEntityManyToOne)
				Case "Folder"
					Me.PerformRelatedEntityRemoval(Me.Folder, relatedEntity, signalRelatedEntityManyToOne)
				Case "Milestone"
					Me.PerformRelatedEntityRemoval(Me.Milestone, relatedEntity, signalRelatedEntityManyToOne)
				Case "News"
					Me.PerformRelatedEntityRemoval(Me.News, relatedEntity, signalRelatedEntityManyToOne)
				Case "OldCimturbine"
					Me.PerformRelatedEntityRemoval(Me.OldCimturbine, relatedEntity, signalRelatedEntityManyToOne)
				Case "Populationlist"
					Me.PerformRelatedEntityRemoval(Me.Populationlist, relatedEntity, signalRelatedEntityManyToOne)
				Case "Rc"
					Me.PerformRelatedEntityRemoval(Me.Rc, relatedEntity, signalRelatedEntityManyToOne)
				Case "RelatedCase"
					Me.PerformRelatedEntityRemoval(Me.RelatedCase, relatedEntity, signalRelatedEntityManyToOne)
				Case "RelatedCase_"
					Me.PerformRelatedEntityRemoval(Me.RelatedCase_, relatedEntity, signalRelatedEntityManyToOne)
				Case "Timeline"
					Me.PerformRelatedEntityRemoval(Me.Timeline, relatedEntity, signalRelatedEntityManyToOne)
				Case "Visits"
					Me.PerformRelatedEntityRemoval(Me.Visits, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _brand Is Nothing Then
				toReturn.Add(_brand)
			End If
			If Not _businessProcess Is Nothing Then
				toReturn.Add(_businessProcess)
			End If
			If Not _parentCase Is Nothing Then
				toReturn.Add(_parentCase)
			End If
			If Not _category Is Nothing Then
				toReturn.Add(_category)
			End If
			If Not _claimStatus Is Nothing Then
				toReturn.Add(_claimStatus)
			End If
			If Not _component Is Nothing Then
				toReturn.Add(_component)
			End If
			If Not _createdByParticipant Is Nothing Then
				toReturn.Add(_createdByParticipant)
			End If
			If Not _executionManagerParticipant Is Nothing Then
				toReturn.Add(_executionManagerParticipant)
			End If
			If Not _lastEditedByParticipant Is Nothing Then
				toReturn.Add(_lastEditedByParticipant)
			End If
			If Not _managerParticipant Is Nothing Then
				toReturn.Add(_managerParticipant)
			End If
			If Not _participant Is Nothing Then
				toReturn.Add(_participant)
			End If
			If Not _technicalSpecialistParticipant Is Nothing Then
				toReturn.Add(_technicalSpecialistParticipant)
			End If
			If Not _pbu Is Nothing Then
				toReturn.Add(_pbu)
			End If
			If Not _personalSafety Is Nothing Then
				toReturn.Add(_personalSafety)
			End If
			If Not _phase Is Nothing Then
				toReturn.Add(_phase)
			End If
			If Not _platform_ Is Nothing Then
				toReturn.Add(_platform_)
			End If
			If Not _portfolio Is Nothing Then
				toReturn.Add(_portfolio)
			End If
			If Not _projectScope Is Nothing Then
				toReturn.Add(_projectScope)
			End If
			If Not _standardTask Is Nothing Then
				toReturn.Add(_standardTask)
			End If
			If Not _status Is Nothing Then
				toReturn.Add(_status)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.ChildCase)
			toReturn.Add(Me.Case2CaseBundle)
			toReturn.Add(Me.Case2ComponentType)
			toReturn.Add(Me.Case2Item)
			toReturn.Add(Me.Case2LogInfo)
			toReturn.Add(Me.Case2Participant)
			toReturn.Add(Me.Case2Phase)
			toReturn.Add(Me.Case2ReasonCode)
			toReturn.Add(Me.Case2Sbu)
			toReturn.Add(Me.Case2ServiceCode)
			toReturn.Add(Me.Case2Supplier)
			toReturn.Add(Me.Case2System)
			toReturn.Add(Me.Case2TurbineUnitType)
			toReturn.Add(Me.ChangeLog)
			toReturn.Add(Me.Cir)
			toReturn.Add(Me.Discussion)
			toReturn.Add(Me.Folder)
			toReturn.Add(Me.Milestone)
			toReturn.Add(Me.News)
			toReturn.Add(Me.OldCimturbine)
			toReturn.Add(Me.Populationlist)
			toReturn.Add(Me.Rc)
			toReturn.Add(Me.RelatedCase)
			toReturn.Add(Me.RelatedCase_)
			toReturn.Add(Me.Timeline)
			toReturn.Add(Me.Visits)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_childCase Is Nothing)) AndAlso (_childCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _childCase 
				End If
				info.AddValue("_childCase", value)
				value = Nothing 
				If (Not (_case2CaseBundle Is Nothing)) AndAlso (_case2CaseBundle.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2CaseBundle 
				End If
				info.AddValue("_case2CaseBundle", value)
				value = Nothing 
				If (Not (_case2ComponentType Is Nothing)) AndAlso (_case2ComponentType.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2ComponentType 
				End If
				info.AddValue("_case2ComponentType", value)
				value = Nothing 
				If (Not (_case2Item Is Nothing)) AndAlso (_case2Item.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2Item 
				End If
				info.AddValue("_case2Item", value)
				value = Nothing 
				If (Not (_case2LogInfo Is Nothing)) AndAlso (_case2LogInfo.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2LogInfo 
				End If
				info.AddValue("_case2LogInfo", value)
				value = Nothing 
				If (Not (_case2Participant Is Nothing)) AndAlso (_case2Participant.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2Participant 
				End If
				info.AddValue("_case2Participant", value)
				value = Nothing 
				If (Not (_case2Phase Is Nothing)) AndAlso (_case2Phase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2Phase 
				End If
				info.AddValue("_case2Phase", value)
				value = Nothing 
				If (Not (_case2ReasonCode Is Nothing)) AndAlso (_case2ReasonCode.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2ReasonCode 
				End If
				info.AddValue("_case2ReasonCode", value)
				value = Nothing 
				If (Not (_case2Sbu Is Nothing)) AndAlso (_case2Sbu.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2Sbu 
				End If
				info.AddValue("_case2Sbu", value)
				value = Nothing 
				If (Not (_case2ServiceCode Is Nothing)) AndAlso (_case2ServiceCode.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2ServiceCode 
				End If
				info.AddValue("_case2ServiceCode", value)
				value = Nothing 
				If (Not (_case2Supplier Is Nothing)) AndAlso (_case2Supplier.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2Supplier 
				End If
				info.AddValue("_case2Supplier", value)
				value = Nothing 
				If (Not (_case2System Is Nothing)) AndAlso (_case2System.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2System 
				End If
				info.AddValue("_case2System", value)
				value = Nothing 
				If (Not (_case2TurbineUnitType Is Nothing)) AndAlso (_case2TurbineUnitType.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2TurbineUnitType 
				End If
				info.AddValue("_case2TurbineUnitType", value)
				value = Nothing 
				If (Not (_changeLog Is Nothing)) AndAlso (_changeLog.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _changeLog 
				End If
				info.AddValue("_changeLog", value)
				value = Nothing 
				If (Not (_cir Is Nothing)) AndAlso (_cir.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _cir 
				End If
				info.AddValue("_cir", value)
				value = Nothing 
				If (Not (_discussion Is Nothing)) AndAlso (_discussion.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _discussion 
				End If
				info.AddValue("_discussion", value)
				value = Nothing 
				If (Not (_folder Is Nothing)) AndAlso (_folder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _folder 
				End If
				info.AddValue("_folder", value)
				value = Nothing 
				If (Not (_milestone Is Nothing)) AndAlso (_milestone.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _milestone 
				End If
				info.AddValue("_milestone", value)
				value = Nothing 
				If (Not (_news Is Nothing)) AndAlso (_news.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _news 
				End If
				info.AddValue("_news", value)
				value = Nothing 
				If (Not (_oldCimturbine Is Nothing)) AndAlso (_oldCimturbine.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _oldCimturbine 
				End If
				info.AddValue("_oldCimturbine", value)
				value = Nothing 
				If (Not (_populationlist Is Nothing)) AndAlso (_populationlist.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _populationlist 
				End If
				info.AddValue("_populationlist", value)
				value = Nothing 
				If (Not (_rc Is Nothing)) AndAlso (_rc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rc 
				End If
				info.AddValue("_rc", value)
				value = Nothing 
				If (Not (_relatedCase Is Nothing)) AndAlso (_relatedCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _relatedCase 
				End If
				info.AddValue("_relatedCase", value)
				value = Nothing 
				If (Not (_relatedCase_ Is Nothing)) AndAlso (_relatedCase_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _relatedCase_ 
				End If
				info.AddValue("_relatedCase_", value)
				value = Nothing 
				If (Not (_timeline Is Nothing)) AndAlso (_timeline.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _timeline 
				End If
				info.AddValue("_timeline", value)
				value = Nothing 
				If (Not (_visits Is Nothing)) AndAlso (_visits.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _visits 
				End If
				info.AddValue("_visits", value)
				value = Nothing 
				If (Not (_brandCollectionViaCase Is Nothing)) AndAlso (_brandCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brandCollectionViaCase 
				End If
				info.AddValue("_brandCollectionViaCase", value)
				value = Nothing 
				If (Not (_businessProcessCollectionViaCase Is Nothing)) AndAlso (_businessProcessCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _businessProcessCollectionViaCase 
				End If
				info.AddValue("_businessProcessCollectionViaCase", value)
				value = Nothing 
				If (Not (_case2SupplierCollectionViaCase2ComponentType Is Nothing)) AndAlso (_case2SupplierCollectionViaCase2ComponentType.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2SupplierCollectionViaCase2ComponentType 
				End If
				info.AddValue("_case2SupplierCollectionViaCase2ComponentType", value)
				value = Nothing 
				If (Not (_caseBundleCollectionViaCase2CaseBundle Is Nothing)) AndAlso (_caseBundleCollectionViaCase2CaseBundle.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _caseBundleCollectionViaCase2CaseBundle 
				End If
				info.AddValue("_caseBundleCollectionViaCase2CaseBundle", value)
				value = Nothing 
				If (Not (_categoryCollectionViaCase Is Nothing)) AndAlso (_categoryCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _categoryCollectionViaCase 
				End If
				info.AddValue("_categoryCollectionViaCase", value)
				value = Nothing 
				If (Not (_changeTypeCollectionViaChangeLog Is Nothing)) AndAlso (_changeTypeCollectionViaChangeLog.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _changeTypeCollectionViaChangeLog 
				End If
				info.AddValue("_changeTypeCollectionViaChangeLog", value)
				value = Nothing 
				If (Not (_claimStatusCollectionViaCase Is Nothing)) AndAlso (_claimStatusCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _claimStatusCollectionViaCase 
				End If
				info.AddValue("_claimStatusCollectionViaCase", value)
				value = Nothing 
				If (Not (_componentCollectionViaCase Is Nothing)) AndAlso (_componentCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _componentCollectionViaCase 
				End If
				info.AddValue("_componentCollectionViaCase", value)
				value = Nothing 
				If (Not (_componentTypeCollectionViaCase2ComponentType Is Nothing)) AndAlso (_componentTypeCollectionViaCase2ComponentType.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _componentTypeCollectionViaCase2ComponentType 
				End If
				info.AddValue("_componentTypeCollectionViaCase2ComponentType", value)
				value = Nothing 
				If (Not (_discussionCollectionViaDiscussion Is Nothing)) AndAlso (_discussionCollectionViaDiscussion.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _discussionCollectionViaDiscussion 
				End If
				info.AddValue("_discussionCollectionViaDiscussion", value)
				value = Nothing 
				If (Not (_folderCollectionViaFolder Is Nothing)) AndAlso (_folderCollectionViaFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _folderCollectionViaFolder 
				End If
				info.AddValue("_folderCollectionViaFolder", value)
				value = Nothing 
				If (Not (_folderTypeCollectionViaFolder Is Nothing)) AndAlso (_folderTypeCollectionViaFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _folderTypeCollectionViaFolder 
				End If
				info.AddValue("_folderTypeCollectionViaFolder", value)
				value = Nothing 
				If (Not (_itemCollectionViaCase2Item Is Nothing)) AndAlso (_itemCollectionViaCase2Item.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _itemCollectionViaCase2Item 
				End If
				info.AddValue("_itemCollectionViaCase2Item", value)
				value = Nothing 
				If (Not (_logInfoCollectionViaCase2LogInfo Is Nothing)) AndAlso (_logInfoCollectionViaCase2LogInfo.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _logInfoCollectionViaCase2LogInfo 
				End If
				info.AddValue("_logInfoCollectionViaCase2LogInfo", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase Is Nothing)) AndAlso (_participantCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase 
				End If
				info.AddValue("_participantCollectionViaCase", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase_ Is Nothing)) AndAlso (_participantCollectionViaCase_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase_ 
				End If
				info.AddValue("_participantCollectionViaCase_", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase__ Is Nothing)) AndAlso (_participantCollectionViaCase__.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase__ 
				End If
				info.AddValue("_participantCollectionViaCase__", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase___ Is Nothing)) AndAlso (_participantCollectionViaCase___.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase___ 
				End If
				info.AddValue("_participantCollectionViaCase___", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase____ Is Nothing)) AndAlso (_participantCollectionViaCase____.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase____ 
				End If
				info.AddValue("_participantCollectionViaCase____", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase_____ Is Nothing)) AndAlso (_participantCollectionViaCase_____.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase_____ 
				End If
				info.AddValue("_participantCollectionViaCase_____", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase2Participant Is Nothing)) AndAlso (_participantCollectionViaCase2Participant.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase2Participant 
				End If
				info.AddValue("_participantCollectionViaCase2Participant", value)
				value = Nothing 
				If (Not (_participantCollectionViaChangeLog Is Nothing)) AndAlso (_participantCollectionViaChangeLog.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaChangeLog 
				End If
				info.AddValue("_participantCollectionViaChangeLog", value)
				value = Nothing 
				If (Not (_participantCollectionViaChangeLog_ Is Nothing)) AndAlso (_participantCollectionViaChangeLog_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaChangeLog_ 
				End If
				info.AddValue("_participantCollectionViaChangeLog_", value)
				value = Nothing 
				If (Not (_participantCollectionViaCir Is Nothing)) AndAlso (_participantCollectionViaCir.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCir 
				End If
				info.AddValue("_participantCollectionViaCir", value)
				value = Nothing 
				If (Not (_participantCollectionViaCir_ Is Nothing)) AndAlso (_participantCollectionViaCir_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCir_ 
				End If
				info.AddValue("_participantCollectionViaCir_", value)
				value = Nothing 
				If (Not (_participantCollectionViaDiscussion Is Nothing)) AndAlso (_participantCollectionViaDiscussion.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaDiscussion 
				End If
				info.AddValue("_participantCollectionViaDiscussion", value)
				value = Nothing 
				If (Not (_participantCollectionViaDiscussion_ Is Nothing)) AndAlso (_participantCollectionViaDiscussion_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaDiscussion_ 
				End If
				info.AddValue("_participantCollectionViaDiscussion_", value)
				value = Nothing 
				If (Not (_participantCollectionViaFolder Is Nothing)) AndAlso (_participantCollectionViaFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaFolder 
				End If
				info.AddValue("_participantCollectionViaFolder", value)
				value = Nothing 
				If (Not (_participantCollectionViaFolder_ Is Nothing)) AndAlso (_participantCollectionViaFolder_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaFolder_ 
				End If
				info.AddValue("_participantCollectionViaFolder_", value)
				value = Nothing 
				If (Not (_participantCollectionViaMilestone Is Nothing)) AndAlso (_participantCollectionViaMilestone.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaMilestone 
				End If
				info.AddValue("_participantCollectionViaMilestone", value)
				value = Nothing 
				If (Not (_participantCollectionViaNews Is Nothing)) AndAlso (_participantCollectionViaNews.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaNews 
				End If
				info.AddValue("_participantCollectionViaNews", value)
				value = Nothing 
				If (Not (_participantCollectionViaNews_ Is Nothing)) AndAlso (_participantCollectionViaNews_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaNews_ 
				End If
				info.AddValue("_participantCollectionViaNews_", value)
				value = Nothing 
				If (Not (_participantCollectionViaPopulationlist Is Nothing)) AndAlso (_participantCollectionViaPopulationlist.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaPopulationlist 
				End If
				info.AddValue("_participantCollectionViaPopulationlist", value)
				value = Nothing 
				If (Not (_participantCollectionViaRc Is Nothing)) AndAlso (_participantCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaRc 
				End If
				info.AddValue("_participantCollectionViaRc", value)
				value = Nothing 
				If (Not (_participantCollectionViaRc_ Is Nothing)) AndAlso (_participantCollectionViaRc_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaRc_ 
				End If
				info.AddValue("_participantCollectionViaRc_", value)
				value = Nothing 
				If (Not (_participantCollectionViaTimeline Is Nothing)) AndAlso (_participantCollectionViaTimeline.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaTimeline 
				End If
				info.AddValue("_participantCollectionViaTimeline", value)
				value = Nothing 
				If (Not (_participantCollectionViaVisits Is Nothing)) AndAlso (_participantCollectionViaVisits.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaVisits 
				End If
				info.AddValue("_participantCollectionViaVisits", value)
				value = Nothing 
				If (Not (_participantCollectionViaVisits_ Is Nothing)) AndAlso (_participantCollectionViaVisits_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaVisits_ 
				End If
				info.AddValue("_participantCollectionViaVisits_", value)
				value = Nothing 
				If (Not (_participationTypeCollectionViaCase2Participant Is Nothing)) AndAlso (_participationTypeCollectionViaCase2Participant.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participationTypeCollectionViaCase2Participant 
				End If
				info.AddValue("_participationTypeCollectionViaCase2Participant", value)
				value = Nothing 
				If (Not (_pbuCollectionViaCase Is Nothing)) AndAlso (_pbuCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _pbuCollectionViaCase 
				End If
				info.AddValue("_pbuCollectionViaCase", value)
				value = Nothing 
				If (Not (_personalSafetyCollectionViaCase Is Nothing)) AndAlso (_personalSafetyCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _personalSafetyCollectionViaCase 
				End If
				info.AddValue("_personalSafetyCollectionViaCase", value)
				value = Nothing 
				If (Not (_phaseCollectionViaCase Is Nothing)) AndAlso (_phaseCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaCase 
				End If
				info.AddValue("_phaseCollectionViaCase", value)
				value = Nothing 
				If (Not (_phaseCollectionViaCase2Phase Is Nothing)) AndAlso (_phaseCollectionViaCase2Phase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaCase2Phase 
				End If
				info.AddValue("_phaseCollectionViaCase2Phase", value)
				value = Nothing 
				If (Not (_phaseCollectionViaPopulationlist Is Nothing)) AndAlso (_phaseCollectionViaPopulationlist.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaPopulationlist 
				End If
				info.AddValue("_phaseCollectionViaPopulationlist", value)
				value = Nothing 
				If (Not (_platformCollectionViaCase Is Nothing)) AndAlso (_platformCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _platformCollectionViaCase 
				End If
				info.AddValue("_platformCollectionViaCase", value)
				value = Nothing 
				If (Not (_portfolioCollectionViaCase Is Nothing)) AndAlso (_portfolioCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _portfolioCollectionViaCase 
				End If
				info.AddValue("_portfolioCollectionViaCase", value)
				value = Nothing 
				If (Not (_projectScopeCollectionViaCase Is Nothing)) AndAlso (_projectScopeCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _projectScopeCollectionViaCase 
				End If
				info.AddValue("_projectScopeCollectionViaCase", value)
				value = Nothing 
				If (Not (_rccomponentOwnerCollectionViaRc Is Nothing)) AndAlso (_rccomponentOwnerCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rccomponentOwnerCollectionViaRc 
				End If
				info.AddValue("_rccomponentOwnerCollectionViaRc", value)
				value = Nothing 
				If (Not (_rcoriginCollectionViaRc Is Nothing)) AndAlso (_rcoriginCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginCollectionViaRc 
				End If
				info.AddValue("_rcoriginCollectionViaRc", value)
				value = Nothing 
				If (Not (_rcoriginResponsibleCollectionViaRc Is Nothing)) AndAlso (_rcoriginResponsibleCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginResponsibleCollectionViaRc 
				End If
				info.AddValue("_rcoriginResponsibleCollectionViaRc", value)
				value = Nothing 
				If (Not (_rcoriginUnitCollectionViaRc Is Nothing)) AndAlso (_rcoriginUnitCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginUnitCollectionViaRc 
				End If
				info.AddValue("_rcoriginUnitCollectionViaRc", value)
				value = Nothing 
				If (Not (_reasonCodeCollectionViaCase2ReasonCode Is Nothing)) AndAlso (_reasonCodeCollectionViaCase2ReasonCode.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _reasonCodeCollectionViaCase2ReasonCode 
				End If
				info.AddValue("_reasonCodeCollectionViaCase2ReasonCode", value)
				value = Nothing 
				If (Not (_reportTypeCollectionViaCir Is Nothing)) AndAlso (_reportTypeCollectionViaCir.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _reportTypeCollectionViaCir 
				End If
				info.AddValue("_reportTypeCollectionViaCir", value)
				value = Nothing 
				If (Not (_sbuCollectionViaCase2Sbu Is Nothing)) AndAlso (_sbuCollectionViaCase2Sbu.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _sbuCollectionViaCase2Sbu 
				End If
				info.AddValue("_sbuCollectionViaCase2Sbu", value)
				value = Nothing 
				If (Not (_serviceCodeCollectionViaCase2ServiceCode Is Nothing)) AndAlso (_serviceCodeCollectionViaCase2ServiceCode.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _serviceCodeCollectionViaCase2ServiceCode 
				End If
				info.AddValue("_serviceCodeCollectionViaCase2ServiceCode", value)
				value = Nothing 
				If (Not (_standardTaskCollectionViaCase Is Nothing)) AndAlso (_standardTaskCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardTaskCollectionViaCase 
				End If
				info.AddValue("_standardTaskCollectionViaCase", value)
				value = Nothing 
				If (Not (_stateCollectionViaPopulationlist Is Nothing)) AndAlso (_stateCollectionViaPopulationlist.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _stateCollectionViaPopulationlist 
				End If
				info.AddValue("_stateCollectionViaPopulationlist", value)
				value = Nothing 
				If (Not (_statusCollectionViaCase Is Nothing)) AndAlso (_statusCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _statusCollectionViaCase 
				End If
				info.AddValue("_statusCollectionViaCase", value)
				value = Nothing 
				If (Not (_statusCollectionViaPopulationlist Is Nothing)) AndAlso (_statusCollectionViaPopulationlist.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _statusCollectionViaPopulationlist 
				End If
				info.AddValue("_statusCollectionViaPopulationlist", value)
				value = Nothing 
				If (Not (_supplierCollectionViaCase2Supplier Is Nothing)) AndAlso (_supplierCollectionViaCase2Supplier.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _supplierCollectionViaCase2Supplier 
				End If
				info.AddValue("_supplierCollectionViaCase2Supplier", value)
				value = Nothing 
				If (Not (_systemDescriptionCollectionViaCase2System Is Nothing)) AndAlso (_systemDescriptionCollectionViaCase2System.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _systemDescriptionCollectionViaCase2System 
				End If
				info.AddValue("_systemDescriptionCollectionViaCase2System", value)
				value = Nothing 
				If (Not (_turbineMatrixCollectionViaCase2TurbineUnitType Is Nothing)) AndAlso (_turbineMatrixCollectionViaCase2TurbineUnitType.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineMatrixCollectionViaCase2TurbineUnitType 
				End If
				info.AddValue("_turbineMatrixCollectionViaCase2TurbineUnitType", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _brand
				End If
				info.AddValue("_brand", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _businessProcess
				End If
				info.AddValue("_businessProcess", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _parentCase
				End If
				info.AddValue("_parentCase", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _category
				End If
				info.AddValue("_category", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _claimStatus
				End If
				info.AddValue("_claimStatus", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _component
				End If
				info.AddValue("_component", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _createdByParticipant
				End If
				info.AddValue("_createdByParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _executionManagerParticipant
				End If
				info.AddValue("_executionManagerParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _lastEditedByParticipant
				End If
				info.AddValue("_lastEditedByParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _managerParticipant
				End If
				info.AddValue("_managerParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant
				End If
				info.AddValue("_participant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _technicalSpecialistParticipant
				End If
				info.AddValue("_technicalSpecialistParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _pbu
				End If
				info.AddValue("_pbu", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _personalSafety
				End If
				info.AddValue("_personalSafety", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _phase
				End If
				info.AddValue("_phase", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _platform_
				End If
				info.AddValue("_platform_", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _portfolio
				End If
				info.AddValue("_portfolio", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _projectScope
				End If
				info.AddValue("_projectScope", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _standardTask
				End If
				info.AddValue("_standardTask", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _status
				End If
				info.AddValue("_status", entityValue)
			End If
      ' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
      ' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New CaseRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoChildCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.Uplink, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2CaseBundle' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2CaseBundle() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2CaseBundleFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2ComponentType' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2ComponentType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2ComponentTypeFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2Item' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2Item() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2ItemFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2LogInfo' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2LogInfo() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2LogInfoFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2Participant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2ParticipantFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2Phase' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2Phase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2PhaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2ReasonCode' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2ReasonCode() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2ReasonCodeFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2Sbu' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2Sbu() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2SbuFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2ServiceCode' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2ServiceCode() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2ServiceCodeFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2Supplier' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2Supplier() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2SupplierFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2System' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2System() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2SystemFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2TurbineMatrix' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2TurbineUnitType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2TurbineMatrixFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ChangeLog' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoChangeLog() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ChangeLogFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Cir' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCir() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CirFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Discussion' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDiscussion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DiscussionFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Folder' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(FolderFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Milestone' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoMilestone() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(MilestoneFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'News' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoNews() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(NewsFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'OldCimturbine' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoOldCimturbine() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(OldCimturbineFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Populationlist' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPopulationlist() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PopulationlistFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Rc' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RelatedCase' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRelatedCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RelatedCaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RelatedCase' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRelatedCase_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RelatedCaseFields.CaseIdRelated, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Timeline' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTimeline() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TimelineFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Visits' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoVisits() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(VisitsFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrandCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BrandCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'BusinessProcess' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBusinessProcessCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BusinessProcessCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2Supplier' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2SupplierCollectionViaCase2ComponentType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("Case2SupplierCollectionViaCase2ComponentType"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'CaseBundle' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCaseBundleCollectionViaCase2CaseBundle() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CaseBundleCollectionViaCase2CaseBundle"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Category' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCategoryCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CategoryCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ChangeType' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoChangeTypeCollectionViaChangeLog() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ChangeTypeCollectionViaChangeLog"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ClaimStatus' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoClaimStatusCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ClaimStatusCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Component' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoComponentCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ComponentCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ComponentType' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoComponentTypeCollectionViaCase2ComponentType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ComponentTypeCollectionViaCase2ComponentType"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Discussion' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDiscussionCollectionViaDiscussion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("DiscussionCollectionViaDiscussion"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Folder' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolderCollectionViaFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("FolderCollectionViaFolder"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'FolderType' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolderTypeCollectionViaFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("FolderTypeCollectionViaFolder"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Item' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoItemCollectionViaCase2Item() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ItemCollectionViaCase2Item"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'LogInfo' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoLogInfoCollectionViaCase2LogInfo() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("LogInfoCollectionViaCase2LogInfo"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase__() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase__"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase___() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase___"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase____() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase____"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase_____() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase_____"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase2Participant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase2Participant"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaChangeLog() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaChangeLog"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaChangeLog_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaChangeLog_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCir() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCir"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCir_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCir_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaDiscussion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaDiscussion"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaDiscussion_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaDiscussion_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaFolder"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaFolder_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaFolder_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaMilestone() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaMilestone"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaNews() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaNews"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaNews_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaNews_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaPopulationlist() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaPopulationlist"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaRc_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaRc_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaTimeline() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaTimeline"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaVisits() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaVisits"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaVisits_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaVisits_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ParticipationType' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipationTypeCollectionViaCase2Participant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipationTypeCollectionViaCase2Participant"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Pbu' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPbuCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PbuCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'PersonalSafety' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPersonalSafetyCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PersonalSafetyCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaCase2Phase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaCase2Phase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaPopulationlist() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaPopulationlist"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Platform' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPlatformCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PlatformCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Portfolio' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPortfolioCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PortfolioCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ProjectScope' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoProjectScopeCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ProjectScopeCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RccomponentOwner' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRccomponentOwnerCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RccomponentOwnerCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Rcorigin' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RcoriginCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RcoriginResponsible' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginResponsibleCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RcoriginResponsibleCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RcoriginUnit' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginUnitCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RcoriginUnitCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ReasonCode' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoReasonCodeCollectionViaCase2ReasonCode() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ReasonCodeCollectionViaCase2ReasonCode"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ReportType' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoReportTypeCollectionViaCir() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ReportTypeCollectionViaCir"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Sbu' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoSbuCollectionViaCase2Sbu() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("SbuCollectionViaCase2Sbu"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ServiceCode' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoServiceCodeCollectionViaCase2ServiceCode() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ServiceCodeCollectionViaCase2ServiceCode"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardTask' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardTaskCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StandardTaskCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'State' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStateCollectionViaPopulationlist() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StateCollectionViaPopulationlist"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Status' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStatusCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StatusCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Status' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStatusCollectionViaPopulationlist() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StatusCollectionViaPopulationlist"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Supplier' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoSupplierCollectionViaCase2Supplier() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("SupplierCollectionViaCase2Supplier"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'SystemDescription' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoSystemDescriptionCollectionViaCase2System() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("SystemDescriptionCollectionViaCase2System"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineMatrix' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineMatrixCollectionViaCase2TurbineUnitType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineMatrixCollectionViaCase2TurbineUnitType"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId, "CaseEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Brand' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrand() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'BusinessProcess' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBusinessProcess() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BusinessProcessFields.BusinessProcessId, Nothing, ComparisonOperator.Equal, Me.BusinessProcessId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Case' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParentCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.Uplink))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Category' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCategory() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'ClaimStatus' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoClaimStatus() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ClaimStatusFields.ClaimStatusId, Nothing, ComparisonOperator.Equal, Me.ClaimStatusId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Component' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoComponent() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ComponentFields.ComponentId, Nothing, ComparisonOperator.Equal, Me.ComponentId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCreatedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoExecutionManagerParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.ExecutionManagerId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoLastEditedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.LastEditedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoManagerParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.ManagerId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.ContainmentLeadId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTechnicalSpecialistParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.TechnicalSpecialistId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Pbu' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPbu() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PbuFields.Pbuid, Nothing, ComparisonOperator.Equal, Me.Pbuid))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'PersonalSafety' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPersonalSafety() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PersonalSafetyFields.PersonalSafetyId, Nothing, ComparisonOperator.Equal, Me.PersonalSafetyId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Phase' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PhaseFields.PhaseId, Nothing, ComparisonOperator.Equal, Me.PhaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Platform' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPlatform_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PlatformFields.PlatformId, Nothing, ComparisonOperator.Equal, Me.Platform))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Portfolio' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPortfolio() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PortfolioFields.PortfolioId, Nothing, ComparisonOperator.Equal, Me.PortfolioId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'ProjectScope' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoProjectScope() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ProjectScopeFields.ProjectScopeId, Nothing, ComparisonOperator.Equal, Me.ProjectScopeId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'StandardTask' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardTask() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardTaskFields.StandardTaskId, Nothing, ComparisonOperator.Equal, Me.StandardTaskId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Status' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStatus() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StatusFields.StatusId, Nothing, ComparisonOperator.Equal, Me.StatusId))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_childCase)
			collectionsQueue.Enqueue(_case2CaseBundle)
			collectionsQueue.Enqueue(_case2ComponentType)
			collectionsQueue.Enqueue(_case2Item)
			collectionsQueue.Enqueue(_case2LogInfo)
			collectionsQueue.Enqueue(_case2Participant)
			collectionsQueue.Enqueue(_case2Phase)
			collectionsQueue.Enqueue(_case2ReasonCode)
			collectionsQueue.Enqueue(_case2Sbu)
			collectionsQueue.Enqueue(_case2ServiceCode)
			collectionsQueue.Enqueue(_case2Supplier)
			collectionsQueue.Enqueue(_case2System)
			collectionsQueue.Enqueue(_case2TurbineUnitType)
			collectionsQueue.Enqueue(_changeLog)
			collectionsQueue.Enqueue(_cir)
			collectionsQueue.Enqueue(_discussion)
			collectionsQueue.Enqueue(_folder)
			collectionsQueue.Enqueue(_milestone)
			collectionsQueue.Enqueue(_news)
			collectionsQueue.Enqueue(_oldCimturbine)
			collectionsQueue.Enqueue(_populationlist)
			collectionsQueue.Enqueue(_rc)
			collectionsQueue.Enqueue(_relatedCase)
			collectionsQueue.Enqueue(_relatedCase_)
			collectionsQueue.Enqueue(_timeline)
			collectionsQueue.Enqueue(_visits)
			collectionsQueue.Enqueue(_brandCollectionViaCase)
			collectionsQueue.Enqueue(_businessProcessCollectionViaCase)
			collectionsQueue.Enqueue(_case2SupplierCollectionViaCase2ComponentType)
			collectionsQueue.Enqueue(_caseBundleCollectionViaCase2CaseBundle)
			collectionsQueue.Enqueue(_categoryCollectionViaCase)
			collectionsQueue.Enqueue(_changeTypeCollectionViaChangeLog)
			collectionsQueue.Enqueue(_claimStatusCollectionViaCase)
			collectionsQueue.Enqueue(_componentCollectionViaCase)
			collectionsQueue.Enqueue(_componentTypeCollectionViaCase2ComponentType)
			collectionsQueue.Enqueue(_discussionCollectionViaDiscussion)
			collectionsQueue.Enqueue(_folderCollectionViaFolder)
			collectionsQueue.Enqueue(_folderTypeCollectionViaFolder)
			collectionsQueue.Enqueue(_itemCollectionViaCase2Item)
			collectionsQueue.Enqueue(_logInfoCollectionViaCase2LogInfo)
			collectionsQueue.Enqueue(_participantCollectionViaCase)
			collectionsQueue.Enqueue(_participantCollectionViaCase_)
			collectionsQueue.Enqueue(_participantCollectionViaCase__)
			collectionsQueue.Enqueue(_participantCollectionViaCase___)
			collectionsQueue.Enqueue(_participantCollectionViaCase____)
			collectionsQueue.Enqueue(_participantCollectionViaCase_____)
			collectionsQueue.Enqueue(_participantCollectionViaCase2Participant)
			collectionsQueue.Enqueue(_participantCollectionViaChangeLog)
			collectionsQueue.Enqueue(_participantCollectionViaChangeLog_)
			collectionsQueue.Enqueue(_participantCollectionViaCir)
			collectionsQueue.Enqueue(_participantCollectionViaCir_)
			collectionsQueue.Enqueue(_participantCollectionViaDiscussion)
			collectionsQueue.Enqueue(_participantCollectionViaDiscussion_)
			collectionsQueue.Enqueue(_participantCollectionViaFolder)
			collectionsQueue.Enqueue(_participantCollectionViaFolder_)
			collectionsQueue.Enqueue(_participantCollectionViaMilestone)
			collectionsQueue.Enqueue(_participantCollectionViaNews)
			collectionsQueue.Enqueue(_participantCollectionViaNews_)
			collectionsQueue.Enqueue(_participantCollectionViaPopulationlist)
			collectionsQueue.Enqueue(_participantCollectionViaRc)
			collectionsQueue.Enqueue(_participantCollectionViaRc_)
			collectionsQueue.Enqueue(_participantCollectionViaTimeline)
			collectionsQueue.Enqueue(_participantCollectionViaVisits)
			collectionsQueue.Enqueue(_participantCollectionViaVisits_)
			collectionsQueue.Enqueue(_participationTypeCollectionViaCase2Participant)
			collectionsQueue.Enqueue(_pbuCollectionViaCase)
			collectionsQueue.Enqueue(_personalSafetyCollectionViaCase)
			collectionsQueue.Enqueue(_phaseCollectionViaCase)
			collectionsQueue.Enqueue(_phaseCollectionViaCase2Phase)
			collectionsQueue.Enqueue(_phaseCollectionViaPopulationlist)
			collectionsQueue.Enqueue(_platformCollectionViaCase)
			collectionsQueue.Enqueue(_portfolioCollectionViaCase)
			collectionsQueue.Enqueue(_projectScopeCollectionViaCase)
			collectionsQueue.Enqueue(_rccomponentOwnerCollectionViaRc)
			collectionsQueue.Enqueue(_rcoriginCollectionViaRc)
			collectionsQueue.Enqueue(_rcoriginResponsibleCollectionViaRc)
			collectionsQueue.Enqueue(_rcoriginUnitCollectionViaRc)
			collectionsQueue.Enqueue(_reasonCodeCollectionViaCase2ReasonCode)
			collectionsQueue.Enqueue(_reportTypeCollectionViaCir)
			collectionsQueue.Enqueue(_sbuCollectionViaCase2Sbu)
			collectionsQueue.Enqueue(_serviceCodeCollectionViaCase2ServiceCode)
			collectionsQueue.Enqueue(_standardTaskCollectionViaCase)
			collectionsQueue.Enqueue(_stateCollectionViaPopulationlist)
			collectionsQueue.Enqueue(_statusCollectionViaCase)
			collectionsQueue.Enqueue(_statusCollectionViaPopulationlist)
			collectionsQueue.Enqueue(_supplierCollectionViaCase2Supplier)
			collectionsQueue.Enqueue(_systemDescriptionCollectionViaCase2System)
			collectionsQueue.Enqueue(_turbineMatrixCollectionViaCase2TurbineUnitType)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_childCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_case2CaseBundle = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2CaseBundleEntity))
			_case2ComponentType = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2ComponentTypeEntity))
			_case2Item = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2ItemEntity))
			_case2LogInfo = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2LogInfoEntity))
			_case2Participant = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2ParticipantEntity))
			_case2Phase = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2PhaseEntity))
			_case2ReasonCode = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2ReasonCodeEntity))
			_case2Sbu = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2SbuEntity))
			_case2ServiceCode = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2ServiceCodeEntity))
			_case2Supplier = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2SupplierEntity))
			_case2System = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2SystemEntity))
			_case2TurbineUnitType = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2TurbineMatrixEntity))
			_changeLog = CType(collectionsQueue.Dequeue(), EntityCollection(Of ChangeLogEntity))
			_cir = CType(collectionsQueue.Dequeue(), EntityCollection(Of CirEntity))
			_discussion = CType(collectionsQueue.Dequeue(), EntityCollection(Of DiscussionEntity))
			_folder = CType(collectionsQueue.Dequeue(), EntityCollection(Of FolderEntity))
			_milestone = CType(collectionsQueue.Dequeue(), EntityCollection(Of MilestoneEntity))
			_news = CType(collectionsQueue.Dequeue(), EntityCollection(Of NewsEntity))
			_oldCimturbine = CType(collectionsQueue.Dequeue(), EntityCollection(Of OldCimturbineEntity))
			_populationlist = CType(collectionsQueue.Dequeue(), EntityCollection(Of PopulationlistEntity))
			_rc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcEntity))
			_relatedCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of RelatedCaseEntity))
			_relatedCase_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of RelatedCaseEntity))
			_timeline = CType(collectionsQueue.Dequeue(), EntityCollection(Of TimelineEntity))
			_visits = CType(collectionsQueue.Dequeue(), EntityCollection(Of VisitsEntity))
			_brandCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of BrandEntity))
			_businessProcessCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of BusinessProcessEntity))
			_case2SupplierCollectionViaCase2ComponentType = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2SupplierEntity))
			_caseBundleCollectionViaCase2CaseBundle = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseBundleEntity))
			_categoryCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of CategoryEntity))
			_changeTypeCollectionViaChangeLog = CType(collectionsQueue.Dequeue(), EntityCollection(Of ChangeTypeEntity))
			_claimStatusCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ClaimStatusEntity))
			_componentCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ComponentEntity))
			_componentTypeCollectionViaCase2ComponentType = CType(collectionsQueue.Dequeue(), EntityCollection(Of ComponentTypeEntity))
			_discussionCollectionViaDiscussion = CType(collectionsQueue.Dequeue(), EntityCollection(Of DiscussionEntity))
			_folderCollectionViaFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of FolderEntity))
			_folderTypeCollectionViaFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of FolderTypeEntity))
			_itemCollectionViaCase2Item = CType(collectionsQueue.Dequeue(), EntityCollection(Of ItemEntity))
			_logInfoCollectionViaCase2LogInfo = CType(collectionsQueue.Dequeue(), EntityCollection(Of LogInfoEntity))
			_participantCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase__ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase___ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase____ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase_____ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase2Participant = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaChangeLog = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaChangeLog_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCir = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCir_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaDiscussion = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaDiscussion_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaFolder_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaMilestone = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaNews = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaNews_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaPopulationlist = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaRc_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaTimeline = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaVisits = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaVisits_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participationTypeCollectionViaCase2Participant = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipationTypeEntity))
			_pbuCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PbuEntity))
			_personalSafetyCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PersonalSafetyEntity))
			_phaseCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_phaseCollectionViaCase2Phase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_phaseCollectionViaPopulationlist = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_platformCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PlatformEntity))
			_portfolioCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PortfolioEntity))
			_projectScopeCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ProjectScopeEntity))
			_rccomponentOwnerCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RccomponentOwnerEntity))
			_rcoriginCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginEntity))
			_rcoriginResponsibleCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginResponsibleEntity))
			_rcoriginUnitCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginUnitEntity))
			_reasonCodeCollectionViaCase2ReasonCode = CType(collectionsQueue.Dequeue(), EntityCollection(Of ReasonCodeEntity))
			_reportTypeCollectionViaCir = CType(collectionsQueue.Dequeue(), EntityCollection(Of ReportTypeEntity))
			_sbuCollectionViaCase2Sbu = CType(collectionsQueue.Dequeue(), EntityCollection(Of SbuEntity))
			_serviceCodeCollectionViaCase2ServiceCode = CType(collectionsQueue.Dequeue(), EntityCollection(Of ServiceCodeEntity))
			_standardTaskCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardTaskEntity))
			_stateCollectionViaPopulationlist = CType(collectionsQueue.Dequeue(), EntityCollection(Of StateEntity))
			_statusCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of StatusEntity))
			_statusCollectionViaPopulationlist = CType(collectionsQueue.Dequeue(), EntityCollection(Of StatusEntity))
			_supplierCollectionViaCase2Supplier = CType(collectionsQueue.Dequeue(), EntityCollection(Of SupplierEntity))
			_systemDescriptionCollectionViaCase2System = CType(collectionsQueue.Dequeue(), EntityCollection(Of SystemDescriptionEntity))
			_turbineMatrixCollectionViaCase2TurbineUnitType = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineMatrixEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _childCase Is Nothing) Then
				Return True
			End If
			If (Not _case2CaseBundle Is Nothing) Then
				Return True
			End If
			If (Not _case2ComponentType Is Nothing) Then
				Return True
			End If
			If (Not _case2Item Is Nothing) Then
				Return True
			End If
			If (Not _case2LogInfo Is Nothing) Then
				Return True
			End If
			If (Not _case2Participant Is Nothing) Then
				Return True
			End If
			If (Not _case2Phase Is Nothing) Then
				Return True
			End If
			If (Not _case2ReasonCode Is Nothing) Then
				Return True
			End If
			If (Not _case2Sbu Is Nothing) Then
				Return True
			End If
			If (Not _case2ServiceCode Is Nothing) Then
				Return True
			End If
			If (Not _case2Supplier Is Nothing) Then
				Return True
			End If
			If (Not _case2System Is Nothing) Then
				Return True
			End If
			If (Not _case2TurbineUnitType Is Nothing) Then
				Return True
			End If
			If (Not _changeLog Is Nothing) Then
				Return True
			End If
			If (Not _cir Is Nothing) Then
				Return True
			End If
			If (Not _discussion Is Nothing) Then
				Return True
			End If
			If (Not _folder Is Nothing) Then
				Return True
			End If
			If (Not _milestone Is Nothing) Then
				Return True
			End If
			If (Not _news Is Nothing) Then
				Return True
			End If
			If (Not _oldCimturbine Is Nothing) Then
				Return True
			End If
			If (Not _populationlist Is Nothing) Then
				Return True
			End If
			If (Not _rc Is Nothing) Then
				Return True
			End If
			If (Not _relatedCase Is Nothing) Then
				Return True
			End If
			If (Not _relatedCase_ Is Nothing) Then
				Return True
			End If
			If (Not _timeline Is Nothing) Then
				Return True
			End If
			If (Not _visits Is Nothing) Then
				Return True
			End If
			If (Not _brandCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _businessProcessCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _case2SupplierCollectionViaCase2ComponentType Is Nothing) Then
				Return True
			End If
			If (Not _caseBundleCollectionViaCase2CaseBundle Is Nothing) Then
				Return True
			End If
			If (Not _categoryCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _changeTypeCollectionViaChangeLog Is Nothing) Then
				Return True
			End If
			If (Not _claimStatusCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _componentCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _componentTypeCollectionViaCase2ComponentType Is Nothing) Then
				Return True
			End If
			If (Not _discussionCollectionViaDiscussion Is Nothing) Then
				Return True
			End If
			If (Not _folderCollectionViaFolder Is Nothing) Then
				Return True
			End If
			If (Not _folderTypeCollectionViaFolder Is Nothing) Then
				Return True
			End If
			If (Not _itemCollectionViaCase2Item Is Nothing) Then
				Return True
			End If
			If (Not _logInfoCollectionViaCase2LogInfo Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase__ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase___ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase____ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase_____ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase2Participant Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaChangeLog Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaChangeLog_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCir Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCir_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaDiscussion Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaDiscussion_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaFolder Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaFolder_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaMilestone Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaNews Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaNews_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaPopulationlist Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaRc_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaTimeline Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaVisits Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaVisits_ Is Nothing) Then
				Return True
			End If
			If (Not _participationTypeCollectionViaCase2Participant Is Nothing) Then
				Return True
			End If
			If (Not _pbuCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _personalSafetyCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaCase2Phase Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaPopulationlist Is Nothing) Then
				Return True
			End If
			If (Not _platformCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _portfolioCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _projectScopeCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _rccomponentOwnerCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginResponsibleCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginUnitCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _reasonCodeCollectionViaCase2ReasonCode Is Nothing) Then
				Return True
			End If
			If (Not _reportTypeCollectionViaCir Is Nothing) Then
				Return True
			End If
			If (Not _sbuCollectionViaCase2Sbu Is Nothing) Then
				Return True
			End If
			If (Not _serviceCodeCollectionViaCase2ServiceCode Is Nothing) Then
				Return True
			End If
			If (Not _standardTaskCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _stateCollectionViaPopulationlist Is Nothing) Then
				Return True
			End If
			If (Not _statusCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _statusCollectionViaPopulationlist Is Nothing) Then
				Return True
			End If
			If (Not _supplierCollectionViaCase2Supplier Is Nothing) Then
				Return True
			End If
			If (Not _systemDescriptionCollectionViaCase2System Is Nothing) Then
				Return True
			End If
			If (Not _turbineMatrixCollectionViaCase2TurbineUnitType Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2CaseBundleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2CaseBundleEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2ComponentTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ComponentTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2ItemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ItemEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2LogInfoEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2LogInfoEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2ReasonCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ReasonCodeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2SbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SbuEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2ServiceCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ServiceCodeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SupplierEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2SystemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SystemEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2TurbineMatrixEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ChangeLogEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ChangeLogEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CirEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CirEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of MilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(MilestoneEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of NewsEntity)(EntityFactoryCache2.GetEntityFactory(GetType(NewsEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of OldCimturbineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(OldCimturbineEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PopulationlistEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PopulationlistEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RelatedCaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RelatedCaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RelatedCaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RelatedCaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TimelineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TimelineEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of VisitsEntity)(EntityFactoryCache2.GetEntityFactory(GetType(VisitsEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SupplierEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseBundleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseBundleEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CategoryEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ChangeTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ChangeTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ComponentTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ItemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ItemEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of LogInfoEntity)(EntityFactoryCache2.GetEntityFactory(GetType(LogInfoEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipationTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipationTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RccomponentOwnerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RccomponentOwnerEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginResponsibleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginResponsibleEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ReasonCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ReasonCodeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ReportTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ReportTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of SbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SbuEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ServiceCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ServiceCodeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StateEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SupplierEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of SystemDescriptionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SystemDescriptionEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMatrixEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Brand", _brand)
			toReturn.Add("BusinessProcess", _businessProcess)
			toReturn.Add("ParentCase", _parentCase)
			toReturn.Add("Category", _category)
			toReturn.Add("ClaimStatus", _claimStatus)
			toReturn.Add("Component", _component)
			toReturn.Add("CreatedByParticipant", _createdByParticipant)
			toReturn.Add("ExecutionManagerParticipant", _executionManagerParticipant)
			toReturn.Add("LastEditedByParticipant", _lastEditedByParticipant)
			toReturn.Add("ManagerParticipant", _managerParticipant)
			toReturn.Add("Participant", _participant)
			toReturn.Add("TechnicalSpecialistParticipant", _technicalSpecialistParticipant)
			toReturn.Add("Pbu", _pbu)
			toReturn.Add("PersonalSafety", _personalSafety)
			toReturn.Add("Phase", _phase)
			toReturn.Add("Platform_", _platform_)
			toReturn.Add("Portfolio", _portfolio)
			toReturn.Add("ProjectScope", _projectScope)
			toReturn.Add("StandardTask", _standardTask)
			toReturn.Add("Status", _status)
			toReturn.Add("ChildCase", _childCase)
			toReturn.Add("Case2CaseBundle", _case2CaseBundle)
			toReturn.Add("Case2ComponentType", _case2ComponentType)
			toReturn.Add("Case2Item", _case2Item)
			toReturn.Add("Case2LogInfo", _case2LogInfo)
			toReturn.Add("Case2Participant", _case2Participant)
			toReturn.Add("Case2Phase", _case2Phase)
			toReturn.Add("Case2ReasonCode", _case2ReasonCode)
			toReturn.Add("Case2Sbu", _case2Sbu)
			toReturn.Add("Case2ServiceCode", _case2ServiceCode)
			toReturn.Add("Case2Supplier", _case2Supplier)
			toReturn.Add("Case2System", _case2System)
			toReturn.Add("Case2TurbineUnitType", _case2TurbineUnitType)
			toReturn.Add("ChangeLog", _changeLog)
			toReturn.Add("Cir", _cir)
			toReturn.Add("Discussion", _discussion)
			toReturn.Add("Folder", _folder)
			toReturn.Add("Milestone", _milestone)
			toReturn.Add("News", _news)
			toReturn.Add("OldCimturbine", _oldCimturbine)
			toReturn.Add("Populationlist", _populationlist)
			toReturn.Add("Rc", _rc)
			toReturn.Add("RelatedCase", _relatedCase)
			toReturn.Add("RelatedCase_", _relatedCase_)
			toReturn.Add("Timeline", _timeline)
			toReturn.Add("Visits", _visits)
			toReturn.Add("BrandCollectionViaCase", _brandCollectionViaCase)
			toReturn.Add("BusinessProcessCollectionViaCase", _businessProcessCollectionViaCase)
			toReturn.Add("Case2SupplierCollectionViaCase2ComponentType", _case2SupplierCollectionViaCase2ComponentType)
			toReturn.Add("CaseBundleCollectionViaCase2CaseBundle", _caseBundleCollectionViaCase2CaseBundle)
			toReturn.Add("CategoryCollectionViaCase", _categoryCollectionViaCase)
			toReturn.Add("ChangeTypeCollectionViaChangeLog", _changeTypeCollectionViaChangeLog)
			toReturn.Add("ClaimStatusCollectionViaCase", _claimStatusCollectionViaCase)
			toReturn.Add("ComponentCollectionViaCase", _componentCollectionViaCase)
			toReturn.Add("ComponentTypeCollectionViaCase2ComponentType", _componentTypeCollectionViaCase2ComponentType)
			toReturn.Add("DiscussionCollectionViaDiscussion", _discussionCollectionViaDiscussion)
			toReturn.Add("FolderCollectionViaFolder", _folderCollectionViaFolder)
			toReturn.Add("FolderTypeCollectionViaFolder", _folderTypeCollectionViaFolder)
			toReturn.Add("ItemCollectionViaCase2Item", _itemCollectionViaCase2Item)
			toReturn.Add("LogInfoCollectionViaCase2LogInfo", _logInfoCollectionViaCase2LogInfo)
			toReturn.Add("ParticipantCollectionViaCase", _participantCollectionViaCase)
			toReturn.Add("ParticipantCollectionViaCase_", _participantCollectionViaCase_)
			toReturn.Add("ParticipantCollectionViaCase__", _participantCollectionViaCase__)
			toReturn.Add("ParticipantCollectionViaCase___", _participantCollectionViaCase___)
			toReturn.Add("ParticipantCollectionViaCase____", _participantCollectionViaCase____)
			toReturn.Add("ParticipantCollectionViaCase_____", _participantCollectionViaCase_____)
			toReturn.Add("ParticipantCollectionViaCase2Participant", _participantCollectionViaCase2Participant)
			toReturn.Add("ParticipantCollectionViaChangeLog", _participantCollectionViaChangeLog)
			toReturn.Add("ParticipantCollectionViaChangeLog_", _participantCollectionViaChangeLog_)
			toReturn.Add("ParticipantCollectionViaCir", _participantCollectionViaCir)
			toReturn.Add("ParticipantCollectionViaCir_", _participantCollectionViaCir_)
			toReturn.Add("ParticipantCollectionViaDiscussion", _participantCollectionViaDiscussion)
			toReturn.Add("ParticipantCollectionViaDiscussion_", _participantCollectionViaDiscussion_)
			toReturn.Add("ParticipantCollectionViaFolder", _participantCollectionViaFolder)
			toReturn.Add("ParticipantCollectionViaFolder_", _participantCollectionViaFolder_)
			toReturn.Add("ParticipantCollectionViaMilestone", _participantCollectionViaMilestone)
			toReturn.Add("ParticipantCollectionViaNews", _participantCollectionViaNews)
			toReturn.Add("ParticipantCollectionViaNews_", _participantCollectionViaNews_)
			toReturn.Add("ParticipantCollectionViaPopulationlist", _participantCollectionViaPopulationlist)
			toReturn.Add("ParticipantCollectionViaRc", _participantCollectionViaRc)
			toReturn.Add("ParticipantCollectionViaRc_", _participantCollectionViaRc_)
			toReturn.Add("ParticipantCollectionViaTimeline", _participantCollectionViaTimeline)
			toReturn.Add("ParticipantCollectionViaVisits", _participantCollectionViaVisits)
			toReturn.Add("ParticipantCollectionViaVisits_", _participantCollectionViaVisits_)
			toReturn.Add("ParticipationTypeCollectionViaCase2Participant", _participationTypeCollectionViaCase2Participant)
			toReturn.Add("PbuCollectionViaCase", _pbuCollectionViaCase)
			toReturn.Add("PersonalSafetyCollectionViaCase", _personalSafetyCollectionViaCase)
			toReturn.Add("PhaseCollectionViaCase", _phaseCollectionViaCase)
			toReturn.Add("PhaseCollectionViaCase2Phase", _phaseCollectionViaCase2Phase)
			toReturn.Add("PhaseCollectionViaPopulationlist", _phaseCollectionViaPopulationlist)
			toReturn.Add("PlatformCollectionViaCase", _platformCollectionViaCase)
			toReturn.Add("PortfolioCollectionViaCase", _portfolioCollectionViaCase)
			toReturn.Add("ProjectScopeCollectionViaCase", _projectScopeCollectionViaCase)
			toReturn.Add("RccomponentOwnerCollectionViaRc", _rccomponentOwnerCollectionViaRc)
			toReturn.Add("RcoriginCollectionViaRc", _rcoriginCollectionViaRc)
			toReturn.Add("RcoriginResponsibleCollectionViaRc", _rcoriginResponsibleCollectionViaRc)
			toReturn.Add("RcoriginUnitCollectionViaRc", _rcoriginUnitCollectionViaRc)
			toReturn.Add("ReasonCodeCollectionViaCase2ReasonCode", _reasonCodeCollectionViaCase2ReasonCode)
			toReturn.Add("ReportTypeCollectionViaCir", _reportTypeCollectionViaCir)
			toReturn.Add("SbuCollectionViaCase2Sbu", _sbuCollectionViaCase2Sbu)
			toReturn.Add("ServiceCodeCollectionViaCase2ServiceCode", _serviceCodeCollectionViaCase2ServiceCode)
			toReturn.Add("StandardTaskCollectionViaCase", _standardTaskCollectionViaCase)
			toReturn.Add("StateCollectionViaPopulationlist", _stateCollectionViaPopulationlist)
			toReturn.Add("StatusCollectionViaCase", _statusCollectionViaCase)
			toReturn.Add("StatusCollectionViaPopulationlist", _statusCollectionViaPopulationlist)
			toReturn.Add("SupplierCollectionViaCase2Supplier", _supplierCollectionViaCase2Supplier)
			toReturn.Add("SystemDescriptionCollectionViaCase2System", _systemDescriptionCollectionViaCase2System)
			toReturn.Add("TurbineMatrixCollectionViaCase2TurbineUnitType", _turbineMatrixCollectionViaCase2TurbineUnitType)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

      ' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
      ' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CaseId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("BrandId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CaseNo", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PhaseId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StatusId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ClaimStatusId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Pbuid", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ProjectPortalId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ManagerId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Uplink", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Description", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("LastEdited", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("LastEditedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StandbyText", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ConfirmedBySupplier", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("HasProcessedMsprojectPlan", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StartDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("FinishDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DurationHours", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PercentComplete", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("SalesOption", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Platform", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ClosureDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ReopenDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TechnicalSpecialistId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ExecutionManagerId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ClosedForInvoicing", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PortfolioId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("BusinessProcessId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StandardTaskId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StandardTask_", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StateChangedDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CategoryId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ComponentId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PersonalSafetyId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Bleeding", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("SafetyAlert", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Dmsdocument", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ReferenceNumber", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Econumber", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ContainmentLeadId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ProjectScopeId", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _brand</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncBrand(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _brand, AddressOf OnBrandPropertyChanged, "Brand", PManagement.Data.RelationClasses.StaticCaseRelations.BrandEntityUsingBrandIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.BrandId) } )
			_brand = Nothing
		End Sub

		''' <summary>setups the sync logic for member _brand</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncBrand(relatedEntity As IEntityCore)
			If Not _brand Is relatedEntity Then
				DesetupSyncBrand(True, True)
				_brand = CType(relatedEntity, BrandEntity)
				Me.PerformSetupSyncRelatedEntity( _brand, AddressOf OnBrandPropertyChanged, "Brand", PManagement.Data.RelationClasses.StaticCaseRelations.BrandEntityUsingBrandIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnBrandPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _businessProcess</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncBusinessProcess(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _businessProcess, AddressOf OnBusinessProcessPropertyChanged, "BusinessProcess", PManagement.Data.RelationClasses.StaticCaseRelations.BusinessProcessEntityUsingBusinessProcessIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.BusinessProcessId) } )
			_businessProcess = Nothing
		End Sub

		''' <summary>setups the sync logic for member _businessProcess</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncBusinessProcess(relatedEntity As IEntityCore)
			If Not _businessProcess Is relatedEntity Then
				DesetupSyncBusinessProcess(True, True)
				_businessProcess = CType(relatedEntity, BusinessProcessEntity)
				Me.PerformSetupSyncRelatedEntity( _businessProcess, AddressOf OnBusinessProcessPropertyChanged, "BusinessProcess", PManagement.Data.RelationClasses.StaticCaseRelations.BusinessProcessEntityUsingBusinessProcessIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnBusinessProcessPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _parentCase</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParentCase(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _parentCase, AddressOf OnParentCasePropertyChanged, "ParentCase", PManagement.Data.RelationClasses.StaticCaseRelations.CaseEntityUsingCaseIdUplinkStatic, True, signalRelatedEntity, "ChildCase", resetFKFields, New Integer() { CInt(CaseFieldIndex.Uplink) } )
			_parentCase = Nothing
		End Sub

		''' <summary>setups the sync logic for member _parentCase</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParentCase(relatedEntity As IEntityCore)
			If Not _parentCase Is relatedEntity Then
				DesetupSyncParentCase(True, True)
				_parentCase = CType(relatedEntity, CaseEntity)
				Me.PerformSetupSyncRelatedEntity( _parentCase, AddressOf OnParentCasePropertyChanged, "ParentCase", PManagement.Data.RelationClasses.StaticCaseRelations.CaseEntityUsingCaseIdUplinkStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParentCasePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _category</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncCategory(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _category, AddressOf OnCategoryPropertyChanged, "Category", PManagement.Data.RelationClasses.StaticCaseRelations.CategoryEntityUsingCategoryIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.CategoryId) } )
			_category = Nothing
		End Sub

		''' <summary>setups the sync logic for member _category</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncCategory(relatedEntity As IEntityCore)
			If Not _category Is relatedEntity Then
				DesetupSyncCategory(True, True)
				_category = CType(relatedEntity, CategoryEntity)
				Me.PerformSetupSyncRelatedEntity( _category, AddressOf OnCategoryPropertyChanged, "Category", PManagement.Data.RelationClasses.StaticCaseRelations.CategoryEntityUsingCategoryIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnCategoryPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _claimStatus</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncClaimStatus(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _claimStatus, AddressOf OnClaimStatusPropertyChanged, "ClaimStatus", PManagement.Data.RelationClasses.StaticCaseRelations.ClaimStatusEntityUsingClaimStatusIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.ClaimStatusId) } )
			_claimStatus = Nothing
		End Sub

		''' <summary>setups the sync logic for member _claimStatus</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncClaimStatus(relatedEntity As IEntityCore)
			If Not _claimStatus Is relatedEntity Then
				DesetupSyncClaimStatus(True, True)
				_claimStatus = CType(relatedEntity, ClaimStatusEntity)
				Me.PerformSetupSyncRelatedEntity( _claimStatus, AddressOf OnClaimStatusPropertyChanged, "ClaimStatus", PManagement.Data.RelationClasses.StaticCaseRelations.ClaimStatusEntityUsingClaimStatusIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnClaimStatusPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _component</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncComponent(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _component, AddressOf OnComponentPropertyChanged, "Component", PManagement.Data.RelationClasses.StaticCaseRelations.ComponentEntityUsingComponentIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.ComponentId) } )
			_component = Nothing
		End Sub

		''' <summary>setups the sync logic for member _component</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncComponent(relatedEntity As IEntityCore)
			If Not _component Is relatedEntity Then
				DesetupSyncComponent(True, True)
				_component = CType(relatedEntity, ComponentEntity)
				Me.PerformSetupSyncRelatedEntity( _component, AddressOf OnComponentPropertyChanged, "Component", PManagement.Data.RelationClasses.StaticCaseRelations.ComponentEntityUsingComponentIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnComponentPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _createdByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncCreatedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _createdByParticipant, AddressOf OnCreatedByParticipantPropertyChanged, "CreatedByParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingCreatedByIdStatic, True, signalRelatedEntity, "Case_", resetFKFields, New Integer() { CInt(CaseFieldIndex.CreatedById) } )
			_createdByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _createdByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncCreatedByParticipant(relatedEntity As IEntityCore)
			If Not _createdByParticipant Is relatedEntity Then
				DesetupSyncCreatedByParticipant(True, True)
				_createdByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _createdByParticipant, AddressOf OnCreatedByParticipantPropertyChanged, "CreatedByParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingCreatedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnCreatedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _executionManagerParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncExecutionManagerParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _executionManagerParticipant, AddressOf OnExecutionManagerParticipantPropertyChanged, "ExecutionManagerParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingExecutionManagerIdStatic, True, signalRelatedEntity, "Case____", resetFKFields, New Integer() { CInt(CaseFieldIndex.ExecutionManagerId) } )
			_executionManagerParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _executionManagerParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncExecutionManagerParticipant(relatedEntity As IEntityCore)
			If Not _executionManagerParticipant Is relatedEntity Then
				DesetupSyncExecutionManagerParticipant(True, True)
				_executionManagerParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _executionManagerParticipant, AddressOf OnExecutionManagerParticipantPropertyChanged, "ExecutionManagerParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingExecutionManagerIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnExecutionManagerParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _lastEditedByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncLastEditedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _lastEditedByParticipant, AddressOf OnLastEditedByParticipantPropertyChanged, "LastEditedByParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingLastEditedByIdStatic, True, signalRelatedEntity, "Case__", resetFKFields, New Integer() { CInt(CaseFieldIndex.LastEditedById) } )
			_lastEditedByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _lastEditedByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncLastEditedByParticipant(relatedEntity As IEntityCore)
			If Not _lastEditedByParticipant Is relatedEntity Then
				DesetupSyncLastEditedByParticipant(True, True)
				_lastEditedByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _lastEditedByParticipant, AddressOf OnLastEditedByParticipantPropertyChanged, "LastEditedByParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingLastEditedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnLastEditedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _managerParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncManagerParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _managerParticipant, AddressOf OnManagerParticipantPropertyChanged, "ManagerParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingManagerIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.ManagerId) } )
			_managerParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _managerParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncManagerParticipant(relatedEntity As IEntityCore)
			If Not _managerParticipant Is relatedEntity Then
				DesetupSyncManagerParticipant(True, True)
				_managerParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _managerParticipant, AddressOf OnManagerParticipantPropertyChanged, "ManagerParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingManagerIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnManagerParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingContainmentLeadIdStatic, True, signalRelatedEntity, "Case_____", resetFKFields, New Integer() { CInt(CaseFieldIndex.ContainmentLeadId) } )
			_participant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant(relatedEntity As IEntityCore)
			If Not _participant Is relatedEntity Then
				DesetupSyncParticipant(True, True)
				_participant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingContainmentLeadIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _technicalSpecialistParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTechnicalSpecialistParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _technicalSpecialistParticipant, AddressOf OnTechnicalSpecialistParticipantPropertyChanged, "TechnicalSpecialistParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingTechnicalSpecialistIdStatic, True, signalRelatedEntity, "Case___", resetFKFields, New Integer() { CInt(CaseFieldIndex.TechnicalSpecialistId) } )
			_technicalSpecialistParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _technicalSpecialistParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTechnicalSpecialistParticipant(relatedEntity As IEntityCore)
			If Not _technicalSpecialistParticipant Is relatedEntity Then
				DesetupSyncTechnicalSpecialistParticipant(True, True)
				_technicalSpecialistParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _technicalSpecialistParticipant, AddressOf OnTechnicalSpecialistParticipantPropertyChanged, "TechnicalSpecialistParticipant", PManagement.Data.RelationClasses.StaticCaseRelations.ParticipantEntityUsingTechnicalSpecialistIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTechnicalSpecialistParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _pbu</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncPbu(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _pbu, AddressOf OnPbuPropertyChanged, "Pbu", PManagement.Data.RelationClasses.StaticCaseRelations.PbuEntityUsingPbuidStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.Pbuid) } )
			_pbu = Nothing
		End Sub

		''' <summary>setups the sync logic for member _pbu</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncPbu(relatedEntity As IEntityCore)
			If Not _pbu Is relatedEntity Then
				DesetupSyncPbu(True, True)
				_pbu = CType(relatedEntity, PbuEntity)
				Me.PerformSetupSyncRelatedEntity( _pbu, AddressOf OnPbuPropertyChanged, "Pbu", PManagement.Data.RelationClasses.StaticCaseRelations.PbuEntityUsingPbuidStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnPbuPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _personalSafety</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncPersonalSafety(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _personalSafety, AddressOf OnPersonalSafetyPropertyChanged, "PersonalSafety", PManagement.Data.RelationClasses.StaticCaseRelations.PersonalSafetyEntityUsingPersonalSafetyIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.PersonalSafetyId) } )
			_personalSafety = Nothing
		End Sub

		''' <summary>setups the sync logic for member _personalSafety</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncPersonalSafety(relatedEntity As IEntityCore)
			If Not _personalSafety Is relatedEntity Then
				DesetupSyncPersonalSafety(True, True)
				_personalSafety = CType(relatedEntity, PersonalSafetyEntity)
				Me.PerformSetupSyncRelatedEntity( _personalSafety, AddressOf OnPersonalSafetyPropertyChanged, "PersonalSafety", PManagement.Data.RelationClasses.StaticCaseRelations.PersonalSafetyEntityUsingPersonalSafetyIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnPersonalSafetyPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _phase</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncPhase(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _phase, AddressOf OnPhasePropertyChanged, "Phase", PManagement.Data.RelationClasses.StaticCaseRelations.PhaseEntityUsingPhaseIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.PhaseId) } )
			_phase = Nothing
		End Sub

		''' <summary>setups the sync logic for member _phase</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncPhase(relatedEntity As IEntityCore)
			If Not _phase Is relatedEntity Then
				DesetupSyncPhase(True, True)
				_phase = CType(relatedEntity, PhaseEntity)
				Me.PerformSetupSyncRelatedEntity( _phase, AddressOf OnPhasePropertyChanged, "Phase", PManagement.Data.RelationClasses.StaticCaseRelations.PhaseEntityUsingPhaseIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnPhasePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _platform_</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncPlatform_(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _platform_, AddressOf OnPlatform_PropertyChanged, "Platform_", PManagement.Data.RelationClasses.StaticCaseRelations.PlatformEntityUsingPlatformStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.Platform) } )
			_platform_ = Nothing
		End Sub

		''' <summary>setups the sync logic for member _platform_</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncPlatform_(relatedEntity As IEntityCore)
			If Not _platform_ Is relatedEntity Then
				DesetupSyncPlatform_(True, True)
				_platform_ = CType(relatedEntity, PlatformEntity)
				Me.PerformSetupSyncRelatedEntity( _platform_, AddressOf OnPlatform_PropertyChanged, "Platform_", PManagement.Data.RelationClasses.StaticCaseRelations.PlatformEntityUsingPlatformStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnPlatform_PropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _portfolio</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncPortfolio(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _portfolio, AddressOf OnPortfolioPropertyChanged, "Portfolio", PManagement.Data.RelationClasses.StaticCaseRelations.PortfolioEntityUsingPortfolioIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.PortfolioId) } )
			_portfolio = Nothing
		End Sub

		''' <summary>setups the sync logic for member _portfolio</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncPortfolio(relatedEntity As IEntityCore)
			If Not _portfolio Is relatedEntity Then
				DesetupSyncPortfolio(True, True)
				_portfolio = CType(relatedEntity, PortfolioEntity)
				Me.PerformSetupSyncRelatedEntity( _portfolio, AddressOf OnPortfolioPropertyChanged, "Portfolio", PManagement.Data.RelationClasses.StaticCaseRelations.PortfolioEntityUsingPortfolioIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnPortfolioPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _projectScope</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncProjectScope(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _projectScope, AddressOf OnProjectScopePropertyChanged, "ProjectScope", PManagement.Data.RelationClasses.StaticCaseRelations.ProjectScopeEntityUsingProjectScopeIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.ProjectScopeId) } )
			_projectScope = Nothing
		End Sub

		''' <summary>setups the sync logic for member _projectScope</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncProjectScope(relatedEntity As IEntityCore)
			If Not _projectScope Is relatedEntity Then
				DesetupSyncProjectScope(True, True)
				_projectScope = CType(relatedEntity, ProjectScopeEntity)
				Me.PerformSetupSyncRelatedEntity( _projectScope, AddressOf OnProjectScopePropertyChanged, "ProjectScope", PManagement.Data.RelationClasses.StaticCaseRelations.ProjectScopeEntityUsingProjectScopeIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnProjectScopePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _standardTask</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncStandardTask(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _standardTask, AddressOf OnStandardTaskPropertyChanged, "StandardTask", PManagement.Data.RelationClasses.StaticCaseRelations.StandardTaskEntityUsingStandardTaskIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.StandardTaskId) } )
			_standardTask = Nothing
		End Sub

		''' <summary>setups the sync logic for member _standardTask</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncStandardTask(relatedEntity As IEntityCore)
			If Not _standardTask Is relatedEntity Then
				DesetupSyncStandardTask(True, True)
				_standardTask = CType(relatedEntity, StandardTaskEntity)
				Me.PerformSetupSyncRelatedEntity( _standardTask, AddressOf OnStandardTaskPropertyChanged, "StandardTask", PManagement.Data.RelationClasses.StaticCaseRelations.StandardTaskEntityUsingStandardTaskIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnStandardTaskPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _status</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncStatus(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _status, AddressOf OnStatusPropertyChanged, "Status", PManagement.Data.RelationClasses.StaticCaseRelations.StatusEntityUsingStatusIdStatic, True, signalRelatedEntity, "Case", resetFKFields, New Integer() { CInt(CaseFieldIndex.StatusId) } )
			_status = Nothing
		End Sub

		''' <summary>setups the sync logic for member _status</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncStatus(relatedEntity As IEntityCore)
			If Not _status Is relatedEntity Then
				DesetupSyncStatus(True, True)
				_status = CType(relatedEntity, StatusEntity)
				Me.PerformSetupSyncRelatedEntity( _status, AddressOf OnStatusPropertyChanged, "Status", PManagement.Data.RelationClasses.StaticCaseRelations.StatusEntityUsingStatusIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnStatusPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this CaseEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

      ' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
      ' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As CaseRelations
			Get	
				Return New CaseRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathChildCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					CType(GetRelationsForField("ChildCase")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ChildCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2CaseBundle'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2CaseBundle() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2CaseBundleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2CaseBundleEntityFactory))), _
					CType(GetRelationsForField("Case2CaseBundle")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2CaseBundleEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2CaseBundle", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2ComponentType'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2ComponentType() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2ComponentTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ComponentTypeEntityFactory))), _
					CType(GetRelationsForField("Case2ComponentType")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2ComponentTypeEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2ComponentType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2Item'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2Item() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2ItemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ItemEntityFactory))), _
					CType(GetRelationsForField("Case2Item")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2ItemEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2Item", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2LogInfo'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2LogInfo() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2LogInfoEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2LogInfoEntityFactory))), _
					CType(GetRelationsForField("Case2LogInfo")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2LogInfoEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2LogInfo", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2Participant'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2Participant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ParticipantEntityFactory))), _
					CType(GetRelationsForField("Case2Participant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2Phase'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2Phase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2PhaseEntityFactory))), _
					CType(GetRelationsForField("Case2Phase")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2PhaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2Phase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2ReasonCode'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2ReasonCode() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2ReasonCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ReasonCodeEntityFactory))), _
					CType(GetRelationsForField("Case2ReasonCode")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2ReasonCodeEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2ReasonCode", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2Sbu'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2Sbu() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2SbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SbuEntityFactory))), _
					CType(GetRelationsForField("Case2Sbu")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2SbuEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2Sbu", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2ServiceCode'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2ServiceCode() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2ServiceCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ServiceCodeEntityFactory))), _
					CType(GetRelationsForField("Case2ServiceCode")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2ServiceCodeEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2ServiceCode", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2Supplier'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2Supplier() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SupplierEntityFactory))), _
					CType(GetRelationsForField("Case2Supplier")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2SupplierEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2Supplier", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2System'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2System() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2SystemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SystemEntityFactory))), _
					CType(GetRelationsForField("Case2System")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2SystemEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2System", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2TurbineMatrix'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2TurbineUnitType() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2TurbineMatrixEntityFactory))), _
					CType(GetRelationsForField("Case2TurbineUnitType")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2TurbineMatrixEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2TurbineUnitType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ChangeLog'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathChangeLog() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of ChangeLogEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ChangeLogEntityFactory))), _
					CType(GetRelationsForField("ChangeLog")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ChangeLogEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ChangeLog", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Cir'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCir() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of CirEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CirEntityFactory))), _
					CType(GetRelationsForField("Cir")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.CirEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Cir", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Discussion'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDiscussion() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory))), _
					CType(GetRelationsForField("Discussion")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Discussion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Folder'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolder() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory))), _
					CType(GetRelationsForField("Folder")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.FolderEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Folder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Milestone'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathMilestone() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of MilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(MilestoneEntityFactory))), _
					CType(GetRelationsForField("Milestone")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.MilestoneEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Milestone", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'News'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathNews() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of NewsEntity)(EntityFactoryCache2.GetEntityFactory(GetType(NewsEntityFactory))), _
					CType(GetRelationsForField("News")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.NewsEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "News", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'OldCimturbine'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathOldCimturbine() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of OldCimturbineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(OldCimturbineEntityFactory))), _
					CType(GetRelationsForField("OldCimturbine")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.OldCimturbineEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "OldCimturbine", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Populationlist'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPopulationlist() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of PopulationlistEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PopulationlistEntityFactory))), _
					CType(GetRelationsForField("Populationlist")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PopulationlistEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Populationlist", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Rc'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRc() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of RcEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcEntityFactory))), _
					CType(GetRelationsForField("Rc")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.RcEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Rc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RelatedCase'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRelatedCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of RelatedCaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RelatedCaseEntityFactory))), _
					CType(GetRelationsForField("RelatedCase")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.RelatedCaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "RelatedCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RelatedCase'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRelatedCase_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of RelatedCaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RelatedCaseEntityFactory))), _
					CType(GetRelationsForField("RelatedCase_")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.RelatedCaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "RelatedCase_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Timeline'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTimeline() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of TimelineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TimelineEntityFactory))), _
					CType(GetRelationsForField("Timeline")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.TimelineEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Timeline", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Visits'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathVisits() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of VisitsEntity)(EntityFactoryCache2.GetEntityFactory(GetType(VisitsEntityFactory))), _
					CType(GetRelationsForField("Visits")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.VisitsEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Visits", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrandCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BrandCollectionViaCase"), Nothing, "BrandCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'BusinessProcess' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBusinessProcessCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.BusinessProcessEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BusinessProcessCollectionViaCase"), Nothing, "BusinessProcessCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2Supplier' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2SupplierCollectionViaCase2ComponentType() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2ComponentTypeEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2ComponentType_")
				Return New PrefetchPathElement2( New EntityCollection(Of Case2SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SupplierEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.Case2SupplierEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("Case2SupplierCollectionViaCase2ComponentType"), Nothing, "Case2SupplierCollectionViaCase2ComponentType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'CaseBundle' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCaseBundleCollectionViaCase2CaseBundle() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2CaseBundleEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2CaseBundle_")
				Return New PrefetchPathElement2( New EntityCollection(Of CaseBundleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseBundleEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.CaseBundleEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CaseBundleCollectionViaCase2CaseBundle"), Nothing, "CaseBundleCollectionViaCase2CaseBundle", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Category' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCategoryCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of CategoryEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.CategoryEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CategoryCollectionViaCase"), Nothing, "CategoryCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ChangeType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathChangeTypeCollectionViaChangeLog() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.ChangeLogEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "ChangeLog_")
				Return New PrefetchPathElement2( New EntityCollection(Of ChangeTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ChangeTypeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ChangeTypeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ChangeTypeCollectionViaChangeLog"), Nothing, "ChangeTypeCollectionViaChangeLog", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ClaimStatus' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathClaimStatusCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ClaimStatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ClaimStatusCollectionViaCase"), Nothing, "ClaimStatusCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Component' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathComponentCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ComponentEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ComponentCollectionViaCase"), Nothing, "ComponentCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ComponentType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathComponentTypeCollectionViaCase2ComponentType() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2ComponentTypeEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2ComponentType_")
				Return New PrefetchPathElement2( New EntityCollection(Of ComponentTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentTypeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ComponentTypeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ComponentTypeCollectionViaCase2ComponentType"), Nothing, "ComponentTypeCollectionViaCase2ComponentType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Discussion' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDiscussionCollectionViaDiscussion() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.DiscussionEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Discussion_")
				Return New PrefetchPathElement2( New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("DiscussionCollectionViaDiscussion"), Nothing, "DiscussionCollectionViaDiscussion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Folder' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolderCollectionViaFolder() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.FolderEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Folder_")
				Return New PrefetchPathElement2( New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.FolderEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("FolderCollectionViaFolder"), Nothing, "FolderCollectionViaFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'FolderType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolderTypeCollectionViaFolder() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.FolderEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Folder_")
				Return New PrefetchPathElement2( New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.FolderTypeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("FolderTypeCollectionViaFolder"), Nothing, "FolderTypeCollectionViaFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Item' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathItemCollectionViaCase2Item() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2ItemEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2Item_")
				Return New PrefetchPathElement2( New EntityCollection(Of ItemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ItemEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ItemEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ItemCollectionViaCase2Item"), Nothing, "ItemCollectionViaCase2Item", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'LogInfo' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathLogInfoCollectionViaCase2LogInfo() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2LogInfoEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2LogInfo_")
				Return New PrefetchPathElement2( New EntityCollection(Of LogInfoEntity)(EntityFactoryCache2.GetEntityFactory(GetType(LogInfoEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.LogInfoEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("LogInfoCollectionViaCase2LogInfo"), Nothing, "LogInfoCollectionViaCase2LogInfo", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase"), Nothing, "ParticipantCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase_"), Nothing, "ParticipantCollectionViaCase_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase__() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase__"), Nothing, "ParticipantCollectionViaCase__", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase___() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase___"), Nothing, "ParticipantCollectionViaCase___", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase____() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase____"), Nothing, "ParticipantCollectionViaCase____", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase_____() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase_____"), Nothing, "ParticipantCollectionViaCase_____", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase2Participant() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2ParticipantEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2Participant_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase2Participant"), Nothing, "ParticipantCollectionViaCase2Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaChangeLog() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.ChangeLogEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "ChangeLog_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaChangeLog"), Nothing, "ParticipantCollectionViaChangeLog", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaChangeLog_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.ChangeLogEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "ChangeLog_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaChangeLog_"), Nothing, "ParticipantCollectionViaChangeLog_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCir() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CirEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Cir_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCir"), Nothing, "ParticipantCollectionViaCir", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCir_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CirEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Cir_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCir_"), Nothing, "ParticipantCollectionViaCir_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaDiscussion() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.DiscussionEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Discussion_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaDiscussion"), Nothing, "ParticipantCollectionViaDiscussion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaDiscussion_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.DiscussionEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Discussion_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaDiscussion_"), Nothing, "ParticipantCollectionViaDiscussion_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaFolder() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.FolderEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Folder_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaFolder"), Nothing, "ParticipantCollectionViaFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaFolder_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.FolderEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Folder_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaFolder_"), Nothing, "ParticipantCollectionViaFolder_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaMilestone() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.MilestoneEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Milestone_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaMilestone"), Nothing, "ParticipantCollectionViaMilestone", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaNews() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.NewsEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "News_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaNews"), Nothing, "ParticipantCollectionViaNews", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaNews_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.NewsEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "News_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaNews_"), Nothing, "ParticipantCollectionViaNews_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaPopulationlist() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.PopulationlistEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Populationlist_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaPopulationlist"), Nothing, "ParticipantCollectionViaPopulationlist", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.RcEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaRc"), Nothing, "ParticipantCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaRc_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.RcEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaRc_"), Nothing, "ParticipantCollectionViaRc_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaTimeline() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.TimelineEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Timeline_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaTimeline"), Nothing, "ParticipantCollectionViaTimeline", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaVisits() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.VisitsEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Visits_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaVisits"), Nothing, "ParticipantCollectionViaVisits", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaVisits_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.VisitsEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Visits_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaVisits_"), Nothing, "ParticipantCollectionViaVisits_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ParticipationType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipationTypeCollectionViaCase2Participant() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2ParticipantEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2Participant_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipationTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipationTypeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipationTypeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipationTypeCollectionViaCase2Participant"), Nothing, "ParticipationTypeCollectionViaCase2Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Pbu' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPbuCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PbuEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PbuCollectionViaCase"), Nothing, "PbuCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'PersonalSafety' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPersonalSafetyCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PersonalSafetyEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PersonalSafetyCollectionViaCase"), Nothing, "PersonalSafetyCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaCase"), Nothing, "PhaseCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaCase2Phase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2PhaseEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2Phase_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaCase2Phase"), Nothing, "PhaseCollectionViaCase2Phase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaPopulationlist() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.PopulationlistEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Populationlist_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaPopulationlist"), Nothing, "PhaseCollectionViaPopulationlist", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Platform' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPlatformCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PlatformEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PlatformCollectionViaCase"), Nothing, "PlatformCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Portfolio' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPortfolioCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PortfolioEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PortfolioCollectionViaCase"), Nothing, "PortfolioCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ProjectScope' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathProjectScopeCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ProjectScopeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ProjectScopeCollectionViaCase"), Nothing, "ProjectScopeCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RccomponentOwner' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRccomponentOwnerCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.RcEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of RccomponentOwnerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RccomponentOwnerEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.RccomponentOwnerEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RccomponentOwnerCollectionViaRc"), Nothing, "RccomponentOwnerCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Rcorigin' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.RcEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.RcoriginEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RcoriginCollectionViaRc"), Nothing, "RcoriginCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RcoriginResponsible' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginResponsibleCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.RcEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginResponsibleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginResponsibleEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RcoriginResponsibleCollectionViaRc"), Nothing, "RcoriginResponsibleCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RcoriginUnit' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginUnitCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.RcEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.RcoriginUnitEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RcoriginUnitCollectionViaRc"), Nothing, "RcoriginUnitCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ReasonCode' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathReasonCodeCollectionViaCase2ReasonCode() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2ReasonCodeEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2ReasonCode_")
				Return New PrefetchPathElement2( New EntityCollection(Of ReasonCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ReasonCodeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ReasonCodeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ReasonCodeCollectionViaCase2ReasonCode"), Nothing, "ReasonCodeCollectionViaCase2ReasonCode", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ReportType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathReportTypeCollectionViaCir() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CirEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Cir_")
				Return New PrefetchPathElement2( New EntityCollection(Of ReportTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ReportTypeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ReportTypeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ReportTypeCollectionViaCir"), Nothing, "ReportTypeCollectionViaCir", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Sbu' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathSbuCollectionViaCase2Sbu() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2SbuEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2Sbu_")
				Return New PrefetchPathElement2( New EntityCollection(Of SbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SbuEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.SbuEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("SbuCollectionViaCase2Sbu"), Nothing, "SbuCollectionViaCase2Sbu", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ServiceCode' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathServiceCodeCollectionViaCase2ServiceCode() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2ServiceCodeEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2ServiceCode_")
				Return New PrefetchPathElement2( New EntityCollection(Of ServiceCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ServiceCodeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ServiceCodeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ServiceCodeCollectionViaCase2ServiceCode"), Nothing, "ServiceCodeCollectionViaCase2ServiceCode", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardTask' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardTaskCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.StandardTaskEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StandardTaskCollectionViaCase"), Nothing, "StandardTaskCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'State' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStateCollectionViaPopulationlist() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.PopulationlistEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Populationlist_")
				Return New PrefetchPathElement2( New EntityCollection(Of StateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StateEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.StateEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StateCollectionViaPopulationlist"), Nothing, "StateCollectionViaPopulationlist", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Status' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStatusCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.CaseEntityUsingUplink
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.StatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StatusCollectionViaCase"), Nothing, "StatusCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Status' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStatusCollectionViaPopulationlist() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.PopulationlistEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Populationlist_")
				Return New PrefetchPathElement2( New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.StatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StatusCollectionViaPopulationlist"), Nothing, "StatusCollectionViaPopulationlist", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Supplier' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathSupplierCollectionViaCase2Supplier() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2SupplierEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2Supplier_")
				Return New PrefetchPathElement2( New EntityCollection(Of SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SupplierEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.SupplierEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("SupplierCollectionViaCase2Supplier"), Nothing, "SupplierCollectionViaCase2Supplier", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'SystemDescription' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathSystemDescriptionCollectionViaCase2System() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2SystemEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2System_")
				Return New PrefetchPathElement2( New EntityCollection(Of SystemDescriptionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SystemDescriptionEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.SystemDescriptionEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("SystemDescriptionCollectionViaCase2System"), Nothing, "SystemDescriptionCollectionViaCase2System", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineMatrix' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineMatrixCollectionViaCase2TurbineUnitType() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CaseEntity.Relations.Case2TurbineMatrixEntityUsingCaseId
				intermediateRelation.SetAliases(String.Empty, "Case2TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMatrixEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineMatrixCollectionViaCase2TurbineUnitType"), Nothing, "TurbineMatrixCollectionViaCase2TurbineUnitType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrand() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					CType(GetRelationsForField("Brand")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Brand", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'BusinessProcess' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBusinessProcess() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory))), _
					CType(GetRelationsForField("BusinessProcess")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.BusinessProcessEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "BusinessProcess", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParentCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					CType(GetRelationsForField("ParentCase")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ParentCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Category' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCategory() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory))), _
					CType(GetRelationsForField("Category")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.CategoryEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Category", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ClaimStatus' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathClaimStatus() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory))), _
					CType(GetRelationsForField("ClaimStatus")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ClaimStatusEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ClaimStatus", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Component' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathComponent() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory))), _
					CType(GetRelationsForField("Component")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ComponentEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Component", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCreatedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("CreatedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "CreatedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathExecutionManagerParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("ExecutionManagerParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ExecutionManagerParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathLastEditedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("LastEditedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "LastEditedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathManagerParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("ManagerParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ManagerParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTechnicalSpecialistParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("TechnicalSpecialistParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TechnicalSpecialistParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Pbu' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPbu() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory))), _
					CType(GetRelationsForField("Pbu")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PbuEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Pbu", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'PersonalSafety' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPersonalSafety() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory))), _
					CType(GetRelationsForField("PersonalSafety")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PersonalSafetyEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "PersonalSafety", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					CType(GetRelationsForField("Phase")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Phase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Platform' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPlatform_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory))), _
					CType(GetRelationsForField("Platform_")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PlatformEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Platform_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Portfolio' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPortfolio() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory))), _
					CType(GetRelationsForField("Portfolio")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.PortfolioEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Portfolio", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ProjectScope' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathProjectScope() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory))), _
					CType(GetRelationsForField("ProjectScope")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.ProjectScopeEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ProjectScope", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardTask' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardTask() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory))), _
					CType(GetRelationsForField("StandardTask")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.StandardTaskEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "StandardTask", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Status' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStatus() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory))), _
					CType(GetRelationsForField("Status")(0), IEntityRelation), CType(PManagement.Data.EntityType.CaseEntity, Integer), CType(PManagement.Data.EntityType.StatusEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Status", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return CaseEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return CaseEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The CaseId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."CaseId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [CaseId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.CaseId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.CaseId), value)
			End Set
		End Property
		''' <summary>The BrandId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."BrandId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [BrandId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.BrandId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.BrandId), value)
			End Set
		End Property
		''' <summary>The CaseNo property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."CaseNo"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CaseNo]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.CaseNo), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.CaseNo), value)
			End Set
		End Property
		''' <summary>The PhaseId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."PhaseId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [PhaseId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.PhaseId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.PhaseId), value)
			End Set
		End Property
		''' <summary>The StatusId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."StatusId"<br/>
		''' Table field type characteristics (type, precision, scale, length): TinyInt, 3, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [StatusId]() As System.Byte
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.StatusId), True), System.Byte)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.StatusId), value)
			End Set
		End Property
		''' <summary>The ClaimStatusId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ClaimStatusId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ClaimStatusId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ClaimStatusId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ClaimStatusId), value)
			End Set
		End Property
		''' <summary>The Pbuid property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."PBUId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Pbuid]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Pbuid), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Pbuid), value)
			End Set
		End Property
		''' <summary>The ProjectPortalId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ProjectPortalId"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ProjectPortalId]() As System.Int32
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ProjectPortalId), True), System.Int32)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ProjectPortalId), value)
			End Set
		End Property
		''' <summary>The ManagerId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ManagerId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ManagerId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ManagerId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ManagerId), value)
			End Set
		End Property
		''' <summary>The Uplink property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."Uplink"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Uplink]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Uplink), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Uplink), value)
			End Set
		End Property
		''' <summary>The Description property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."Description"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 4000<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Description]() As System.String
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Description), True), System.String)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Description), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The CreatedById property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.CreatedById), value)
			End Set
		End Property
		''' <summary>The LastEdited property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."LastEdited"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [LastEdited]() As System.DateTime
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.LastEdited), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.LastEdited), value)
			End Set
		End Property
		''' <summary>The LastEditedById property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."LastEditedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [LastEditedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.LastEditedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.LastEditedById), value)
			End Set
		End Property
		''' <summary>The StandbyText property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."StandbyText"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 100<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [StandbyText]() As System.String
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.StandbyText), True), System.String)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.StandbyText), value)
			End Set
		End Property
		''' <summary>The ConfirmedBySupplier property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ConfirmedBySupplier"<br/>
		''' Table field type characteristics (type, precision, scale, length): Bit, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ConfirmedBySupplier]() As System.Boolean
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ConfirmedBySupplier), True), System.Boolean)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ConfirmedBySupplier), value)
			End Set
		End Property
		''' <summary>The HasProcessedMsprojectPlan property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."HasProcessedMSProjectPlan"<br/>
		''' Table field type characteristics (type, precision, scale, length): Bit, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [HasProcessedMsprojectPlan]() As System.Boolean
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.HasProcessedMsprojectPlan), True), System.Boolean)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.HasProcessedMsprojectPlan), value)
			End Set
		End Property
		''' <summary>The StartDate property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."StartDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [StartDate]() As System.DateTime
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.StartDate), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.StartDate), value)
			End Set
		End Property
		''' <summary>The FinishDate property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."FinishDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [FinishDate]() As System.DateTime
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.FinishDate), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.FinishDate), value)
			End Set
		End Property
		''' <summary>The DurationHours property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."DurationHours"<br/>
		''' Table field type characteristics (type, precision, scale, length): Decimal, 7, 2, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [DurationHours]() As System.Decimal
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.DurationHours), True), System.Decimal)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.DurationHours), value)
			End Set
		End Property
		''' <summary>The PercentComplete property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."PercentComplete"<br/>
		''' Table field type characteristics (type, precision, scale, length): TinyInt, 3, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [PercentComplete]() As System.Byte
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.PercentComplete), True), System.Byte)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.PercentComplete), value)
			End Set
		End Property
		''' <summary>The SalesOption property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."SalesOption"<br/>
		''' Table field type characteristics (type, precision, scale, length): Bit, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [SalesOption]() As System.Boolean
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.SalesOption), True), System.Boolean)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.SalesOption), value)
			End Set
		End Property
		''' <summary>The Platform property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."Platform"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Platform]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Platform), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Platform), value)
			End Set
		End Property
		''' <summary>The ClosureDate property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ClosureDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ClosureDate]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ClosureDate), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ClosureDate), value)
			End Set
		End Property
		''' <summary>The ReopenDate property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ReopenDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ReopenDate]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ReopenDate), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ReopenDate), value)
			End Set
		End Property
		''' <summary>The TechnicalSpecialistId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."TechnicalSpecialistId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TechnicalSpecialistId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.TechnicalSpecialistId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.TechnicalSpecialistId), value)
			End Set
		End Property
		''' <summary>The ExecutionManagerId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ExecutionManagerId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ExecutionManagerId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ExecutionManagerId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ExecutionManagerId), value)
			End Set
		End Property
		''' <summary>The ClosedForInvoicing property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ClosedForInvoicing"<br/>
		''' Table field type characteristics (type, precision, scale, length): Bit, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ClosedForInvoicing]() As System.Boolean
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ClosedForInvoicing), True), System.Boolean)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ClosedForInvoicing), value)
			End Set
		End Property
		''' <summary>The PortfolioId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."PortfolioId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [PortfolioId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.PortfolioId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.PortfolioId), value)
			End Set
		End Property
		''' <summary>The BusinessProcessId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."BusinessProcessId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [BusinessProcessId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.BusinessProcessId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.BusinessProcessId), value)
			End Set
		End Property
		''' <summary>The StandardTaskId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."StandardTaskId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [StandardTaskId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.StandardTaskId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.StandardTaskId), value)
			End Set
		End Property
		''' <summary>The StandardTask_ property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."StandardTask"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [StandardTask_]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.StandardTask_), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.StandardTask_), value)
			End Set
		End Property
		''' <summary>The StateChangedDate property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."StateChangedDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [StateChangedDate]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.StateChangedDate), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.StateChangedDate), value)
			End Set
		End Property
		''' <summary>The CategoryId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."CategoryId"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [CategoryId]() As Nullable(Of System.Int32)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.CategoryId), False), Nullable(Of System.Int32))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.CategoryId), value)
			End Set
		End Property
		''' <summary>The ComponentId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ComponentId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ComponentId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ComponentId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ComponentId), value)
			End Set
		End Property
		''' <summary>The PersonalSafetyId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."PersonalSafetyId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [PersonalSafetyId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.PersonalSafetyId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.PersonalSafetyId), value)
			End Set
		End Property
		''' <summary>The Bleeding property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."Bleeding"<br/>
		''' Table field type characteristics (type, precision, scale, length): NChar, 0, 0, 10<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Bleeding]() As System.String
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Bleeding), True), System.String)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Bleeding), value)
			End Set
		End Property
		''' <summary>The SafetyAlert property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."Safety Alert"<br/>
		''' Table field type characteristics (type, precision, scale, length): NChar, 0, 0, 10<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [SafetyAlert]() As System.String
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.SafetyAlert), True), System.String)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.SafetyAlert), value)
			End Set
		End Property
		''' <summary>The Dmsdocument property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."DMSDocument"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 10<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Dmsdocument]() As System.String
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Dmsdocument), True), System.String)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Dmsdocument), value)
			End Set
		End Property
		''' <summary>The ReferenceNumber property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ReferenceNumber"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ReferenceNumber]() As System.String
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ReferenceNumber), True), System.String)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ReferenceNumber), value)
			End Set
		End Property
		''' <summary>The Econumber property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ECONumber"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Econumber]() As System.String
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.Econumber), True), System.String)
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.Econumber), value)
			End Set
		End Property
		''' <summary>The ContainmentLeadId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ContainmentLeadID"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ContainmentLeadId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ContainmentLeadId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ContainmentLeadId), value)
			End Set
		End Property
		''' <summary>The ProjectScopeId property of the Entity Case<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Case"."ProjectScopeID"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ProjectScopeId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CaseFieldIndex.ProjectScopeId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CaseFieldIndex.ProjectScopeId), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [ChildCase]() As EntityCollection(Of CaseEntity)
			Get
				If _childCase Is Nothing Then
					_childCase = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_childCase.ActiveContext = Me.ActiveContext
					_childCase.SetContainingEntityInfo(Me, "ParentCase")
				End If
				Return _childCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2CaseBundleEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2CaseBundleEntity))> _
		Public Overridable ReadOnly Property [Case2CaseBundle]() As EntityCollection(Of Case2CaseBundleEntity)
			Get
				If _case2CaseBundle Is Nothing Then
					_case2CaseBundle = New EntityCollection(Of Case2CaseBundleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2CaseBundleEntityFactory)))
					_case2CaseBundle.ActiveContext = Me.ActiveContext
					_case2CaseBundle.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2CaseBundle
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2ComponentTypeEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2ComponentTypeEntity))> _
		Public Overridable ReadOnly Property [Case2ComponentType]() As EntityCollection(Of Case2ComponentTypeEntity)
			Get
				If _case2ComponentType Is Nothing Then
					_case2ComponentType = New EntityCollection(Of Case2ComponentTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ComponentTypeEntityFactory)))
					_case2ComponentType.ActiveContext = Me.ActiveContext
					_case2ComponentType.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2ComponentType
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2ItemEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2ItemEntity))> _
		Public Overridable ReadOnly Property [Case2Item]() As EntityCollection(Of Case2ItemEntity)
			Get
				If _case2Item Is Nothing Then
					_case2Item = New EntityCollection(Of Case2ItemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ItemEntityFactory)))
					_case2Item.ActiveContext = Me.ActiveContext
					_case2Item.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2Item
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2LogInfoEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2LogInfoEntity))> _
		Public Overridable ReadOnly Property [Case2LogInfo]() As EntityCollection(Of Case2LogInfoEntity)
			Get
				If _case2LogInfo Is Nothing Then
					_case2LogInfo = New EntityCollection(Of Case2LogInfoEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2LogInfoEntityFactory)))
					_case2LogInfo.ActiveContext = Me.ActiveContext
					_case2LogInfo.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2LogInfo
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2ParticipantEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2ParticipantEntity))> _
		Public Overridable ReadOnly Property [Case2Participant]() As EntityCollection(Of Case2ParticipantEntity)
			Get
				If _case2Participant Is Nothing Then
					_case2Participant = New EntityCollection(Of Case2ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ParticipantEntityFactory)))
					_case2Participant.ActiveContext = Me.ActiveContext
					_case2Participant.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2Participant
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2PhaseEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2PhaseEntity))> _
		Public Overridable ReadOnly Property [Case2Phase]() As EntityCollection(Of Case2PhaseEntity)
			Get
				If _case2Phase Is Nothing Then
					_case2Phase = New EntityCollection(Of Case2PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2PhaseEntityFactory)))
					_case2Phase.ActiveContext = Me.ActiveContext
					_case2Phase.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2Phase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2ReasonCodeEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2ReasonCodeEntity))> _
		Public Overridable ReadOnly Property [Case2ReasonCode]() As EntityCollection(Of Case2ReasonCodeEntity)
			Get
				If _case2ReasonCode Is Nothing Then
					_case2ReasonCode = New EntityCollection(Of Case2ReasonCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ReasonCodeEntityFactory)))
					_case2ReasonCode.ActiveContext = Me.ActiveContext
					_case2ReasonCode.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2ReasonCode
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2SbuEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2SbuEntity))> _
		Public Overridable ReadOnly Property [Case2Sbu]() As EntityCollection(Of Case2SbuEntity)
			Get
				If _case2Sbu Is Nothing Then
					_case2Sbu = New EntityCollection(Of Case2SbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SbuEntityFactory)))
					_case2Sbu.ActiveContext = Me.ActiveContext
					_case2Sbu.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2Sbu
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2ServiceCodeEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2ServiceCodeEntity))> _
		Public Overridable ReadOnly Property [Case2ServiceCode]() As EntityCollection(Of Case2ServiceCodeEntity)
			Get
				If _case2ServiceCode Is Nothing Then
					_case2ServiceCode = New EntityCollection(Of Case2ServiceCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2ServiceCodeEntityFactory)))
					_case2ServiceCode.ActiveContext = Me.ActiveContext
					_case2ServiceCode.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2ServiceCode
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2SupplierEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2SupplierEntity))> _
		Public Overridable ReadOnly Property [Case2Supplier]() As EntityCollection(Of Case2SupplierEntity)
			Get
				If _case2Supplier Is Nothing Then
					_case2Supplier = New EntityCollection(Of Case2SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SupplierEntityFactory)))
					_case2Supplier.ActiveContext = Me.ActiveContext
					_case2Supplier.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2Supplier
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2SystemEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2SystemEntity))> _
		Public Overridable ReadOnly Property [Case2System]() As EntityCollection(Of Case2SystemEntity)
			Get
				If _case2System Is Nothing Then
					_case2System = New EntityCollection(Of Case2SystemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SystemEntityFactory)))
					_case2System.ActiveContext = Me.ActiveContext
					_case2System.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2System
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2TurbineMatrixEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2TurbineMatrixEntity))> _
		Public Overridable ReadOnly Property [Case2TurbineUnitType]() As EntityCollection(Of Case2TurbineMatrixEntity)
			Get
				If _case2TurbineUnitType Is Nothing Then
					_case2TurbineUnitType = New EntityCollection(Of Case2TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2TurbineMatrixEntityFactory)))
					_case2TurbineUnitType.ActiveContext = Me.ActiveContext
					_case2TurbineUnitType.SetContainingEntityInfo(Me, "Case")
				End If
				Return _case2TurbineUnitType
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ChangeLogEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ChangeLogEntity))> _
		Public Overridable ReadOnly Property [ChangeLog]() As EntityCollection(Of ChangeLogEntity)
			Get
				If _changeLog Is Nothing Then
					_changeLog = New EntityCollection(Of ChangeLogEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ChangeLogEntityFactory)))
					_changeLog.ActiveContext = Me.ActiveContext
					_changeLog.SetContainingEntityInfo(Me, "Case")
				End If
				Return _changeLog
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CirEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CirEntity))> _
		Public Overridable ReadOnly Property [Cir]() As EntityCollection(Of CirEntity)
			Get
				If _cir Is Nothing Then
					_cir = New EntityCollection(Of CirEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CirEntityFactory)))
					_cir.ActiveContext = Me.ActiveContext
					_cir.SetContainingEntityInfo(Me, "Case")
				End If
				Return _cir
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'DiscussionEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(DiscussionEntity))> _
		Public Overridable ReadOnly Property [Discussion]() As EntityCollection(Of DiscussionEntity)
			Get
				If _discussion Is Nothing Then
					_discussion = New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory)))
					_discussion.ActiveContext = Me.ActiveContext
					_discussion.SetContainingEntityInfo(Me, "Case")
				End If
				Return _discussion
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'FolderEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(FolderEntity))> _
		Public Overridable ReadOnly Property [Folder]() As EntityCollection(Of FolderEntity)
			Get
				If _folder Is Nothing Then
					_folder = New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory)))
					_folder.ActiveContext = Me.ActiveContext
					_folder.SetContainingEntityInfo(Me, "Case")
				End If
				Return _folder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'MilestoneEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(MilestoneEntity))> _
		Public Overridable ReadOnly Property [Milestone]() As EntityCollection(Of MilestoneEntity)
			Get
				If _milestone Is Nothing Then
					_milestone = New EntityCollection(Of MilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(MilestoneEntityFactory)))
					_milestone.ActiveContext = Me.ActiveContext
					_milestone.SetContainingEntityInfo(Me, "Case")
				End If
				Return _milestone
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'NewsEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(NewsEntity))> _
		Public Overridable ReadOnly Property [News]() As EntityCollection(Of NewsEntity)
			Get
				If _news Is Nothing Then
					_news = New EntityCollection(Of NewsEntity)(EntityFactoryCache2.GetEntityFactory(GetType(NewsEntityFactory)))
					_news.ActiveContext = Me.ActiveContext
					_news.SetContainingEntityInfo(Me, "Case")
				End If
				Return _news
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'OldCimturbineEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(OldCimturbineEntity))> _
		Public Overridable ReadOnly Property [OldCimturbine]() As EntityCollection(Of OldCimturbineEntity)
			Get
				If _oldCimturbine Is Nothing Then
					_oldCimturbine = New EntityCollection(Of OldCimturbineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(OldCimturbineEntityFactory)))
					_oldCimturbine.ActiveContext = Me.ActiveContext
					_oldCimturbine.SetContainingEntityInfo(Me, "Case")
				End If
				Return _oldCimturbine
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PopulationlistEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PopulationlistEntity))> _
		Public Overridable ReadOnly Property [Populationlist]() As EntityCollection(Of PopulationlistEntity)
			Get
				If _populationlist Is Nothing Then
					_populationlist = New EntityCollection(Of PopulationlistEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PopulationlistEntityFactory)))
					_populationlist.ActiveContext = Me.ActiveContext
					_populationlist.SetContainingEntityInfo(Me, "Case")
				End If
				Return _populationlist
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcEntity))> _
		Public Overridable ReadOnly Property [Rc]() As EntityCollection(Of RcEntity)
			Get
				If _rc Is Nothing Then
					_rc = New EntityCollection(Of RcEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcEntityFactory)))
					_rc.ActiveContext = Me.ActiveContext
					_rc.SetContainingEntityInfo(Me, "Case")
				End If
				Return _rc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RelatedCaseEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RelatedCaseEntity))> _
		Public Overridable ReadOnly Property [RelatedCase]() As EntityCollection(Of RelatedCaseEntity)
			Get
				If _relatedCase Is Nothing Then
					_relatedCase = New EntityCollection(Of RelatedCaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RelatedCaseEntityFactory)))
					_relatedCase.ActiveContext = Me.ActiveContext
					_relatedCase.SetContainingEntityInfo(Me, "Case")
				End If
				Return _relatedCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RelatedCaseEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RelatedCaseEntity))> _
		Public Overridable ReadOnly Property [RelatedCase_]() As EntityCollection(Of RelatedCaseEntity)
			Get
				If _relatedCase_ Is Nothing Then
					_relatedCase_ = New EntityCollection(Of RelatedCaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RelatedCaseEntityFactory)))
					_relatedCase_.ActiveContext = Me.ActiveContext
					_relatedCase_.SetContainingEntityInfo(Me, "Case_")
				End If
				Return _relatedCase_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TimelineEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TimelineEntity))> _
		Public Overridable ReadOnly Property [Timeline]() As EntityCollection(Of TimelineEntity)
			Get
				If _timeline Is Nothing Then
					_timeline = New EntityCollection(Of TimelineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TimelineEntityFactory)))
					_timeline.ActiveContext = Me.ActiveContext
					_timeline.SetContainingEntityInfo(Me, "Case")
				End If
				Return _timeline
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'VisitsEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(VisitsEntity))> _
		Public Overridable ReadOnly Property [Visits]() As EntityCollection(Of VisitsEntity)
			Get
				If _visits Is Nothing Then
					_visits = New EntityCollection(Of VisitsEntity)(EntityFactoryCache2.GetEntityFactory(GetType(VisitsEntityFactory)))
					_visits.ActiveContext = Me.ActiveContext
					_visits.SetContainingEntityInfo(Me, "Case")
				End If
				Return _visits
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BrandEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BrandEntity))> _
		Public Overridable ReadOnly Property [BrandCollectionViaCase]() As EntityCollection(Of BrandEntity)
			Get
				If _brandCollectionViaCase Is Nothing Then
					_brandCollectionViaCase = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
					_brandCollectionViaCase.ActiveContext = Me.ActiveContext
					_brandCollectionViaCase.IsReadOnly = True
					CType(_brandCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _brandCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BusinessProcessEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BusinessProcessEntity))> _
		Public Overridable ReadOnly Property [BusinessProcessCollectionViaCase]() As EntityCollection(Of BusinessProcessEntity)
			Get
				If _businessProcessCollectionViaCase Is Nothing Then
					_businessProcessCollectionViaCase = New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory)))
					_businessProcessCollectionViaCase.ActiveContext = Me.ActiveContext
					_businessProcessCollectionViaCase.IsReadOnly = True
					CType(_businessProcessCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _businessProcessCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2SupplierEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2SupplierEntity))> _
		Public Overridable ReadOnly Property [Case2SupplierCollectionViaCase2ComponentType]() As EntityCollection(Of Case2SupplierEntity)
			Get
				If _case2SupplierCollectionViaCase2ComponentType Is Nothing Then
					_case2SupplierCollectionViaCase2ComponentType = New EntityCollection(Of Case2SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2SupplierEntityFactory)))
					_case2SupplierCollectionViaCase2ComponentType.ActiveContext = Me.ActiveContext
					_case2SupplierCollectionViaCase2ComponentType.IsReadOnly = True
					CType(_case2SupplierCollectionViaCase2ComponentType, IEntityCollectionCore).IsForMN = True
				End If
				Return _case2SupplierCollectionViaCase2ComponentType
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseBundleEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseBundleEntity))> _
		Public Overridable ReadOnly Property [CaseBundleCollectionViaCase2CaseBundle]() As EntityCollection(Of CaseBundleEntity)
			Get
				If _caseBundleCollectionViaCase2CaseBundle Is Nothing Then
					_caseBundleCollectionViaCase2CaseBundle = New EntityCollection(Of CaseBundleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseBundleEntityFactory)))
					_caseBundleCollectionViaCase2CaseBundle.ActiveContext = Me.ActiveContext
					_caseBundleCollectionViaCase2CaseBundle.IsReadOnly = True
					CType(_caseBundleCollectionViaCase2CaseBundle, IEntityCollectionCore).IsForMN = True
				End If
				Return _caseBundleCollectionViaCase2CaseBundle
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CategoryEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CategoryEntity))> _
		Public Overridable ReadOnly Property [CategoryCollectionViaCase]() As EntityCollection(Of CategoryEntity)
			Get
				If _categoryCollectionViaCase Is Nothing Then
					_categoryCollectionViaCase = New EntityCollection(Of CategoryEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory)))
					_categoryCollectionViaCase.ActiveContext = Me.ActiveContext
					_categoryCollectionViaCase.IsReadOnly = True
					CType(_categoryCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _categoryCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ChangeTypeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ChangeTypeEntity))> _
		Public Overridable ReadOnly Property [ChangeTypeCollectionViaChangeLog]() As EntityCollection(Of ChangeTypeEntity)
			Get
				If _changeTypeCollectionViaChangeLog Is Nothing Then
					_changeTypeCollectionViaChangeLog = New EntityCollection(Of ChangeTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ChangeTypeEntityFactory)))
					_changeTypeCollectionViaChangeLog.ActiveContext = Me.ActiveContext
					_changeTypeCollectionViaChangeLog.IsReadOnly = True
					CType(_changeTypeCollectionViaChangeLog, IEntityCollectionCore).IsForMN = True
				End If
				Return _changeTypeCollectionViaChangeLog
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ClaimStatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ClaimStatusEntity))> _
		Public Overridable ReadOnly Property [ClaimStatusCollectionViaCase]() As EntityCollection(Of ClaimStatusEntity)
			Get
				If _claimStatusCollectionViaCase Is Nothing Then
					_claimStatusCollectionViaCase = New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory)))
					_claimStatusCollectionViaCase.ActiveContext = Me.ActiveContext
					_claimStatusCollectionViaCase.IsReadOnly = True
					CType(_claimStatusCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _claimStatusCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ComponentEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ComponentEntity))> _
		Public Overridable ReadOnly Property [ComponentCollectionViaCase]() As EntityCollection(Of ComponentEntity)
			Get
				If _componentCollectionViaCase Is Nothing Then
					_componentCollectionViaCase = New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory)))
					_componentCollectionViaCase.ActiveContext = Me.ActiveContext
					_componentCollectionViaCase.IsReadOnly = True
					CType(_componentCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _componentCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ComponentTypeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ComponentTypeEntity))> _
		Public Overridable ReadOnly Property [ComponentTypeCollectionViaCase2ComponentType]() As EntityCollection(Of ComponentTypeEntity)
			Get
				If _componentTypeCollectionViaCase2ComponentType Is Nothing Then
					_componentTypeCollectionViaCase2ComponentType = New EntityCollection(Of ComponentTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentTypeEntityFactory)))
					_componentTypeCollectionViaCase2ComponentType.ActiveContext = Me.ActiveContext
					_componentTypeCollectionViaCase2ComponentType.IsReadOnly = True
					CType(_componentTypeCollectionViaCase2ComponentType, IEntityCollectionCore).IsForMN = True
				End If
				Return _componentTypeCollectionViaCase2ComponentType
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'DiscussionEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(DiscussionEntity))> _
		Public Overridable ReadOnly Property [DiscussionCollectionViaDiscussion]() As EntityCollection(Of DiscussionEntity)
			Get
				If _discussionCollectionViaDiscussion Is Nothing Then
					_discussionCollectionViaDiscussion = New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory)))
					_discussionCollectionViaDiscussion.ActiveContext = Me.ActiveContext
					_discussionCollectionViaDiscussion.IsReadOnly = True
					CType(_discussionCollectionViaDiscussion, IEntityCollectionCore).IsForMN = True
				End If
				Return _discussionCollectionViaDiscussion
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'FolderEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(FolderEntity))> _
		Public Overridable ReadOnly Property [FolderCollectionViaFolder]() As EntityCollection(Of FolderEntity)
			Get
				If _folderCollectionViaFolder Is Nothing Then
					_folderCollectionViaFolder = New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory)))
					_folderCollectionViaFolder.ActiveContext = Me.ActiveContext
					_folderCollectionViaFolder.IsReadOnly = True
					CType(_folderCollectionViaFolder, IEntityCollectionCore).IsForMN = True
				End If
				Return _folderCollectionViaFolder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'FolderTypeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(FolderTypeEntity))> _
		Public Overridable ReadOnly Property [FolderTypeCollectionViaFolder]() As EntityCollection(Of FolderTypeEntity)
			Get
				If _folderTypeCollectionViaFolder Is Nothing Then
					_folderTypeCollectionViaFolder = New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory)))
					_folderTypeCollectionViaFolder.ActiveContext = Me.ActiveContext
					_folderTypeCollectionViaFolder.IsReadOnly = True
					CType(_folderTypeCollectionViaFolder, IEntityCollectionCore).IsForMN = True
				End If
				Return _folderTypeCollectionViaFolder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ItemEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ItemEntity))> _
		Public Overridable ReadOnly Property [ItemCollectionViaCase2Item]() As EntityCollection(Of ItemEntity)
			Get
				If _itemCollectionViaCase2Item Is Nothing Then
					_itemCollectionViaCase2Item = New EntityCollection(Of ItemEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ItemEntityFactory)))
					_itemCollectionViaCase2Item.ActiveContext = Me.ActiveContext
					_itemCollectionViaCase2Item.IsReadOnly = True
					CType(_itemCollectionViaCase2Item, IEntityCollectionCore).IsForMN = True
				End If
				Return _itemCollectionViaCase2Item
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'LogInfoEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(LogInfoEntity))> _
		Public Overridable ReadOnly Property [LogInfoCollectionViaCase2LogInfo]() As EntityCollection(Of LogInfoEntity)
			Get
				If _logInfoCollectionViaCase2LogInfo Is Nothing Then
					_logInfoCollectionViaCase2LogInfo = New EntityCollection(Of LogInfoEntity)(EntityFactoryCache2.GetEntityFactory(GetType(LogInfoEntityFactory)))
					_logInfoCollectionViaCase2LogInfo.ActiveContext = Me.ActiveContext
					_logInfoCollectionViaCase2LogInfo.IsReadOnly = True
					CType(_logInfoCollectionViaCase2LogInfo, IEntityCollectionCore).IsForMN = True
				End If
				Return _logInfoCollectionViaCase2LogInfo
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase Is Nothing Then
					_participantCollectionViaCase = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase.IsReadOnly = True
					CType(_participantCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase_ Is Nothing Then
					_participantCollectionViaCase_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase_.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase_.IsReadOnly = True
					CType(_participantCollectionViaCase_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase__]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase__ Is Nothing Then
					_participantCollectionViaCase__ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase__.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase__.IsReadOnly = True
					CType(_participantCollectionViaCase__, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase__
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase___]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase___ Is Nothing Then
					_participantCollectionViaCase___ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase___.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase___.IsReadOnly = True
					CType(_participantCollectionViaCase___, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase___
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase____]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase____ Is Nothing Then
					_participantCollectionViaCase____ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase____.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase____.IsReadOnly = True
					CType(_participantCollectionViaCase____, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase____
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase_____]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase_____ Is Nothing Then
					_participantCollectionViaCase_____ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase_____.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase_____.IsReadOnly = True
					CType(_participantCollectionViaCase_____, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase_____
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase2Participant]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase2Participant Is Nothing Then
					_participantCollectionViaCase2Participant = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase2Participant.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase2Participant.IsReadOnly = True
					CType(_participantCollectionViaCase2Participant, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase2Participant
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaChangeLog]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaChangeLog Is Nothing Then
					_participantCollectionViaChangeLog = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaChangeLog.ActiveContext = Me.ActiveContext
					_participantCollectionViaChangeLog.IsReadOnly = True
					CType(_participantCollectionViaChangeLog, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaChangeLog
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaChangeLog_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaChangeLog_ Is Nothing Then
					_participantCollectionViaChangeLog_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaChangeLog_.ActiveContext = Me.ActiveContext
					_participantCollectionViaChangeLog_.IsReadOnly = True
					CType(_participantCollectionViaChangeLog_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaChangeLog_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCir]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCir Is Nothing Then
					_participantCollectionViaCir = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCir.ActiveContext = Me.ActiveContext
					_participantCollectionViaCir.IsReadOnly = True
					CType(_participantCollectionViaCir, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCir
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCir_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCir_ Is Nothing Then
					_participantCollectionViaCir_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCir_.ActiveContext = Me.ActiveContext
					_participantCollectionViaCir_.IsReadOnly = True
					CType(_participantCollectionViaCir_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCir_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaDiscussion]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaDiscussion Is Nothing Then
					_participantCollectionViaDiscussion = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaDiscussion.ActiveContext = Me.ActiveContext
					_participantCollectionViaDiscussion.IsReadOnly = True
					CType(_participantCollectionViaDiscussion, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaDiscussion
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaDiscussion_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaDiscussion_ Is Nothing Then
					_participantCollectionViaDiscussion_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaDiscussion_.ActiveContext = Me.ActiveContext
					_participantCollectionViaDiscussion_.IsReadOnly = True
					CType(_participantCollectionViaDiscussion_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaDiscussion_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaFolder]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaFolder Is Nothing Then
					_participantCollectionViaFolder = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaFolder.ActiveContext = Me.ActiveContext
					_participantCollectionViaFolder.IsReadOnly = True
					CType(_participantCollectionViaFolder, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaFolder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaFolder_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaFolder_ Is Nothing Then
					_participantCollectionViaFolder_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaFolder_.ActiveContext = Me.ActiveContext
					_participantCollectionViaFolder_.IsReadOnly = True
					CType(_participantCollectionViaFolder_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaFolder_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaMilestone]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaMilestone Is Nothing Then
					_participantCollectionViaMilestone = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaMilestone.ActiveContext = Me.ActiveContext
					_participantCollectionViaMilestone.IsReadOnly = True
					CType(_participantCollectionViaMilestone, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaMilestone
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaNews]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaNews Is Nothing Then
					_participantCollectionViaNews = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaNews.ActiveContext = Me.ActiveContext
					_participantCollectionViaNews.IsReadOnly = True
					CType(_participantCollectionViaNews, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaNews
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaNews_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaNews_ Is Nothing Then
					_participantCollectionViaNews_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaNews_.ActiveContext = Me.ActiveContext
					_participantCollectionViaNews_.IsReadOnly = True
					CType(_participantCollectionViaNews_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaNews_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaPopulationlist]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaPopulationlist Is Nothing Then
					_participantCollectionViaPopulationlist = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaPopulationlist.ActiveContext = Me.ActiveContext
					_participantCollectionViaPopulationlist.IsReadOnly = True
					CType(_participantCollectionViaPopulationlist, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaPopulationlist
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaRc]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaRc Is Nothing Then
					_participantCollectionViaRc = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaRc.ActiveContext = Me.ActiveContext
					_participantCollectionViaRc.IsReadOnly = True
					CType(_participantCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaRc_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaRc_ Is Nothing Then
					_participantCollectionViaRc_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaRc_.ActiveContext = Me.ActiveContext
					_participantCollectionViaRc_.IsReadOnly = True
					CType(_participantCollectionViaRc_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaRc_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaTimeline]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaTimeline Is Nothing Then
					_participantCollectionViaTimeline = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaTimeline.ActiveContext = Me.ActiveContext
					_participantCollectionViaTimeline.IsReadOnly = True
					CType(_participantCollectionViaTimeline, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaTimeline
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaVisits]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaVisits Is Nothing Then
					_participantCollectionViaVisits = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaVisits.ActiveContext = Me.ActiveContext
					_participantCollectionViaVisits.IsReadOnly = True
					CType(_participantCollectionViaVisits, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaVisits
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaVisits_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaVisits_ Is Nothing Then
					_participantCollectionViaVisits_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaVisits_.ActiveContext = Me.ActiveContext
					_participantCollectionViaVisits_.IsReadOnly = True
					CType(_participantCollectionViaVisits_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaVisits_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipationTypeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipationTypeEntity))> _
		Public Overridable ReadOnly Property [ParticipationTypeCollectionViaCase2Participant]() As EntityCollection(Of ParticipationTypeEntity)
			Get
				If _participationTypeCollectionViaCase2Participant Is Nothing Then
					_participationTypeCollectionViaCase2Participant = New EntityCollection(Of ParticipationTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipationTypeEntityFactory)))
					_participationTypeCollectionViaCase2Participant.ActiveContext = Me.ActiveContext
					_participationTypeCollectionViaCase2Participant.IsReadOnly = True
					CType(_participationTypeCollectionViaCase2Participant, IEntityCollectionCore).IsForMN = True
				End If
				Return _participationTypeCollectionViaCase2Participant
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PbuEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PbuEntity))> _
		Public Overridable ReadOnly Property [PbuCollectionViaCase]() As EntityCollection(Of PbuEntity)
			Get
				If _pbuCollectionViaCase Is Nothing Then
					_pbuCollectionViaCase = New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory)))
					_pbuCollectionViaCase.ActiveContext = Me.ActiveContext
					_pbuCollectionViaCase.IsReadOnly = True
					CType(_pbuCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _pbuCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PersonalSafetyEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PersonalSafetyEntity))> _
		Public Overridable ReadOnly Property [PersonalSafetyCollectionViaCase]() As EntityCollection(Of PersonalSafetyEntity)
			Get
				If _personalSafetyCollectionViaCase Is Nothing Then
					_personalSafetyCollectionViaCase = New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory)))
					_personalSafetyCollectionViaCase.ActiveContext = Me.ActiveContext
					_personalSafetyCollectionViaCase.IsReadOnly = True
					CType(_personalSafetyCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _personalSafetyCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaCase]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaCase Is Nothing Then
					_phaseCollectionViaCase = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaCase.ActiveContext = Me.ActiveContext
					_phaseCollectionViaCase.IsReadOnly = True
					CType(_phaseCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaCase2Phase]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaCase2Phase Is Nothing Then
					_phaseCollectionViaCase2Phase = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaCase2Phase.ActiveContext = Me.ActiveContext
					_phaseCollectionViaCase2Phase.IsReadOnly = True
					CType(_phaseCollectionViaCase2Phase, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaCase2Phase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaPopulationlist]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaPopulationlist Is Nothing Then
					_phaseCollectionViaPopulationlist = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaPopulationlist.ActiveContext = Me.ActiveContext
					_phaseCollectionViaPopulationlist.IsReadOnly = True
					CType(_phaseCollectionViaPopulationlist, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaPopulationlist
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PlatformEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PlatformEntity))> _
		Public Overridable ReadOnly Property [PlatformCollectionViaCase]() As EntityCollection(Of PlatformEntity)
			Get
				If _platformCollectionViaCase Is Nothing Then
					_platformCollectionViaCase = New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory)))
					_platformCollectionViaCase.ActiveContext = Me.ActiveContext
					_platformCollectionViaCase.IsReadOnly = True
					CType(_platformCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _platformCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PortfolioEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PortfolioEntity))> _
		Public Overridable ReadOnly Property [PortfolioCollectionViaCase]() As EntityCollection(Of PortfolioEntity)
			Get
				If _portfolioCollectionViaCase Is Nothing Then
					_portfolioCollectionViaCase = New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory)))
					_portfolioCollectionViaCase.ActiveContext = Me.ActiveContext
					_portfolioCollectionViaCase.IsReadOnly = True
					CType(_portfolioCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _portfolioCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ProjectScopeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ProjectScopeEntity))> _
		Public Overridable ReadOnly Property [ProjectScopeCollectionViaCase]() As EntityCollection(Of ProjectScopeEntity)
			Get
				If _projectScopeCollectionViaCase Is Nothing Then
					_projectScopeCollectionViaCase = New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory)))
					_projectScopeCollectionViaCase.ActiveContext = Me.ActiveContext
					_projectScopeCollectionViaCase.IsReadOnly = True
					CType(_projectScopeCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _projectScopeCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RccomponentOwnerEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RccomponentOwnerEntity))> _
		Public Overridable ReadOnly Property [RccomponentOwnerCollectionViaRc]() As EntityCollection(Of RccomponentOwnerEntity)
			Get
				If _rccomponentOwnerCollectionViaRc Is Nothing Then
					_rccomponentOwnerCollectionViaRc = New EntityCollection(Of RccomponentOwnerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RccomponentOwnerEntityFactory)))
					_rccomponentOwnerCollectionViaRc.ActiveContext = Me.ActiveContext
					_rccomponentOwnerCollectionViaRc.IsReadOnly = True
					CType(_rccomponentOwnerCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _rccomponentOwnerCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginEntity))> _
		Public Overridable ReadOnly Property [RcoriginCollectionViaRc]() As EntityCollection(Of RcoriginEntity)
			Get
				If _rcoriginCollectionViaRc Is Nothing Then
					_rcoriginCollectionViaRc = New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory)))
					_rcoriginCollectionViaRc.ActiveContext = Me.ActiveContext
					_rcoriginCollectionViaRc.IsReadOnly = True
					CType(_rcoriginCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _rcoriginCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginResponsibleEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginResponsibleEntity))> _
		Public Overridable ReadOnly Property [RcoriginResponsibleCollectionViaRc]() As EntityCollection(Of RcoriginResponsibleEntity)
			Get
				If _rcoriginResponsibleCollectionViaRc Is Nothing Then
					_rcoriginResponsibleCollectionViaRc = New EntityCollection(Of RcoriginResponsibleEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginResponsibleEntityFactory)))
					_rcoriginResponsibleCollectionViaRc.ActiveContext = Me.ActiveContext
					_rcoriginResponsibleCollectionViaRc.IsReadOnly = True
					CType(_rcoriginResponsibleCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _rcoriginResponsibleCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginUnitEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginUnitEntity))> _
		Public Overridable ReadOnly Property [RcoriginUnitCollectionViaRc]() As EntityCollection(Of RcoriginUnitEntity)
			Get
				If _rcoriginUnitCollectionViaRc Is Nothing Then
					_rcoriginUnitCollectionViaRc = New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory)))
					_rcoriginUnitCollectionViaRc.ActiveContext = Me.ActiveContext
					_rcoriginUnitCollectionViaRc.IsReadOnly = True
					CType(_rcoriginUnitCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _rcoriginUnitCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ReasonCodeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ReasonCodeEntity))> _
		Public Overridable ReadOnly Property [ReasonCodeCollectionViaCase2ReasonCode]() As EntityCollection(Of ReasonCodeEntity)
			Get
				If _reasonCodeCollectionViaCase2ReasonCode Is Nothing Then
					_reasonCodeCollectionViaCase2ReasonCode = New EntityCollection(Of ReasonCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ReasonCodeEntityFactory)))
					_reasonCodeCollectionViaCase2ReasonCode.ActiveContext = Me.ActiveContext
					_reasonCodeCollectionViaCase2ReasonCode.IsReadOnly = True
					CType(_reasonCodeCollectionViaCase2ReasonCode, IEntityCollectionCore).IsForMN = True
				End If
				Return _reasonCodeCollectionViaCase2ReasonCode
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ReportTypeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ReportTypeEntity))> _
		Public Overridable ReadOnly Property [ReportTypeCollectionViaCir]() As EntityCollection(Of ReportTypeEntity)
			Get
				If _reportTypeCollectionViaCir Is Nothing Then
					_reportTypeCollectionViaCir = New EntityCollection(Of ReportTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ReportTypeEntityFactory)))
					_reportTypeCollectionViaCir.ActiveContext = Me.ActiveContext
					_reportTypeCollectionViaCir.IsReadOnly = True
					CType(_reportTypeCollectionViaCir, IEntityCollectionCore).IsForMN = True
				End If
				Return _reportTypeCollectionViaCir
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'SbuEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(SbuEntity))> _
		Public Overridable ReadOnly Property [SbuCollectionViaCase2Sbu]() As EntityCollection(Of SbuEntity)
			Get
				If _sbuCollectionViaCase2Sbu Is Nothing Then
					_sbuCollectionViaCase2Sbu = New EntityCollection(Of SbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SbuEntityFactory)))
					_sbuCollectionViaCase2Sbu.ActiveContext = Me.ActiveContext
					_sbuCollectionViaCase2Sbu.IsReadOnly = True
					CType(_sbuCollectionViaCase2Sbu, IEntityCollectionCore).IsForMN = True
				End If
				Return _sbuCollectionViaCase2Sbu
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ServiceCodeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ServiceCodeEntity))> _
		Public Overridable ReadOnly Property [ServiceCodeCollectionViaCase2ServiceCode]() As EntityCollection(Of ServiceCodeEntity)
			Get
				If _serviceCodeCollectionViaCase2ServiceCode Is Nothing Then
					_serviceCodeCollectionViaCase2ServiceCode = New EntityCollection(Of ServiceCodeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ServiceCodeEntityFactory)))
					_serviceCodeCollectionViaCase2ServiceCode.ActiveContext = Me.ActiveContext
					_serviceCodeCollectionViaCase2ServiceCode.IsReadOnly = True
					CType(_serviceCodeCollectionViaCase2ServiceCode, IEntityCollectionCore).IsForMN = True
				End If
				Return _serviceCodeCollectionViaCase2ServiceCode
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardTaskEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardTaskEntity))> _
		Public Overridable ReadOnly Property [StandardTaskCollectionViaCase]() As EntityCollection(Of StandardTaskEntity)
			Get
				If _standardTaskCollectionViaCase Is Nothing Then
					_standardTaskCollectionViaCase = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
					_standardTaskCollectionViaCase.ActiveContext = Me.ActiveContext
					_standardTaskCollectionViaCase.IsReadOnly = True
					CType(_standardTaskCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _standardTaskCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StateEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StateEntity))> _
		Public Overridable ReadOnly Property [StateCollectionViaPopulationlist]() As EntityCollection(Of StateEntity)
			Get
				If _stateCollectionViaPopulationlist Is Nothing Then
					_stateCollectionViaPopulationlist = New EntityCollection(Of StateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StateEntityFactory)))
					_stateCollectionViaPopulationlist.ActiveContext = Me.ActiveContext
					_stateCollectionViaPopulationlist.IsReadOnly = True
					CType(_stateCollectionViaPopulationlist, IEntityCollectionCore).IsForMN = True
				End If
				Return _stateCollectionViaPopulationlist
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StatusEntity))> _
		Public Overridable ReadOnly Property [StatusCollectionViaCase]() As EntityCollection(Of StatusEntity)
			Get
				If _statusCollectionViaCase Is Nothing Then
					_statusCollectionViaCase = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
					_statusCollectionViaCase.ActiveContext = Me.ActiveContext
					_statusCollectionViaCase.IsReadOnly = True
					CType(_statusCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _statusCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StatusEntity))> _
		Public Overridable ReadOnly Property [StatusCollectionViaPopulationlist]() As EntityCollection(Of StatusEntity)
			Get
				If _statusCollectionViaPopulationlist Is Nothing Then
					_statusCollectionViaPopulationlist = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
					_statusCollectionViaPopulationlist.ActiveContext = Me.ActiveContext
					_statusCollectionViaPopulationlist.IsReadOnly = True
					CType(_statusCollectionViaPopulationlist, IEntityCollectionCore).IsForMN = True
				End If
				Return _statusCollectionViaPopulationlist
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'SupplierEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(SupplierEntity))> _
		Public Overridable ReadOnly Property [SupplierCollectionViaCase2Supplier]() As EntityCollection(Of SupplierEntity)
			Get
				If _supplierCollectionViaCase2Supplier Is Nothing Then
					_supplierCollectionViaCase2Supplier = New EntityCollection(Of SupplierEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SupplierEntityFactory)))
					_supplierCollectionViaCase2Supplier.ActiveContext = Me.ActiveContext
					_supplierCollectionViaCase2Supplier.IsReadOnly = True
					CType(_supplierCollectionViaCase2Supplier, IEntityCollectionCore).IsForMN = True
				End If
				Return _supplierCollectionViaCase2Supplier
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'SystemDescriptionEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(SystemDescriptionEntity))> _
		Public Overridable ReadOnly Property [SystemDescriptionCollectionViaCase2System]() As EntityCollection(Of SystemDescriptionEntity)
			Get
				If _systemDescriptionCollectionViaCase2System Is Nothing Then
					_systemDescriptionCollectionViaCase2System = New EntityCollection(Of SystemDescriptionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(SystemDescriptionEntityFactory)))
					_systemDescriptionCollectionViaCase2System.ActiveContext = Me.ActiveContext
					_systemDescriptionCollectionViaCase2System.IsReadOnly = True
					CType(_systemDescriptionCollectionViaCase2System, IEntityCollectionCore).IsForMN = True
				End If
				Return _systemDescriptionCollectionViaCase2System
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineMatrixEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineMatrixEntity))> _
		Public Overridable ReadOnly Property [TurbineMatrixCollectionViaCase2TurbineUnitType]() As EntityCollection(Of TurbineMatrixEntity)
			Get
				If _turbineMatrixCollectionViaCase2TurbineUnitType Is Nothing Then
					_turbineMatrixCollectionViaCase2TurbineUnitType = New EntityCollection(Of TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMatrixEntityFactory)))
					_turbineMatrixCollectionViaCase2TurbineUnitType.ActiveContext = Me.ActiveContext
					_turbineMatrixCollectionViaCase2TurbineUnitType.IsReadOnly = True
					CType(_turbineMatrixCollectionViaCase2TurbineUnitType, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineMatrixCollectionViaCase2TurbineUnitType
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'BrandEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Brand]() As BrandEntity
			Get
				Return _brand
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncBrand(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Brand", _brand, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'BusinessProcessEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [BusinessProcess]() As BusinessProcessEntity
			Get
				Return _businessProcess
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncBusinessProcess(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "BusinessProcess", _businessProcess, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'CaseEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ParentCase]() As CaseEntity
			Get
				Return _parentCase
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParentCase(value)
				Else
					SetSingleRelatedEntityNavigator(value, "ChildCase", "ParentCase", _parentCase, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'CategoryEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Category]() As CategoryEntity
			Get
				Return _category
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncCategory(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Category", _category, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ClaimStatusEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ClaimStatus]() As ClaimStatusEntity
			Get
				Return _claimStatus
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncClaimStatus(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "ClaimStatus", _claimStatus, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ComponentEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Component]() As ComponentEntity
			Get
				Return _component
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncComponent(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Component", _component, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [CreatedByParticipant]() As ParticipantEntity
			Get
				Return _createdByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncCreatedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case_", "CreatedByParticipant", _createdByParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ExecutionManagerParticipant]() As ParticipantEntity
			Get
				Return _executionManagerParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncExecutionManagerParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case____", "ExecutionManagerParticipant", _executionManagerParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [LastEditedByParticipant]() As ParticipantEntity
			Get
				Return _lastEditedByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncLastEditedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case__", "LastEditedByParticipant", _lastEditedByParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ManagerParticipant]() As ParticipantEntity
			Get
				Return _managerParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncManagerParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "ManagerParticipant", _managerParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant]() As ParticipantEntity
			Get
				Return _participant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case_____", "Participant", _participant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TechnicalSpecialistParticipant]() As ParticipantEntity
			Get
				Return _technicalSpecialistParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTechnicalSpecialistParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case___", "TechnicalSpecialistParticipant", _technicalSpecialistParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'PbuEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Pbu]() As PbuEntity
			Get
				Return _pbu
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncPbu(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Pbu", _pbu, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'PersonalSafetyEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [PersonalSafety]() As PersonalSafetyEntity
			Get
				Return _personalSafety
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncPersonalSafety(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "PersonalSafety", _personalSafety, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'PhaseEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Phase]() As PhaseEntity
			Get
				Return _phase
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncPhase(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Phase", _phase, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'PlatformEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Platform_]() As PlatformEntity
			Get
				Return _platform_
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncPlatform_(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Platform_", _platform_, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'PortfolioEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Portfolio]() As PortfolioEntity
			Get
				Return _portfolio
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncPortfolio(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Portfolio", _portfolio, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ProjectScopeEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ProjectScope]() As ProjectScopeEntity
			Get
				Return _projectScope
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncProjectScope(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "ProjectScope", _projectScope, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'StandardTaskEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [StandardTask]() As StandardTaskEntity
			Get
				Return _standardTask
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncStandardTask(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "StandardTask", _standardTask, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'StatusEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Status]() As StatusEntity
			Get
				Return _status
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncStatus(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Case", "Status", _status, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.CaseEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
    ' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
    ' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
