﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'Category'.<br/><br/></summary>
	<Serializable()> _
	Public Class CategoryEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _case As EntityCollection(Of CaseEntity)
		Private WithEvents _brandCollectionViaCase As EntityCollection(Of BrandEntity)
		Private WithEvents _businessProcessCollectionViaCase As EntityCollection(Of BusinessProcessEntity)
		Private WithEvents _caseCollectionViaCase As EntityCollection(Of CaseEntity)
		Private WithEvents _claimStatusCollectionViaCase As EntityCollection(Of ClaimStatusEntity)
		Private WithEvents _componentCollectionViaCase As EntityCollection(Of ComponentEntity)
		Private WithEvents _participantCollectionViaCase As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase__ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase___ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase____ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaCase_____ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _pbuCollectionViaCase As EntityCollection(Of PbuEntity)
		Private WithEvents _personalSafetyCollectionViaCase As EntityCollection(Of PersonalSafetyEntity)
		Private WithEvents _phaseCollectionViaCase As EntityCollection(Of PhaseEntity)
		Private WithEvents _platformCollectionViaCase As EntityCollection(Of PlatformEntity)
		Private WithEvents _portfolioCollectionViaCase As EntityCollection(Of PortfolioEntity)
		Private WithEvents _projectScopeCollectionViaCase As EntityCollection(Of ProjectScopeEntity)
		Private WithEvents _standardTaskCollectionViaCase As EntityCollection(Of StandardTaskEntity)
		Private WithEvents _statusCollectionViaCase As EntityCollection(Of StatusEntity)
		Private WithEvents _participant As ParticipantEntity
		Private WithEvents _participant_ As ParticipantEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Participant</summary>
			Public Shared ReadOnly [Participant] As String = "Participant"
			''' <summary>Member name Participant_</summary>
			Public Shared ReadOnly [Participant_] As String = "Participant_"
			''' <summary>Member name Case</summary>
			Public Shared ReadOnly [Case] As String  = "Case"
			''' <summary>Member name BrandCollectionViaCase</summary>
			Public Shared ReadOnly [BrandCollectionViaCase] As String  = "BrandCollectionViaCase"
			''' <summary>Member name BusinessProcessCollectionViaCase</summary>
			Public Shared ReadOnly [BusinessProcessCollectionViaCase] As String  = "BusinessProcessCollectionViaCase"
			''' <summary>Member name CaseCollectionViaCase</summary>
			Public Shared ReadOnly [CaseCollectionViaCase] As String  = "CaseCollectionViaCase"
			''' <summary>Member name ClaimStatusCollectionViaCase</summary>
			Public Shared ReadOnly [ClaimStatusCollectionViaCase] As String  = "ClaimStatusCollectionViaCase"
			''' <summary>Member name ComponentCollectionViaCase</summary>
			Public Shared ReadOnly [ComponentCollectionViaCase] As String  = "ComponentCollectionViaCase"
			''' <summary>Member name ParticipantCollectionViaCase</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase] As String  = "ParticipantCollectionViaCase"
			''' <summary>Member name ParticipantCollectionViaCase_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase_] As String  = "ParticipantCollectionViaCase_"
			''' <summary>Member name ParticipantCollectionViaCase__</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase__] As String  = "ParticipantCollectionViaCase__"
			''' <summary>Member name ParticipantCollectionViaCase___</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase___] As String  = "ParticipantCollectionViaCase___"
			''' <summary>Member name ParticipantCollectionViaCase____</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase____] As String  = "ParticipantCollectionViaCase____"
			''' <summary>Member name ParticipantCollectionViaCase_____</summary>
			Public Shared ReadOnly [ParticipantCollectionViaCase_____] As String  = "ParticipantCollectionViaCase_____"
			''' <summary>Member name PbuCollectionViaCase</summary>
			Public Shared ReadOnly [PbuCollectionViaCase] As String  = "PbuCollectionViaCase"
			''' <summary>Member name PersonalSafetyCollectionViaCase</summary>
			Public Shared ReadOnly [PersonalSafetyCollectionViaCase] As String  = "PersonalSafetyCollectionViaCase"
			''' <summary>Member name PhaseCollectionViaCase</summary>
			Public Shared ReadOnly [PhaseCollectionViaCase] As String  = "PhaseCollectionViaCase"
			''' <summary>Member name PlatformCollectionViaCase</summary>
			Public Shared ReadOnly [PlatformCollectionViaCase] As String  = "PlatformCollectionViaCase"
			''' <summary>Member name PortfolioCollectionViaCase</summary>
			Public Shared ReadOnly [PortfolioCollectionViaCase] As String  = "PortfolioCollectionViaCase"
			''' <summary>Member name ProjectScopeCollectionViaCase</summary>
			Public Shared ReadOnly [ProjectScopeCollectionViaCase] As String  = "ProjectScopeCollectionViaCase"
			''' <summary>Member name StandardTaskCollectionViaCase</summary>
			Public Shared ReadOnly [StandardTaskCollectionViaCase] As String  = "StandardTaskCollectionViaCase"
			''' <summary>Member name StatusCollectionViaCase</summary>
			Public Shared ReadOnly [StatusCollectionViaCase] As String  = "StatusCollectionViaCase"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CategoryEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("CategoryEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this CategoryEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("CategoryEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="categoryId">PK value for Category which data should be fetched into this Category object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(categoryId As System.Int32)
			MyBase.New("CategoryEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.CategoryId = categoryId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="categoryId">PK value for Category which data should be fetched into this Category object</param>
		''' <param name="validator">The custom validator object for this CategoryEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(categoryId As System.Int32, validator As IValidator)
			MyBase.New("CategoryEntity")
			InitClassEmpty(validator, Nothing)
			Me.CategoryId = categoryId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_case = CType(info.GetValue("_case", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_brandCollectionViaCase = CType(info.GetValue("_brandCollectionViaCase", GetType(EntityCollection(Of BrandEntity))), EntityCollection(Of BrandEntity))
				_businessProcessCollectionViaCase = CType(info.GetValue("_businessProcessCollectionViaCase", GetType(EntityCollection(Of BusinessProcessEntity))), EntityCollection(Of BusinessProcessEntity))
				_caseCollectionViaCase = CType(info.GetValue("_caseCollectionViaCase", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_claimStatusCollectionViaCase = CType(info.GetValue("_claimStatusCollectionViaCase", GetType(EntityCollection(Of ClaimStatusEntity))), EntityCollection(Of ClaimStatusEntity))
				_componentCollectionViaCase = CType(info.GetValue("_componentCollectionViaCase", GetType(EntityCollection(Of ComponentEntity))), EntityCollection(Of ComponentEntity))
				_participantCollectionViaCase = CType(info.GetValue("_participantCollectionViaCase", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase_ = CType(info.GetValue("_participantCollectionViaCase_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase__ = CType(info.GetValue("_participantCollectionViaCase__", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase___ = CType(info.GetValue("_participantCollectionViaCase___", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase____ = CType(info.GetValue("_participantCollectionViaCase____", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaCase_____ = CType(info.GetValue("_participantCollectionViaCase_____", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_pbuCollectionViaCase = CType(info.GetValue("_pbuCollectionViaCase", GetType(EntityCollection(Of PbuEntity))), EntityCollection(Of PbuEntity))
				_personalSafetyCollectionViaCase = CType(info.GetValue("_personalSafetyCollectionViaCase", GetType(EntityCollection(Of PersonalSafetyEntity))), EntityCollection(Of PersonalSafetyEntity))
				_phaseCollectionViaCase = CType(info.GetValue("_phaseCollectionViaCase", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_platformCollectionViaCase = CType(info.GetValue("_platformCollectionViaCase", GetType(EntityCollection(Of PlatformEntity))), EntityCollection(Of PlatformEntity))
				_portfolioCollectionViaCase = CType(info.GetValue("_portfolioCollectionViaCase", GetType(EntityCollection(Of PortfolioEntity))), EntityCollection(Of PortfolioEntity))
				_projectScopeCollectionViaCase = CType(info.GetValue("_projectScopeCollectionViaCase", GetType(EntityCollection(Of ProjectScopeEntity))), EntityCollection(Of ProjectScopeEntity))
				_standardTaskCollectionViaCase = CType(info.GetValue("_standardTaskCollectionViaCase", GetType(EntityCollection(Of StandardTaskEntity))), EntityCollection(Of StandardTaskEntity))
				_statusCollectionViaCase = CType(info.GetValue("_statusCollectionViaCase", GetType(EntityCollection(Of StatusEntity))), EntityCollection(Of StatusEntity))
				_participant = CType(info.GetValue("_participant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant Is Nothing Then
					AddHandler _participant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant_ = CType(info.GetValue("_participant_", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant_ Is Nothing Then
					AddHandler _participant_.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, CategoryFieldIndex)


				Case CategoryFieldIndex.CreatedById
					DesetupSyncParticipant(True, False)

				Case CategoryFieldIndex.DeletedById
					DesetupSyncParticipant_(True, False)

				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Participant"
					Me.Participant = CType(entity, ParticipantEntity)
				Case "Participant_"
					Me.Participant_ = CType(entity, ParticipantEntity)
				Case "Case"
					Me.Case.Add(CType(entity, CaseEntity))
				Case "BrandCollectionViaCase"
					Me.BrandCollectionViaCase.IsReadOnly = False
					Me.BrandCollectionViaCase.Add(CType(entity, BrandEntity))
					Me.BrandCollectionViaCase.IsReadOnly = True
				Case "BusinessProcessCollectionViaCase"
					Me.BusinessProcessCollectionViaCase.IsReadOnly = False
					Me.BusinessProcessCollectionViaCase.Add(CType(entity, BusinessProcessEntity))
					Me.BusinessProcessCollectionViaCase.IsReadOnly = True
				Case "CaseCollectionViaCase"
					Me.CaseCollectionViaCase.IsReadOnly = False
					Me.CaseCollectionViaCase.Add(CType(entity, CaseEntity))
					Me.CaseCollectionViaCase.IsReadOnly = True
				Case "ClaimStatusCollectionViaCase"
					Me.ClaimStatusCollectionViaCase.IsReadOnly = False
					Me.ClaimStatusCollectionViaCase.Add(CType(entity, ClaimStatusEntity))
					Me.ClaimStatusCollectionViaCase.IsReadOnly = True
				Case "ComponentCollectionViaCase"
					Me.ComponentCollectionViaCase.IsReadOnly = False
					Me.ComponentCollectionViaCase.Add(CType(entity, ComponentEntity))
					Me.ComponentCollectionViaCase.IsReadOnly = True
				Case "ParticipantCollectionViaCase"
					Me.ParticipantCollectionViaCase.IsReadOnly = False
					Me.ParticipantCollectionViaCase.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase.IsReadOnly = True
				Case "ParticipantCollectionViaCase_"
					Me.ParticipantCollectionViaCase_.IsReadOnly = False
					Me.ParticipantCollectionViaCase_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase_.IsReadOnly = True
				Case "ParticipantCollectionViaCase__"
					Me.ParticipantCollectionViaCase__.IsReadOnly = False
					Me.ParticipantCollectionViaCase__.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase__.IsReadOnly = True
				Case "ParticipantCollectionViaCase___"
					Me.ParticipantCollectionViaCase___.IsReadOnly = False
					Me.ParticipantCollectionViaCase___.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase___.IsReadOnly = True
				Case "ParticipantCollectionViaCase____"
					Me.ParticipantCollectionViaCase____.IsReadOnly = False
					Me.ParticipantCollectionViaCase____.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase____.IsReadOnly = True
				Case "ParticipantCollectionViaCase_____"
					Me.ParticipantCollectionViaCase_____.IsReadOnly = False
					Me.ParticipantCollectionViaCase_____.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaCase_____.IsReadOnly = True
				Case "PbuCollectionViaCase"
					Me.PbuCollectionViaCase.IsReadOnly = False
					Me.PbuCollectionViaCase.Add(CType(entity, PbuEntity))
					Me.PbuCollectionViaCase.IsReadOnly = True
				Case "PersonalSafetyCollectionViaCase"
					Me.PersonalSafetyCollectionViaCase.IsReadOnly = False
					Me.PersonalSafetyCollectionViaCase.Add(CType(entity, PersonalSafetyEntity))
					Me.PersonalSafetyCollectionViaCase.IsReadOnly = True
				Case "PhaseCollectionViaCase"
					Me.PhaseCollectionViaCase.IsReadOnly = False
					Me.PhaseCollectionViaCase.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaCase.IsReadOnly = True
				Case "PlatformCollectionViaCase"
					Me.PlatformCollectionViaCase.IsReadOnly = False
					Me.PlatformCollectionViaCase.Add(CType(entity, PlatformEntity))
					Me.PlatformCollectionViaCase.IsReadOnly = True
				Case "PortfolioCollectionViaCase"
					Me.PortfolioCollectionViaCase.IsReadOnly = False
					Me.PortfolioCollectionViaCase.Add(CType(entity, PortfolioEntity))
					Me.PortfolioCollectionViaCase.IsReadOnly = True
				Case "ProjectScopeCollectionViaCase"
					Me.ProjectScopeCollectionViaCase.IsReadOnly = False
					Me.ProjectScopeCollectionViaCase.Add(CType(entity, ProjectScopeEntity))
					Me.ProjectScopeCollectionViaCase.IsReadOnly = True
				Case "StandardTaskCollectionViaCase"
					Me.StandardTaskCollectionViaCase.IsReadOnly = False
					Me.StandardTaskCollectionViaCase.Add(CType(entity, StandardTaskEntity))
					Me.StandardTaskCollectionViaCase.IsReadOnly = True
				Case "StatusCollectionViaCase"
					Me.StatusCollectionViaCase.IsReadOnly = False
					Me.StatusCollectionViaCase.Add(CType(entity, StatusEntity))
					Me.StatusCollectionViaCase.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return CategoryEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Participant"
					toReturn.Add(CategoryEntity.Relations.ParticipantEntityUsingCreatedById)
				Case "Participant_"
					toReturn.Add(CategoryEntity.Relations.ParticipantEntityUsingDeletedById)
				Case "Case"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId)
				Case "BrandCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.BrandEntityUsingBrandId, "Case_", String.Empty, JoinHint.None)
				Case "BusinessProcessCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.BusinessProcessEntityUsingBusinessProcessId, "Case_", String.Empty, JoinHint.None)
				Case "CaseCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.CaseEntityUsingUplink, "Case_", String.Empty, JoinHint.None)
				Case "ClaimStatusCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ClaimStatusEntityUsingClaimStatusId, "Case_", String.Empty, JoinHint.None)
				Case "ComponentCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ComponentEntityUsingComponentId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingManagerId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase_"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingLastEditedById, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase__"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingCreatedById, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase___"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingTechnicalSpecialistId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase____"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingExecutionManagerId, "Case_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaCase_____"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ParticipantEntityUsingContainmentLeadId, "Case_", String.Empty, JoinHint.None)
				Case "PbuCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PbuEntityUsingPbuid, "Case_", String.Empty, JoinHint.None)
				Case "PersonalSafetyCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PersonalSafetyEntityUsingPersonalSafetyId, "Case_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PhaseEntityUsingPhaseId, "Case_", String.Empty, JoinHint.None)
				Case "PlatformCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PlatformEntityUsingPlatform, "Case_", String.Empty, JoinHint.None)
				Case "PortfolioCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.PortfolioEntityUsingPortfolioId, "Case_", String.Empty, JoinHint.None)
				Case "ProjectScopeCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.ProjectScopeEntityUsingProjectScopeId, "Case_", String.Empty, JoinHint.None)
				Case "StandardTaskCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.StandardTaskEntityUsingStandardTaskId, "Case_", String.Empty, JoinHint.None)
				Case "StatusCollectionViaCase"
					toReturn.Add(CategoryEntity.Relations.CaseEntityUsingCategoryId, "CategoryEntity__", "Case_", JoinHint.None)
					toReturn.Add(CaseEntity.Relations.StatusEntityUsingStatusId, "Case_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Participant"
					SetupSyncParticipant(relatedEntity)
				Case "Participant_"
					SetupSyncParticipant_(relatedEntity)
				Case "Case"
					Me.Case.Add(CType(relatedEntity, CaseEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Participant"
					DesetupSyncParticipant(False, True)
				Case "Participant_"
					DesetupSyncParticipant_(False, True)
				Case "Case"
					Me.PerformRelatedEntityRemoval(Me.Case, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _participant Is Nothing Then
				toReturn.Add(_participant)
			End If
			If Not _participant_ Is Nothing Then
				toReturn.Add(_participant_)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Case)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_case Is Nothing)) AndAlso (_case.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case 
				End If
				info.AddValue("_case", value)
				value = Nothing 
				If (Not (_brandCollectionViaCase Is Nothing)) AndAlso (_brandCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brandCollectionViaCase 
				End If
				info.AddValue("_brandCollectionViaCase", value)
				value = Nothing 
				If (Not (_businessProcessCollectionViaCase Is Nothing)) AndAlso (_businessProcessCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _businessProcessCollectionViaCase 
				End If
				info.AddValue("_businessProcessCollectionViaCase", value)
				value = Nothing 
				If (Not (_caseCollectionViaCase Is Nothing)) AndAlso (_caseCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _caseCollectionViaCase 
				End If
				info.AddValue("_caseCollectionViaCase", value)
				value = Nothing 
				If (Not (_claimStatusCollectionViaCase Is Nothing)) AndAlso (_claimStatusCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _claimStatusCollectionViaCase 
				End If
				info.AddValue("_claimStatusCollectionViaCase", value)
				value = Nothing 
				If (Not (_componentCollectionViaCase Is Nothing)) AndAlso (_componentCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _componentCollectionViaCase 
				End If
				info.AddValue("_componentCollectionViaCase", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase Is Nothing)) AndAlso (_participantCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase 
				End If
				info.AddValue("_participantCollectionViaCase", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase_ Is Nothing)) AndAlso (_participantCollectionViaCase_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase_ 
				End If
				info.AddValue("_participantCollectionViaCase_", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase__ Is Nothing)) AndAlso (_participantCollectionViaCase__.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase__ 
				End If
				info.AddValue("_participantCollectionViaCase__", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase___ Is Nothing)) AndAlso (_participantCollectionViaCase___.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase___ 
				End If
				info.AddValue("_participantCollectionViaCase___", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase____ Is Nothing)) AndAlso (_participantCollectionViaCase____.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase____ 
				End If
				info.AddValue("_participantCollectionViaCase____", value)
				value = Nothing 
				If (Not (_participantCollectionViaCase_____ Is Nothing)) AndAlso (_participantCollectionViaCase_____.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaCase_____ 
				End If
				info.AddValue("_participantCollectionViaCase_____", value)
				value = Nothing 
				If (Not (_pbuCollectionViaCase Is Nothing)) AndAlso (_pbuCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _pbuCollectionViaCase 
				End If
				info.AddValue("_pbuCollectionViaCase", value)
				value = Nothing 
				If (Not (_personalSafetyCollectionViaCase Is Nothing)) AndAlso (_personalSafetyCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _personalSafetyCollectionViaCase 
				End If
				info.AddValue("_personalSafetyCollectionViaCase", value)
				value = Nothing 
				If (Not (_phaseCollectionViaCase Is Nothing)) AndAlso (_phaseCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaCase 
				End If
				info.AddValue("_phaseCollectionViaCase", value)
				value = Nothing 
				If (Not (_platformCollectionViaCase Is Nothing)) AndAlso (_platformCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _platformCollectionViaCase 
				End If
				info.AddValue("_platformCollectionViaCase", value)
				value = Nothing 
				If (Not (_portfolioCollectionViaCase Is Nothing)) AndAlso (_portfolioCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _portfolioCollectionViaCase 
				End If
				info.AddValue("_portfolioCollectionViaCase", value)
				value = Nothing 
				If (Not (_projectScopeCollectionViaCase Is Nothing)) AndAlso (_projectScopeCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _projectScopeCollectionViaCase 
				End If
				info.AddValue("_projectScopeCollectionViaCase", value)
				value = Nothing 
				If (Not (_standardTaskCollectionViaCase Is Nothing)) AndAlso (_standardTaskCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardTaskCollectionViaCase 
				End If
				info.AddValue("_standardTaskCollectionViaCase", value)
				value = Nothing 
				If (Not (_statusCollectionViaCase Is Nothing)) AndAlso (_statusCollectionViaCase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _statusCollectionViaCase 
				End If
				info.AddValue("_statusCollectionViaCase", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant
				End If
				info.AddValue("_participant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant_
				End If
				info.AddValue("_participant_", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New CategoryRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrandCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BrandCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'BusinessProcess' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBusinessProcessCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BusinessProcessCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCaseCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CaseCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ClaimStatus' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoClaimStatusCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ClaimStatusCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Component' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoComponentCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ComponentCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase__() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase__"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase___() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase___"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase____() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase____"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaCase_____() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaCase_____"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Pbu' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPbuCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PbuCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'PersonalSafety' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPersonalSafetyCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PersonalSafetyCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Platform' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPlatformCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PlatformCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Portfolio' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPortfolioCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PortfolioCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'ProjectScope' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoProjectScopeCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ProjectScopeCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardTask' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardTaskCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StandardTaskCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Status' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStatusCollectionViaCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("StatusCollectionViaCase"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CategoryFields.CategoryId, Nothing, ComparisonOperator.Equal, Me.CategoryId, "CategoryEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.DeletedById))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(CategoryEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_case)
			collectionsQueue.Enqueue(_brandCollectionViaCase)
			collectionsQueue.Enqueue(_businessProcessCollectionViaCase)
			collectionsQueue.Enqueue(_caseCollectionViaCase)
			collectionsQueue.Enqueue(_claimStatusCollectionViaCase)
			collectionsQueue.Enqueue(_componentCollectionViaCase)
			collectionsQueue.Enqueue(_participantCollectionViaCase)
			collectionsQueue.Enqueue(_participantCollectionViaCase_)
			collectionsQueue.Enqueue(_participantCollectionViaCase__)
			collectionsQueue.Enqueue(_participantCollectionViaCase___)
			collectionsQueue.Enqueue(_participantCollectionViaCase____)
			collectionsQueue.Enqueue(_participantCollectionViaCase_____)
			collectionsQueue.Enqueue(_pbuCollectionViaCase)
			collectionsQueue.Enqueue(_personalSafetyCollectionViaCase)
			collectionsQueue.Enqueue(_phaseCollectionViaCase)
			collectionsQueue.Enqueue(_platformCollectionViaCase)
			collectionsQueue.Enqueue(_portfolioCollectionViaCase)
			collectionsQueue.Enqueue(_projectScopeCollectionViaCase)
			collectionsQueue.Enqueue(_standardTaskCollectionViaCase)
			collectionsQueue.Enqueue(_statusCollectionViaCase)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_case = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_brandCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of BrandEntity))
			_businessProcessCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of BusinessProcessEntity))
			_caseCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_claimStatusCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ClaimStatusEntity))
			_componentCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ComponentEntity))
			_participantCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase__ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase___ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase____ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaCase_____ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_pbuCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PbuEntity))
			_personalSafetyCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PersonalSafetyEntity))
			_phaseCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_platformCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PlatformEntity))
			_portfolioCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PortfolioEntity))
			_projectScopeCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ProjectScopeEntity))
			_standardTaskCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardTaskEntity))
			_statusCollectionViaCase = CType(collectionsQueue.Dequeue(), EntityCollection(Of StatusEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _case Is Nothing) Then
				Return True
			End If
			If (Not _brandCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _businessProcessCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _caseCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _claimStatusCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _componentCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase__ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase___ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase____ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaCase_____ Is Nothing) Then
				Return True
			End If
			If (Not _pbuCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _personalSafetyCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _platformCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _portfolioCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _projectScopeCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _standardTaskCollectionViaCase Is Nothing) Then
				Return True
			End If
			If (Not _statusCollectionViaCase Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Participant", _participant)
			toReturn.Add("Participant_", _participant_)
			toReturn.Add("Case", _case)
			toReturn.Add("BrandCollectionViaCase", _brandCollectionViaCase)
			toReturn.Add("BusinessProcessCollectionViaCase", _businessProcessCollectionViaCase)
			toReturn.Add("CaseCollectionViaCase", _caseCollectionViaCase)
			toReturn.Add("ClaimStatusCollectionViaCase", _claimStatusCollectionViaCase)
			toReturn.Add("ComponentCollectionViaCase", _componentCollectionViaCase)
			toReturn.Add("ParticipantCollectionViaCase", _participantCollectionViaCase)
			toReturn.Add("ParticipantCollectionViaCase_", _participantCollectionViaCase_)
			toReturn.Add("ParticipantCollectionViaCase__", _participantCollectionViaCase__)
			toReturn.Add("ParticipantCollectionViaCase___", _participantCollectionViaCase___)
			toReturn.Add("ParticipantCollectionViaCase____", _participantCollectionViaCase____)
			toReturn.Add("ParticipantCollectionViaCase_____", _participantCollectionViaCase_____)
			toReturn.Add("PbuCollectionViaCase", _pbuCollectionViaCase)
			toReturn.Add("PersonalSafetyCollectionViaCase", _personalSafetyCollectionViaCase)
			toReturn.Add("PhaseCollectionViaCase", _phaseCollectionViaCase)
			toReturn.Add("PlatformCollectionViaCase", _platformCollectionViaCase)
			toReturn.Add("PortfolioCollectionViaCase", _portfolioCollectionViaCase)
			toReturn.Add("ProjectScopeCollectionViaCase", _projectScopeCollectionViaCase)
			toReturn.Add("StandardTaskCollectionViaCase", _standardTaskCollectionViaCase)
			toReturn.Add("StatusCollectionViaCase", _statusCollectionViaCase)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CategoryId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Name", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeletedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _participant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticCategoryRelations.ParticipantEntityUsingCreatedByIdStatic, True, signalRelatedEntity, "Category", resetFKFields, New Integer() { CInt(CategoryFieldIndex.CreatedById) } )
			_participant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant(relatedEntity As IEntityCore)
			If Not _participant Is relatedEntity Then
				DesetupSyncParticipant(True, True)
				_participant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticCategoryRelations.ParticipantEntityUsingCreatedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant_</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant_(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticCategoryRelations.ParticipantEntityUsingDeletedByIdStatic, True, signalRelatedEntity, "Category_", resetFKFields, New Integer() { CInt(CategoryFieldIndex.DeletedById) } )
			_participant_ = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant_</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant_(relatedEntity As IEntityCore)
			If Not _participant_ Is relatedEntity Then
				DesetupSyncParticipant_(True, True)
				_participant_ = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticCategoryRelations.ParticipantEntityUsingDeletedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipant_PropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this CategoryEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As CategoryRelations
			Get	
				Return New CategoryRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					CType(GetRelationsForField("Case")(0), IEntityRelation), CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrandCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BrandCollectionViaCase"), Nothing, "BrandCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'BusinessProcess' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBusinessProcessCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.BusinessProcessEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BusinessProcessCollectionViaCase"), Nothing, "BusinessProcessCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCaseCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CaseCollectionViaCase"), Nothing, "CaseCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ClaimStatus' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathClaimStatusCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ClaimStatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ClaimStatusCollectionViaCase"), Nothing, "ClaimStatusCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Component' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathComponentCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ComponentEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ComponentCollectionViaCase"), Nothing, "ComponentCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase"), Nothing, "ParticipantCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase_"), Nothing, "ParticipantCollectionViaCase_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase__() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase__"), Nothing, "ParticipantCollectionViaCase__", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase___() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase___"), Nothing, "ParticipantCollectionViaCase___", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase____() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase____"), Nothing, "ParticipantCollectionViaCase____", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaCase_____() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaCase_____"), Nothing, "ParticipantCollectionViaCase_____", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Pbu' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPbuCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.PbuEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PbuCollectionViaCase"), Nothing, "PbuCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'PersonalSafety' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPersonalSafetyCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.PersonalSafetyEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PersonalSafetyCollectionViaCase"), Nothing, "PersonalSafetyCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaCase"), Nothing, "PhaseCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Platform' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPlatformCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.PlatformEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PlatformCollectionViaCase"), Nothing, "PlatformCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Portfolio' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPortfolioCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.PortfolioEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PortfolioCollectionViaCase"), Nothing, "PortfolioCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ProjectScope' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathProjectScopeCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ProjectScopeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ProjectScopeCollectionViaCase"), Nothing, "ProjectScopeCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardTask' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardTaskCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.StandardTaskEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StandardTaskCollectionViaCase"), Nothing, "StandardTaskCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Status' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStatusCollectionViaCase() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = CategoryEntity.Relations.CaseEntityUsingCategoryId
				intermediateRelation.SetAliases(String.Empty, "Case_")
				Return New PrefetchPathElement2( New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.StatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("StatusCollectionViaCase"), Nothing, "StatusCollectionViaCase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant_")(0), IEntityRelation), CType(PManagement.Data.EntityType.CategoryEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return CategoryEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return CategoryEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The CategoryId property of the Entity Category<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Category"."CategoryId"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [CategoryId]() As System.Int32
			Get
				Return CType(GetValue(CInt(CategoryFieldIndex.CategoryId), True), System.Int32)
			End Get
			Set
				SetValue(CInt(CategoryFieldIndex.CategoryId), value)
			End Set
		End Property
		''' <summary>The Name property of the Entity Category<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Category"."Name"<br/>
		''' Table field type characteristics (type, precision, scale, length): VarChar, 0, 0, 200<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Name]() As System.String
			Get
				Return CType(GetValue(CInt(CategoryFieldIndex.Name), True), System.String)
			End Get
			Set
				SetValue(CInt(CategoryFieldIndex.Name), value)
			End Set
		End Property
		''' <summary>The CreatedById property of the Entity Category<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Category"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(CategoryFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CategoryFieldIndex.CreatedById), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity Category<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Category"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(CategoryFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(CategoryFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The DeletedById property of the Entity Category<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Category"."DeletedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CategoryFieldIndex.DeletedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CategoryFieldIndex.DeletedById), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity Category<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Category"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CategoryFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CategoryFieldIndex.Deleted), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [Case]() As EntityCollection(Of CaseEntity)
			Get
				If _case Is Nothing Then
					_case = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_case.ActiveContext = Me.ActiveContext
					_case.SetContainingEntityInfo(Me, "Category")
				End If
				Return _case
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BrandEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BrandEntity))> _
		Public Overridable ReadOnly Property [BrandCollectionViaCase]() As EntityCollection(Of BrandEntity)
			Get
				If _brandCollectionViaCase Is Nothing Then
					_brandCollectionViaCase = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
					_brandCollectionViaCase.ActiveContext = Me.ActiveContext
					_brandCollectionViaCase.IsReadOnly = True
					CType(_brandCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _brandCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BusinessProcessEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BusinessProcessEntity))> _
		Public Overridable ReadOnly Property [BusinessProcessCollectionViaCase]() As EntityCollection(Of BusinessProcessEntity)
			Get
				If _businessProcessCollectionViaCase Is Nothing Then
					_businessProcessCollectionViaCase = New EntityCollection(Of BusinessProcessEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory)))
					_businessProcessCollectionViaCase.ActiveContext = Me.ActiveContext
					_businessProcessCollectionViaCase.IsReadOnly = True
					CType(_businessProcessCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _businessProcessCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [CaseCollectionViaCase]() As EntityCollection(Of CaseEntity)
			Get
				If _caseCollectionViaCase Is Nothing Then
					_caseCollectionViaCase = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_caseCollectionViaCase.ActiveContext = Me.ActiveContext
					_caseCollectionViaCase.IsReadOnly = True
					CType(_caseCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _caseCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ClaimStatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ClaimStatusEntity))> _
		Public Overridable ReadOnly Property [ClaimStatusCollectionViaCase]() As EntityCollection(Of ClaimStatusEntity)
			Get
				If _claimStatusCollectionViaCase Is Nothing Then
					_claimStatusCollectionViaCase = New EntityCollection(Of ClaimStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ClaimStatusEntityFactory)))
					_claimStatusCollectionViaCase.ActiveContext = Me.ActiveContext
					_claimStatusCollectionViaCase.IsReadOnly = True
					CType(_claimStatusCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _claimStatusCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ComponentEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ComponentEntity))> _
		Public Overridable ReadOnly Property [ComponentCollectionViaCase]() As EntityCollection(Of ComponentEntity)
			Get
				If _componentCollectionViaCase Is Nothing Then
					_componentCollectionViaCase = New EntityCollection(Of ComponentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ComponentEntityFactory)))
					_componentCollectionViaCase.ActiveContext = Me.ActiveContext
					_componentCollectionViaCase.IsReadOnly = True
					CType(_componentCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _componentCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase Is Nothing Then
					_participantCollectionViaCase = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase.IsReadOnly = True
					CType(_participantCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase_ Is Nothing Then
					_participantCollectionViaCase_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase_.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase_.IsReadOnly = True
					CType(_participantCollectionViaCase_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase__]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase__ Is Nothing Then
					_participantCollectionViaCase__ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase__.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase__.IsReadOnly = True
					CType(_participantCollectionViaCase__, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase__
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase___]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase___ Is Nothing Then
					_participantCollectionViaCase___ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase___.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase___.IsReadOnly = True
					CType(_participantCollectionViaCase___, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase___
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase____]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase____ Is Nothing Then
					_participantCollectionViaCase____ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase____.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase____.IsReadOnly = True
					CType(_participantCollectionViaCase____, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase____
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaCase_____]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaCase_____ Is Nothing Then
					_participantCollectionViaCase_____ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaCase_____.ActiveContext = Me.ActiveContext
					_participantCollectionViaCase_____.IsReadOnly = True
					CType(_participantCollectionViaCase_____, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaCase_____
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PbuEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PbuEntity))> _
		Public Overridable ReadOnly Property [PbuCollectionViaCase]() As EntityCollection(Of PbuEntity)
			Get
				If _pbuCollectionViaCase Is Nothing Then
					_pbuCollectionViaCase = New EntityCollection(Of PbuEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PbuEntityFactory)))
					_pbuCollectionViaCase.ActiveContext = Me.ActiveContext
					_pbuCollectionViaCase.IsReadOnly = True
					CType(_pbuCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _pbuCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PersonalSafetyEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PersonalSafetyEntity))> _
		Public Overridable ReadOnly Property [PersonalSafetyCollectionViaCase]() As EntityCollection(Of PersonalSafetyEntity)
			Get
				If _personalSafetyCollectionViaCase Is Nothing Then
					_personalSafetyCollectionViaCase = New EntityCollection(Of PersonalSafetyEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PersonalSafetyEntityFactory)))
					_personalSafetyCollectionViaCase.ActiveContext = Me.ActiveContext
					_personalSafetyCollectionViaCase.IsReadOnly = True
					CType(_personalSafetyCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _personalSafetyCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaCase]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaCase Is Nothing Then
					_phaseCollectionViaCase = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaCase.ActiveContext = Me.ActiveContext
					_phaseCollectionViaCase.IsReadOnly = True
					CType(_phaseCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PlatformEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PlatformEntity))> _
		Public Overridable ReadOnly Property [PlatformCollectionViaCase]() As EntityCollection(Of PlatformEntity)
			Get
				If _platformCollectionViaCase Is Nothing Then
					_platformCollectionViaCase = New EntityCollection(Of PlatformEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PlatformEntityFactory)))
					_platformCollectionViaCase.ActiveContext = Me.ActiveContext
					_platformCollectionViaCase.IsReadOnly = True
					CType(_platformCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _platformCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PortfolioEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PortfolioEntity))> _
		Public Overridable ReadOnly Property [PortfolioCollectionViaCase]() As EntityCollection(Of PortfolioEntity)
			Get
				If _portfolioCollectionViaCase Is Nothing Then
					_portfolioCollectionViaCase = New EntityCollection(Of PortfolioEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PortfolioEntityFactory)))
					_portfolioCollectionViaCase.ActiveContext = Me.ActiveContext
					_portfolioCollectionViaCase.IsReadOnly = True
					CType(_portfolioCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _portfolioCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ProjectScopeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ProjectScopeEntity))> _
		Public Overridable ReadOnly Property [ProjectScopeCollectionViaCase]() As EntityCollection(Of ProjectScopeEntity)
			Get
				If _projectScopeCollectionViaCase Is Nothing Then
					_projectScopeCollectionViaCase = New EntityCollection(Of ProjectScopeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ProjectScopeEntityFactory)))
					_projectScopeCollectionViaCase.ActiveContext = Me.ActiveContext
					_projectScopeCollectionViaCase.IsReadOnly = True
					CType(_projectScopeCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _projectScopeCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardTaskEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardTaskEntity))> _
		Public Overridable ReadOnly Property [StandardTaskCollectionViaCase]() As EntityCollection(Of StandardTaskEntity)
			Get
				If _standardTaskCollectionViaCase Is Nothing Then
					_standardTaskCollectionViaCase = New EntityCollection(Of StandardTaskEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardTaskEntityFactory)))
					_standardTaskCollectionViaCase.ActiveContext = Me.ActiveContext
					_standardTaskCollectionViaCase.IsReadOnly = True
					CType(_standardTaskCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _standardTaskCollectionViaCase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StatusEntity))> _
		Public Overridable ReadOnly Property [StatusCollectionViaCase]() As EntityCollection(Of StatusEntity)
			Get
				If _statusCollectionViaCase Is Nothing Then
					_statusCollectionViaCase = New EntityCollection(Of StatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StatusEntityFactory)))
					_statusCollectionViaCase.ActiveContext = Me.ActiveContext
					_statusCollectionViaCase.IsReadOnly = True
					CType(_statusCollectionViaCase, IEntityCollectionCore).IsForMN = True
				End If
				Return _statusCollectionViaCase
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant]() As ParticipantEntity
			Get
				Return _participant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Category", "Participant", _participant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant_]() As ParticipantEntity
			Get
				Return _participant_
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant_(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Category_", "Participant_", _participant_, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.CategoryEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
