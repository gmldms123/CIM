﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'ChangeLog'.<br/><br/></summary>
	<Serializable()> _
	Public Class ChangeLogEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _case As CaseEntity
		Private WithEvents _changeType As ChangeTypeEntity
		Private WithEvents _participant As ParticipantEntity
		Private WithEvents _participant_ As ParticipantEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Case</summary>
			Public Shared ReadOnly [Case] As String = "Case"
			''' <summary>Member name ChangeType</summary>
			Public Shared ReadOnly [ChangeType] As String = "ChangeType"
			''' <summary>Member name Participant</summary>
			Public Shared ReadOnly [Participant] As String = "Participant"
			''' <summary>Member name Participant_</summary>
			Public Shared ReadOnly [Participant_] As String = "Participant_"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ChangeLogEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("ChangeLogEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this ChangeLogEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("ChangeLogEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="changeLogId">PK value for ChangeLog which data should be fetched into this ChangeLog object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(changeLogId As System.Int64)
			MyBase.New("ChangeLogEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.ChangeLogId = changeLogId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="changeLogId">PK value for ChangeLog which data should be fetched into this ChangeLog object</param>
		''' <param name="validator">The custom validator object for this ChangeLogEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(changeLogId As System.Int64, validator As IValidator)
			MyBase.New("ChangeLogEntity")
			InitClassEmpty(validator, Nothing)
			Me.ChangeLogId = changeLogId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_case = CType(info.GetValue("_case", GetType(CaseEntity)), CaseEntity)
				If Not _case Is Nothing Then
					AddHandler _case.AfterSave, AddressOf OnEntityAfterSave
				End If
				_changeType = CType(info.GetValue("_changeType", GetType(ChangeTypeEntity)), ChangeTypeEntity)
				If Not _changeType Is Nothing Then
					AddHandler _changeType.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant = CType(info.GetValue("_participant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant Is Nothing Then
					AddHandler _participant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant_ = CType(info.GetValue("_participant_", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant_ Is Nothing Then
					AddHandler _participant_.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, ChangeLogFieldIndex)

				Case ChangeLogFieldIndex.CaseId
					DesetupSyncCase(True, False)


				Case ChangeLogFieldIndex.ChangeTypeId
					DesetupSyncChangeType(True, False)
				Case ChangeLogFieldIndex.CreatedById
					DesetupSyncParticipant(True, False)

				Case ChangeLogFieldIndex.DeletedById
					DesetupSyncParticipant_(True, False)


				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Case"
					Me.Case = CType(entity, CaseEntity)
				Case "ChangeType"
					Me.ChangeType = CType(entity, ChangeTypeEntity)
				Case "Participant"
					Me.Participant = CType(entity, ParticipantEntity)
				Case "Participant_"
					Me.Participant_ = CType(entity, ParticipantEntity)

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return ChangeLogEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Case"
					toReturn.Add(ChangeLogEntity.Relations.CaseEntityUsingCaseId)
				Case "ChangeType"
					toReturn.Add(ChangeLogEntity.Relations.ChangeTypeEntityUsingChangeTypeId)
				Case "Participant"
					toReturn.Add(ChangeLogEntity.Relations.ParticipantEntityUsingCreatedById)
				Case "Participant_"
					toReturn.Add(ChangeLogEntity.Relations.ParticipantEntityUsingDeletedById)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Case"
					SetupSyncCase(relatedEntity)
				Case "ChangeType"
					SetupSyncChangeType(relatedEntity)
				Case "Participant"
					SetupSyncParticipant(relatedEntity)
				Case "Participant_"
					SetupSyncParticipant_(relatedEntity)

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Case"
					DesetupSyncCase(False, True)
				Case "ChangeType"
					DesetupSyncChangeType(False, True)
				Case "Participant"
					DesetupSyncParticipant(False, True)
				Case "Participant_"
					DesetupSyncParticipant_(False, True)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _case Is Nothing Then
				toReturn.Add(_case)
			End If
			If Not _changeType Is Nothing Then
				toReturn.Add(_changeType)
			End If
			If Not _participant Is Nothing Then
				toReturn.Add(_participant)
			End If
			If Not _participant_ Is Nothing Then
				toReturn.Add(_participant_)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _case
				End If
				info.AddValue("_case", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _changeType
				End If
				info.AddValue("_changeType", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant
				End If
				info.AddValue("_participant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant_
				End If
				info.AddValue("_participant_", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New ChangeLogRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Case' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'ChangeType' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoChangeType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ChangeTypeFields.ChangeTypeId, Nothing, ComparisonOperator.Equal, Me.ChangeTypeId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.DeletedById))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(ChangeLogEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Case", _case)
			toReturn.Add("ChangeType", _changeType)
			toReturn.Add("Participant", _participant)
			toReturn.Add("Participant_", _participant_)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ChangeLogId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CaseId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("BeforeValue", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("AfterValue", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ChangeTypeId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeletedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("AdditionalInfo", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _case</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncCase(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _case, AddressOf OnCasePropertyChanged, "Case", PManagement.Data.RelationClasses.StaticChangeLogRelations.CaseEntityUsingCaseIdStatic, True, signalRelatedEntity, "ChangeLog", resetFKFields, New Integer() { CInt(ChangeLogFieldIndex.CaseId) } )
			_case = Nothing
		End Sub

		''' <summary>setups the sync logic for member _case</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncCase(relatedEntity As IEntityCore)
			If Not _case Is relatedEntity Then
				DesetupSyncCase(True, True)
				_case = CType(relatedEntity, CaseEntity)
				Me.PerformSetupSyncRelatedEntity( _case, AddressOf OnCasePropertyChanged, "Case", PManagement.Data.RelationClasses.StaticChangeLogRelations.CaseEntityUsingCaseIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnCasePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _changeType</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncChangeType(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _changeType, AddressOf OnChangeTypePropertyChanged, "ChangeType", PManagement.Data.RelationClasses.StaticChangeLogRelations.ChangeTypeEntityUsingChangeTypeIdStatic, True, signalRelatedEntity, "ChangeLog", resetFKFields, New Integer() { CInt(ChangeLogFieldIndex.ChangeTypeId) } )
			_changeType = Nothing
		End Sub

		''' <summary>setups the sync logic for member _changeType</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncChangeType(relatedEntity As IEntityCore)
			If Not _changeType Is relatedEntity Then
				DesetupSyncChangeType(True, True)
				_changeType = CType(relatedEntity, ChangeTypeEntity)
				Me.PerformSetupSyncRelatedEntity( _changeType, AddressOf OnChangeTypePropertyChanged, "ChangeType", PManagement.Data.RelationClasses.StaticChangeLogRelations.ChangeTypeEntityUsingChangeTypeIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnChangeTypePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticChangeLogRelations.ParticipantEntityUsingCreatedByIdStatic, True, signalRelatedEntity, "ChangeLog", resetFKFields, New Integer() { CInt(ChangeLogFieldIndex.CreatedById) } )
			_participant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant(relatedEntity As IEntityCore)
			If Not _participant Is relatedEntity Then
				DesetupSyncParticipant(True, True)
				_participant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticChangeLogRelations.ParticipantEntityUsingCreatedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant_</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant_(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticChangeLogRelations.ParticipantEntityUsingDeletedByIdStatic, True, signalRelatedEntity, "ChangeLog_", resetFKFields, New Integer() { CInt(ChangeLogFieldIndex.DeletedById) } )
			_participant_ = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant_</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant_(relatedEntity As IEntityCore)
			If Not _participant_ Is relatedEntity Then
				DesetupSyncParticipant_(True, True)
				_participant_ = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticChangeLogRelations.ParticipantEntityUsingDeletedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipant_PropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this ChangeLogEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As ChangeLogRelations
			Get	
				Return New ChangeLogRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property




		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					CType(GetRelationsForField("Case")(0), IEntityRelation), CType(PManagement.Data.EntityType.ChangeLogEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ChangeType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathChangeType() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ChangeTypeEntityFactory))), _
					CType(GetRelationsForField("ChangeType")(0), IEntityRelation), CType(PManagement.Data.EntityType.ChangeLogEntity, Integer), CType(PManagement.Data.EntityType.ChangeTypeEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ChangeType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant")(0), IEntityRelation), CType(PManagement.Data.EntityType.ChangeLogEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant_")(0), IEntityRelation), CType(PManagement.Data.EntityType.ChangeLogEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return ChangeLogEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return ChangeLogEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The ChangeLogId property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."ChangeLogId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [ChangeLogId]() As System.Int64
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.ChangeLogId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.ChangeLogId), value)
			End Set
		End Property
		''' <summary>The CaseId property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."CaseId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CaseId]() As System.Int64
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.CaseId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.CaseId), value)
			End Set
		End Property
		''' <summary>The BeforeValue property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."BeforeValue"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [BeforeValue]() As System.String
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.BeforeValue), True), System.String)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.BeforeValue), value)
			End Set
		End Property
		''' <summary>The AfterValue property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."AfterValue"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [AfterValue]() As System.String
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.AfterValue), True), System.String)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.AfterValue), value)
			End Set
		End Property
		''' <summary>The ChangeTypeId property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."ChangeTypeId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ChangeTypeId]() As System.Int64
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.ChangeTypeId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.ChangeTypeId), value)
			End Set
		End Property
		''' <summary>The CreatedById property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.CreatedById), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The DeletedById property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."DeletedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.DeletedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.DeletedById), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.Deleted), value)
			End Set
		End Property
		''' <summary>The AdditionalInfo property of the Entity ChangeLog<br/><br/></summary>
		''' <remarks> Mapped on  table field: "ChangeLog"."AdditionalInfo"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 300<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [AdditionalInfo]() As System.String
			Get
				Return CType(GetValue(CInt(ChangeLogFieldIndex.AdditionalInfo), True), System.String)
			End Get
			Set
				SetValue(CInt(ChangeLogFieldIndex.AdditionalInfo), value)
			End Set
		End Property



		''' <summary>Gets / sets related entity of type 'CaseEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Case]() As CaseEntity
			Get
				Return _case
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncCase(value)
				Else
					SetSingleRelatedEntityNavigator(value, "ChangeLog", "Case", _case, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ChangeTypeEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ChangeType]() As ChangeTypeEntity
			Get
				Return _changeType
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncChangeType(value)
				Else
					SetSingleRelatedEntityNavigator(value, "ChangeLog", "ChangeType", _changeType, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant]() As ParticipantEntity
			Get
				Return _participant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "ChangeLog", "Participant", _participant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant_]() As ParticipantEntity
			Get
				Return _participant_
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant_(value)
				Else
					SetSingleRelatedEntityNavigator(value, "ChangeLog_", "Participant_", _participant_, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.ChangeLogEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
