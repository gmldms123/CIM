﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'Cir'.<br/><br/></summary>
	<Serializable()> _
	Public Class CirEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _case As CaseEntity
		Private WithEvents _rejectedByParticipant As ParticipantEntity
		Private WithEvents _verifiedByParticipant As ParticipantEntity
		Private WithEvents _reportType As ReportTypeEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Case</summary>
			Public Shared ReadOnly [Case] As String = "Case"
			''' <summary>Member name RejectedByParticipant</summary>
			Public Shared ReadOnly [RejectedByParticipant] As String = "RejectedByParticipant"
			''' <summary>Member name VerifiedByParticipant</summary>
			Public Shared ReadOnly [VerifiedByParticipant] As String = "VerifiedByParticipant"
			''' <summary>Member name ReportType</summary>
			Public Shared ReadOnly [ReportType] As String = "ReportType"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CirEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("CirEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this CirEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("CirEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="cirid">PK value for Cir which data should be fetched into this Cir object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(cirid As System.Int64)
			MyBase.New("CirEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.Cirid = cirid
		End Sub

		''' <summary>CTor</summary>
		''' <param name="cirid">PK value for Cir which data should be fetched into this Cir object</param>
		''' <param name="validator">The custom validator object for this CirEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(cirid As System.Int64, validator As IValidator)
			MyBase.New("CirEntity")
			InitClassEmpty(validator, Nothing)
			Me.Cirid = cirid
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_case = CType(info.GetValue("_case", GetType(CaseEntity)), CaseEntity)
				If Not _case Is Nothing Then
					AddHandler _case.AfterSave, AddressOf OnEntityAfterSave
				End If
				_rejectedByParticipant = CType(info.GetValue("_rejectedByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _rejectedByParticipant Is Nothing Then
					AddHandler _rejectedByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_verifiedByParticipant = CType(info.GetValue("_verifiedByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _verifiedByParticipant Is Nothing Then
					AddHandler _verifiedByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_reportType = CType(info.GetValue("_reportType", GetType(ReportTypeEntity)), ReportTypeEntity)
				If Not _reportType Is Nothing Then
					AddHandler _reportType.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, CirFieldIndex)

				Case CirFieldIndex.CaseId
					DesetupSyncCase(True, False)








				Case CirFieldIndex.ReportTypeId
					DesetupSyncReportType(True, False)

				Case CirFieldIndex.VerifiedBy
					DesetupSyncVerifiedByParticipant(True, False)

				Case CirFieldIndex.RejectedBy
					DesetupSyncRejectedByParticipant(True, False)




				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Case"
					Me.Case = CType(entity, CaseEntity)
				Case "RejectedByParticipant"
					Me.RejectedByParticipant = CType(entity, ParticipantEntity)
				Case "VerifiedByParticipant"
					Me.VerifiedByParticipant = CType(entity, ParticipantEntity)
				Case "ReportType"
					Me.ReportType = CType(entity, ReportTypeEntity)

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return CirEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Case"
					toReturn.Add(CirEntity.Relations.CaseEntityUsingCaseId)
				Case "RejectedByParticipant"
					toReturn.Add(CirEntity.Relations.ParticipantEntityUsingRejectedBy)
				Case "VerifiedByParticipant"
					toReturn.Add(CirEntity.Relations.ParticipantEntityUsingVerifiedBy)
				Case "ReportType"
					toReturn.Add(CirEntity.Relations.ReportTypeEntityUsingReportTypeId)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Case"
					SetupSyncCase(relatedEntity)
				Case "RejectedByParticipant"
					SetupSyncRejectedByParticipant(relatedEntity)
				Case "VerifiedByParticipant"
					SetupSyncVerifiedByParticipant(relatedEntity)
				Case "ReportType"
					SetupSyncReportType(relatedEntity)

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Case"
					DesetupSyncCase(False, True)
				Case "RejectedByParticipant"
					DesetupSyncRejectedByParticipant(False, True)
				Case "VerifiedByParticipant"
					DesetupSyncVerifiedByParticipant(False, True)
				Case "ReportType"
					DesetupSyncReportType(False, True)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _case Is Nothing Then
				toReturn.Add(_case)
			End If
			If Not _rejectedByParticipant Is Nothing Then
				toReturn.Add(_rejectedByParticipant)
			End If
			If Not _verifiedByParticipant Is Nothing Then
				toReturn.Add(_verifiedByParticipant)
			End If
			If Not _reportType Is Nothing Then
				toReturn.Add(_reportType)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _case
				End If
				info.AddValue("_case", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _rejectedByParticipant
				End If
				info.AddValue("_rejectedByParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _verifiedByParticipant
				End If
				info.AddValue("_verifiedByParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _reportType
				End If
				info.AddValue("_reportType", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New CirRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Case' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRejectedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.RejectedBy))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoVerifiedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.VerifiedBy))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'ReportType' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoReportType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ReportTypeFields.ReportTypeId, Nothing, ComparisonOperator.Equal, Me.ReportTypeId))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(CirEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Case", _case)
			toReturn.Add("RejectedByParticipant", _rejectedByParticipant)
			toReturn.Add("VerifiedByParticipant", _verifiedByParticipant)
			toReturn.Add("ReportType", _reportType)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Cirid", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CaseId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ComponentFailureReportId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineNo", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ProcessedDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedBy", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeletedBy", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("NewCir", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ReportTypeId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Verified", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("VerifiedBy", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Rejected", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("RejectedBy", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DateOfInspection", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DateOfFailure", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("SiteName", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ServiceReportNumber", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _case</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncCase(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _case, AddressOf OnCasePropertyChanged, "Case", PManagement.Data.RelationClasses.StaticCirRelations.CaseEntityUsingCaseIdStatic, True, signalRelatedEntity, "Cir", resetFKFields, New Integer() { CInt(CirFieldIndex.CaseId) } )
			_case = Nothing
		End Sub

		''' <summary>setups the sync logic for member _case</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncCase(relatedEntity As IEntityCore)
			If Not _case Is relatedEntity Then
				DesetupSyncCase(True, True)
				_case = CType(relatedEntity, CaseEntity)
				Me.PerformSetupSyncRelatedEntity( _case, AddressOf OnCasePropertyChanged, "Case", PManagement.Data.RelationClasses.StaticCirRelations.CaseEntityUsingCaseIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnCasePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _rejectedByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncRejectedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _rejectedByParticipant, AddressOf OnRejectedByParticipantPropertyChanged, "RejectedByParticipant", PManagement.Data.RelationClasses.StaticCirRelations.ParticipantEntityUsingRejectedByStatic, True, signalRelatedEntity, "Cir_", resetFKFields, New Integer() { CInt(CirFieldIndex.RejectedBy) } )
			_rejectedByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _rejectedByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncRejectedByParticipant(relatedEntity As IEntityCore)
			If Not _rejectedByParticipant Is relatedEntity Then
				DesetupSyncRejectedByParticipant(True, True)
				_rejectedByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _rejectedByParticipant, AddressOf OnRejectedByParticipantPropertyChanged, "RejectedByParticipant", PManagement.Data.RelationClasses.StaticCirRelations.ParticipantEntityUsingRejectedByStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnRejectedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _verifiedByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncVerifiedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _verifiedByParticipant, AddressOf OnVerifiedByParticipantPropertyChanged, "VerifiedByParticipant", PManagement.Data.RelationClasses.StaticCirRelations.ParticipantEntityUsingVerifiedByStatic, True, signalRelatedEntity, "Cir", resetFKFields, New Integer() { CInt(CirFieldIndex.VerifiedBy) } )
			_verifiedByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _verifiedByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncVerifiedByParticipant(relatedEntity As IEntityCore)
			If Not _verifiedByParticipant Is relatedEntity Then
				DesetupSyncVerifiedByParticipant(True, True)
				_verifiedByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _verifiedByParticipant, AddressOf OnVerifiedByParticipantPropertyChanged, "VerifiedByParticipant", PManagement.Data.RelationClasses.StaticCirRelations.ParticipantEntityUsingVerifiedByStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnVerifiedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _reportType</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncReportType(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _reportType, AddressOf OnReportTypePropertyChanged, "ReportType", PManagement.Data.RelationClasses.StaticCirRelations.ReportTypeEntityUsingReportTypeIdStatic, True, signalRelatedEntity, "Cir", resetFKFields, New Integer() { CInt(CirFieldIndex.ReportTypeId) } )
			_reportType = Nothing
		End Sub

		''' <summary>setups the sync logic for member _reportType</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncReportType(relatedEntity As IEntityCore)
			If Not _reportType Is relatedEntity Then
				DesetupSyncReportType(True, True)
				_reportType = CType(relatedEntity, ReportTypeEntity)
				Me.PerformSetupSyncRelatedEntity( _reportType, AddressOf OnReportTypePropertyChanged, "ReportType", PManagement.Data.RelationClasses.StaticCirRelations.ReportTypeEntityUsingReportTypeIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnReportTypePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this CirEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As CirRelations
			Get	
				Return New CirRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property




		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					CType(GetRelationsForField("Case")(0), IEntityRelation), CType(PManagement.Data.EntityType.CirEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRejectedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("RejectedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CirEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "RejectedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathVerifiedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("VerifiedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.CirEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "VerifiedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'ReportType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathReportType() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ReportTypeEntityFactory))), _
					CType(GetRelationsForField("ReportType")(0), IEntityRelation), CType(PManagement.Data.EntityType.CirEntity, Integer), CType(PManagement.Data.EntityType.ReportTypeEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ReportType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return CirEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return CirEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The Cirid property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."CIRId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [Cirid]() As System.Int64
			Get
				Return CType(GetValue(CInt(CirFieldIndex.Cirid), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.Cirid), value)
			End Set
		End Property
		''' <summary>The CaseId property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."CaseId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CaseId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CirFieldIndex.CaseId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.CaseId), value)
			End Set
		End Property
		''' <summary>The ComponentFailureReportId property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."ComponentFailureReportId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ComponentFailureReportId]() As System.Int64
			Get
				Return CType(GetValue(CInt(CirFieldIndex.ComponentFailureReportId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.ComponentFailureReportId), value)
			End Set
		End Property
		''' <summary>The TurbineNo property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."TurbineNo"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 10<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineNo]() As System.String
			Get
				Return CType(GetValue(CInt(CirFieldIndex.TurbineNo), True), System.String)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.TurbineNo), value)
			End Set
		End Property
		''' <summary>The ProcessedDate property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."ProcessedDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ProcessedDate]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.ProcessedDate), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.ProcessedDate), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(CirFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The CreatedBy property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."CreatedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedBy]() As System.String
			Get
				Return CType(GetValue(CInt(CirFieldIndex.CreatedBy), True), System.String)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.CreatedBy), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.Deleted), value)
			End Set
		End Property
		''' <summary>The DeletedBy property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."DeletedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedBy]() As System.String
			Get
				Return CType(GetValue(CInt(CirFieldIndex.DeletedBy), True), System.String)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.DeletedBy), value)
			End Set
		End Property
		''' <summary>The NewCir property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."NewCIR"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallInt, 5, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [NewCir]() As System.Int16
			Get
				Return CType(GetValue(CInt(CirFieldIndex.NewCir), True), System.Int16)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.NewCir), value)
			End Set
		End Property
		''' <summary>The ReportTypeId property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."ReportTypeID"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ReportTypeId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.ReportTypeId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.ReportTypeId), value)
			End Set
		End Property
		''' <summary>The Verified property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."Verified"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Verified]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.Verified), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.Verified), value)
			End Set
		End Property
		''' <summary>The VerifiedBy property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."VerifiedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [VerifiedBy]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.VerifiedBy), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.VerifiedBy), value)
			End Set
		End Property
		''' <summary>The Rejected property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."Rejected"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Rejected]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.Rejected), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.Rejected), value)
			End Set
		End Property
		''' <summary>The RejectedBy property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."RejectedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [RejectedBy]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.RejectedBy), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.RejectedBy), value)
			End Set
		End Property
		''' <summary>The DateOfInspection property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."DateOfInspection"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DateOfInspection]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.DateOfInspection), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.DateOfInspection), value)
			End Set
		End Property
		''' <summary>The DateOfFailure property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."DateOfFailure"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DateOfFailure]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(CirFieldIndex.DateOfFailure), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(CirFieldIndex.DateOfFailure), value)
			End Set
		End Property
		''' <summary>The SiteName property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."SiteName"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 200<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [SiteName]() As System.String
			Get
				Return CType(GetValue(CInt(CirFieldIndex.SiteName), True), System.String)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.SiteName), value)
			End Set
		End Property
		''' <summary>The ServiceReportNumber property of the Entity Cir<br/><br/></summary>
		''' <remarks> Mapped on  table field: "CIR"."ServiceReportNumber"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 200<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [ServiceReportNumber]() As System.String
			Get
				Return CType(GetValue(CInt(CirFieldIndex.ServiceReportNumber), True), System.String)
			End Get
			Set
				SetValue(CInt(CirFieldIndex.ServiceReportNumber), value)
			End Set
		End Property



		''' <summary>Gets / sets related entity of type 'CaseEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Case]() As CaseEntity
			Get
				Return _case
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncCase(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Cir", "Case", _case, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [RejectedByParticipant]() As ParticipantEntity
			Get
				Return _rejectedByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncRejectedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Cir_", "RejectedByParticipant", _rejectedByParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [VerifiedByParticipant]() As ParticipantEntity
			Get
				Return _verifiedByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncVerifiedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Cir", "VerifiedByParticipant", _verifiedByParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ReportTypeEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ReportType]() As ReportTypeEntity
			Get
				Return _reportType
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncReportType(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Cir", "ReportType", _reportType, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.CirEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
