﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated Imports LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated Imports templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses
#If Not CF Then
Imports System.Runtime.Serialization
#End If

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses
	''' <summary>Common base class which is the base class for all generated entities which aren't a subtype of another entity.</summary>
	<Serializable()> _
	Public MustInherit Class CommonEntityBase
		Inherits EntityBase2
		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		
		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

		''' <summary>CTor</summary>
		Protected Sub New()
			MyBase.New()
		End Sub

		''' <summary>CTor</summary>
		Protected Sub New(name As String)
			MyBase.New(name)
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		''' <summary>Gets the inheritance info provider instance of the project this entity instance is located in. </summary>
		''' <returns>ready to use inheritance info provider instance.</returns>
		Protected Overrides Function GetInheritanceInfoProvider() As IInheritanceInfoProvider 
			Return InheritanceInfoProviderSingleton.GetInstance()
		End Function
		
		''' <summary>Creates the ITypeDefaultValue instance used To provide Default values For value types which aren't of type nullable(of T)</summary>
		''' <returns></returns>
		Protected Overrides Function CreateTypeDefaultValueProvider() As ITypeDefaultValue 
			Return New TypeDefaultValue()
		End Function

#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
