﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'Discussion'.<br/><br/></summary>
	<Serializable()> _
	Public Class DiscussionEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _childDiscussion As EntityCollection(Of DiscussionEntity)
		Private WithEvents _caseCollectionViaDiscussion As EntityCollection(Of CaseEntity)
		Private WithEvents _participantCollectionViaDiscussion As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaDiscussion_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _case As CaseEntity
		Private WithEvents _parentDiscussion As DiscussionEntity
		Private WithEvents _createdByParticipant As ParticipantEntity
		Private WithEvents _modifiedByParticipant As ParticipantEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Case</summary>
			Public Shared ReadOnly [Case] As String = "Case"
			''' <summary>Member name ParentDiscussion</summary>
			Public Shared ReadOnly [ParentDiscussion] As String = "ParentDiscussion"
			''' <summary>Member name CreatedByParticipant</summary>
			Public Shared ReadOnly [CreatedByParticipant] As String = "CreatedByParticipant"
			''' <summary>Member name ModifiedByParticipant</summary>
			Public Shared ReadOnly [ModifiedByParticipant] As String = "ModifiedByParticipant"
			''' <summary>Member name ChildDiscussion</summary>
			Public Shared ReadOnly [ChildDiscussion] As String  = "ChildDiscussion"
			''' <summary>Member name CaseCollectionViaDiscussion</summary>
			Public Shared ReadOnly [CaseCollectionViaDiscussion] As String  = "CaseCollectionViaDiscussion"
			''' <summary>Member name ParticipantCollectionViaDiscussion</summary>
			Public Shared ReadOnly [ParticipantCollectionViaDiscussion] As String  = "ParticipantCollectionViaDiscussion"
			''' <summary>Member name ParticipantCollectionViaDiscussion_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaDiscussion_] As String  = "ParticipantCollectionViaDiscussion_"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DiscussionEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("DiscussionEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this DiscussionEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("DiscussionEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="discussionId">PK value for Discussion which data should be fetched into this Discussion object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(discussionId As System.Int64)
			MyBase.New("DiscussionEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.DiscussionId = discussionId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="discussionId">PK value for Discussion which data should be fetched into this Discussion object</param>
		''' <param name="validator">The custom validator object for this DiscussionEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(discussionId As System.Int64, validator As IValidator)
			MyBase.New("DiscussionEntity")
			InitClassEmpty(validator, Nothing)
			Me.DiscussionId = discussionId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_childDiscussion = CType(info.GetValue("_childDiscussion", GetType(EntityCollection(Of DiscussionEntity))), EntityCollection(Of DiscussionEntity))
				_caseCollectionViaDiscussion = CType(info.GetValue("_caseCollectionViaDiscussion", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_participantCollectionViaDiscussion = CType(info.GetValue("_participantCollectionViaDiscussion", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaDiscussion_ = CType(info.GetValue("_participantCollectionViaDiscussion_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_case = CType(info.GetValue("_case", GetType(CaseEntity)), CaseEntity)
				If Not _case Is Nothing Then
					AddHandler _case.AfterSave, AddressOf OnEntityAfterSave
				End If
				_parentDiscussion = CType(info.GetValue("_parentDiscussion", GetType(DiscussionEntity)), DiscussionEntity)
				If Not _parentDiscussion Is Nothing Then
					AddHandler _parentDiscussion.AfterSave, AddressOf OnEntityAfterSave
				End If
				_createdByParticipant = CType(info.GetValue("_createdByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _createdByParticipant Is Nothing Then
					AddHandler _createdByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_modifiedByParticipant = CType(info.GetValue("_modifiedByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _modifiedByParticipant Is Nothing Then
					AddHandler _modifiedByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, DiscussionFieldIndex)

				Case DiscussionFieldIndex.CaseId
					DesetupSyncCase(True, False)
				Case DiscussionFieldIndex.ReplyToDiscussionId
					DesetupSyncParentDiscussion(True, False)



				Case DiscussionFieldIndex.CreatedById
					DesetupSyncCreatedByParticipant(True, False)

				Case DiscussionFieldIndex.ModifiedById
					DesetupSyncModifiedByParticipant(True, False)
				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Case"
					Me.Case = CType(entity, CaseEntity)
				Case "ParentDiscussion"
					Me.ParentDiscussion = CType(entity, DiscussionEntity)
				Case "CreatedByParticipant"
					Me.CreatedByParticipant = CType(entity, ParticipantEntity)
				Case "ModifiedByParticipant"
					Me.ModifiedByParticipant = CType(entity, ParticipantEntity)
				Case "ChildDiscussion"
					Me.ChildDiscussion.Add(CType(entity, DiscussionEntity))
				Case "CaseCollectionViaDiscussion"
					Me.CaseCollectionViaDiscussion.IsReadOnly = False
					Me.CaseCollectionViaDiscussion.Add(CType(entity, CaseEntity))
					Me.CaseCollectionViaDiscussion.IsReadOnly = True
				Case "ParticipantCollectionViaDiscussion"
					Me.ParticipantCollectionViaDiscussion.IsReadOnly = False
					Me.ParticipantCollectionViaDiscussion.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaDiscussion.IsReadOnly = True
				Case "ParticipantCollectionViaDiscussion_"
					Me.ParticipantCollectionViaDiscussion_.IsReadOnly = False
					Me.ParticipantCollectionViaDiscussion_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaDiscussion_.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return DiscussionEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Case"
					toReturn.Add(DiscussionEntity.Relations.CaseEntityUsingCaseId)
				Case "ParentDiscussion"
					toReturn.Add(DiscussionEntity.Relations.DiscussionEntityUsingDiscussionIdReplyToDiscussionId)
				Case "CreatedByParticipant"
					toReturn.Add(DiscussionEntity.Relations.ParticipantEntityUsingCreatedById)
				Case "ModifiedByParticipant"
					toReturn.Add(DiscussionEntity.Relations.ParticipantEntityUsingModifiedById)
				Case "ChildDiscussion"
					toReturn.Add(DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId)
				Case "CaseCollectionViaDiscussion"
					toReturn.Add(DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId, "DiscussionEntity__", "Discussion_", JoinHint.None)
					toReturn.Add(DiscussionEntity.Relations.CaseEntityUsingCaseId, "Discussion_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaDiscussion"
					toReturn.Add(DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId, "DiscussionEntity__", "Discussion_", JoinHint.None)
					toReturn.Add(DiscussionEntity.Relations.ParticipantEntityUsingModifiedById, "Discussion_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaDiscussion_"
					toReturn.Add(DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId, "DiscussionEntity__", "Discussion_", JoinHint.None)
					toReturn.Add(DiscussionEntity.Relations.ParticipantEntityUsingCreatedById, "Discussion_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Case"
					SetupSyncCase(relatedEntity)
				Case "ParentDiscussion"
					SetupSyncParentDiscussion(relatedEntity)
				Case "CreatedByParticipant"
					SetupSyncCreatedByParticipant(relatedEntity)
				Case "ModifiedByParticipant"
					SetupSyncModifiedByParticipant(relatedEntity)
				Case "ChildDiscussion"
					Me.ChildDiscussion.Add(CType(relatedEntity, DiscussionEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Case"
					DesetupSyncCase(False, True)
				Case "ParentDiscussion"
					DesetupSyncParentDiscussion(False, True)
				Case "CreatedByParticipant"
					DesetupSyncCreatedByParticipant(False, True)
				Case "ModifiedByParticipant"
					DesetupSyncModifiedByParticipant(False, True)
				Case "ChildDiscussion"
					Me.PerformRelatedEntityRemoval(Me.ChildDiscussion, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _case Is Nothing Then
				toReturn.Add(_case)
			End If
			If Not _parentDiscussion Is Nothing Then
				toReturn.Add(_parentDiscussion)
			End If
			If Not _createdByParticipant Is Nothing Then
				toReturn.Add(_createdByParticipant)
			End If
			If Not _modifiedByParticipant Is Nothing Then
				toReturn.Add(_modifiedByParticipant)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.ChildDiscussion)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_childDiscussion Is Nothing)) AndAlso (_childDiscussion.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _childDiscussion 
				End If
				info.AddValue("_childDiscussion", value)
				value = Nothing 
				If (Not (_caseCollectionViaDiscussion Is Nothing)) AndAlso (_caseCollectionViaDiscussion.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _caseCollectionViaDiscussion 
				End If
				info.AddValue("_caseCollectionViaDiscussion", value)
				value = Nothing 
				If (Not (_participantCollectionViaDiscussion Is Nothing)) AndAlso (_participantCollectionViaDiscussion.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaDiscussion 
				End If
				info.AddValue("_participantCollectionViaDiscussion", value)
				value = Nothing 
				If (Not (_participantCollectionViaDiscussion_ Is Nothing)) AndAlso (_participantCollectionViaDiscussion_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaDiscussion_ 
				End If
				info.AddValue("_participantCollectionViaDiscussion_", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _case
				End If
				info.AddValue("_case", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _parentDiscussion
				End If
				info.AddValue("_parentDiscussion", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _createdByParticipant
				End If
				info.AddValue("_createdByParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _modifiedByParticipant
				End If
				info.AddValue("_modifiedByParticipant", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New DiscussionRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Discussion' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoChildDiscussion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DiscussionFields.ReplyToDiscussionId, Nothing, ComparisonOperator.Equal, Me.DiscussionId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCaseCollectionViaDiscussion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CaseCollectionViaDiscussion"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DiscussionFields.DiscussionId, Nothing, ComparisonOperator.Equal, Me.DiscussionId, "DiscussionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaDiscussion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaDiscussion"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DiscussionFields.DiscussionId, Nothing, ComparisonOperator.Equal, Me.DiscussionId, "DiscussionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaDiscussion_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaDiscussion_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DiscussionFields.DiscussionId, Nothing, ComparisonOperator.Equal, Me.DiscussionId, "DiscussionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Case' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(CaseFields.CaseId, Nothing, ComparisonOperator.Equal, Me.CaseId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Discussion' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParentDiscussion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DiscussionFields.DiscussionId, Nothing, ComparisonOperator.Equal, Me.ReplyToDiscussionId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCreatedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoModifiedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.ModifiedById))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_childDiscussion)
			collectionsQueue.Enqueue(_caseCollectionViaDiscussion)
			collectionsQueue.Enqueue(_participantCollectionViaDiscussion)
			collectionsQueue.Enqueue(_participantCollectionViaDiscussion_)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_childDiscussion = CType(collectionsQueue.Dequeue(), EntityCollection(Of DiscussionEntity))
			_caseCollectionViaDiscussion = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_participantCollectionViaDiscussion = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaDiscussion_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _childDiscussion Is Nothing) Then
				Return True
			End If
			If (Not _caseCollectionViaDiscussion Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaDiscussion Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaDiscussion_ Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Case", _case)
			toReturn.Add("ParentDiscussion", _parentDiscussion)
			toReturn.Add("CreatedByParticipant", _createdByParticipant)
			toReturn.Add("ModifiedByParticipant", _modifiedByParticipant)
			toReturn.Add("ChildDiscussion", _childDiscussion)
			toReturn.Add("CaseCollectionViaDiscussion", _caseCollectionViaDiscussion)
			toReturn.Add("ParticipantCollectionViaDiscussion", _participantCollectionViaDiscussion)
			toReturn.Add("ParticipantCollectionViaDiscussion_", _participantCollectionViaDiscussion_)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DiscussionId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CaseId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ReplyToDiscussionId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Name", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Description", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Modified", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ModifiedById", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _case</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncCase(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _case, AddressOf OnCasePropertyChanged, "Case", PManagement.Data.RelationClasses.StaticDiscussionRelations.CaseEntityUsingCaseIdStatic, True, signalRelatedEntity, "Discussion", resetFKFields, New Integer() { CInt(DiscussionFieldIndex.CaseId) } )
			_case = Nothing
		End Sub

		''' <summary>setups the sync logic for member _case</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncCase(relatedEntity As IEntityCore)
			If Not _case Is relatedEntity Then
				DesetupSyncCase(True, True)
				_case = CType(relatedEntity, CaseEntity)
				Me.PerformSetupSyncRelatedEntity( _case, AddressOf OnCasePropertyChanged, "Case", PManagement.Data.RelationClasses.StaticDiscussionRelations.CaseEntityUsingCaseIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnCasePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _parentDiscussion</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParentDiscussion(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _parentDiscussion, AddressOf OnParentDiscussionPropertyChanged, "ParentDiscussion", PManagement.Data.RelationClasses.StaticDiscussionRelations.DiscussionEntityUsingDiscussionIdReplyToDiscussionIdStatic, True, signalRelatedEntity, "ChildDiscussion", resetFKFields, New Integer() { CInt(DiscussionFieldIndex.ReplyToDiscussionId) } )
			_parentDiscussion = Nothing
		End Sub

		''' <summary>setups the sync logic for member _parentDiscussion</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParentDiscussion(relatedEntity As IEntityCore)
			If Not _parentDiscussion Is relatedEntity Then
				DesetupSyncParentDiscussion(True, True)
				_parentDiscussion = CType(relatedEntity, DiscussionEntity)
				Me.PerformSetupSyncRelatedEntity( _parentDiscussion, AddressOf OnParentDiscussionPropertyChanged, "ParentDiscussion", PManagement.Data.RelationClasses.StaticDiscussionRelations.DiscussionEntityUsingDiscussionIdReplyToDiscussionIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParentDiscussionPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _createdByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncCreatedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _createdByParticipant, AddressOf OnCreatedByParticipantPropertyChanged, "CreatedByParticipant", PManagement.Data.RelationClasses.StaticDiscussionRelations.ParticipantEntityUsingCreatedByIdStatic, True, signalRelatedEntity, "Discussion_", resetFKFields, New Integer() { CInt(DiscussionFieldIndex.CreatedById) } )
			_createdByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _createdByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncCreatedByParticipant(relatedEntity As IEntityCore)
			If Not _createdByParticipant Is relatedEntity Then
				DesetupSyncCreatedByParticipant(True, True)
				_createdByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _createdByParticipant, AddressOf OnCreatedByParticipantPropertyChanged, "CreatedByParticipant", PManagement.Data.RelationClasses.StaticDiscussionRelations.ParticipantEntityUsingCreatedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnCreatedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _modifiedByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncModifiedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _modifiedByParticipant, AddressOf OnModifiedByParticipantPropertyChanged, "ModifiedByParticipant", PManagement.Data.RelationClasses.StaticDiscussionRelations.ParticipantEntityUsingModifiedByIdStatic, True, signalRelatedEntity, "Discussion", resetFKFields, New Integer() { CInt(DiscussionFieldIndex.ModifiedById) } )
			_modifiedByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _modifiedByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncModifiedByParticipant(relatedEntity As IEntityCore)
			If Not _modifiedByParticipant Is relatedEntity Then
				DesetupSyncModifiedByParticipant(True, True)
				_modifiedByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _modifiedByParticipant, AddressOf OnModifiedByParticipantPropertyChanged, "ModifiedByParticipant", PManagement.Data.RelationClasses.StaticDiscussionRelations.ParticipantEntityUsingModifiedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnModifiedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this DiscussionEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As DiscussionRelations
			Get	
				Return New DiscussionRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Discussion'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathChildDiscussion() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory))), _
					CType(GetRelationsForField("ChildDiscussion")(0), IEntityRelation), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ChildDiscussion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCaseCollectionViaDiscussion() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId
				intermediateRelation.SetAliases(String.Empty, "Discussion_")
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CaseCollectionViaDiscussion"), Nothing, "CaseCollectionViaDiscussion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaDiscussion() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId
				intermediateRelation.SetAliases(String.Empty, "Discussion_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaDiscussion"), Nothing, "ParticipantCollectionViaDiscussion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaDiscussion_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = DiscussionEntity.Relations.DiscussionEntityUsingReplyToDiscussionId
				intermediateRelation.SetAliases(String.Empty, "Discussion_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaDiscussion_"), Nothing, "ParticipantCollectionViaDiscussion_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					CType(GetRelationsForField("Case")(0), IEntityRelation), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Discussion' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParentDiscussion() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory))), _
					CType(GetRelationsForField("ParentDiscussion")(0), IEntityRelation), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ParentDiscussion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCreatedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("CreatedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "CreatedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathModifiedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("ModifiedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.DiscussionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "ModifiedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return DiscussionEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return DiscussionEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The DiscussionId property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."DiscussionId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [DiscussionId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.DiscussionId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.DiscussionId), value)
			End Set
		End Property
		''' <summary>The CaseId property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."CaseId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CaseId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.CaseId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.CaseId), value)
			End Set
		End Property
		''' <summary>The ReplyToDiscussionId property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."ReplyToDiscussionId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ReplyToDiscussionId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.ReplyToDiscussionId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.ReplyToDiscussionId), value)
			End Set
		End Property
		''' <summary>The Name property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."Name"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 100<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Name]() As System.String
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.Name), True), System.String)
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.Name), value)
			End Set
		End Property
		''' <summary>The Description property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."Description"<br/>
		''' Table field type characteristics (type, precision, scale, length): NText, 0, 0, 1073741823<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Description]() As System.String
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.Description), True), System.String)
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.Description), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The CreatedById property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.CreatedById), value)
			End Set
		End Property
		''' <summary>The Modified property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."Modified"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Modified]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.Modified), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.Modified), value)
			End Set
		End Property
		''' <summary>The ModifiedById property of the Entity Discussion<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Discussion"."ModifiedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ModifiedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(DiscussionFieldIndex.ModifiedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(DiscussionFieldIndex.ModifiedById), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'DiscussionEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(DiscussionEntity))> _
		Public Overridable ReadOnly Property [ChildDiscussion]() As EntityCollection(Of DiscussionEntity)
			Get
				If _childDiscussion Is Nothing Then
					_childDiscussion = New EntityCollection(Of DiscussionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DiscussionEntityFactory)))
					_childDiscussion.ActiveContext = Me.ActiveContext
					_childDiscussion.SetContainingEntityInfo(Me, "ParentDiscussion")
				End If
				Return _childDiscussion
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [CaseCollectionViaDiscussion]() As EntityCollection(Of CaseEntity)
			Get
				If _caseCollectionViaDiscussion Is Nothing Then
					_caseCollectionViaDiscussion = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_caseCollectionViaDiscussion.ActiveContext = Me.ActiveContext
					_caseCollectionViaDiscussion.IsReadOnly = True
					CType(_caseCollectionViaDiscussion, IEntityCollectionCore).IsForMN = True
				End If
				Return _caseCollectionViaDiscussion
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaDiscussion]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaDiscussion Is Nothing Then
					_participantCollectionViaDiscussion = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaDiscussion.ActiveContext = Me.ActiveContext
					_participantCollectionViaDiscussion.IsReadOnly = True
					CType(_participantCollectionViaDiscussion, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaDiscussion
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaDiscussion_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaDiscussion_ Is Nothing Then
					_participantCollectionViaDiscussion_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaDiscussion_.ActiveContext = Me.ActiveContext
					_participantCollectionViaDiscussion_.IsReadOnly = True
					CType(_participantCollectionViaDiscussion_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaDiscussion_
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'CaseEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Case]() As CaseEntity
			Get
				Return _case
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncCase(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Discussion", "Case", _case, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'DiscussionEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ParentDiscussion]() As DiscussionEntity
			Get
				Return _parentDiscussion
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParentDiscussion(value)
				Else
					SetSingleRelatedEntityNavigator(value, "ChildDiscussion", "ParentDiscussion", _parentDiscussion, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [CreatedByParticipant]() As ParticipantEntity
			Get
				Return _createdByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncCreatedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Discussion_", "CreatedByParticipant", _createdByParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [ModifiedByParticipant]() As ParticipantEntity
			Get
				Return _modifiedByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncModifiedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Discussion", "ModifiedByParticipant", _modifiedByParticipant, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.DiscussionEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
