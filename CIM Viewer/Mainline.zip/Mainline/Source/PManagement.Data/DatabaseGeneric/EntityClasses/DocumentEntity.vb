﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'Document'.<br/><br/></summary>
	<Serializable()> _
	Public Class DocumentEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _documentVersion As EntityCollection(Of DocumentVersionEntity)
		Private WithEvents _folder2Document As EntityCollection(Of Folder2DocumentEntity)
		Private WithEvents _documentStatusCollectionViaFolder2Document As EntityCollection(Of DocumentStatusEntity)
		Private WithEvents _folderCollectionViaFolder2Document As EntityCollection(Of FolderEntity)
		Private WithEvents _documentBinary As DocumentBinaryEntity
		Private WithEvents _documentClassification As DocumentClassificationEntity
		Private WithEvents _createdByParticipant As ParticipantEntity
		Private WithEvents _lockedByParticipant As ParticipantEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name DocumentBinary</summary>
			Public Shared ReadOnly [DocumentBinary] As String = "DocumentBinary"
			''' <summary>Member name DocumentClassification</summary>
			Public Shared ReadOnly [DocumentClassification] As String = "DocumentClassification"
			''' <summary>Member name CreatedByParticipant</summary>
			Public Shared ReadOnly [CreatedByParticipant] As String = "CreatedByParticipant"
			''' <summary>Member name LockedByParticipant</summary>
			Public Shared ReadOnly [LockedByParticipant] As String = "LockedByParticipant"
			''' <summary>Member name DocumentVersion</summary>
			Public Shared ReadOnly [DocumentVersion] As String  = "DocumentVersion"
			''' <summary>Member name Folder2Document</summary>
			Public Shared ReadOnly [Folder2Document] As String  = "Folder2Document"
			''' <summary>Member name DocumentStatusCollectionViaFolder2Document</summary>
			Public Shared ReadOnly [DocumentStatusCollectionViaFolder2Document] As String  = "DocumentStatusCollectionViaFolder2Document"
			''' <summary>Member name FolderCollectionViaFolder2Document</summary>
			Public Shared ReadOnly [FolderCollectionViaFolder2Document] As String  = "FolderCollectionViaFolder2Document"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("DocumentEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this DocumentEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("DocumentEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="documentId">PK value for Document which data should be fetched into this Document object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(documentId As System.Int64)
			MyBase.New("DocumentEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.DocumentId = documentId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="documentId">PK value for Document which data should be fetched into this Document object</param>
		''' <param name="validator">The custom validator object for this DocumentEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(documentId As System.Int64, validator As IValidator)
			MyBase.New("DocumentEntity")
			InitClassEmpty(validator, Nothing)
			Me.DocumentId = documentId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_documentVersion = CType(info.GetValue("_documentVersion", GetType(EntityCollection(Of DocumentVersionEntity))), EntityCollection(Of DocumentVersionEntity))
				_folder2Document = CType(info.GetValue("_folder2Document", GetType(EntityCollection(Of Folder2DocumentEntity))), EntityCollection(Of Folder2DocumentEntity))
				_documentStatusCollectionViaFolder2Document = CType(info.GetValue("_documentStatusCollectionViaFolder2Document", GetType(EntityCollection(Of DocumentStatusEntity))), EntityCollection(Of DocumentStatusEntity))
				_folderCollectionViaFolder2Document = CType(info.GetValue("_folderCollectionViaFolder2Document", GetType(EntityCollection(Of FolderEntity))), EntityCollection(Of FolderEntity))
				_documentBinary = CType(info.GetValue("_documentBinary", GetType(DocumentBinaryEntity)), DocumentBinaryEntity)
				If Not _documentBinary Is Nothing Then
					AddHandler _documentBinary.AfterSave, AddressOf OnEntityAfterSave
				End If
				_documentClassification = CType(info.GetValue("_documentClassification", GetType(DocumentClassificationEntity)), DocumentClassificationEntity)
				If Not _documentClassification Is Nothing Then
					AddHandler _documentClassification.AfterSave, AddressOf OnEntityAfterSave
				End If
				_createdByParticipant = CType(info.GetValue("_createdByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _createdByParticipant Is Nothing Then
					AddHandler _createdByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_lockedByParticipant = CType(info.GetValue("_lockedByParticipant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _lockedByParticipant Is Nothing Then
					AddHandler _lockedByParticipant.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, DocumentFieldIndex)

				Case DocumentFieldIndex.DocumentBinaryId
					DesetupSyncDocumentBinary(True, False)
				Case DocumentFieldIndex.DocumentClassificationId
					DesetupSyncDocumentClassification(True, False)













				Case DocumentFieldIndex.CreatedById
					DesetupSyncCreatedByParticipant(True, False)

				Case DocumentFieldIndex.LockedById
					DesetupSyncLockedByParticipant(True, False)

				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "DocumentBinary"
					Me.DocumentBinary = CType(entity, DocumentBinaryEntity)
				Case "DocumentClassification"
					Me.DocumentClassification = CType(entity, DocumentClassificationEntity)
				Case "CreatedByParticipant"
					Me.CreatedByParticipant = CType(entity, ParticipantEntity)
				Case "LockedByParticipant"
					Me.LockedByParticipant = CType(entity, ParticipantEntity)
				Case "DocumentVersion"
					Me.DocumentVersion.Add(CType(entity, DocumentVersionEntity))
				Case "Folder2Document"
					Me.Folder2Document.Add(CType(entity, Folder2DocumentEntity))
				Case "DocumentStatusCollectionViaFolder2Document"
					Me.DocumentStatusCollectionViaFolder2Document.IsReadOnly = False
					Me.DocumentStatusCollectionViaFolder2Document.Add(CType(entity, DocumentStatusEntity))
					Me.DocumentStatusCollectionViaFolder2Document.IsReadOnly = True
				Case "FolderCollectionViaFolder2Document"
					Me.FolderCollectionViaFolder2Document.IsReadOnly = False
					Me.FolderCollectionViaFolder2Document.Add(CType(entity, FolderEntity))
					Me.FolderCollectionViaFolder2Document.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return DocumentEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "DocumentBinary"
					toReturn.Add(DocumentEntity.Relations.DocumentBinaryEntityUsingDocumentBinaryId)
				Case "DocumentClassification"
					toReturn.Add(DocumentEntity.Relations.DocumentClassificationEntityUsingDocumentClassificationId)
				Case "CreatedByParticipant"
					toReturn.Add(DocumentEntity.Relations.ParticipantEntityUsingCreatedById)
				Case "LockedByParticipant"
					toReturn.Add(DocumentEntity.Relations.ParticipantEntityUsingLockedById)
				Case "DocumentVersion"
					toReturn.Add(DocumentEntity.Relations.DocumentVersionEntityUsingDocumentId)
				Case "Folder2Document"
					toReturn.Add(DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId)
				Case "DocumentStatusCollectionViaFolder2Document"
					toReturn.Add(DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId, "DocumentEntity__", "Folder2Document_", JoinHint.None)
					toReturn.Add(Folder2DocumentEntity.Relations.DocumentStatusEntityUsingDocumentStatusId, "Folder2Document_", String.Empty, JoinHint.None)
				Case "FolderCollectionViaFolder2Document"
					toReturn.Add(DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId, "DocumentEntity__", "Folder2Document_", JoinHint.None)
					toReturn.Add(Folder2DocumentEntity.Relations.FolderEntityUsingFolderId, "Folder2Document_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "DocumentBinary"
					SetupSyncDocumentBinary(relatedEntity)
				Case "DocumentClassification"
					SetupSyncDocumentClassification(relatedEntity)
				Case "CreatedByParticipant"
					SetupSyncCreatedByParticipant(relatedEntity)
				Case "LockedByParticipant"
					SetupSyncLockedByParticipant(relatedEntity)
				Case "DocumentVersion"
					Me.DocumentVersion.Add(CType(relatedEntity, DocumentVersionEntity))
				Case "Folder2Document"
					Me.Folder2Document.Add(CType(relatedEntity, Folder2DocumentEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "DocumentBinary"
					DesetupSyncDocumentBinary(False, True)
				Case "DocumentClassification"
					DesetupSyncDocumentClassification(False, True)
				Case "CreatedByParticipant"
					DesetupSyncCreatedByParticipant(False, True)
				Case "LockedByParticipant"
					DesetupSyncLockedByParticipant(False, True)
				Case "DocumentVersion"
					Me.PerformRelatedEntityRemoval(Me.DocumentVersion, relatedEntity, signalRelatedEntityManyToOne)
				Case "Folder2Document"
					Me.PerformRelatedEntityRemoval(Me.Folder2Document, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _documentBinary Is Nothing Then
				toReturn.Add(_documentBinary)
			End If
			If Not _documentClassification Is Nothing Then
				toReturn.Add(_documentClassification)
			End If
			If Not _createdByParticipant Is Nothing Then
				toReturn.Add(_createdByParticipant)
			End If
			If Not _lockedByParticipant Is Nothing Then
				toReturn.Add(_lockedByParticipant)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.DocumentVersion)
			toReturn.Add(Me.Folder2Document)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_documentVersion Is Nothing)) AndAlso (_documentVersion.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _documentVersion 
				End If
				info.AddValue("_documentVersion", value)
				value = Nothing 
				If (Not (_folder2Document Is Nothing)) AndAlso (_folder2Document.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _folder2Document 
				End If
				info.AddValue("_folder2Document", value)
				value = Nothing 
				If (Not (_documentStatusCollectionViaFolder2Document Is Nothing)) AndAlso (_documentStatusCollectionViaFolder2Document.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _documentStatusCollectionViaFolder2Document 
				End If
				info.AddValue("_documentStatusCollectionViaFolder2Document", value)
				value = Nothing 
				If (Not (_folderCollectionViaFolder2Document Is Nothing)) AndAlso (_folderCollectionViaFolder2Document.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _folderCollectionViaFolder2Document 
				End If
				info.AddValue("_folderCollectionViaFolder2Document", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _documentBinary
				End If
				info.AddValue("_documentBinary", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _documentClassification
				End If
				info.AddValue("_documentClassification", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _createdByParticipant
				End If
				info.AddValue("_createdByParticipant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _lockedByParticipant
				End If
				info.AddValue("_lockedByParticipant", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New DocumentRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'DocumentVersion' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentVersion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentVersionFields.DocumentId, Nothing, ComparisonOperator.Equal, Me.DocumentId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Folder2Document' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolder2Document() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Folder2DocumentFields.DocumentId, Nothing, ComparisonOperator.Equal, Me.DocumentId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'DocumentStatus' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentStatusCollectionViaFolder2Document() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("DocumentStatusCollectionViaFolder2Document"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentFields.DocumentId, Nothing, ComparisonOperator.Equal, Me.DocumentId, "DocumentEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Folder' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolderCollectionViaFolder2Document() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("FolderCollectionViaFolder2Document"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentFields.DocumentId, Nothing, ComparisonOperator.Equal, Me.DocumentId, "DocumentEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'DocumentBinary' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentBinary() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentBinaryFields.DocumentBinaryId, Nothing, ComparisonOperator.Equal, Me.DocumentBinaryId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'DocumentClassification' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentClassification() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentClassificationFields.DocumentClassificationId, Nothing, ComparisonOperator.Equal, Me.DocumentClassificationId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCreatedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoLockedByParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.LockedById))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(DocumentEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_documentVersion)
			collectionsQueue.Enqueue(_folder2Document)
			collectionsQueue.Enqueue(_documentStatusCollectionViaFolder2Document)
			collectionsQueue.Enqueue(_folderCollectionViaFolder2Document)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_documentVersion = CType(collectionsQueue.Dequeue(), EntityCollection(Of DocumentVersionEntity))
			_folder2Document = CType(collectionsQueue.Dequeue(), EntityCollection(Of Folder2DocumentEntity))
			_documentStatusCollectionViaFolder2Document = CType(collectionsQueue.Dequeue(), EntityCollection(Of DocumentStatusEntity))
			_folderCollectionViaFolder2Document = CType(collectionsQueue.Dequeue(), EntityCollection(Of FolderEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _documentVersion Is Nothing) Then
				Return True
			End If
			If (Not _folder2Document Is Nothing) Then
				Return True
			End If
			If (Not _documentStatusCollectionViaFolder2Document Is Nothing) Then
				Return True
			End If
			If (Not _folderCollectionViaFolder2Document Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of DocumentVersionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentVersionEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Folder2DocumentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Folder2DocumentEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of DocumentStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentStatusEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("DocumentBinary", _documentBinary)
			toReturn.Add("DocumentClassification", _documentClassification)
			toReturn.Add("CreatedByParticipant", _createdByParticipant)
			toReturn.Add("LockedByParticipant", _lockedByParticipant)
			toReturn.Add("DocumentVersion", _documentVersion)
			toReturn.Add("Folder2Document", _folder2Document)
			toReturn.Add("DocumentStatusCollectionViaFolder2Document", _documentStatusCollectionViaFolder2Document)
			toReturn.Add("FolderCollectionViaFolder2Document", _folderCollectionViaFolder2Document)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DocumentId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DocumentBinaryId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DocumentClassificationId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("FileName", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("FileSize", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("FileDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Title", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Description", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Category", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("LinkNo", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PictureHeight", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PictureWidth", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("PictureDate", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Thumbnail", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineNumber", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Locked", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("LockedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _documentBinary</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncDocumentBinary(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _documentBinary, AddressOf OnDocumentBinaryPropertyChanged, "DocumentBinary", PManagement.Data.RelationClasses.StaticDocumentRelations.DocumentBinaryEntityUsingDocumentBinaryIdStatic, True, signalRelatedEntity, "Document_", resetFKFields, New Integer() { CInt(DocumentFieldIndex.DocumentBinaryId) } )
			_documentBinary = Nothing
		End Sub

		''' <summary>setups the sync logic for member _documentBinary</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncDocumentBinary(relatedEntity As IEntityCore)
			If Not _documentBinary Is relatedEntity Then
				DesetupSyncDocumentBinary(True, True)
				_documentBinary = CType(relatedEntity, DocumentBinaryEntity)
				Me.PerformSetupSyncRelatedEntity( _documentBinary, AddressOf OnDocumentBinaryPropertyChanged, "DocumentBinary", PManagement.Data.RelationClasses.StaticDocumentRelations.DocumentBinaryEntityUsingDocumentBinaryIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnDocumentBinaryPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _documentClassification</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncDocumentClassification(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _documentClassification, AddressOf OnDocumentClassificationPropertyChanged, "DocumentClassification", PManagement.Data.RelationClasses.StaticDocumentRelations.DocumentClassificationEntityUsingDocumentClassificationIdStatic, True, signalRelatedEntity, "Document", resetFKFields, New Integer() { CInt(DocumentFieldIndex.DocumentClassificationId) } )
			_documentClassification = Nothing
		End Sub

		''' <summary>setups the sync logic for member _documentClassification</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncDocumentClassification(relatedEntity As IEntityCore)
			If Not _documentClassification Is relatedEntity Then
				DesetupSyncDocumentClassification(True, True)
				_documentClassification = CType(relatedEntity, DocumentClassificationEntity)
				Me.PerformSetupSyncRelatedEntity( _documentClassification, AddressOf OnDocumentClassificationPropertyChanged, "DocumentClassification", PManagement.Data.RelationClasses.StaticDocumentRelations.DocumentClassificationEntityUsingDocumentClassificationIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnDocumentClassificationPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _createdByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncCreatedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _createdByParticipant, AddressOf OnCreatedByParticipantPropertyChanged, "CreatedByParticipant", PManagement.Data.RelationClasses.StaticDocumentRelations.ParticipantEntityUsingCreatedByIdStatic, True, signalRelatedEntity, "Document", resetFKFields, New Integer() { CInt(DocumentFieldIndex.CreatedById) } )
			_createdByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _createdByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncCreatedByParticipant(relatedEntity As IEntityCore)
			If Not _createdByParticipant Is relatedEntity Then
				DesetupSyncCreatedByParticipant(True, True)
				_createdByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _createdByParticipant, AddressOf OnCreatedByParticipantPropertyChanged, "CreatedByParticipant", PManagement.Data.RelationClasses.StaticDocumentRelations.ParticipantEntityUsingCreatedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnCreatedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _lockedByParticipant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncLockedByParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _lockedByParticipant, AddressOf OnLockedByParticipantPropertyChanged, "LockedByParticipant", PManagement.Data.RelationClasses.StaticDocumentRelations.ParticipantEntityUsingLockedByIdStatic, True, signalRelatedEntity, "Document_", resetFKFields, New Integer() { CInt(DocumentFieldIndex.LockedById) } )
			_lockedByParticipant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _lockedByParticipant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncLockedByParticipant(relatedEntity As IEntityCore)
			If Not _lockedByParticipant Is relatedEntity Then
				DesetupSyncLockedByParticipant(True, True)
				_lockedByParticipant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _lockedByParticipant, AddressOf OnLockedByParticipantPropertyChanged, "LockedByParticipant", PManagement.Data.RelationClasses.StaticDocumentRelations.ParticipantEntityUsingLockedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnLockedByParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this DocumentEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As DocumentRelations
			Get	
				Return New DocumentRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentVersion'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentVersion() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of DocumentVersionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentVersionEntityFactory))), _
					CType(GetRelationsForField("DocumentVersion")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.DocumentVersionEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "DocumentVersion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Folder2Document'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolder2Document() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Folder2DocumentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Folder2DocumentEntityFactory))), _
					CType(GetRelationsForField("Folder2Document")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.Folder2DocumentEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Folder2Document", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentStatus' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentStatusCollectionViaFolder2Document() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId
				intermediateRelation.SetAliases(String.Empty, "Folder2Document_")
				Return New PrefetchPathElement2( New EntityCollection(Of DocumentStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentStatusEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.DocumentStatusEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("DocumentStatusCollectionViaFolder2Document"), Nothing, "DocumentStatusCollectionViaFolder2Document", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Folder' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolderCollectionViaFolder2Document() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = DocumentEntity.Relations.Folder2DocumentEntityUsingDocumentId
				intermediateRelation.SetAliases(String.Empty, "Folder2Document_")
				Return New PrefetchPathElement2( New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.FolderEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("FolderCollectionViaFolder2Document"), Nothing, "FolderCollectionViaFolder2Document", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentBinary' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentBinary() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(DocumentBinaryEntityFactory))), _
					CType(GetRelationsForField("DocumentBinary")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.DocumentBinaryEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "DocumentBinary", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentClassification' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentClassification() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(DocumentClassificationEntityFactory))), _
					CType(GetRelationsForField("DocumentClassification")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.DocumentClassificationEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "DocumentClassification", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCreatedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("CreatedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "CreatedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathLockedByParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("LockedByParticipant")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "LockedByParticipant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return DocumentEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return DocumentEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The DocumentId property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."DocumentId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [DocumentId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.DocumentId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.DocumentId), value)
			End Set
		End Property
		''' <summary>The DocumentBinaryId property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."DocumentBinaryId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [DocumentBinaryId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.DocumentBinaryId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.DocumentBinaryId), value)
			End Set
		End Property
		''' <summary>The DocumentClassificationId property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."DocumentClassificationId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [DocumentClassificationId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.DocumentClassificationId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.DocumentClassificationId), value)
			End Set
		End Property
		''' <summary>The FileName property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."FileName"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 260<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [FileName]() As System.String
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.FileName), True), System.String)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.FileName), value)
			End Set
		End Property
		''' <summary>The FileSize property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."FileSize"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [FileSize]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.FileSize), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.FileSize), value)
			End Set
		End Property
		''' <summary>The FileDate property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."FileDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [FileDate]() As System.DateTime
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.FileDate), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.FileDate), value)
			End Set
		End Property
		''' <summary>The Title property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."Title"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 260<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Title]() As System.String
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.Title), True), System.String)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.Title), value)
			End Set
		End Property
		''' <summary>The Description property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."Description"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 2000<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Description]() As System.String
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.Description), True), System.String)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.Description), value)
			End Set
		End Property
		''' <summary>The Category property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."Category"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 260<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Category]() As System.String
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.Category), True), System.String)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.Category), value)
			End Set
		End Property
		''' <summary>The LinkNo property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."LinkNo"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallInt, 5, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [LinkNo]() As Nullable(Of System.Int16)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.LinkNo), False), Nullable(Of System.Int16))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.LinkNo), value)
			End Set
		End Property
		''' <summary>The PictureHeight property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."PictureHeight"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [PictureHeight]() As Nullable(Of System.Int32)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.PictureHeight), False), Nullable(Of System.Int32))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.PictureHeight), value)
			End Set
		End Property
		''' <summary>The PictureWidth property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."PictureWidth"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [PictureWidth]() As Nullable(Of System.Int32)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.PictureWidth), False), Nullable(Of System.Int32))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.PictureWidth), value)
			End Set
		End Property
		''' <summary>The PictureDate property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."PictureDate"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [PictureDate]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.PictureDate), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.PictureDate), value)
			End Set
		End Property
		''' <summary>The Thumbnail property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."Thumbnail"<br/>
		''' Table field type characteristics (type, precision, scale, length): Image, 0, 0, 2147483647<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Thumbnail]() As System.Byte()
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.Thumbnail), True), System.Byte())
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.Thumbnail), value)
			End Set
		End Property
		''' <summary>The TurbineNumber property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."TurbineNumber"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineNumber]() As System.String
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.TurbineNumber), True), System.String)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.TurbineNumber), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Created]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.Created), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The CreatedById property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [CreatedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.CreatedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.CreatedById), value)
			End Set
		End Property
		''' <summary>The Locked property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."Locked"<br/>
		''' Table field type characteristics (type, precision, scale, length): DateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Locked]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.Locked), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.Locked), value)
			End Set
		End Property
		''' <summary>The LockedById property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."LockedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [LockedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.LockedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.LockedById), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity Document<br/><br/></summary>
		''' <remarks> Mapped on  table field: "Document"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): Bit, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Deleted]() As System.Boolean
			Get
				Return CType(GetValue(CInt(DocumentFieldIndex.Deleted), True), System.Boolean)
			End Get
			Set
				SetValue(CInt(DocumentFieldIndex.Deleted), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'DocumentVersionEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(DocumentVersionEntity))> _
		Public Overridable ReadOnly Property [DocumentVersion]() As EntityCollection(Of DocumentVersionEntity)
			Get
				If _documentVersion Is Nothing Then
					_documentVersion = New EntityCollection(Of DocumentVersionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentVersionEntityFactory)))
					_documentVersion.ActiveContext = Me.ActiveContext
					_documentVersion.SetContainingEntityInfo(Me, "Document")
				End If
				Return _documentVersion
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Folder2DocumentEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Folder2DocumentEntity))> _
		Public Overridable ReadOnly Property [Folder2Document]() As EntityCollection(Of Folder2DocumentEntity)
			Get
				If _folder2Document Is Nothing Then
					_folder2Document = New EntityCollection(Of Folder2DocumentEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Folder2DocumentEntityFactory)))
					_folder2Document.ActiveContext = Me.ActiveContext
					_folder2Document.SetContainingEntityInfo(Me, "Document")
				End If
				Return _folder2Document
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'DocumentStatusEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(DocumentStatusEntity))> _
		Public Overridable ReadOnly Property [DocumentStatusCollectionViaFolder2Document]() As EntityCollection(Of DocumentStatusEntity)
			Get
				If _documentStatusCollectionViaFolder2Document Is Nothing Then
					_documentStatusCollectionViaFolder2Document = New EntityCollection(Of DocumentStatusEntity)(EntityFactoryCache2.GetEntityFactory(GetType(DocumentStatusEntityFactory)))
					_documentStatusCollectionViaFolder2Document.ActiveContext = Me.ActiveContext
					_documentStatusCollectionViaFolder2Document.IsReadOnly = True
					CType(_documentStatusCollectionViaFolder2Document, IEntityCollectionCore).IsForMN = True
				End If
				Return _documentStatusCollectionViaFolder2Document
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'FolderEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(FolderEntity))> _
		Public Overridable ReadOnly Property [FolderCollectionViaFolder2Document]() As EntityCollection(Of FolderEntity)
			Get
				If _folderCollectionViaFolder2Document Is Nothing Then
					_folderCollectionViaFolder2Document = New EntityCollection(Of FolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderEntityFactory)))
					_folderCollectionViaFolder2Document.ActiveContext = Me.ActiveContext
					_folderCollectionViaFolder2Document.IsReadOnly = True
					CType(_folderCollectionViaFolder2Document, IEntityCollectionCore).IsForMN = True
				End If
				Return _folderCollectionViaFolder2Document
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'DocumentBinaryEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [DocumentBinary]() As DocumentBinaryEntity
			Get
				Return _documentBinary
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncDocumentBinary(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Document_", "DocumentBinary", _documentBinary, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'DocumentClassificationEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [DocumentClassification]() As DocumentClassificationEntity
			Get
				Return _documentClassification
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncDocumentClassification(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Document", "DocumentClassification", _documentClassification, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [CreatedByParticipant]() As ParticipantEntity
			Get
				Return _createdByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncCreatedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Document", "CreatedByParticipant", _createdByParticipant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [LockedByParticipant]() As ParticipantEntity
			Get
				Return _lockedByParticipant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncLockedByParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "Document_", "LockedByParticipant", _lockedByParticipant, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.DocumentEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
