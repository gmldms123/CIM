﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'DocumentTemplate'.<br/><br/></summary>
	<Serializable()> _
	Public Class DocumentTemplateEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _brand2DocumentTemplate As EntityCollection(Of Brand2DocumentTemplateEntity)
		Private WithEvents _brandCollectionViaBrand2DocumentTemplate As EntityCollection(Of BrandEntity)
		Private WithEvents _phaseCollectionViaBrand2DocumentTemplate As EntityCollection(Of PhaseEntity)
		Private WithEvents _documentBinary As DocumentBinaryEntity
		Private WithEvents _documentClassification As DocumentClassificationEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name DocumentBinary</summary>
			Public Shared ReadOnly [DocumentBinary] As String = "DocumentBinary"
			''' <summary>Member name DocumentClassification</summary>
			Public Shared ReadOnly [DocumentClassification] As String = "DocumentClassification"
			''' <summary>Member name Brand2DocumentTemplate</summary>
			Public Shared ReadOnly [Brand2DocumentTemplate] As String  = "Brand2DocumentTemplate"
			''' <summary>Member name BrandCollectionViaBrand2DocumentTemplate</summary>
			Public Shared ReadOnly [BrandCollectionViaBrand2DocumentTemplate] As String  = "BrandCollectionViaBrand2DocumentTemplate"
			''' <summary>Member name PhaseCollectionViaBrand2DocumentTemplate</summary>
			Public Shared ReadOnly [PhaseCollectionViaBrand2DocumentTemplate] As String  = "PhaseCollectionViaBrand2DocumentTemplate"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentTemplateEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("DocumentTemplateEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this DocumentTemplateEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("DocumentTemplateEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="documentTemplateId">PK value for DocumentTemplate which data should be fetched into this DocumentTemplate object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(documentTemplateId As System.Int64)
			MyBase.New("DocumentTemplateEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.DocumentTemplateId = documentTemplateId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="documentTemplateId">PK value for DocumentTemplate which data should be fetched into this DocumentTemplate object</param>
		''' <param name="validator">The custom validator object for this DocumentTemplateEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(documentTemplateId As System.Int64, validator As IValidator)
			MyBase.New("DocumentTemplateEntity")
			InitClassEmpty(validator, Nothing)
			Me.DocumentTemplateId = documentTemplateId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_brand2DocumentTemplate = CType(info.GetValue("_brand2DocumentTemplate", GetType(EntityCollection(Of Brand2DocumentTemplateEntity))), EntityCollection(Of Brand2DocumentTemplateEntity))
				_brandCollectionViaBrand2DocumentTemplate = CType(info.GetValue("_brandCollectionViaBrand2DocumentTemplate", GetType(EntityCollection(Of BrandEntity))), EntityCollection(Of BrandEntity))
				_phaseCollectionViaBrand2DocumentTemplate = CType(info.GetValue("_phaseCollectionViaBrand2DocumentTemplate", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_documentBinary = CType(info.GetValue("_documentBinary", GetType(DocumentBinaryEntity)), DocumentBinaryEntity)
				If Not _documentBinary Is Nothing Then
					AddHandler _documentBinary.AfterSave, AddressOf OnEntityAfterSave
				End If
				_documentClassification = CType(info.GetValue("_documentClassification", GetType(DocumentClassificationEntity)), DocumentClassificationEntity)
				If Not _documentClassification Is Nothing Then
					AddHandler _documentClassification.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, DocumentTemplateFieldIndex)

				Case DocumentTemplateFieldIndex.DocumentBinaryId
					DesetupSyncDocumentBinary(True, False)
				Case DocumentTemplateFieldIndex.DocumentClassificationId
					DesetupSyncDocumentClassification(True, False)





				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "DocumentBinary"
					Me.DocumentBinary = CType(entity, DocumentBinaryEntity)
				Case "DocumentClassification"
					Me.DocumentClassification = CType(entity, DocumentClassificationEntity)
				Case "Brand2DocumentTemplate"
					Me.Brand2DocumentTemplate.Add(CType(entity, Brand2DocumentTemplateEntity))
				Case "BrandCollectionViaBrand2DocumentTemplate"
					Me.BrandCollectionViaBrand2DocumentTemplate.IsReadOnly = False
					Me.BrandCollectionViaBrand2DocumentTemplate.Add(CType(entity, BrandEntity))
					Me.BrandCollectionViaBrand2DocumentTemplate.IsReadOnly = True
				Case "PhaseCollectionViaBrand2DocumentTemplate"
					Me.PhaseCollectionViaBrand2DocumentTemplate.IsReadOnly = False
					Me.PhaseCollectionViaBrand2DocumentTemplate.Add(CType(entity, PhaseEntity))
					Me.PhaseCollectionViaBrand2DocumentTemplate.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return DocumentTemplateEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "DocumentBinary"
					toReturn.Add(DocumentTemplateEntity.Relations.DocumentBinaryEntityUsingDocumentBinaryId)
				Case "DocumentClassification"
					toReturn.Add(DocumentTemplateEntity.Relations.DocumentClassificationEntityUsingDocumentClassificationId)
				Case "Brand2DocumentTemplate"
					toReturn.Add(DocumentTemplateEntity.Relations.Brand2DocumentTemplateEntityUsingDocumentTemplateId)
				Case "BrandCollectionViaBrand2DocumentTemplate"
					toReturn.Add(DocumentTemplateEntity.Relations.Brand2DocumentTemplateEntityUsingDocumentTemplateId, "DocumentTemplateEntity__", "Brand2DocumentTemplate_", JoinHint.None)
					toReturn.Add(Brand2DocumentTemplateEntity.Relations.BrandEntityUsingBrandId, "Brand2DocumentTemplate_", String.Empty, JoinHint.None)
				Case "PhaseCollectionViaBrand2DocumentTemplate"
					toReturn.Add(DocumentTemplateEntity.Relations.Brand2DocumentTemplateEntityUsingDocumentTemplateId, "DocumentTemplateEntity__", "Brand2DocumentTemplate_", JoinHint.None)
					toReturn.Add(Brand2DocumentTemplateEntity.Relations.PhaseEntityUsingPhaseId, "Brand2DocumentTemplate_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "DocumentBinary"
					SetupSyncDocumentBinary(relatedEntity)
				Case "DocumentClassification"
					SetupSyncDocumentClassification(relatedEntity)
				Case "Brand2DocumentTemplate"
					Me.Brand2DocumentTemplate.Add(CType(relatedEntity, Brand2DocumentTemplateEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "DocumentBinary"
					DesetupSyncDocumentBinary(False, True)
				Case "DocumentClassification"
					DesetupSyncDocumentClassification(False, True)
				Case "Brand2DocumentTemplate"
					Me.PerformRelatedEntityRemoval(Me.Brand2DocumentTemplate, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _documentBinary Is Nothing Then
				toReturn.Add(_documentBinary)
			End If
			If Not _documentClassification Is Nothing Then
				toReturn.Add(_documentClassification)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Brand2DocumentTemplate)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_brand2DocumentTemplate Is Nothing)) AndAlso (_brand2DocumentTemplate.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brand2DocumentTemplate 
				End If
				info.AddValue("_brand2DocumentTemplate", value)
				value = Nothing 
				If (Not (_brandCollectionViaBrand2DocumentTemplate Is Nothing)) AndAlso (_brandCollectionViaBrand2DocumentTemplate.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brandCollectionViaBrand2DocumentTemplate 
				End If
				info.AddValue("_brandCollectionViaBrand2DocumentTemplate", value)
				value = Nothing 
				If (Not (_phaseCollectionViaBrand2DocumentTemplate Is Nothing)) AndAlso (_phaseCollectionViaBrand2DocumentTemplate.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phaseCollectionViaBrand2DocumentTemplate 
				End If
				info.AddValue("_phaseCollectionViaBrand2DocumentTemplate", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _documentBinary
				End If
				info.AddValue("_documentBinary", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _documentClassification
				End If
				info.AddValue("_documentClassification", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New DocumentTemplateRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand2DocumentTemplate' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrand2DocumentTemplate() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Brand2DocumentTemplateFields.DocumentTemplateId, Nothing, ComparisonOperator.Equal, Me.DocumentTemplateId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrandCollectionViaBrand2DocumentTemplate() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BrandCollectionViaBrand2DocumentTemplate"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentTemplateFields.DocumentTemplateId, Nothing, ComparisonOperator.Equal, Me.DocumentTemplateId, "DocumentTemplateEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Phase' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhaseCollectionViaBrand2DocumentTemplate() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("PhaseCollectionViaBrand2DocumentTemplate"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentTemplateFields.DocumentTemplateId, Nothing, ComparisonOperator.Equal, Me.DocumentTemplateId, "DocumentTemplateEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'DocumentBinary' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentBinary() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentBinaryFields.DocumentBinaryId, Nothing, ComparisonOperator.Equal, Me.DocumentBinaryId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'DocumentClassification' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentClassification() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentClassificationFields.DocumentClassificationId, Nothing, ComparisonOperator.Equal, Me.DocumentClassificationId))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(DocumentTemplateEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_brand2DocumentTemplate)
			collectionsQueue.Enqueue(_brandCollectionViaBrand2DocumentTemplate)
			collectionsQueue.Enqueue(_phaseCollectionViaBrand2DocumentTemplate)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_brand2DocumentTemplate = CType(collectionsQueue.Dequeue(), EntityCollection(Of Brand2DocumentTemplateEntity))
			_brandCollectionViaBrand2DocumentTemplate = CType(collectionsQueue.Dequeue(), EntityCollection(Of BrandEntity))
			_phaseCollectionViaBrand2DocumentTemplate = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _brand2DocumentTemplate Is Nothing) Then
				Return True
			End If
			If (Not _brandCollectionViaBrand2DocumentTemplate Is Nothing) Then
				Return True
			End If
			If (Not _phaseCollectionViaBrand2DocumentTemplate Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Brand2DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2DocumentTemplateEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("DocumentBinary", _documentBinary)
			toReturn.Add("DocumentClassification", _documentClassification)
			toReturn.Add("Brand2DocumentTemplate", _brand2DocumentTemplate)
			toReturn.Add("BrandCollectionViaBrand2DocumentTemplate", _brandCollectionViaBrand2DocumentTemplate)
			toReturn.Add("PhaseCollectionViaBrand2DocumentTemplate", _phaseCollectionViaBrand2DocumentTemplate)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DocumentTemplateId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DocumentBinaryId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DocumentClassificationId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Title", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("FileName", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("FileSize", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Thumbnail", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Version", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _documentBinary</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncDocumentBinary(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _documentBinary, AddressOf OnDocumentBinaryPropertyChanged, "DocumentBinary", PManagement.Data.RelationClasses.StaticDocumentTemplateRelations.DocumentBinaryEntityUsingDocumentBinaryIdStatic, True, signalRelatedEntity, "DocumentTemplate", resetFKFields, New Integer() { CInt(DocumentTemplateFieldIndex.DocumentBinaryId) } )
			_documentBinary = Nothing
		End Sub

		''' <summary>setups the sync logic for member _documentBinary</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncDocumentBinary(relatedEntity As IEntityCore)
			If Not _documentBinary Is relatedEntity Then
				DesetupSyncDocumentBinary(True, True)
				_documentBinary = CType(relatedEntity, DocumentBinaryEntity)
				Me.PerformSetupSyncRelatedEntity( _documentBinary, AddressOf OnDocumentBinaryPropertyChanged, "DocumentBinary", PManagement.Data.RelationClasses.StaticDocumentTemplateRelations.DocumentBinaryEntityUsingDocumentBinaryIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnDocumentBinaryPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _documentClassification</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncDocumentClassification(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _documentClassification, AddressOf OnDocumentClassificationPropertyChanged, "DocumentClassification", PManagement.Data.RelationClasses.StaticDocumentTemplateRelations.DocumentClassificationEntityUsingDocumentClassificationIdStatic, True, signalRelatedEntity, "DocumentTemplate", resetFKFields, New Integer() { CInt(DocumentTemplateFieldIndex.DocumentClassificationId) } )
			_documentClassification = Nothing
		End Sub

		''' <summary>setups the sync logic for member _documentClassification</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncDocumentClassification(relatedEntity As IEntityCore)
			If Not _documentClassification Is relatedEntity Then
				DesetupSyncDocumentClassification(True, True)
				_documentClassification = CType(relatedEntity, DocumentClassificationEntity)
				Me.PerformSetupSyncRelatedEntity( _documentClassification, AddressOf OnDocumentClassificationPropertyChanged, "DocumentClassification", PManagement.Data.RelationClasses.StaticDocumentTemplateRelations.DocumentClassificationEntityUsingDocumentClassificationIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnDocumentClassificationPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this DocumentTemplateEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As DocumentTemplateRelations
			Get	
				Return New DocumentTemplateRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand2DocumentTemplate'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrand2DocumentTemplate() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Brand2DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2DocumentTemplateEntityFactory))), _
					CType(GetRelationsForField("Brand2DocumentTemplate")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentTemplateEntity, Integer), CType(PManagement.Data.EntityType.Brand2DocumentTemplateEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Brand2DocumentTemplate", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrandCollectionViaBrand2DocumentTemplate() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = DocumentTemplateEntity.Relations.Brand2DocumentTemplateEntityUsingDocumentTemplateId
				intermediateRelation.SetAliases(String.Empty, "Brand2DocumentTemplate_")
				Return New PrefetchPathElement2( New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.DocumentTemplateEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BrandCollectionViaBrand2DocumentTemplate"), Nothing, "BrandCollectionViaBrand2DocumentTemplate", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhaseCollectionViaBrand2DocumentTemplate() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = DocumentTemplateEntity.Relations.Brand2DocumentTemplateEntityUsingDocumentTemplateId
				intermediateRelation.SetAliases(String.Empty, "Brand2DocumentTemplate_")
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.DocumentTemplateEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("PhaseCollectionViaBrand2DocumentTemplate"), Nothing, "PhaseCollectionViaBrand2DocumentTemplate", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentBinary' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentBinary() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(DocumentBinaryEntityFactory))), _
					CType(GetRelationsForField("DocumentBinary")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentTemplateEntity, Integer), CType(PManagement.Data.EntityType.DocumentBinaryEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "DocumentBinary", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentClassification' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentClassification() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(DocumentClassificationEntityFactory))), _
					CType(GetRelationsForField("DocumentClassification")(0), IEntityRelation), CType(PManagement.Data.EntityType.DocumentTemplateEntity, Integer), CType(PManagement.Data.EntityType.DocumentClassificationEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "DocumentClassification", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return DocumentTemplateEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return DocumentTemplateEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The DocumentTemplateId property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."DocumentTemplateId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [DocumentTemplateId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.DocumentTemplateId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.DocumentTemplateId), value)
			End Set
		End Property
		''' <summary>The DocumentBinaryId property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."DocumentBinaryId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [DocumentBinaryId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.DocumentBinaryId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.DocumentBinaryId), value)
			End Set
		End Property
		''' <summary>The DocumentClassificationId property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."DocumentClassificationId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [DocumentClassificationId]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.DocumentClassificationId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.DocumentClassificationId), value)
			End Set
		End Property
		''' <summary>The Title property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."Title"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 260<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Title]() As System.String
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.Title), True), System.String)
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.Title), value)
			End Set
		End Property
		''' <summary>The FileName property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."FileName"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 260<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [FileName]() As System.String
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.FileName), True), System.String)
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.FileName), value)
			End Set
		End Property
		''' <summary>The FileSize property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."FileSize"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [FileSize]() As System.Int64
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.FileSize), True), System.Int64)
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.FileSize), value)
			End Set
		End Property
		''' <summary>The Thumbnail property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."Thumbnail"<br/>
		''' Table field type characteristics (type, precision, scale, length): Image, 0, 0, 2147483647<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Thumbnail]() As System.Byte()
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.Thumbnail), True), System.Byte())
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.Thumbnail), value)
			End Set
		End Property
		''' <summary>The Version property of the Entity DocumentTemplate<br/><br/></summary>
		''' <remarks> Mapped on  table field: "DocumentTemplate"."Version"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Version]() As Nullable(Of System.Int32)
			Get
				Return CType(GetValue(CInt(DocumentTemplateFieldIndex.Version), False), Nullable(Of System.Int32))
			End Get
			Set
				SetValue(CInt(DocumentTemplateFieldIndex.Version), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Brand2DocumentTemplateEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Brand2DocumentTemplateEntity))> _
		Public Overridable ReadOnly Property [Brand2DocumentTemplate]() As EntityCollection(Of Brand2DocumentTemplateEntity)
			Get
				If _brand2DocumentTemplate Is Nothing Then
					_brand2DocumentTemplate = New EntityCollection(Of Brand2DocumentTemplateEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2DocumentTemplateEntityFactory)))
					_brand2DocumentTemplate.ActiveContext = Me.ActiveContext
					_brand2DocumentTemplate.SetContainingEntityInfo(Me, "DocumentTemplate")
				End If
				Return _brand2DocumentTemplate
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BrandEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BrandEntity))> _
		Public Overridable ReadOnly Property [BrandCollectionViaBrand2DocumentTemplate]() As EntityCollection(Of BrandEntity)
			Get
				If _brandCollectionViaBrand2DocumentTemplate Is Nothing Then
					_brandCollectionViaBrand2DocumentTemplate = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
					_brandCollectionViaBrand2DocumentTemplate.ActiveContext = Me.ActiveContext
					_brandCollectionViaBrand2DocumentTemplate.IsReadOnly = True
					CType(_brandCollectionViaBrand2DocumentTemplate, IEntityCollectionCore).IsForMN = True
				End If
				Return _brandCollectionViaBrand2DocumentTemplate
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [PhaseCollectionViaBrand2DocumentTemplate]() As EntityCollection(Of PhaseEntity)
			Get
				If _phaseCollectionViaBrand2DocumentTemplate Is Nothing Then
					_phaseCollectionViaBrand2DocumentTemplate = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phaseCollectionViaBrand2DocumentTemplate.ActiveContext = Me.ActiveContext
					_phaseCollectionViaBrand2DocumentTemplate.IsReadOnly = True
					CType(_phaseCollectionViaBrand2DocumentTemplate, IEntityCollectionCore).IsForMN = True
				End If
				Return _phaseCollectionViaBrand2DocumentTemplate
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'DocumentBinaryEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [DocumentBinary]() As DocumentBinaryEntity
			Get
				Return _documentBinary
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncDocumentBinary(value)
				Else
					SetSingleRelatedEntityNavigator(value, "DocumentTemplate", "DocumentBinary", _documentBinary, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'DocumentClassificationEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [DocumentClassification]() As DocumentClassificationEntity
			Get
				Return _documentClassification
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncDocumentClassification(value)
				Else
					SetSingleRelatedEntityNavigator(value, "DocumentTemplate", "DocumentClassification", _documentClassification, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.DocumentTemplateEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
