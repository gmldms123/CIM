﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 2.6
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates.NET20
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
#If Not CF Then
Imports System.Runtime.Serialization
#End If
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses
	''' <summary>Entity class which represents the entity 'KPI'.<br/><br/>
	''' </summary>
	<Serializable()> _
	Public Class KPIEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _kpirating As EntityCollection(Of KPIRatingEntity)

		Private WithEvents _kpigroup As KPIGroupEntity

		
		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Kpigroup</summary>
			Public Shared ReadOnly [Kpigroup] As String = "Kpigroup"
			''' <summary>Member name Kpirating</summary>
			Public Shared ReadOnly [Kpirating] As String  = "Kpirating"


		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("KPIEntity")
			InitClassEmpty(Nothing, CreateFields())
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("KPIEntity")
			SetName("KPIEntity")
			InitClassEmpty(Nothing, fields)
		End Sub


		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this KPIEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("KPIEntity")
			InitClassEmpty(validator, CreateFields())
		End Sub
				

		''' <summary>CTor</summary>
		''' <param name="kPIId">PK value for KPI which data should be fetched into this KPI object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(kPIId As System.Int64)
			MyBase.New("KPIEntity")
			InitClassEmpty(Nothing, CreateFields())
			Me.KPIId = kPIId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="kPIId">PK value for KPI which data should be fetched into this KPI object</param>
		''' <param name="validator">The custom validator object for this KPIEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(kPIId As System.Int64, validator As IValidator)
			MyBase.New("KPIEntity")
			InitClassEmpty(validator, CreateFields())
			Me.KPIId = kPIId
		End Sub
	

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_kpirating = CType(info.GetValue("_kpirating", GetType(EntityCollection(Of KPIRatingEntity))), EntityCollection(Of KPIRatingEntity))

				_kpigroup = CType(info.GetValue("_kpigroup", GetType(KPIGroupEntity)), KPIGroupEntity)
				If Not _kpigroup Is Nothing Then
					AddHandler _kpigroup.AfterSave, AddressOf OnEntityAfterSave
				End If

				MyBase.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, KPIFieldIndex)

				Case KPIFieldIndex.KPIGroupId
					DesetupSyncKpigroup(True, False)




				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub
				
		''' <summary>Gets the inheritance info provider instance of the project this entity instance is located in. </summary>
		''' <returns>ready to use inheritance info provider instance.</returns>
		Protected Overrides Function GetInheritanceInfoProvider() As IInheritanceInfoProvider 
			Return InheritanceInfoProviderSingleton.GetInstance()
		End Function

		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntity2)
			Select Case propertyName
				Case "Kpigroup"
					Me.Kpigroup = CType(entity, KPIGroupEntity)
				Case "Kpirating"
					Me.Kpirating.Add(CType(entity, KPIRatingEntity))


				Case Else

			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Public Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return KPIEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Public Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Kpigroup"
					toReturn.Add(KPIEntity.Relations.KPIGroupEntityUsingKPIGroupId)
				Case "Kpirating"
					toReturn.Add(KPIEntity.Relations.KPIRatingEntityUsingKPIId)


				Case Else

			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it
		''' will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			' use template trick To calculate the # of Single-sided / oneway relations. 
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))


				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Sub SetRelatedEntity(relatedEntity As IEntity2, fieldName As String)
			Select Case fieldName
				Case "Kpigroup"
					SetupSyncKpigroup(relatedEntity)
				Case "Kpirating"
					Me.Kpirating.Add(CType(relatedEntity, KPIRatingEntity))

				Case Else

			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntity2, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Kpigroup"
					DesetupSyncKpigroup(False, True)
				Case "Kpirating"
					MyBase.PerformRelatedEntityRemoval(Me.Kpirating, relatedEntity, signalRelatedEntityManyToOne)

				Case Else

			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). These
		''' entities will have to be persisted after this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()


			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields). These
		''' entities will have to be persisted before this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _kpigroup Is Nothing Then
				toReturn.Add(_kpigroup)
			End If


			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. The contents of the ArrayList is
		''' used by the DataAccessAdapter to perform recursive saves. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Public Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Kpirating)

			Return toReturn
		End Function



		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Public Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_kpirating Is Nothing)) AndAlso (_kpirating.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _kpirating 
				End If
				info.AddValue("_kpirating", value)

				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _kpigroup
				End If
				info.AddValue("_kpigroup", entityValue)

			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub



		''' <summary>Returns true if the original value for the field with the fieldIndex passed in, read from the persistent storage was NULL, False otherwise.
		''' Should Not be used For testing If the current value Is NULL, use <see cref="TestCurrentFieldValueForNull"/> For that.</summary>
		''' <param name="fieldIndex">Index of the field to test if that field was NULL in the persistent storage</param>
		''' <returns>true if the field with the passed in index was NULL in the persistent storage, False otherwise</returns>
		Public  Function TestOriginalFieldValueForNull(fieldIndex As KPIFieldIndex) As Boolean
			Return MyBase.Fields(CInt(fieldIndex)).IsNull
		End Function
		
		''' <summary>Returns True If the current value For the field With the fieldIndex passed In represents null/Not defined, False otherwise.
		''' Should Not be used For testing If the original value (read from the db) Is NULL</summary>
		''' <param name="fieldIndex">Index of the field To test If its currentvalue Is null/undefined</param>
		''' <returns>True If the field's value isn't defined yet, false otherwise</returns>
		Public  Function TestCurrentFieldValueForNull(fieldIndex As KPIFieldIndex) As Boolean
			Return MyBase.CheckIfCurrentFieldValueIsNull(CInt(fieldIndex))
		End Function


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Public Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New KPIRelations().GetAllRelations()
		End Function


		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'KPIRating' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoKpirating() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(KPIRatingFields.KPIId, Nothing, ComparisonOperator.Equal, Me.KPIId))
			Return bucket
		End Function


		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'KPIGroup' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoKpigroup() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(KPIGroupFields.KPIGroupId, Nothing, ComparisonOperator.Equal, Me.KPIGroupId))
			Return bucket
		End Function


		''' <summary>Creates entity fields Object For this entity. Used In constructor To setup this entity In a polymorphic scenario.</summary>
		Protected Overridable Function CreateFields() As IEntityFields2
			Return EntityFieldsFactory.CreateEntityFieldsObject(PManagement.Data.EntityType.KPIEntity)
		End Function
				
		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(KPIEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_kpirating)

		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_kpirating = CType(collectionsQueue.Dequeue(), EntityCollection(Of KPIRatingEntity))

		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _kpirating Is Nothing) Then
				Return True
			End If

			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of KPIRatingEntity)(EntityFactoryCache2.GetEntityFactory(GetType(KPIRatingEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)

		End Sub
#End If
		''' <summary>
		''' Creates the ITypeDefaultValue instance used To provide Default values For value types which aren't of type nullable(of T)
		''' </summary>
		''' <returns></returns>
		Protected Overrides Function CreateTypeDefaultValueProvider() As ITypeDefaultValue 
			Return New TypeDefaultValue()
		End Function

		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Public Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Kpigroup", _kpigroup)
			toReturn.Add("Kpirating", _kpirating)


			Return toReturn
		End Function
		
		''' <summary>Adds the internals To the active context. </summary>
		Protected Overrides Overloads Sub AddInternalsToContext()
		If Not _kpirating Is Nothing Then
				_kpirating.ActiveContext = MyBase.ActiveContext
			End If

		If Not _kpigroup Is Nothing Then
				_kpigroup.ActiveContext = MyBase.ActiveContext
			End If


		End Sub

		''' <summary>Initializes the class members</summary>
		Protected Overridable Sub InitClassMembers()

			_kpirating = Nothing

			_kpigroup = Nothing

			PerformDependencyInjection()
			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()

			Dim fieldHashtable As Dictionary(Of String, String) = Nothing
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("KPIId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("KPIGroupId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Name", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Sort", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Hidden", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Calculated", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _kpigroup</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncKpigroup(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _kpigroup, AddressOf OnKpigroupPropertyChanged, "Kpigroup", KPIEntity.Relations.KPIGroupEntityUsingKPIGroupId, True, signalRelatedEntity, "KPI", resetFKFields, New Integer() { CInt(KPIFieldIndex.KPIGroupId) } )
			_kpigroup = Nothing
		End Sub

		''' <summary>setups the sync logic for member _kpigroup</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncKpigroup(relatedEntity As IEntity2)
			If Not _kpigroup Is relatedEntity Then
				DesetupSyncKpigroup(True, True)
				_kpigroup = CType(relatedEntity, KPIGroupEntity)
				MyBase.PerformSetupSyncRelatedEntity( _kpigroup, AddressOf OnKpigroupPropertyChanged, "Kpigroup", KPIEntity.Relations.KPIGroupEntityUsingKPIGroupId, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnKpigroupPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub


		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this KPIEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Protected Overridable Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			MyBase.Fields = fields
			MyBase.IsNew = True
			MyBase.Validator = validator
			InitClassMembers()

			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As KPIRelations
			Get	
				Return New KPIRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'KPIRating' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathKpirating() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of KPIRatingEntity)(EntityFactoryCache2.GetEntityFactory(GetType(KPIRatingEntityFactory))), _
					CType(GetRelationsForField("Kpirating")(0), IEntityRelation), CType(PManagement.Data.EntityType.KPIEntity, Integer), CType(PManagement.Data.EntityType.KPIRatingEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Kpirating", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'KPIGroup' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathKpigroup() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(KPIGroupEntityFactory))), _
					CType(GetRelationsForField("Kpigroup")(0), IEntityRelation), CType(PManagement.Data.EntityType.KPIEntity, Integer), CType(PManagement.Data.EntityType.KPIGroupEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Kpigroup", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return KPIEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return KPIEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The KPIId property of the Entity KPI<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "KPI"."KPIId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [KPIId]() As System.Int64
			Get
				Return CType(GetValue(CInt(KPIFieldIndex.KPIId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(KPIFieldIndex.KPIId), value)
			End Set

		End Property

		''' <summary>The KPIGroupId property of the Entity KPI<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "KPI"."KPIGroupId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [KPIGroupId]() As System.Int64
			Get
				Return CType(GetValue(CInt(KPIFieldIndex.KPIGroupId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(KPIFieldIndex.KPIGroupId), value)
			End Set
		End Property

		''' <summary>The Name property of the Entity KPI<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "KPI"."Name"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Name]() As System.String
			Get
				Return CType(GetValue(CInt(KPIFieldIndex.Name), True), System.String)
			End Get
			Set
				SetValue(CInt(KPIFieldIndex.Name), value)
			End Set
		End Property

		''' <summary>The Sort property of the Entity KPI<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "KPI"."Sort"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Sort]() As System.Int64
			Get
				Return CType(GetValue(CInt(KPIFieldIndex.Sort), True), System.Int64)
			End Get
			Set
				SetValue(CInt(KPIFieldIndex.Sort), value)
			End Set
		End Property

		''' <summary>The Hidden property of the Entity KPI<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "KPI"."Hidden"<br/>
		''' Table field type characteristics (type, precision, scale, length): Bit, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Hidden]() As System.Boolean
			Get
				Return CType(GetValue(CInt(KPIFieldIndex.Hidden), True), System.Boolean)
			End Get
			Set
				SetValue(CInt(KPIFieldIndex.Hidden), value)
			End Set
		End Property

		''' <summary>The Calculated property of the Entity KPI<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "KPI"."Calculated"<br/>
		''' Table field type characteristics (type, precision, scale, length): Bit, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Calculated]() As System.Boolean
			Get
				Return CType(GetValue(CInt(KPIFieldIndex.Calculated), True), System.Boolean)
			End Get
			Set
				SetValue(CInt(KPIFieldIndex.Calculated), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'KPIRatingEntity' which are related to this entity via a relation of type '1:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(KPIRatingEntity))> _
		Public Overridable ReadOnly Property [Kpirating]() As EntityCollection(Of KPIRatingEntity)
			Get
				If _kpirating Is Nothing Then
					_kpirating = New EntityCollection(Of KPIRatingEntity)(EntityFactoryCache2.GetEntityFactory(GetType(KPIRatingEntityFactory)))
					_kpirating.SetContainingEntityInfo(Me, "Kpi")
				End If
				Return _kpirating
			End Get
		End Property


		''' <summary>Gets / sets related entity of type 'KPIGroupEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [Kpigroup]() As KPIGroupEntity
			Get
				Return _kpigroup
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncKpigroup(value)
				Else
					If value Is Nothing Then
						If Not _kpigroup Is Nothing Then
							_kpigroup.UnsetRelatedEntity(Me, "KPI")
						End If
					Else
						If Not _kpigroup Is value Then
							CType(value, IEntity2).SetRelatedEntity(Me, "KPI")
						End If
					End If
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property
		
		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.KPIEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
