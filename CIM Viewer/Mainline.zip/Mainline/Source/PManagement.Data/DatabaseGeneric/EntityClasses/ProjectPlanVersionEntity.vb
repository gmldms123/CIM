﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 2.5
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates.NET20
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
#If Not CF Then
Imports System.Runtime.Serialization
#End If
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses
	''' <summary>Entity class which represents the entity 'ProjectPlanVersion'.<br/><br/>
	''' </summary>
	<Serializable()> _
	Public Class ProjectPlanVersionEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _phase As EntityCollection(Of PhaseEntity)
		Private WithEvents _brandCollectionViaPhase As EntityCollection(Of BrandEntity)
		Private WithEvents _participantCollectionViaPhase_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaPhase As EntityCollection(Of ParticipantEntity)
		Private WithEvents _documentTemplate As DocumentTemplateEntity
		Private WithEvents _businessProcess As BusinessProcessEntity
		
		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name DocumentTemplate</summary>
			Public Shared ReadOnly [DocumentTemplate] As String = "DocumentTemplate"
			''' <summary>Member name Phase</summary>
			Public Shared ReadOnly [Phase] As String  = "Phase"
			''' <summary>Member name BrandCollectionViaPhase</summary>
			Public Shared ReadOnly [BrandCollectionViaPhase] As String  = "BrandCollectionViaPhase"
			''' <summary>Member name ParticipantCollectionViaPhase_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaPhase_] As String  = "ParticipantCollectionViaPhase_"
			''' <summary>Member name ParticipantCollectionViaPhase</summary>
			Public Shared ReadOnly [ParticipantCollectionViaPhase] As String  = "ParticipantCollectionViaPhase"
			''' <summary>Member name BusinessProcess</summary>
			Public Shared ReadOnly [BusinessProcess] As String  = "BusinessProcess"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ProjectPlanVersionEntity")
			InitClassEmpty(Nothing, CreateFields())
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("ProjectPlanVersionEntity")
			SetName("ProjectPlanVersionEntity")
			InitClassEmpty(Nothing, fields)
		End Sub


		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this ProjectPlanVersionEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("ProjectPlanVersionEntity")
			InitClassEmpty(validator, CreateFields())
		End Sub
				

		''' <summary>CTor</summary>
		''' <param name="projectPlanVersionId">PK value for ProjectPlanVersion which data should be fetched into this ProjectPlanVersion object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(projectPlanVersionId As System.Int64)
			MyBase.New("ProjectPlanVersionEntity")
			InitClassEmpty(Nothing, CreateFields())
			Me.ProjectPlanVersionId = projectPlanVersionId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="projectPlanVersionId">PK value for ProjectPlanVersion which data should be fetched into this ProjectPlanVersion object</param>
		''' <param name="validator">The custom validator object for this ProjectPlanVersionEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(projectPlanVersionId As System.Int64, validator As IValidator)
			MyBase.New("ProjectPlanVersionEntity")
			InitClassEmpty(validator, CreateFields())
			Me.ProjectPlanVersionId = projectPlanVersionId
		End Sub
	

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_phase = CType(info.GetValue("_phase", GetType(EntityCollection(Of PhaseEntity))), EntityCollection(Of PhaseEntity))
				_brandCollectionViaPhase = CType(info.GetValue("_brandCollectionViaPhase", GetType(EntityCollection(Of BrandEntity))), EntityCollection(Of BrandEntity))
				_participantCollectionViaPhase_ = CType(info.GetValue("_participantCollectionViaPhase_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaPhase = CType(info.GetValue("_participantCollectionViaPhase", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_documentTemplate = CType(info.GetValue("_documentTemplate", GetType(DocumentTemplateEntity)), DocumentTemplateEntity)
				If Not _documentTemplate Is Nothing Then
					AddHandler _documentTemplate.AfterSave, AddressOf OnEntityAfterSave
				End If
				_businessProcess = CType(info.GetValue("_businessProcess", GetType(BusinessProcessEntity)), BusinessProcessEntity)
				If Not _businessProcess Is Nothing Then
					AddHandler _businessProcess.AfterSave, AddressOf OnEntityAfterSave
				End If
				MyBase.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, ProjectPlanVersionFieldIndex)


				Case ProjectPlanVersionFieldIndex.DocumentTemplateId
					DesetupSyncDocumentTemplate(True, False)
				Case ProjectPlanVersionFieldIndex.BusinessProcessId
					DesetupSyncBusinessProcess(True, False)
				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub
		
		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntity2)
			Select Case propertyName
				Case "DocumentTemplate"
					Me.DocumentTemplate = CType(entity, DocumentTemplateEntity)
				Case "Phase"
					Me.Phase.Add(CType(entity, PhaseEntity))
				Case "BrandCollectionViaPhase"
					Me.BrandCollectionViaPhase.IsReadOnly = False
					Me.BrandCollectionViaPhase.Add(CType(entity, BrandEntity))
					Me.BrandCollectionViaPhase.IsReadOnly = True
				Case "ParticipantCollectionViaPhase_"
					Me.ParticipantCollectionViaPhase_.IsReadOnly = False
					Me.ParticipantCollectionViaPhase_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaPhase_.IsReadOnly = True
				Case "ParticipantCollectionViaPhase"
					Me.ParticipantCollectionViaPhase.IsReadOnly = False
					Me.ParticipantCollectionViaPhase.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaPhase.IsReadOnly = True
				Case "BusinessProcess"
					Me.BusinessProcess = CType(entity, BusinessProcessEntity)
				Case Else

			End Select
		End Sub
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it
		''' will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			' use template trick To calculate the # of Single-sided / oneway relations. 
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))


				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Sub SetRelatedEntity(relatedEntity As IEntity2, fieldName As String)
			Select Case fieldName
				Case "DocumentTemplate"
					SetupSyncDocumentTemplate(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "Phase"
					Me.Phase.Add(CType(relatedEntity, PhaseEntity))
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case "BusinessProcess"
					SetupSyncBusinessProcess(relatedEntity)
					OnRelatedEntitySet(relatedEntity, fieldName)
				Case Else

			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Public Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntity2, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "DocumentTemplate"
					DesetupSyncDocumentTemplate(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "Phase"
					MyBase.PerformRelatedEntityRemoval(Me.Phase, relatedEntity, signalRelatedEntityManyToOne)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case "BusinessProcess"
					DesetupSyncBusinessProcess(False, True)
					OnRelatedEntityUnset(relatedEntity, fieldName)
				Case Else

			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). These
		''' entities will have to be persisted after this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()



			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields). These
		''' entities will have to be persisted before this entity during a recursive save.</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Public Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _documentTemplate Is Nothing Then
				toReturn.Add(_documentTemplate)
			End If


			If Not _businessProcess Is Nothing Then
				toReturn.Add(_businessProcess)
			End If

			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. The contents of the ArrayList is
		''' used by the DataAccessAdapter to perform recursive saves. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Public Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Phase)

			Return toReturn
		End Function



		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Public Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_phase Is Nothing)) AndAlso (_phase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _phase 
				End If
				info.AddValue("_phase", value)
				value = Nothing 
				If (Not (_brandCollectionViaPhase Is Nothing)) AndAlso (_brandCollectionViaPhase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brandCollectionViaPhase 
				End If
				info.AddValue("_brandCollectionViaPhase", value)
				value = Nothing 
				If (Not (_participantCollectionViaPhase_ Is Nothing)) AndAlso (_participantCollectionViaPhase_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaPhase_ 
				End If
				info.AddValue("_participantCollectionViaPhase_", value)
				value = Nothing 
				If (Not (_participantCollectionViaPhase Is Nothing)) AndAlso (_participantCollectionViaPhase.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaPhase 
				End If
				info.AddValue("_participantCollectionViaPhase", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _documentTemplate
				End If
				info.AddValue("_documentTemplate", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _businessProcess
				End If
				info.AddValue("_businessProcess", entityValue)
			End If
			
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Method which will construct a filter (predicate expression) for the unique constraint defined on the fields:
		''' BusinessProcessId .</summary>
		''' <returns>true if succeeded and the contents is read, false otherwise</returns>
		Public Function ConstructFilterForUCBusinessProcessId() As IPredicateExpression
			Dim Filter As IPredicateExpression = New PredicateExpression()
			Filter.Add(New FieldCompareValuePredicate(MyBase.Fields( CType(ProjectPlanVersionFieldIndex.BusinessProcessId, Integer) ), Nothing, ComparisonOperator.Equal)) 
			Return Filter
		End Function

		''' <summary>Returns true if the original value for the field with the fieldIndex passed in, read from the persistent storage was NULL, False otherwise.
		''' Should Not be used For testing If the current value Is NULL, use <see cref="TestCurrentFieldValueForNull"/> For that.</summary>
		''' <param name="fieldIndex">Index of the field to test if that field was NULL in the persistent storage</param>
		''' <returns>true if the field with the passed in index was NULL in the persistent storage, False otherwise</returns>
		Public  Function TestOriginalFieldValueForNull(fieldIndex As ProjectPlanVersionFieldIndex) As Boolean
			Return MyBase.Fields(CInt(fieldIndex)).IsNull
		End Function
		
		''' <summary>Returns True If the current value For the field With the fieldIndex passed In represents null/Not defined, False otherwise.
		''' Should Not be used For testing If the original value (read from the db) Is NULL</summary>
		''' <param name="fieldIndex">Index of the field To test If its currentvalue Is null/undefined</param>
		''' <returns>True If the field's value isn't defined yet, false otherwise</returns>
		Public  Function TestCurrentFieldValueForNull(fieldIndex As ProjectPlanVersionFieldIndex) As Boolean
			Return MyBase.CheckIfCurrentFieldValueIsNull(CInt(fieldIndex))
		End Function


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Public Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New ProjectPlanVersionRelations().GetAllRelations()
		End Function


		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Phase' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoPhase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(PhaseFields.ProjectPlanVersionId, Nothing, ComparisonOperator.Equal, Me.ProjectPlanVersionId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Brand' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrandCollectionViaPhase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId, "ProjectPlanVersionEntity__", "Phase_", JoinHint.None)
			bucket.Relations.Add(PhaseEntity.Relations.BrandEntityUsingBrandId, "Phase_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ProjectPlanVersionFields.ProjectPlanVersionId, Nothing, ComparisonOperator.Equal, Me.ProjectPlanVersionId, "ProjectPlanVersionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Participant' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaPhase_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId, "ProjectPlanVersionEntity__", "Phase_", JoinHint.None)
			bucket.Relations.Add(PhaseEntity.Relations.ParticipantEntityUsingDeletedById, "Phase_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ProjectPlanVersionFields.ProjectPlanVersionId, Nothing, ComparisonOperator.Equal, Me.ProjectPlanVersionId, "ProjectPlanVersionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entities of type 'Participant' to this entity. Use DataAccessAdapter.FetchEntityCollection() to fetch these related entities.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaPhase() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.Add(ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId, "ProjectPlanVersionEntity__", "Phase_", JoinHint.None)
			bucket.Relations.Add(PhaseEntity.Relations.ParticipantEntityUsingCreatedById, "Phase_", String.Empty, JoinHint.None)
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ProjectPlanVersionFields.ProjectPlanVersionId, Nothing, ComparisonOperator.Equal, Me.ProjectPlanVersionId, "ProjectPlanVersionEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'DocumentTemplate' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoDocumentTemplate() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(DocumentTemplateFields.DocumentTemplateId, Nothing, ComparisonOperator.Equal, Me.DocumentTemplateId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch
		''' the related entity of type 'BusinessProcess' to this entity. Use DataAccessAdapter.FetchNewEntity() to fetch this related entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBusinessProcess() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BusinessProcessFields.BusinessProcessId, Nothing, ComparisonOperator.Equal, Me.BusinessProcessId))
			Return bucket
		End Function

		''' <summary>Creates entity fields Object For this entity. Used In constructor To setup this entity In a polymorphic scenario.</summary>
		Protected Overridable Function CreateFields() As IEntityFields2
			Return EntityFieldsFactory.CreateEntityFieldsObject(PManagement.Data.EntityType.ProjectPlanVersionEntity)
		End Function
				
		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(ProjectPlanVersionEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_phase)
			collectionsQueue.Enqueue(_brandCollectionViaPhase)
			collectionsQueue.Enqueue(_participantCollectionViaPhase_)
			collectionsQueue.Enqueue(_participantCollectionViaPhase)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_phase = CType(collectionsQueue.Dequeue(), EntityCollection(Of PhaseEntity))
			_brandCollectionViaPhase = CType(collectionsQueue.Dequeue(), EntityCollection(Of BrandEntity))
			_participantCollectionViaPhase_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaPhase = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _phase Is Nothing) Then
				Return True
			End If
			If (Not _brandCollectionViaPhase Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaPhase_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaPhase Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>
		''' Creates the ITypeDefaultValue instance used To provide Default values For value types which aren't of type nullable(of T)
		''' </summary>
		''' <returns></returns>
		Protected Overrides Function CreateTypeDefaultValueProvider() As ITypeDefaultValue 
			Return New TypeDefaultValue()
		End Function

		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Public Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("DocumentTemplate", _documentTemplate)
			toReturn.Add("Phase", _phase)
			toReturn.Add("BrandCollectionViaPhase", _brandCollectionViaPhase)
			toReturn.Add("ParticipantCollectionViaPhase_", _participantCollectionViaPhase_)
			toReturn.Add("ParticipantCollectionViaPhase", _participantCollectionViaPhase)
			toReturn.Add("BusinessProcess", _businessProcess)
			Return toReturn
		End Function
		
		''' <summary>Adds the internals To the active context. </summary>
		Protected Overrides Overloads Sub AddInternalsToContext()
		If Not _phase Is Nothing Then
				_phase.ActiveContext = MyBase.ActiveContext
			End If
		If Not _brandCollectionViaPhase Is Nothing Then
				_brandCollectionViaPhase.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participantCollectionViaPhase_ Is Nothing Then
				_participantCollectionViaPhase_.ActiveContext = MyBase.ActiveContext
			End If
		If Not _participantCollectionViaPhase Is Nothing Then
				_participantCollectionViaPhase.ActiveContext = MyBase.ActiveContext
			End If
		If Not _documentTemplate Is Nothing Then
				_documentTemplate.ActiveContext = MyBase.ActiveContext
			End If
		If Not _businessProcess Is Nothing Then
				_businessProcess.ActiveContext = MyBase.ActiveContext
			End If

		End Sub

		''' <summary>Initializes the class members</summary>
		Protected Overridable Sub InitClassMembers()

			_phase = Nothing
			_brandCollectionViaPhase = Nothing
			_participantCollectionViaPhase_ = Nothing
			_participantCollectionViaPhase = Nothing
			_documentTemplate = Nothing
			_businessProcess = Nothing
			PerformDependencyInjection()
			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()

			Dim fieldHashtable As Dictionary(Of String, String) = Nothing
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("ProjectPlanVersionId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("Description", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("DocumentTemplateId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()

			_fieldsCustomProperties.Add("BusinessProcessId", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _documentTemplate</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncDocumentTemplate(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _documentTemplate, AddressOf OnDocumentTemplatePropertyChanged, "DocumentTemplate", ProjectPlanVersionEntity.Relations.DocumentTemplateEntityUsingDocumentTemplateId, True, signalRelatedEntity, "ProjectPlanVersion", resetFKFields, New Integer() { CInt(ProjectPlanVersionFieldIndex.DocumentTemplateId) } )
			_documentTemplate = Nothing
		End Sub

		''' <summary>setups the sync logic for member _documentTemplate</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncDocumentTemplate(relatedEntity As IEntity2)
			DesetupSyncDocumentTemplate(True, True)
			_documentTemplate = CType(relatedEntity, DocumentTemplateEntity)
			MyBase.PerformSetupSyncRelatedEntity( _documentTemplate, AddressOf OnDocumentTemplatePropertyChanged, "DocumentTemplate", ProjectPlanVersionEntity.Relations.DocumentTemplateEntityUsingDocumentTemplateId, True, New String() {  } )
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnDocumentTemplatePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _businessProcess</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncBusinessProcess(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			MyBase.PerformDesetupSyncRelatedEntity( _businessProcess, AddressOf OnBusinessProcessPropertyChanged, "BusinessProcess", ProjectPlanVersionEntity.Relations.BusinessProcessEntityUsingBusinessProcessId, True, signalRelatedEntity, "ProjectPlanVersion", resetFKFields, New Integer() { CInt(ProjectPlanVersionFieldIndex.BusinessProcessId) } )
			_businessProcess = Nothing
		End Sub

		''' <summary>setups the sync logic for member _businessProcess</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncBusinessProcess(relatedEntity As IEntity2)
			DesetupSyncBusinessProcess(True, True)
			_businessProcess = CType(relatedEntity, BusinessProcessEntity)
			MyBase.PerformSetupSyncRelatedEntity( _businessProcess, AddressOf OnBusinessProcessPropertyChanged, "BusinessProcess", ProjectPlanVersionEntity.Relations.BusinessProcessEntityUsingBusinessProcessId, True, New String() {  } )
		End Sub
						
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnBusinessProcessPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this ProjectPlanVersionEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Protected Overridable Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			MyBase.Fields = fields
			MyBase.IsNew = True
			MyBase.Validator = validator
			InitClassMembers()

			
			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As ProjectPlanVersionRelations
			Get	
				Return New ProjectPlanVersionRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Phase' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathPhase() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory))), _
					ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId, _
					CType(PManagement.Data.EntityType.ProjectPlanVersionEntity, Integer), CType(PManagement.Data.EntityType.PhaseEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Phase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrandCollectionViaPhase() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId
				intermediateRelation.SetAliases(String.Empty, "Phase_")
				relations.Add(ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId, "ProjectPlanVersionEntity__", "Phase_", JoinHint.None)
				relations.Add(PhaseEntity.Relations.BrandEntityUsingBrandId, "Phase_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.ProjectPlanVersionEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "BrandCollectionViaPhase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaPhase_() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId
				intermediateRelation.SetAliases(String.Empty, "Phase_")
				relations.Add(ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId, "ProjectPlanVersionEntity__", "Phase_", JoinHint.None)
				relations.Add(PhaseEntity.Relations.ParticipantEntityUsingDeletedById, "Phase_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.ProjectPlanVersionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "ParticipantCollectionViaPhase_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaPhase() As IPrefetchPathElement2
			Get
				Dim relations As IRelationCollection = New RelationCollection()
				Dim intermediateRelation As IEntityRelation = ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId
				intermediateRelation.SetAliases(String.Empty, "Phase_")
				relations.Add(ProjectPlanVersionEntity.Relations.PhaseEntityUsingProjectPlanVersionId, "ProjectPlanVersionEntity__", "Phase_", JoinHint.None)
				relations.Add(PhaseEntity.Relations.ParticipantEntityUsingCreatedById, "Phase_", String.Empty, JoinHint.None)
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.ProjectPlanVersionEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, relations, Nothing, "ParticipantCollectionViaPhase", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'DocumentTemplate' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathDocumentTemplate() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(DocumentTemplateEntityFactory))), _
					ProjectPlanVersionEntity.Relations.DocumentTemplateEntityUsingDocumentTemplateId, _
					CType(PManagement.Data.EntityType.ProjectPlanVersionEntity, Integer), CType(PManagement.Data.EntityType.DocumentTemplateEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "DocumentTemplate", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'BusinessProcess' 
		''' for this entity. Add the object Returned by this property to an existing PrefetchPath2 instance.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBusinessProcess() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(BusinessProcessEntityFactory))), _
					ProjectPlanVersionEntity.Relations.BusinessProcessEntityUsingBusinessProcessId, _
					CType(PManagement.Data.EntityType.ProjectPlanVersionEntity, Integer), CType(PManagement.Data.EntityType.BusinessProcessEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "BusinessProcess", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToOne)
			End Get
		End Property

		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return ProjectPlanVersionEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return ProjectPlanVersionEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The ProjectPlanVersionId property of the Entity ProjectPlanVersion<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "ProjectPlanVersion"."ProjectPlanVersionId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, False</remarks>
		Public Overridable Property [ProjectPlanVersionId]() As System.Int64
			Get
				Return CType(GetValue(CInt(ProjectPlanVersionFieldIndex.ProjectPlanVersionId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(ProjectPlanVersionFieldIndex.ProjectPlanVersionId), value)
			End Set
		End Property

		''' <summary>The Description property of the Entity ProjectPlanVersion<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "ProjectPlanVersion"."Description"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 100<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Description]() As System.String
			Get
				Return CType(GetValue(CInt(ProjectPlanVersionFieldIndex.Description), True), System.String)
			End Get
			Set
				SetValue(CInt(ProjectPlanVersionFieldIndex.Description), value)
			End Set
		End Property

		''' <summary>The DocumentTemplateId property of the Entity ProjectPlanVersion<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "ProjectPlanVersion"."DocumentTemplateId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [DocumentTemplateId]() As System.Int64
			Get
				Return CType(GetValue(CInt(ProjectPlanVersionFieldIndex.DocumentTemplateId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(ProjectPlanVersionFieldIndex.DocumentTemplateId), value)
			End Set
		End Property

		''' <summary>The BusinessProcessId property of the Entity ProjectPlanVersion<br/><br/>
		''' </summary>
		''' <remarks> Mapped on  table field: "ProjectPlanVersion"."BusinessProcessId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [BusinessProcessId]() As System.Int64
			Get
				Return CType(GetValue(CInt(ProjectPlanVersionFieldIndex.BusinessProcessId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(ProjectPlanVersionFieldIndex.BusinessProcessId), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'PhaseEntity' which are related to this entity via a relation of type '1:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(PhaseEntity))> _
		Public Overridable ReadOnly Property [Phase]() As EntityCollection(Of PhaseEntity)
			Get
				If _phase Is Nothing Then
					_phase = New EntityCollection(Of PhaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(PhaseEntityFactory)))
					_phase.SetContainingEntityInfo(Me, "ProjectPlanVersion")
				End If
				Return _phase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BrandEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(BrandEntity))> _
		Public Overridable ReadOnly Property [BrandCollectionViaPhase]() As EntityCollection(Of BrandEntity)
			Get
				If _brandCollectionViaPhase Is Nothing Then
					_brandCollectionViaPhase = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
					_brandCollectionViaPhase.IsReadOnly = True
				End If
				Return _brandCollectionViaPhase
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaPhase_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaPhase_ Is Nothing Then
					_participantCollectionViaPhase_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaPhase_.IsReadOnly = True
				End If
				Return _participantCollectionViaPhase_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'.
		''' If the EntityCollection hasn't been fetched yet, the collection returned will be empty.</summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaPhase]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaPhase Is Nothing Then
					_participantCollectionViaPhase = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaPhase.IsReadOnly = True
				End If
				Return _participantCollectionViaPhase
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'DocumentTemplateEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [DocumentTemplate]() As DocumentTemplateEntity
			Get
				Return _documentTemplate
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncDocumentTemplate(value)
				Else
					If value Is Nothing Then
						If Not _documentTemplate Is Nothing Then
							_documentTemplate.UnsetRelatedEntity(Me, "ProjectPlanVersion")
						End If
					Else
						CType(value, IEntity2).SetRelatedEntity(Me, "ProjectPlanVersion")
					End If
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'BusinessProcessEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.</summary>
		<Browsable(False)> _
		Public Overridable Property [BusinessProcess]() As BusinessProcessEntity
			Get
				Return _businessProcess
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncBusinessProcess(value)
					If (SerializationHelper.Optimization = SerializationOptimization.Fast) AndAlso Not (value Is Nothing) Then
						value.SetRelatedEntity(Me, "ProjectPlanVersion")
					End If
				Else
					If value Is Nothing Then
						If Not _businessProcess Is Nothing Then
							Dim originalValue As IEntity2 = _businessProcess
							DesetupSyncBusinessProcess(True, True)
							OnRelatedEntityUnset(originalValue, "BusinessProcess")
						End If
					Else
						Dim relatedEntity As IEntity2 = CType(value, IEntity2)
						relatedEntity.SetRelatedEntity(Me, "ProjectPlanVersion")
						SetupSyncBusinessProcess(relatedEntity)
						OnRelatedEntitySet(relatedEntity, "BusinessProcess")
					End If
				End If
			End Set
		End Property
	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property
		
		''' <summary>Returns the EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Public Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.ProjectPlanVersionEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
