﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'RcoriginResponsible'.<br/><br/></summary>
	<Serializable()> _
	Public Class RcoriginResponsibleEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _rc As EntityCollection(Of RcEntity)
		Private WithEvents _rcoriginRelation As EntityCollection(Of RcoriginRelationEntity)
		Private WithEvents _caseCollectionViaRc As EntityCollection(Of CaseEntity)
		Private WithEvents _participantCollectionViaRc As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaRc_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaRcoriginRelation As EntityCollection(Of ParticipantEntity)
		Private WithEvents _participantCollectionViaRcoriginRelation_ As EntityCollection(Of ParticipantEntity)
		Private WithEvents _rccomponentOwnerCollectionViaRc As EntityCollection(Of RccomponentOwnerEntity)
		Private WithEvents _rcoriginCollectionViaRc As EntityCollection(Of RcoriginEntity)
		Private WithEvents _rcoriginCollectionViaRcoriginRelation As EntityCollection(Of RcoriginEntity)
		Private WithEvents _rcoriginUnitCollectionViaRc As EntityCollection(Of RcoriginUnitEntity)
		Private WithEvents _rcoriginUnitCollectionViaRcoriginRelation As EntityCollection(Of RcoriginUnitEntity)
		Private WithEvents _participant As ParticipantEntity
		Private WithEvents _participant_ As ParticipantEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Participant</summary>
			Public Shared ReadOnly [Participant] As String = "Participant"
			''' <summary>Member name Participant_</summary>
			Public Shared ReadOnly [Participant_] As String = "Participant_"
			''' <summary>Member name Rc</summary>
			Public Shared ReadOnly [Rc] As String  = "Rc"
			''' <summary>Member name RcoriginRelation</summary>
			Public Shared ReadOnly [RcoriginRelation] As String  = "RcoriginRelation"
			''' <summary>Member name CaseCollectionViaRc</summary>
			Public Shared ReadOnly [CaseCollectionViaRc] As String  = "CaseCollectionViaRc"
			''' <summary>Member name ParticipantCollectionViaRc</summary>
			Public Shared ReadOnly [ParticipantCollectionViaRc] As String  = "ParticipantCollectionViaRc"
			''' <summary>Member name ParticipantCollectionViaRc_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaRc_] As String  = "ParticipantCollectionViaRc_"
			''' <summary>Member name ParticipantCollectionViaRcoriginRelation</summary>
			Public Shared ReadOnly [ParticipantCollectionViaRcoriginRelation] As String  = "ParticipantCollectionViaRcoriginRelation"
			''' <summary>Member name ParticipantCollectionViaRcoriginRelation_</summary>
			Public Shared ReadOnly [ParticipantCollectionViaRcoriginRelation_] As String  = "ParticipantCollectionViaRcoriginRelation_"
			''' <summary>Member name RccomponentOwnerCollectionViaRc</summary>
			Public Shared ReadOnly [RccomponentOwnerCollectionViaRc] As String  = "RccomponentOwnerCollectionViaRc"
			''' <summary>Member name RcoriginCollectionViaRc</summary>
			Public Shared ReadOnly [RcoriginCollectionViaRc] As String  = "RcoriginCollectionViaRc"
			''' <summary>Member name RcoriginCollectionViaRcoriginRelation</summary>
			Public Shared ReadOnly [RcoriginCollectionViaRcoriginRelation] As String  = "RcoriginCollectionViaRcoriginRelation"
			''' <summary>Member name RcoriginUnitCollectionViaRc</summary>
			Public Shared ReadOnly [RcoriginUnitCollectionViaRc] As String  = "RcoriginUnitCollectionViaRc"
			''' <summary>Member name RcoriginUnitCollectionViaRcoriginRelation</summary>
			Public Shared ReadOnly [RcoriginUnitCollectionViaRcoriginRelation] As String  = "RcoriginUnitCollectionViaRcoriginRelation"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RcoriginResponsibleEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("RcoriginResponsibleEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this RcoriginResponsibleEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("RcoriginResponsibleEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="rcoriginResponsibleId">PK value for RcoriginResponsible which data should be fetched into this RcoriginResponsible object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(rcoriginResponsibleId As System.Int64)
			MyBase.New("RcoriginResponsibleEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.RcoriginResponsibleId = rcoriginResponsibleId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="rcoriginResponsibleId">PK value for RcoriginResponsible which data should be fetched into this RcoriginResponsible object</param>
		''' <param name="validator">The custom validator object for this RcoriginResponsibleEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(rcoriginResponsibleId As System.Int64, validator As IValidator)
			MyBase.New("RcoriginResponsibleEntity")
			InitClassEmpty(validator, Nothing)
			Me.RcoriginResponsibleId = rcoriginResponsibleId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_rc = CType(info.GetValue("_rc", GetType(EntityCollection(Of RcEntity))), EntityCollection(Of RcEntity))
				_rcoriginRelation = CType(info.GetValue("_rcoriginRelation", GetType(EntityCollection(Of RcoriginRelationEntity))), EntityCollection(Of RcoriginRelationEntity))
				_caseCollectionViaRc = CType(info.GetValue("_caseCollectionViaRc", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_participantCollectionViaRc = CType(info.GetValue("_participantCollectionViaRc", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaRc_ = CType(info.GetValue("_participantCollectionViaRc_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaRcoriginRelation = CType(info.GetValue("_participantCollectionViaRcoriginRelation", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_participantCollectionViaRcoriginRelation_ = CType(info.GetValue("_participantCollectionViaRcoriginRelation_", GetType(EntityCollection(Of ParticipantEntity))), EntityCollection(Of ParticipantEntity))
				_rccomponentOwnerCollectionViaRc = CType(info.GetValue("_rccomponentOwnerCollectionViaRc", GetType(EntityCollection(Of RccomponentOwnerEntity))), EntityCollection(Of RccomponentOwnerEntity))
				_rcoriginCollectionViaRc = CType(info.GetValue("_rcoriginCollectionViaRc", GetType(EntityCollection(Of RcoriginEntity))), EntityCollection(Of RcoriginEntity))
				_rcoriginCollectionViaRcoriginRelation = CType(info.GetValue("_rcoriginCollectionViaRcoriginRelation", GetType(EntityCollection(Of RcoriginEntity))), EntityCollection(Of RcoriginEntity))
				_rcoriginUnitCollectionViaRc = CType(info.GetValue("_rcoriginUnitCollectionViaRc", GetType(EntityCollection(Of RcoriginUnitEntity))), EntityCollection(Of RcoriginUnitEntity))
				_rcoriginUnitCollectionViaRcoriginRelation = CType(info.GetValue("_rcoriginUnitCollectionViaRcoriginRelation", GetType(EntityCollection(Of RcoriginUnitEntity))), EntityCollection(Of RcoriginUnitEntity))
				_participant = CType(info.GetValue("_participant", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant Is Nothing Then
					AddHandler _participant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_participant_ = CType(info.GetValue("_participant_", GetType(ParticipantEntity)), ParticipantEntity)
				If Not _participant_ Is Nothing Then
					AddHandler _participant_.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, RcoriginResponsibleFieldIndex)



				Case RcoriginResponsibleFieldIndex.CreatedById
					DesetupSyncParticipant(True, False)

				Case RcoriginResponsibleFieldIndex.DeletedById
					DesetupSyncParticipant_(True, False)

				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Participant"
					Me.Participant = CType(entity, ParticipantEntity)
				Case "Participant_"
					Me.Participant_ = CType(entity, ParticipantEntity)
				Case "Rc"
					Me.Rc.Add(CType(entity, RcEntity))
				Case "RcoriginRelation"
					Me.RcoriginRelation.Add(CType(entity, RcoriginRelationEntity))
				Case "CaseCollectionViaRc"
					Me.CaseCollectionViaRc.IsReadOnly = False
					Me.CaseCollectionViaRc.Add(CType(entity, CaseEntity))
					Me.CaseCollectionViaRc.IsReadOnly = True
				Case "ParticipantCollectionViaRc"
					Me.ParticipantCollectionViaRc.IsReadOnly = False
					Me.ParticipantCollectionViaRc.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaRc.IsReadOnly = True
				Case "ParticipantCollectionViaRc_"
					Me.ParticipantCollectionViaRc_.IsReadOnly = False
					Me.ParticipantCollectionViaRc_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaRc_.IsReadOnly = True
				Case "ParticipantCollectionViaRcoriginRelation"
					Me.ParticipantCollectionViaRcoriginRelation.IsReadOnly = False
					Me.ParticipantCollectionViaRcoriginRelation.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaRcoriginRelation.IsReadOnly = True
				Case "ParticipantCollectionViaRcoriginRelation_"
					Me.ParticipantCollectionViaRcoriginRelation_.IsReadOnly = False
					Me.ParticipantCollectionViaRcoriginRelation_.Add(CType(entity, ParticipantEntity))
					Me.ParticipantCollectionViaRcoriginRelation_.IsReadOnly = True
				Case "RccomponentOwnerCollectionViaRc"
					Me.RccomponentOwnerCollectionViaRc.IsReadOnly = False
					Me.RccomponentOwnerCollectionViaRc.Add(CType(entity, RccomponentOwnerEntity))
					Me.RccomponentOwnerCollectionViaRc.IsReadOnly = True
				Case "RcoriginCollectionViaRc"
					Me.RcoriginCollectionViaRc.IsReadOnly = False
					Me.RcoriginCollectionViaRc.Add(CType(entity, RcoriginEntity))
					Me.RcoriginCollectionViaRc.IsReadOnly = True
				Case "RcoriginCollectionViaRcoriginRelation"
					Me.RcoriginCollectionViaRcoriginRelation.IsReadOnly = False
					Me.RcoriginCollectionViaRcoriginRelation.Add(CType(entity, RcoriginEntity))
					Me.RcoriginCollectionViaRcoriginRelation.IsReadOnly = True
				Case "RcoriginUnitCollectionViaRc"
					Me.RcoriginUnitCollectionViaRc.IsReadOnly = False
					Me.RcoriginUnitCollectionViaRc.Add(CType(entity, RcoriginUnitEntity))
					Me.RcoriginUnitCollectionViaRc.IsReadOnly = True
				Case "RcoriginUnitCollectionViaRcoriginRelation"
					Me.RcoriginUnitCollectionViaRcoriginRelation.IsReadOnly = False
					Me.RcoriginUnitCollectionViaRcoriginRelation.Add(CType(entity, RcoriginUnitEntity))
					Me.RcoriginUnitCollectionViaRcoriginRelation.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return RcoriginResponsibleEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Participant"
					toReturn.Add(RcoriginResponsibleEntity.Relations.ParticipantEntityUsingCreatedById)
				Case "Participant_"
					toReturn.Add(RcoriginResponsibleEntity.Relations.ParticipantEntityUsingDeletedById)
				Case "Rc"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId)
				Case "RcoriginRelation"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId)
				Case "CaseCollectionViaRc"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.CaseEntityUsingCaseId, "Rc_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaRc"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.ParticipantEntityUsingCreatedById, "Rc_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaRc_"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.ParticipantEntityUsingDeletedById, "Rc_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaRcoriginRelation"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "RcoriginRelation_", JoinHint.None)
					toReturn.Add(RcoriginRelationEntity.Relations.ParticipantEntityUsingCreatedById, "RcoriginRelation_", String.Empty, JoinHint.None)
				Case "ParticipantCollectionViaRcoriginRelation_"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "RcoriginRelation_", JoinHint.None)
					toReturn.Add(RcoriginRelationEntity.Relations.ParticipantEntityUsingDeletedById, "RcoriginRelation_", String.Empty, JoinHint.None)
				Case "RccomponentOwnerCollectionViaRc"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.RccomponentOwnerEntityUsingRccomponentOwnerId, "Rc_", String.Empty, JoinHint.None)
				Case "RcoriginCollectionViaRc"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.RcoriginEntityUsingRcoriginId, "Rc_", String.Empty, JoinHint.None)
				Case "RcoriginCollectionViaRcoriginRelation"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "RcoriginRelation_", JoinHint.None)
					toReturn.Add(RcoriginRelationEntity.Relations.RcoriginEntityUsingRcoriginId, "RcoriginRelation_", String.Empty, JoinHint.None)
				Case "RcoriginUnitCollectionViaRc"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "Rc_", JoinHint.None)
					toReturn.Add(RcEntity.Relations.RcoriginUnitEntityUsingRcoriginUnitId, "Rc_", String.Empty, JoinHint.None)
				Case "RcoriginUnitCollectionViaRcoriginRelation"
					toReturn.Add(RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId, "RcoriginResponsibleEntity__", "RcoriginRelation_", JoinHint.None)
					toReturn.Add(RcoriginRelationEntity.Relations.RcoriginUnitEntityUsingRcoriginUnitId, "RcoriginRelation_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Participant"
					SetupSyncParticipant(relatedEntity)
				Case "Participant_"
					SetupSyncParticipant_(relatedEntity)
				Case "Rc"
					Me.Rc.Add(CType(relatedEntity, RcEntity))
				Case "RcoriginRelation"
					Me.RcoriginRelation.Add(CType(relatedEntity, RcoriginRelationEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Participant"
					DesetupSyncParticipant(False, True)
				Case "Participant_"
					DesetupSyncParticipant_(False, True)
				Case "Rc"
					Me.PerformRelatedEntityRemoval(Me.Rc, relatedEntity, signalRelatedEntityManyToOne)
				Case "RcoriginRelation"
					Me.PerformRelatedEntityRemoval(Me.RcoriginRelation, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _participant Is Nothing Then
				toReturn.Add(_participant)
			End If
			If Not _participant_ Is Nothing Then
				toReturn.Add(_participant_)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Rc)
			toReturn.Add(Me.RcoriginRelation)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_rc Is Nothing)) AndAlso (_rc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rc 
				End If
				info.AddValue("_rc", value)
				value = Nothing 
				If (Not (_rcoriginRelation Is Nothing)) AndAlso (_rcoriginRelation.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginRelation 
				End If
				info.AddValue("_rcoriginRelation", value)
				value = Nothing 
				If (Not (_caseCollectionViaRc Is Nothing)) AndAlso (_caseCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _caseCollectionViaRc 
				End If
				info.AddValue("_caseCollectionViaRc", value)
				value = Nothing 
				If (Not (_participantCollectionViaRc Is Nothing)) AndAlso (_participantCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaRc 
				End If
				info.AddValue("_participantCollectionViaRc", value)
				value = Nothing 
				If (Not (_participantCollectionViaRc_ Is Nothing)) AndAlso (_participantCollectionViaRc_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaRc_ 
				End If
				info.AddValue("_participantCollectionViaRc_", value)
				value = Nothing 
				If (Not (_participantCollectionViaRcoriginRelation Is Nothing)) AndAlso (_participantCollectionViaRcoriginRelation.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaRcoriginRelation 
				End If
				info.AddValue("_participantCollectionViaRcoriginRelation", value)
				value = Nothing 
				If (Not (_participantCollectionViaRcoriginRelation_ Is Nothing)) AndAlso (_participantCollectionViaRcoriginRelation_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _participantCollectionViaRcoriginRelation_ 
				End If
				info.AddValue("_participantCollectionViaRcoriginRelation_", value)
				value = Nothing 
				If (Not (_rccomponentOwnerCollectionViaRc Is Nothing)) AndAlso (_rccomponentOwnerCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rccomponentOwnerCollectionViaRc 
				End If
				info.AddValue("_rccomponentOwnerCollectionViaRc", value)
				value = Nothing 
				If (Not (_rcoriginCollectionViaRc Is Nothing)) AndAlso (_rcoriginCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginCollectionViaRc 
				End If
				info.AddValue("_rcoriginCollectionViaRc", value)
				value = Nothing 
				If (Not (_rcoriginCollectionViaRcoriginRelation Is Nothing)) AndAlso (_rcoriginCollectionViaRcoriginRelation.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginCollectionViaRcoriginRelation 
				End If
				info.AddValue("_rcoriginCollectionViaRcoriginRelation", value)
				value = Nothing 
				If (Not (_rcoriginUnitCollectionViaRc Is Nothing)) AndAlso (_rcoriginUnitCollectionViaRc.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginUnitCollectionViaRc 
				End If
				info.AddValue("_rcoriginUnitCollectionViaRc", value)
				value = Nothing 
				If (Not (_rcoriginUnitCollectionViaRcoriginRelation Is Nothing)) AndAlso (_rcoriginUnitCollectionViaRcoriginRelation.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _rcoriginUnitCollectionViaRcoriginRelation 
				End If
				info.AddValue("_rcoriginUnitCollectionViaRcoriginRelation", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant
				End If
				info.AddValue("_participant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _participant_
				End If
				info.AddValue("_participant_", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New RcoriginResponsibleRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Rc' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RcoriginRelation' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginRelation() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginRelationFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCaseCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CaseCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaRc_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaRc_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaRcoriginRelation() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaRcoriginRelation"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Participant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipantCollectionViaRcoriginRelation_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("ParticipantCollectionViaRcoriginRelation_"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RccomponentOwner' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRccomponentOwnerCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RccomponentOwnerCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Rcorigin' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RcoriginCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Rcorigin' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginCollectionViaRcoriginRelation() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RcoriginCollectionViaRcoriginRelation"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RcoriginUnit' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginUnitCollectionViaRc() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RcoriginUnitCollectionViaRc"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'RcoriginUnit' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoRcoriginUnitCollectionViaRcoriginRelation() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("RcoriginUnitCollectionViaRcoriginRelation"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(RcoriginResponsibleFields.RcoriginResponsibleId, Nothing, ComparisonOperator.Equal, Me.RcoriginResponsibleId, "RcoriginResponsibleEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.CreatedById))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Participant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoParticipant_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(ParticipantFields.ParticipantId, Nothing, ComparisonOperator.Equal, Me.DeletedById))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(RcoriginResponsibleEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_rc)
			collectionsQueue.Enqueue(_rcoriginRelation)
			collectionsQueue.Enqueue(_caseCollectionViaRc)
			collectionsQueue.Enqueue(_participantCollectionViaRc)
			collectionsQueue.Enqueue(_participantCollectionViaRc_)
			collectionsQueue.Enqueue(_participantCollectionViaRcoriginRelation)
			collectionsQueue.Enqueue(_participantCollectionViaRcoriginRelation_)
			collectionsQueue.Enqueue(_rccomponentOwnerCollectionViaRc)
			collectionsQueue.Enqueue(_rcoriginCollectionViaRc)
			collectionsQueue.Enqueue(_rcoriginCollectionViaRcoriginRelation)
			collectionsQueue.Enqueue(_rcoriginUnitCollectionViaRc)
			collectionsQueue.Enqueue(_rcoriginUnitCollectionViaRcoriginRelation)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_rc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcEntity))
			_rcoriginRelation = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginRelationEntity))
			_caseCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
			_participantCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaRc_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaRcoriginRelation = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_participantCollectionViaRcoriginRelation_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of ParticipantEntity))
			_rccomponentOwnerCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RccomponentOwnerEntity))
			_rcoriginCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginEntity))
			_rcoriginCollectionViaRcoriginRelation = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginEntity))
			_rcoriginUnitCollectionViaRc = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginUnitEntity))
			_rcoriginUnitCollectionViaRcoriginRelation = CType(collectionsQueue.Dequeue(), EntityCollection(Of RcoriginUnitEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _rc Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginRelation Is Nothing) Then
				Return True
			End If
			If (Not _caseCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaRc_ Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaRcoriginRelation Is Nothing) Then
				Return True
			End If
			If (Not _participantCollectionViaRcoriginRelation_ Is Nothing) Then
				Return True
			End If
			If (Not _rccomponentOwnerCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginCollectionViaRcoriginRelation Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginUnitCollectionViaRc Is Nothing) Then
				Return True
			End If
			If (Not _rcoriginUnitCollectionViaRcoriginRelation Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginRelationEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginRelationEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RccomponentOwnerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RccomponentOwnerEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Participant", _participant)
			toReturn.Add("Participant_", _participant_)
			toReturn.Add("Rc", _rc)
			toReturn.Add("RcoriginRelation", _rcoriginRelation)
			toReturn.Add("CaseCollectionViaRc", _caseCollectionViaRc)
			toReturn.Add("ParticipantCollectionViaRc", _participantCollectionViaRc)
			toReturn.Add("ParticipantCollectionViaRc_", _participantCollectionViaRc_)
			toReturn.Add("ParticipantCollectionViaRcoriginRelation", _participantCollectionViaRcoriginRelation)
			toReturn.Add("ParticipantCollectionViaRcoriginRelation_", _participantCollectionViaRcoriginRelation_)
			toReturn.Add("RccomponentOwnerCollectionViaRc", _rccomponentOwnerCollectionViaRc)
			toReturn.Add("RcoriginCollectionViaRc", _rcoriginCollectionViaRc)
			toReturn.Add("RcoriginCollectionViaRcoriginRelation", _rcoriginCollectionViaRcoriginRelation)
			toReturn.Add("RcoriginUnitCollectionViaRc", _rcoriginUnitCollectionViaRc)
			toReturn.Add("RcoriginUnitCollectionViaRcoriginRelation", _rcoriginUnitCollectionViaRcoriginRelation)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("RcoriginResponsibleId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("RcoriginResponsible", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeletedById", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Sort", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _participant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticRcoriginResponsibleRelations.ParticipantEntityUsingCreatedByIdStatic, True, signalRelatedEntity, "RcoriginResponsible", resetFKFields, New Integer() { CInt(RcoriginResponsibleFieldIndex.CreatedById) } )
			_participant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant(relatedEntity As IEntityCore)
			If Not _participant Is relatedEntity Then
				DesetupSyncParticipant(True, True)
				_participant = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant, AddressOf OnParticipantPropertyChanged, "Participant", PManagement.Data.RelationClasses.StaticRcoriginResponsibleRelations.ParticipantEntityUsingCreatedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _participant_</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncParticipant_(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticRcoriginResponsibleRelations.ParticipantEntityUsingDeletedByIdStatic, True, signalRelatedEntity, "RcoriginResponsible_", resetFKFields, New Integer() { CInt(RcoriginResponsibleFieldIndex.DeletedById) } )
			_participant_ = Nothing
		End Sub

		''' <summary>setups the sync logic for member _participant_</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncParticipant_(relatedEntity As IEntityCore)
			If Not _participant_ Is relatedEntity Then
				DesetupSyncParticipant_(True, True)
				_participant_ = CType(relatedEntity, ParticipantEntity)
				Me.PerformSetupSyncRelatedEntity( _participant_, AddressOf OnParticipant_PropertyChanged, "Participant_", PManagement.Data.RelationClasses.StaticRcoriginResponsibleRelations.ParticipantEntityUsingDeletedByIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnParticipant_PropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this RcoriginResponsibleEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As RcoriginResponsibleRelations
			Get	
				Return New RcoriginResponsibleRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Rc'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRc() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of RcEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcEntityFactory))), _
					CType(GetRelationsForField("Rc")(0), IEntityRelation), CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.RcEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Rc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RcoriginRelation'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginRelation() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginRelationEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginRelationEntityFactory))), _
					CType(GetRelationsForField("RcoriginRelation")(0), IEntityRelation), CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.RcoriginRelationEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "RcoriginRelation", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCaseCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CaseCollectionViaRc"), Nothing, "CaseCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaRc"), Nothing, "ParticipantCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaRc_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaRc_"), Nothing, "ParticipantCollectionViaRc_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaRcoriginRelation() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "RcoriginRelation_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaRcoriginRelation"), Nothing, "ParticipantCollectionViaRcoriginRelation", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipantCollectionViaRcoriginRelation_() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "RcoriginRelation_")
				Return New PrefetchPathElement2( New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("ParticipantCollectionViaRcoriginRelation_"), Nothing, "ParticipantCollectionViaRcoriginRelation_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RccomponentOwner' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRccomponentOwnerCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of RccomponentOwnerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RccomponentOwnerEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.RccomponentOwnerEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RccomponentOwnerCollectionViaRc"), Nothing, "RccomponentOwnerCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Rcorigin' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.RcoriginEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RcoriginCollectionViaRc"), Nothing, "RcoriginCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Rcorigin' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginCollectionViaRcoriginRelation() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "RcoriginRelation_")
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.RcoriginEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RcoriginCollectionViaRcoriginRelation"), Nothing, "RcoriginCollectionViaRcoriginRelation", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RcoriginUnit' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginUnitCollectionViaRc() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "Rc_")
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.RcoriginUnitEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RcoriginUnitCollectionViaRc"), Nothing, "RcoriginUnitCollectionViaRc", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'RcoriginUnit' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathRcoriginUnitCollectionViaRcoriginRelation() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = RcoriginResponsibleEntity.Relations.RcoriginRelationEntityUsingRcoriginResponsibleId
				intermediateRelation.SetAliases(String.Empty, "RcoriginRelation_")
				Return New PrefetchPathElement2( New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.RcoriginUnitEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("RcoriginUnitCollectionViaRcoriginRelation"), Nothing, "RcoriginUnitCollectionViaRcoriginRelation", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant")(0), IEntityRelation), CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Participant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathParticipant_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory))), _
					CType(GetRelationsForField("Participant_")(0), IEntityRelation), CType(PManagement.Data.EntityType.RcoriginResponsibleEntity, Integer), CType(PManagement.Data.EntityType.ParticipantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Participant_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return RcoriginResponsibleEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return RcoriginResponsibleEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The RcoriginResponsibleId property of the Entity RcoriginResponsible<br/><br/></summary>
		''' <remarks> Mapped on  table field: "RCOriginResponsible"."RCOriginResponsibleId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [RcoriginResponsibleId]() As System.Int64
			Get
				Return CType(GetValue(CInt(RcoriginResponsibleFieldIndex.RcoriginResponsibleId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(RcoriginResponsibleFieldIndex.RcoriginResponsibleId), value)
			End Set
		End Property
		''' <summary>The RcoriginResponsible property of the Entity RcoriginResponsible<br/><br/></summary>
		''' <remarks> Mapped on  table field: "RCOriginResponsible"."RCOriginResponsible"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [RcoriginResponsible]() As System.String
			Get
				Return CType(GetValue(CInt(RcoriginResponsibleFieldIndex.RcoriginResponsible), True), System.String)
			End Get
			Set
				SetValue(CInt(RcoriginResponsibleFieldIndex.RcoriginResponsible), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity RcoriginResponsible<br/><br/></summary>
		''' <remarks> Mapped on  table field: "RCOriginResponsible"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(RcoriginResponsibleFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(RcoriginResponsibleFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The CreatedById property of the Entity RcoriginResponsible<br/><br/></summary>
		''' <remarks> Mapped on  table field: "RCOriginResponsible"."CreatedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedById]() As System.Int64
			Get
				Return CType(GetValue(CInt(RcoriginResponsibleFieldIndex.CreatedById), True), System.Int64)
			End Get
			Set
				SetValue(CInt(RcoriginResponsibleFieldIndex.CreatedById), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity RcoriginResponsible<br/><br/></summary>
		''' <remarks> Mapped on  table field: "RCOriginResponsible"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(RcoriginResponsibleFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(RcoriginResponsibleFieldIndex.Deleted), value)
			End Set
		End Property
		''' <summary>The DeletedById property of the Entity RcoriginResponsible<br/><br/></summary>
		''' <remarks> Mapped on  table field: "RCOriginResponsible"."DeletedById"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedById]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(RcoriginResponsibleFieldIndex.DeletedById), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(RcoriginResponsibleFieldIndex.DeletedById), value)
			End Set
		End Property
		''' <summary>The Sort property of the Entity RcoriginResponsible<br/><br/></summary>
		''' <remarks> Mapped on  table field: "RCOriginResponsible"."Sort"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Sort]() As Nullable(Of System.Int32)
			Get
				Return CType(GetValue(CInt(RcoriginResponsibleFieldIndex.Sort), False), Nullable(Of System.Int32))
			End Get
			Set
				SetValue(CInt(RcoriginResponsibleFieldIndex.Sort), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcEntity))> _
		Public Overridable ReadOnly Property [Rc]() As EntityCollection(Of RcEntity)
			Get
				If _rc Is Nothing Then
					_rc = New EntityCollection(Of RcEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcEntityFactory)))
					_rc.ActiveContext = Me.ActiveContext
					_rc.SetContainingEntityInfo(Me, "RcoriginResponsible")
				End If
				Return _rc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginRelationEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginRelationEntity))> _
		Public Overridable ReadOnly Property [RcoriginRelation]() As EntityCollection(Of RcoriginRelationEntity)
			Get
				If _rcoriginRelation Is Nothing Then
					_rcoriginRelation = New EntityCollection(Of RcoriginRelationEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginRelationEntityFactory)))
					_rcoriginRelation.ActiveContext = Me.ActiveContext
					_rcoriginRelation.SetContainingEntityInfo(Me, "RcoriginResponsible")
				End If
				Return _rcoriginRelation
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [CaseCollectionViaRc]() As EntityCollection(Of CaseEntity)
			Get
				If _caseCollectionViaRc Is Nothing Then
					_caseCollectionViaRc = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_caseCollectionViaRc.ActiveContext = Me.ActiveContext
					_caseCollectionViaRc.IsReadOnly = True
					CType(_caseCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _caseCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaRc]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaRc Is Nothing Then
					_participantCollectionViaRc = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaRc.ActiveContext = Me.ActiveContext
					_participantCollectionViaRc.IsReadOnly = True
					CType(_participantCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaRc_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaRc_ Is Nothing Then
					_participantCollectionViaRc_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaRc_.ActiveContext = Me.ActiveContext
					_participantCollectionViaRc_.IsReadOnly = True
					CType(_participantCollectionViaRc_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaRc_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaRcoriginRelation]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaRcoriginRelation Is Nothing Then
					_participantCollectionViaRcoriginRelation = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaRcoriginRelation.ActiveContext = Me.ActiveContext
					_participantCollectionViaRcoriginRelation.IsReadOnly = True
					CType(_participantCollectionViaRcoriginRelation, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaRcoriginRelation
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'ParticipantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(ParticipantEntity))> _
		Public Overridable ReadOnly Property [ParticipantCollectionViaRcoriginRelation_]() As EntityCollection(Of ParticipantEntity)
			Get
				If _participantCollectionViaRcoriginRelation_ Is Nothing Then
					_participantCollectionViaRcoriginRelation_ = New EntityCollection(Of ParticipantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(ParticipantEntityFactory)))
					_participantCollectionViaRcoriginRelation_.ActiveContext = Me.ActiveContext
					_participantCollectionViaRcoriginRelation_.IsReadOnly = True
					CType(_participantCollectionViaRcoriginRelation_, IEntityCollectionCore).IsForMN = True
				End If
				Return _participantCollectionViaRcoriginRelation_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RccomponentOwnerEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RccomponentOwnerEntity))> _
		Public Overridable ReadOnly Property [RccomponentOwnerCollectionViaRc]() As EntityCollection(Of RccomponentOwnerEntity)
			Get
				If _rccomponentOwnerCollectionViaRc Is Nothing Then
					_rccomponentOwnerCollectionViaRc = New EntityCollection(Of RccomponentOwnerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RccomponentOwnerEntityFactory)))
					_rccomponentOwnerCollectionViaRc.ActiveContext = Me.ActiveContext
					_rccomponentOwnerCollectionViaRc.IsReadOnly = True
					CType(_rccomponentOwnerCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _rccomponentOwnerCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginEntity))> _
		Public Overridable ReadOnly Property [RcoriginCollectionViaRc]() As EntityCollection(Of RcoriginEntity)
			Get
				If _rcoriginCollectionViaRc Is Nothing Then
					_rcoriginCollectionViaRc = New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory)))
					_rcoriginCollectionViaRc.ActiveContext = Me.ActiveContext
					_rcoriginCollectionViaRc.IsReadOnly = True
					CType(_rcoriginCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _rcoriginCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginEntity))> _
		Public Overridable ReadOnly Property [RcoriginCollectionViaRcoriginRelation]() As EntityCollection(Of RcoriginEntity)
			Get
				If _rcoriginCollectionViaRcoriginRelation Is Nothing Then
					_rcoriginCollectionViaRcoriginRelation = New EntityCollection(Of RcoriginEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginEntityFactory)))
					_rcoriginCollectionViaRcoriginRelation.ActiveContext = Me.ActiveContext
					_rcoriginCollectionViaRcoriginRelation.IsReadOnly = True
					CType(_rcoriginCollectionViaRcoriginRelation, IEntityCollectionCore).IsForMN = True
				End If
				Return _rcoriginCollectionViaRcoriginRelation
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginUnitEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginUnitEntity))> _
		Public Overridable ReadOnly Property [RcoriginUnitCollectionViaRc]() As EntityCollection(Of RcoriginUnitEntity)
			Get
				If _rcoriginUnitCollectionViaRc Is Nothing Then
					_rcoriginUnitCollectionViaRc = New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory)))
					_rcoriginUnitCollectionViaRc.ActiveContext = Me.ActiveContext
					_rcoriginUnitCollectionViaRc.IsReadOnly = True
					CType(_rcoriginUnitCollectionViaRc, IEntityCollectionCore).IsForMN = True
				End If
				Return _rcoriginUnitCollectionViaRc
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'RcoriginUnitEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(RcoriginUnitEntity))> _
		Public Overridable ReadOnly Property [RcoriginUnitCollectionViaRcoriginRelation]() As EntityCollection(Of RcoriginUnitEntity)
			Get
				If _rcoriginUnitCollectionViaRcoriginRelation Is Nothing Then
					_rcoriginUnitCollectionViaRcoriginRelation = New EntityCollection(Of RcoriginUnitEntity)(EntityFactoryCache2.GetEntityFactory(GetType(RcoriginUnitEntityFactory)))
					_rcoriginUnitCollectionViaRcoriginRelation.ActiveContext = Me.ActiveContext
					_rcoriginUnitCollectionViaRcoriginRelation.IsReadOnly = True
					CType(_rcoriginUnitCollectionViaRcoriginRelation, IEntityCollectionCore).IsForMN = True
				End If
				Return _rcoriginUnitCollectionViaRcoriginRelation
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant]() As ParticipantEntity
			Get
				Return _participant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "RcoriginResponsible", "Participant", _participant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'ParticipantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Participant_]() As ParticipantEntity
			Get
				Return _participant_
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncParticipant_(value)
				Else
					SetSingleRelatedEntityNavigator(value, "RcoriginResponsible_", "Participant_", _participant_, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.RcoriginResponsibleEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
