﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'StandardFolder'.<br/><br/></summary>
	<Serializable()> _
	Public Class StandardFolderEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _standardFolder_ As EntityCollection(Of StandardFolderEntity)
		Private WithEvents _brandCollectionViaStandardFolder As EntityCollection(Of BrandEntity)
		Private WithEvents _folderTypeCollectionViaStandardFolder As EntityCollection(Of FolderTypeEntity)
		Private WithEvents _brand As BrandEntity
		Private WithEvents _folderType As FolderTypeEntity
		Private WithEvents _standardFolder As StandardFolderEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Brand</summary>
			Public Shared ReadOnly [Brand] As String = "Brand"
			''' <summary>Member name FolderType</summary>
			Public Shared ReadOnly [FolderType] As String = "FolderType"
			''' <summary>Member name StandardFolder</summary>
			Public Shared ReadOnly [StandardFolder] As String = "StandardFolder"
			''' <summary>Member name StandardFolder_</summary>
			Public Shared ReadOnly [StandardFolder_] As String  = "StandardFolder_"
			''' <summary>Member name BrandCollectionViaStandardFolder</summary>
			Public Shared ReadOnly [BrandCollectionViaStandardFolder] As String  = "BrandCollectionViaStandardFolder"
			''' <summary>Member name FolderTypeCollectionViaStandardFolder</summary>
			Public Shared ReadOnly [FolderTypeCollectionViaStandardFolder] As String  = "FolderTypeCollectionViaStandardFolder"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StandardFolderEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("StandardFolderEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this StandardFolderEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("StandardFolderEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="standardFolderId">PK value for StandardFolder which data should be fetched into this StandardFolder object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(standardFolderId As System.Int64)
			MyBase.New("StandardFolderEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.StandardFolderId = standardFolderId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="standardFolderId">PK value for StandardFolder which data should be fetched into this StandardFolder object</param>
		''' <param name="validator">The custom validator object for this StandardFolderEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(standardFolderId As System.Int64, validator As IValidator)
			MyBase.New("StandardFolderEntity")
			InitClassEmpty(validator, Nothing)
			Me.StandardFolderId = standardFolderId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_standardFolder_ = CType(info.GetValue("_standardFolder_", GetType(EntityCollection(Of StandardFolderEntity))), EntityCollection(Of StandardFolderEntity))
				_brandCollectionViaStandardFolder = CType(info.GetValue("_brandCollectionViaStandardFolder", GetType(EntityCollection(Of BrandEntity))), EntityCollection(Of BrandEntity))
				_folderTypeCollectionViaStandardFolder = CType(info.GetValue("_folderTypeCollectionViaStandardFolder", GetType(EntityCollection(Of FolderTypeEntity))), EntityCollection(Of FolderTypeEntity))
				_brand = CType(info.GetValue("_brand", GetType(BrandEntity)), BrandEntity)
				If Not _brand Is Nothing Then
					AddHandler _brand.AfterSave, AddressOf OnEntityAfterSave
				End If
				_folderType = CType(info.GetValue("_folderType", GetType(FolderTypeEntity)), FolderTypeEntity)
				If Not _folderType Is Nothing Then
					AddHandler _folderType.AfterSave, AddressOf OnEntityAfterSave
				End If
				_standardFolder = CType(info.GetValue("_standardFolder", GetType(StandardFolderEntity)), StandardFolderEntity)
				If Not _standardFolder Is Nothing Then
					AddHandler _standardFolder.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, StandardFolderFieldIndex)

				Case StandardFolderFieldIndex.BrandId
					DesetupSyncBrand(True, False)
				Case StandardFolderFieldIndex.FolderTypeId
					DesetupSyncFolderType(True, False)

				Case StandardFolderFieldIndex.ParentStandardFolderId
					DesetupSyncStandardFolder(True, False)

				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Brand"
					Me.Brand = CType(entity, BrandEntity)
				Case "FolderType"
					Me.FolderType = CType(entity, FolderTypeEntity)
				Case "StandardFolder"
					Me.StandardFolder = CType(entity, StandardFolderEntity)
				Case "StandardFolder_"
					Me.StandardFolder_.Add(CType(entity, StandardFolderEntity))
				Case "BrandCollectionViaStandardFolder"
					Me.BrandCollectionViaStandardFolder.IsReadOnly = False
					Me.BrandCollectionViaStandardFolder.Add(CType(entity, BrandEntity))
					Me.BrandCollectionViaStandardFolder.IsReadOnly = True
				Case "FolderTypeCollectionViaStandardFolder"
					Me.FolderTypeCollectionViaStandardFolder.IsReadOnly = False
					Me.FolderTypeCollectionViaStandardFolder.Add(CType(entity, FolderTypeEntity))
					Me.FolderTypeCollectionViaStandardFolder.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return StandardFolderEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Brand"
					toReturn.Add(StandardFolderEntity.Relations.BrandEntityUsingBrandId)
				Case "FolderType"
					toReturn.Add(StandardFolderEntity.Relations.FolderTypeEntityUsingFolderTypeId)
				Case "StandardFolder"
					toReturn.Add(StandardFolderEntity.Relations.StandardFolderEntityUsingStandardFolderIdParentStandardFolderId)
				Case "StandardFolder_"
					toReturn.Add(StandardFolderEntity.Relations.StandardFolderEntityUsingParentStandardFolderId)
				Case "BrandCollectionViaStandardFolder"
					toReturn.Add(StandardFolderEntity.Relations.StandardFolderEntityUsingParentStandardFolderId, "StandardFolderEntity__", "StandardFolder_", JoinHint.None)
					toReturn.Add(StandardFolderEntity.Relations.BrandEntityUsingBrandId, "StandardFolder_", String.Empty, JoinHint.None)
				Case "FolderTypeCollectionViaStandardFolder"
					toReturn.Add(StandardFolderEntity.Relations.StandardFolderEntityUsingParentStandardFolderId, "StandardFolderEntity__", "StandardFolder_", JoinHint.None)
					toReturn.Add(StandardFolderEntity.Relations.FolderTypeEntityUsingFolderTypeId, "StandardFolder_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Brand"
					SetupSyncBrand(relatedEntity)
				Case "FolderType"
					SetupSyncFolderType(relatedEntity)
				Case "StandardFolder"
					SetupSyncStandardFolder(relatedEntity)
				Case "StandardFolder_"
					Me.StandardFolder_.Add(CType(relatedEntity, StandardFolderEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Brand"
					DesetupSyncBrand(False, True)
				Case "FolderType"
					DesetupSyncFolderType(False, True)
				Case "StandardFolder"
					DesetupSyncStandardFolder(False, True)
				Case "StandardFolder_"
					Me.PerformRelatedEntityRemoval(Me.StandardFolder_, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _brand Is Nothing Then
				toReturn.Add(_brand)
			End If
			If Not _folderType Is Nothing Then
				toReturn.Add(_folderType)
			End If
			If Not _standardFolder Is Nothing Then
				toReturn.Add(_standardFolder)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.StandardFolder_)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_standardFolder_ Is Nothing)) AndAlso (_standardFolder_.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _standardFolder_ 
				End If
				info.AddValue("_standardFolder_", value)
				value = Nothing 
				If (Not (_brandCollectionViaStandardFolder Is Nothing)) AndAlso (_brandCollectionViaStandardFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brandCollectionViaStandardFolder 
				End If
				info.AddValue("_brandCollectionViaStandardFolder", value)
				value = Nothing 
				If (Not (_folderTypeCollectionViaStandardFolder Is Nothing)) AndAlso (_folderTypeCollectionViaStandardFolder.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _folderTypeCollectionViaStandardFolder 
				End If
				info.AddValue("_folderTypeCollectionViaStandardFolder", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _brand
				End If
				info.AddValue("_brand", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _folderType
				End If
				info.AddValue("_folderType", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _standardFolder
				End If
				info.AddValue("_standardFolder", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New StandardFolderRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'StandardFolder' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardFolder_() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardFolderFields.ParentStandardFolderId, Nothing, ComparisonOperator.Equal, Me.StandardFolderId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrandCollectionViaStandardFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BrandCollectionViaStandardFolder"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardFolderFields.StandardFolderId, Nothing, ComparisonOperator.Equal, Me.StandardFolderId, "StandardFolderEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'FolderType' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolderTypeCollectionViaStandardFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("FolderTypeCollectionViaStandardFolder"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardFolderFields.StandardFolderId, Nothing, ComparisonOperator.Equal, Me.StandardFolderId, "StandardFolderEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Brand' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrand() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(BrandFields.BrandId, Nothing, ComparisonOperator.Equal, Me.BrandId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'FolderType' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoFolderType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(FolderTypeFields.FolderTypeId, Nothing, ComparisonOperator.Equal, Me.FolderTypeId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'StandardFolder' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoStandardFolder() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardFolderFields.StandardFolderId, Nothing, ComparisonOperator.Equal, Me.ParentStandardFolderId))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_standardFolder_)
			collectionsQueue.Enqueue(_brandCollectionViaStandardFolder)
			collectionsQueue.Enqueue(_folderTypeCollectionViaStandardFolder)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_standardFolder_ = CType(collectionsQueue.Dequeue(), EntityCollection(Of StandardFolderEntity))
			_brandCollectionViaStandardFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of BrandEntity))
			_folderTypeCollectionViaStandardFolder = CType(collectionsQueue.Dequeue(), EntityCollection(Of FolderTypeEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _standardFolder_ Is Nothing) Then
				Return True
			End If
			If (Not _brandCollectionViaStandardFolder Is Nothing) Then
				Return True
			End If
			If (Not _folderTypeCollectionViaStandardFolder Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Brand", _brand)
			toReturn.Add("FolderType", _folderType)
			toReturn.Add("StandardFolder", _standardFolder)
			toReturn.Add("StandardFolder_", _standardFolder_)
			toReturn.Add("BrandCollectionViaStandardFolder", _brandCollectionViaStandardFolder)
			toReturn.Add("FolderTypeCollectionViaStandardFolder", _folderTypeCollectionViaStandardFolder)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StandardFolderId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("BrandId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("FolderTypeId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Name", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("ParentStandardFolderId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Sort", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _brand</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncBrand(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _brand, AddressOf OnBrandPropertyChanged, "Brand", PManagement.Data.RelationClasses.StaticStandardFolderRelations.BrandEntityUsingBrandIdStatic, True, signalRelatedEntity, "StandardFolder", resetFKFields, New Integer() { CInt(StandardFolderFieldIndex.BrandId) } )
			_brand = Nothing
		End Sub

		''' <summary>setups the sync logic for member _brand</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncBrand(relatedEntity As IEntityCore)
			If Not _brand Is relatedEntity Then
				DesetupSyncBrand(True, True)
				_brand = CType(relatedEntity, BrandEntity)
				Me.PerformSetupSyncRelatedEntity( _brand, AddressOf OnBrandPropertyChanged, "Brand", PManagement.Data.RelationClasses.StaticStandardFolderRelations.BrandEntityUsingBrandIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnBrandPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _folderType</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncFolderType(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _folderType, AddressOf OnFolderTypePropertyChanged, "FolderType", PManagement.Data.RelationClasses.StaticStandardFolderRelations.FolderTypeEntityUsingFolderTypeIdStatic, True, signalRelatedEntity, "StandardFolder", resetFKFields, New Integer() { CInt(StandardFolderFieldIndex.FolderTypeId) } )
			_folderType = Nothing
		End Sub

		''' <summary>setups the sync logic for member _folderType</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncFolderType(relatedEntity As IEntityCore)
			If Not _folderType Is relatedEntity Then
				DesetupSyncFolderType(True, True)
				_folderType = CType(relatedEntity, FolderTypeEntity)
				Me.PerformSetupSyncRelatedEntity( _folderType, AddressOf OnFolderTypePropertyChanged, "FolderType", PManagement.Data.RelationClasses.StaticStandardFolderRelations.FolderTypeEntityUsingFolderTypeIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnFolderTypePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _standardFolder</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncStandardFolder(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _standardFolder, AddressOf OnStandardFolderPropertyChanged, "StandardFolder", PManagement.Data.RelationClasses.StaticStandardFolderRelations.StandardFolderEntityUsingStandardFolderIdParentStandardFolderIdStatic, True, signalRelatedEntity, "StandardFolder_", resetFKFields, New Integer() { CInt(StandardFolderFieldIndex.ParentStandardFolderId) } )
			_standardFolder = Nothing
		End Sub

		''' <summary>setups the sync logic for member _standardFolder</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncStandardFolder(relatedEntity As IEntityCore)
			If Not _standardFolder Is relatedEntity Then
				DesetupSyncStandardFolder(True, True)
				_standardFolder = CType(relatedEntity, StandardFolderEntity)
				Me.PerformSetupSyncRelatedEntity( _standardFolder, AddressOf OnStandardFolderPropertyChanged, "StandardFolder", PManagement.Data.RelationClasses.StaticStandardFolderRelations.StandardFolderEntityUsingStandardFolderIdParentStandardFolderIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnStandardFolderPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this StandardFolderEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As StandardFolderRelations
			Get	
				Return New StandardFolderRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardFolder'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardFolder_() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory))), _
					CType(GetRelationsForField("StandardFolder_")(0), IEntityRelation), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "StandardFolder_", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrandCollectionViaStandardFolder() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = StandardFolderEntity.Relations.StandardFolderEntityUsingParentStandardFolderId
				intermediateRelation.SetAliases(String.Empty, "StandardFolder_")
				Return New PrefetchPathElement2( New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BrandCollectionViaStandardFolder"), Nothing, "BrandCollectionViaStandardFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'FolderType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolderTypeCollectionViaStandardFolder() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = StandardFolderEntity.Relations.StandardFolderEntityUsingParentStandardFolderId
				intermediateRelation.SetAliases(String.Empty, "StandardFolder_")
				Return New PrefetchPathElement2( New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), CType(PManagement.Data.EntityType.FolderTypeEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("FolderTypeCollectionViaStandardFolder"), Nothing, "FolderTypeCollectionViaStandardFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrand() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					CType(GetRelationsForField("Brand")(0), IEntityRelation), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Brand", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'FolderType' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathFolderType() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory))), _
					CType(GetRelationsForField("FolderType")(0), IEntityRelation), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), CType(PManagement.Data.EntityType.FolderTypeEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "FolderType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'StandardFolder' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathStandardFolder() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory))), _
					CType(GetRelationsForField("StandardFolder")(0), IEntityRelation), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), CType(PManagement.Data.EntityType.StandardFolderEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "StandardFolder", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return StandardFolderEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return StandardFolderEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The StandardFolderId property of the Entity StandardFolder<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardFolder"."StandardFolderId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [StandardFolderId]() As System.Int64
			Get
				Return CType(GetValue(CInt(StandardFolderFieldIndex.StandardFolderId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(StandardFolderFieldIndex.StandardFolderId), value)
			End Set
		End Property
		''' <summary>The BrandId property of the Entity StandardFolder<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardFolder"."BrandId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [BrandId]() As System.Int64
			Get
				Return CType(GetValue(CInt(StandardFolderFieldIndex.BrandId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(StandardFolderFieldIndex.BrandId), value)
			End Set
		End Property
		''' <summary>The FolderTypeId property of the Entity StandardFolder<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardFolder"."FolderTypeId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [FolderTypeId]() As System.Int64
			Get
				Return CType(GetValue(CInt(StandardFolderFieldIndex.FolderTypeId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(StandardFolderFieldIndex.FolderTypeId), value)
			End Set
		End Property
		''' <summary>The Name property of the Entity StandardFolder<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardFolder"."Name"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 260<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Name]() As System.String
			Get
				Return CType(GetValue(CInt(StandardFolderFieldIndex.Name), True), System.String)
			End Get
			Set
				SetValue(CInt(StandardFolderFieldIndex.Name), value)
			End Set
		End Property
		''' <summary>The ParentStandardFolderId property of the Entity StandardFolder<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardFolder"."ParentStandardFolderId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [ParentStandardFolderId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(StandardFolderFieldIndex.ParentStandardFolderId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(StandardFolderFieldIndex.ParentStandardFolderId), value)
			End Set
		End Property
		''' <summary>The Sort property of the Entity StandardFolder<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardFolder"."Sort"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Sort]() As System.Int64
			Get
				Return CType(GetValue(CInt(StandardFolderFieldIndex.Sort), True), System.Int64)
			End Get
			Set
				SetValue(CInt(StandardFolderFieldIndex.Sort), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'StandardFolderEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(StandardFolderEntity))> _
		Public Overridable ReadOnly Property [StandardFolder_]() As EntityCollection(Of StandardFolderEntity)
			Get
				If _standardFolder_ Is Nothing Then
					_standardFolder_ = New EntityCollection(Of StandardFolderEntity)(EntityFactoryCache2.GetEntityFactory(GetType(StandardFolderEntityFactory)))
					_standardFolder_.ActiveContext = Me.ActiveContext
					_standardFolder_.SetContainingEntityInfo(Me, "StandardFolder")
				End If
				Return _standardFolder_
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BrandEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BrandEntity))> _
		Public Overridable ReadOnly Property [BrandCollectionViaStandardFolder]() As EntityCollection(Of BrandEntity)
			Get
				If _brandCollectionViaStandardFolder Is Nothing Then
					_brandCollectionViaStandardFolder = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
					_brandCollectionViaStandardFolder.ActiveContext = Me.ActiveContext
					_brandCollectionViaStandardFolder.IsReadOnly = True
					CType(_brandCollectionViaStandardFolder, IEntityCollectionCore).IsForMN = True
				End If
				Return _brandCollectionViaStandardFolder
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'FolderTypeEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(FolderTypeEntity))> _
		Public Overridable ReadOnly Property [FolderTypeCollectionViaStandardFolder]() As EntityCollection(Of FolderTypeEntity)
			Get
				If _folderTypeCollectionViaStandardFolder Is Nothing Then
					_folderTypeCollectionViaStandardFolder = New EntityCollection(Of FolderTypeEntity)(EntityFactoryCache2.GetEntityFactory(GetType(FolderTypeEntityFactory)))
					_folderTypeCollectionViaStandardFolder.ActiveContext = Me.ActiveContext
					_folderTypeCollectionViaStandardFolder.IsReadOnly = True
					CType(_folderTypeCollectionViaStandardFolder, IEntityCollectionCore).IsForMN = True
				End If
				Return _folderTypeCollectionViaStandardFolder
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'BrandEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Brand]() As BrandEntity
			Get
				Return _brand
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncBrand(value)
				Else
					SetSingleRelatedEntityNavigator(value, "StandardFolder", "Brand", _brand, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'FolderTypeEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [FolderType]() As FolderTypeEntity
			Get
				Return _folderType
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncFolderType(value)
				Else
					SetSingleRelatedEntityNavigator(value, "StandardFolder", "FolderType", _folderType, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'StandardFolderEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [StandardFolder]() As StandardFolderEntity
			Get
				Return _standardFolder
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncStandardFolder(value)
				Else
					SetSingleRelatedEntityNavigator(value, "StandardFolder_", "StandardFolder", _standardFolder, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.StandardFolderEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
