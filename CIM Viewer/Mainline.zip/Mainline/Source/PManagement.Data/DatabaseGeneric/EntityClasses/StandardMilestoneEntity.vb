﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'StandardMilestone'.<br/><br/></summary>
	<Serializable()> _
	Public Class StandardMilestoneEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _brand2StandardMilestone As EntityCollection(Of Brand2StandardMilestoneEntity)
		Private WithEvents _brandCollectionViaBrand2StandardMilestone As EntityCollection(Of BrandEntity)

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Brand2StandardMilestone</summary>
			Public Shared ReadOnly [Brand2StandardMilestone] As String  = "Brand2StandardMilestone"
			''' <summary>Member name BrandCollectionViaBrand2StandardMilestone</summary>
			Public Shared ReadOnly [BrandCollectionViaBrand2StandardMilestone] As String  = "BrandCollectionViaBrand2StandardMilestone"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StandardMilestoneEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("StandardMilestoneEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this StandardMilestoneEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("StandardMilestoneEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="standardMilestoneId">PK value for StandardMilestone which data should be fetched into this StandardMilestone object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(standardMilestoneId As System.Int64)
			MyBase.New("StandardMilestoneEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.StandardMilestoneId = standardMilestoneId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="standardMilestoneId">PK value for StandardMilestone which data should be fetched into this StandardMilestone object</param>
		''' <param name="validator">The custom validator object for this StandardMilestoneEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(standardMilestoneId As System.Int64, validator As IValidator)
			MyBase.New("StandardMilestoneEntity")
			InitClassEmpty(validator, Nothing)
			Me.StandardMilestoneId = standardMilestoneId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_brand2StandardMilestone = CType(info.GetValue("_brand2StandardMilestone", GetType(EntityCollection(Of Brand2StandardMilestoneEntity))), EntityCollection(Of Brand2StandardMilestoneEntity))
				_brandCollectionViaBrand2StandardMilestone = CType(info.GetValue("_brandCollectionViaBrand2StandardMilestone", GetType(EntityCollection(Of BrandEntity))), EntityCollection(Of BrandEntity))
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub



		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Brand2StandardMilestone"
					Me.Brand2StandardMilestone.Add(CType(entity, Brand2StandardMilestoneEntity))
				Case "BrandCollectionViaBrand2StandardMilestone"
					Me.BrandCollectionViaBrand2StandardMilestone.IsReadOnly = False
					Me.BrandCollectionViaBrand2StandardMilestone.Add(CType(entity, BrandEntity))
					Me.BrandCollectionViaBrand2StandardMilestone.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return StandardMilestoneEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Brand2StandardMilestone"
					toReturn.Add(StandardMilestoneEntity.Relations.Brand2StandardMilestoneEntityUsingStandardMilestoneId)
				Case "BrandCollectionViaBrand2StandardMilestone"
					toReturn.Add(StandardMilestoneEntity.Relations.Brand2StandardMilestoneEntityUsingStandardMilestoneId, "StandardMilestoneEntity__", "Brand2StandardMilestone_", JoinHint.None)
					toReturn.Add(Brand2StandardMilestoneEntity.Relations.BrandEntityUsingBrandId, "Brand2StandardMilestone_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Brand2StandardMilestone"
					Me.Brand2StandardMilestone.Add(CType(relatedEntity, Brand2StandardMilestoneEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Brand2StandardMilestone"
					Me.PerformRelatedEntityRemoval(Me.Brand2StandardMilestone, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Brand2StandardMilestone)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_brand2StandardMilestone Is Nothing)) AndAlso (_brand2StandardMilestone.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brand2StandardMilestone 
				End If
				info.AddValue("_brand2StandardMilestone", value)
				value = Nothing 
				If (Not (_brandCollectionViaBrand2StandardMilestone Is Nothing)) AndAlso (_brandCollectionViaBrand2StandardMilestone.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _brandCollectionViaBrand2StandardMilestone 
				End If
				info.AddValue("_brandCollectionViaBrand2StandardMilestone", value)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New StandardMilestoneRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand2StandardMilestone' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrand2StandardMilestone() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Brand2StandardMilestoneFields.StandardMilestoneId, Nothing, ComparisonOperator.Equal, Me.StandardMilestoneId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Brand' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoBrandCollectionViaBrand2StandardMilestone() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("BrandCollectionViaBrand2StandardMilestone"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(StandardMilestoneFields.StandardMilestoneId, Nothing, ComparisonOperator.Equal, Me.StandardMilestoneId, "StandardMilestoneEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(StandardMilestoneEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_brand2StandardMilestone)
			collectionsQueue.Enqueue(_brandCollectionViaBrand2StandardMilestone)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_brand2StandardMilestone = CType(collectionsQueue.Dequeue(), EntityCollection(Of Brand2StandardMilestoneEntity))
			_brandCollectionViaBrand2StandardMilestone = CType(collectionsQueue.Dequeue(), EntityCollection(Of BrandEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _brand2StandardMilestone Is Nothing) Then
				Return True
			End If
			If (Not _brandCollectionViaBrand2StandardMilestone Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Brand2StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2StandardMilestoneEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Brand2StandardMilestone", _brand2StandardMilestone)
			toReturn.Add("BrandCollectionViaBrand2StandardMilestone", _brandCollectionViaBrand2StandardMilestone)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("StandardMilestoneId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeadlineOffset", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Description", fieldHashtable)
		End Sub





		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this StandardMilestoneEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As StandardMilestoneRelations
			Get	
				Return New StandardMilestoneRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand2StandardMilestone'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrand2StandardMilestone() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Brand2StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2StandardMilestoneEntityFactory))), _
					CType(GetRelationsForField("Brand2StandardMilestone")(0), IEntityRelation), CType(PManagement.Data.EntityType.StandardMilestoneEntity, Integer), CType(PManagement.Data.EntityType.Brand2StandardMilestoneEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Brand2StandardMilestone", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Brand' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathBrandCollectionViaBrand2StandardMilestone() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = StandardMilestoneEntity.Relations.Brand2StandardMilestoneEntityUsingStandardMilestoneId
				intermediateRelation.SetAliases(String.Empty, "Brand2StandardMilestone_")
				Return New PrefetchPathElement2( New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.StandardMilestoneEntity, Integer), CType(PManagement.Data.EntityType.BrandEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("BrandCollectionViaBrand2StandardMilestone"), Nothing, "BrandCollectionViaBrand2StandardMilestone", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property



		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return StandardMilestoneEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return StandardMilestoneEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The StandardMilestoneId property of the Entity StandardMilestone<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardMilestone"."StandardMilestoneId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, True</remarks>
		Public Overridable Property [StandardMilestoneId]() As System.Int64
			Get
				Return CType(GetValue(CInt(StandardMilestoneFieldIndex.StandardMilestoneId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(StandardMilestoneFieldIndex.StandardMilestoneId), value)
			End Set
		End Property
		''' <summary>The DeadlineOffset property of the Entity StandardMilestone<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardMilestone"."DeadlineOffset"<br/>
		''' Table field type characteristics (type, precision, scale, length): Int, 10, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [DeadlineOffset]() As System.Int32
			Get
				Return CType(GetValue(CInt(StandardMilestoneFieldIndex.DeadlineOffset), True), System.Int32)
			End Get
			Set
				SetValue(CInt(StandardMilestoneFieldIndex.DeadlineOffset), value)
			End Set
		End Property
		''' <summary>The Description property of the Entity StandardMilestone<br/><br/></summary>
		''' <remarks> Mapped on  table field: "StandardMilestone"."Description"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 100<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Description]() As System.String
			Get
				Return CType(GetValue(CInt(StandardMilestoneFieldIndex.Description), True), System.String)
			End Get
			Set
				SetValue(CInt(StandardMilestoneFieldIndex.Description), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Brand2StandardMilestoneEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Brand2StandardMilestoneEntity))> _
		Public Overridable ReadOnly Property [Brand2StandardMilestone]() As EntityCollection(Of Brand2StandardMilestoneEntity)
			Get
				If _brand2StandardMilestone Is Nothing Then
					_brand2StandardMilestone = New EntityCollection(Of Brand2StandardMilestoneEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Brand2StandardMilestoneEntityFactory)))
					_brand2StandardMilestone.ActiveContext = Me.ActiveContext
					_brand2StandardMilestone.SetContainingEntityInfo(Me, "StandardMilestone")
				End If
				Return _brand2StandardMilestone
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'BrandEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(BrandEntity))> _
		Public Overridable ReadOnly Property [BrandCollectionViaBrand2StandardMilestone]() As EntityCollection(Of BrandEntity)
			Get
				If _brandCollectionViaBrand2StandardMilestone Is Nothing Then
					_brandCollectionViaBrand2StandardMilestone = New EntityCollection(Of BrandEntity)(EntityFactoryCache2.GetEntityFactory(GetType(BrandEntityFactory)))
					_brandCollectionViaBrand2StandardMilestone.ActiveContext = Me.ActiveContext
					_brandCollectionViaBrand2StandardMilestone.IsReadOnly = True
					CType(_brandCollectionViaBrand2StandardMilestone, IEntityCollectionCore).IsForMN = True
				End If
				Return _brandCollectionViaBrand2StandardMilestone
			End Get
		End Property


	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.StandardMilestoneEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
