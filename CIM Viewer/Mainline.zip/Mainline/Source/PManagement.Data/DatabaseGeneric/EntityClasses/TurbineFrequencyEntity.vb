﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'TurbineFrequency'.<br/><br/></summary>
	<Serializable()> _
	Public Class TurbineFrequencyEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _turbineMatrix As EntityCollection(Of TurbineMatrixEntity)
		Private WithEvents _turbineCollectionViaTurbineMatrix As EntityCollection(Of TurbineEntity)
		Private WithEvents _turbineManufacturerCollectionViaTurbineMatrix As EntityCollection(Of TurbineManufacturerEntity)
		Private WithEvents _turbineMarkVersionCollectionViaTurbineMatrix As EntityCollection(Of TurbineMarkVersionEntity)
		Private WithEvents _turbineNominelPowerCollectionViaTurbineMatrix As EntityCollection(Of TurbineNominelPowerEntity)
		Private WithEvents _turbineOldCollectionViaTurbineMatrix As EntityCollection(Of TurbineOldEntity)
		Private WithEvents _turbinePlacementCollectionViaTurbineMatrix As EntityCollection(Of TurbinePlacementEntity)
		Private WithEvents _turbinePowerRegulationCollectionViaTurbineMatrix As EntityCollection(Of TurbinePowerRegulationEntity)
		Private WithEvents _turbineRotorDiameterCollectionViaTurbineMatrix As EntityCollection(Of TurbineRotorDiameterEntity)
		Private WithEvents _turbineSmallGeneratorCollectionViaTurbineMatrix As EntityCollection(Of TurbineSmallGeneratorEntity)
		Private WithEvents _turbineTemperatureVariantCollectionViaTurbineMatrix As EntityCollection(Of TurbineTemperatureVariantEntity)
		Private WithEvents _turbineVoltageCollectionViaTurbineMatrix As EntityCollection(Of TurbineVoltageEntity)

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name TurbineMatrix</summary>
			Public Shared ReadOnly [TurbineMatrix] As String  = "TurbineMatrix"
			''' <summary>Member name TurbineCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineCollectionViaTurbineMatrix] As String  = "TurbineCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineManufacturerCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineManufacturerCollectionViaTurbineMatrix] As String  = "TurbineManufacturerCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineMarkVersionCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineMarkVersionCollectionViaTurbineMatrix] As String  = "TurbineMarkVersionCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineNominelPowerCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineNominelPowerCollectionViaTurbineMatrix] As String  = "TurbineNominelPowerCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineOldCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineOldCollectionViaTurbineMatrix] As String  = "TurbineOldCollectionViaTurbineMatrix"
			''' <summary>Member name TurbinePlacementCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbinePlacementCollectionViaTurbineMatrix] As String  = "TurbinePlacementCollectionViaTurbineMatrix"
			''' <summary>Member name TurbinePowerRegulationCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbinePowerRegulationCollectionViaTurbineMatrix] As String  = "TurbinePowerRegulationCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineRotorDiameterCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineRotorDiameterCollectionViaTurbineMatrix] As String  = "TurbineRotorDiameterCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineSmallGeneratorCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineSmallGeneratorCollectionViaTurbineMatrix] As String  = "TurbineSmallGeneratorCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineTemperatureVariantCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineTemperatureVariantCollectionViaTurbineMatrix] As String  = "TurbineTemperatureVariantCollectionViaTurbineMatrix"
			''' <summary>Member name TurbineVoltageCollectionViaTurbineMatrix</summary>
			Public Shared ReadOnly [TurbineVoltageCollectionViaTurbineMatrix] As String  = "TurbineVoltageCollectionViaTurbineMatrix"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineFrequencyEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("TurbineFrequencyEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this TurbineFrequencyEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("TurbineFrequencyEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="turbineFrequencyId">PK value for TurbineFrequency which data should be fetched into this TurbineFrequency object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(turbineFrequencyId As System.Int64)
			MyBase.New("TurbineFrequencyEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.TurbineFrequencyId = turbineFrequencyId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="turbineFrequencyId">PK value for TurbineFrequency which data should be fetched into this TurbineFrequency object</param>
		''' <param name="validator">The custom validator object for this TurbineFrequencyEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(turbineFrequencyId As System.Int64, validator As IValidator)
			MyBase.New("TurbineFrequencyEntity")
			InitClassEmpty(validator, Nothing)
			Me.TurbineFrequencyId = turbineFrequencyId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_turbineMatrix = CType(info.GetValue("_turbineMatrix", GetType(EntityCollection(Of TurbineMatrixEntity))), EntityCollection(Of TurbineMatrixEntity))
				_turbineCollectionViaTurbineMatrix = CType(info.GetValue("_turbineCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineEntity))), EntityCollection(Of TurbineEntity))
				_turbineManufacturerCollectionViaTurbineMatrix = CType(info.GetValue("_turbineManufacturerCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineManufacturerEntity))), EntityCollection(Of TurbineManufacturerEntity))
				_turbineMarkVersionCollectionViaTurbineMatrix = CType(info.GetValue("_turbineMarkVersionCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineMarkVersionEntity))), EntityCollection(Of TurbineMarkVersionEntity))
				_turbineNominelPowerCollectionViaTurbineMatrix = CType(info.GetValue("_turbineNominelPowerCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineNominelPowerEntity))), EntityCollection(Of TurbineNominelPowerEntity))
				_turbineOldCollectionViaTurbineMatrix = CType(info.GetValue("_turbineOldCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineOldEntity))), EntityCollection(Of TurbineOldEntity))
				_turbinePlacementCollectionViaTurbineMatrix = CType(info.GetValue("_turbinePlacementCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbinePlacementEntity))), EntityCollection(Of TurbinePlacementEntity))
				_turbinePowerRegulationCollectionViaTurbineMatrix = CType(info.GetValue("_turbinePowerRegulationCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbinePowerRegulationEntity))), EntityCollection(Of TurbinePowerRegulationEntity))
				_turbineRotorDiameterCollectionViaTurbineMatrix = CType(info.GetValue("_turbineRotorDiameterCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineRotorDiameterEntity))), EntityCollection(Of TurbineRotorDiameterEntity))
				_turbineSmallGeneratorCollectionViaTurbineMatrix = CType(info.GetValue("_turbineSmallGeneratorCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineSmallGeneratorEntity))), EntityCollection(Of TurbineSmallGeneratorEntity))
				_turbineTemperatureVariantCollectionViaTurbineMatrix = CType(info.GetValue("_turbineTemperatureVariantCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineTemperatureVariantEntity))), EntityCollection(Of TurbineTemperatureVariantEntity))
				_turbineVoltageCollectionViaTurbineMatrix = CType(info.GetValue("_turbineVoltageCollectionViaTurbineMatrix", GetType(EntityCollection(Of TurbineVoltageEntity))), EntityCollection(Of TurbineVoltageEntity))
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub



		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "TurbineMatrix"
					Me.TurbineMatrix.Add(CType(entity, TurbineMatrixEntity))
				Case "TurbineCollectionViaTurbineMatrix"
					Me.TurbineCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineCollectionViaTurbineMatrix.Add(CType(entity, TurbineEntity))
					Me.TurbineCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineManufacturerCollectionViaTurbineMatrix"
					Me.TurbineManufacturerCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineManufacturerCollectionViaTurbineMatrix.Add(CType(entity, TurbineManufacturerEntity))
					Me.TurbineManufacturerCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineMarkVersionCollectionViaTurbineMatrix"
					Me.TurbineMarkVersionCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineMarkVersionCollectionViaTurbineMatrix.Add(CType(entity, TurbineMarkVersionEntity))
					Me.TurbineMarkVersionCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineNominelPowerCollectionViaTurbineMatrix"
					Me.TurbineNominelPowerCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineNominelPowerCollectionViaTurbineMatrix.Add(CType(entity, TurbineNominelPowerEntity))
					Me.TurbineNominelPowerCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineOldCollectionViaTurbineMatrix"
					Me.TurbineOldCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineOldCollectionViaTurbineMatrix.Add(CType(entity, TurbineOldEntity))
					Me.TurbineOldCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbinePlacementCollectionViaTurbineMatrix"
					Me.TurbinePlacementCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbinePlacementCollectionViaTurbineMatrix.Add(CType(entity, TurbinePlacementEntity))
					Me.TurbinePlacementCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbinePowerRegulationCollectionViaTurbineMatrix"
					Me.TurbinePowerRegulationCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbinePowerRegulationCollectionViaTurbineMatrix.Add(CType(entity, TurbinePowerRegulationEntity))
					Me.TurbinePowerRegulationCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineRotorDiameterCollectionViaTurbineMatrix"
					Me.TurbineRotorDiameterCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineRotorDiameterCollectionViaTurbineMatrix.Add(CType(entity, TurbineRotorDiameterEntity))
					Me.TurbineRotorDiameterCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineSmallGeneratorCollectionViaTurbineMatrix"
					Me.TurbineSmallGeneratorCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineSmallGeneratorCollectionViaTurbineMatrix.Add(CType(entity, TurbineSmallGeneratorEntity))
					Me.TurbineSmallGeneratorCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineTemperatureVariantCollectionViaTurbineMatrix"
					Me.TurbineTemperatureVariantCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineTemperatureVariantCollectionViaTurbineMatrix.Add(CType(entity, TurbineTemperatureVariantEntity))
					Me.TurbineTemperatureVariantCollectionViaTurbineMatrix.IsReadOnly = True
				Case "TurbineVoltageCollectionViaTurbineMatrix"
					Me.TurbineVoltageCollectionViaTurbineMatrix.IsReadOnly = False
					Me.TurbineVoltageCollectionViaTurbineMatrix.Add(CType(entity, TurbineVoltageEntity))
					Me.TurbineVoltageCollectionViaTurbineMatrix.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return TurbineFrequencyEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "TurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId)
				Case "TurbineCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineEntityUsingTurbineId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineManufacturerCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineManufacturerEntityUsingTurbineManufacturerId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineMarkVersionCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineMarkVersionEntityUsingTurbineMarkVersionId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineNominelPowerCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineNominelPowerEntityUsingTurbineNominelPowerId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineOldCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineOldEntityUsingTurbineOldId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbinePlacementCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbinePlacementEntityUsingTurbinePlacementId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbinePowerRegulationCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbinePowerRegulationEntityUsingTurbinePowerRegulationId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineRotorDiameterCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineRotorDiameterEntityUsingTurbineRotorDiameterId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineSmallGeneratorCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineSmallGeneratorEntityUsingTurbineSmallGeneratorId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineTemperatureVariantCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineTemperatureVariantEntityUsingTurbineTemperatureVariantId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case "TurbineVoltageCollectionViaTurbineMatrix"
					toReturn.Add(TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId, "TurbineFrequencyEntity__", "TurbineMatrix_", JoinHint.None)
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineVoltageEntityUsingTurbineVoltageId, "TurbineMatrix_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "TurbineMatrix"
					Me.TurbineMatrix.Add(CType(relatedEntity, TurbineMatrixEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "TurbineMatrix"
					Me.PerformRelatedEntityRemoval(Me.TurbineMatrix, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.TurbineMatrix)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_turbineMatrix Is Nothing)) AndAlso (_turbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineMatrix 
				End If
				info.AddValue("_turbineMatrix", value)
				value = Nothing 
				If (Not (_turbineCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineManufacturerCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineManufacturerCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineManufacturerCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineManufacturerCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineMarkVersionCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineMarkVersionCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineMarkVersionCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineMarkVersionCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineNominelPowerCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineNominelPowerCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineNominelPowerCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineNominelPowerCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineOldCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineOldCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineOldCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineOldCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbinePlacementCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbinePlacementCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbinePlacementCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbinePlacementCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbinePowerRegulationCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbinePowerRegulationCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbinePowerRegulationCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbinePowerRegulationCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineRotorDiameterCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineRotorDiameterCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineRotorDiameterCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineRotorDiameterCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineSmallGeneratorCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineSmallGeneratorCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineSmallGeneratorCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineSmallGeneratorCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineTemperatureVariantCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineTemperatureVariantCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineTemperatureVariantCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineTemperatureVariantCollectionViaTurbineMatrix", value)
				value = Nothing 
				If (Not (_turbineVoltageCollectionViaTurbineMatrix Is Nothing)) AndAlso (_turbineVoltageCollectionViaTurbineMatrix.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _turbineVoltageCollectionViaTurbineMatrix 
				End If
				info.AddValue("_turbineVoltageCollectionViaTurbineMatrix", value)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New TurbineFrequencyRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineMatrix' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineMatrixFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Turbine' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineManufacturer' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineManufacturerCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineManufacturerCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineMarkVersion' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineMarkVersionCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineMarkVersionCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineNominelPower' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineNominelPowerCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineNominelPowerCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineOld' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineOldCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineOldCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbinePlacement' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbinePlacementCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbinePlacementCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbinePowerRegulation' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbinePowerRegulationCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbinePowerRegulationCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineRotorDiameter' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineRotorDiameterCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineRotorDiameterCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineSmallGenerator' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineSmallGeneratorCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineSmallGeneratorCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineTemperatureVariant' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineTemperatureVariantCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineTemperatureVariantCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'TurbineVoltage' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineVoltageCollectionViaTurbineMatrix() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("TurbineVoltageCollectionViaTurbineMatrix"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId, "TurbineFrequencyEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(TurbineFrequencyEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_turbineMatrix)
			collectionsQueue.Enqueue(_turbineCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineManufacturerCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineMarkVersionCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineNominelPowerCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineOldCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbinePlacementCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbinePowerRegulationCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineRotorDiameterCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineSmallGeneratorCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineTemperatureVariantCollectionViaTurbineMatrix)
			collectionsQueue.Enqueue(_turbineVoltageCollectionViaTurbineMatrix)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_turbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineMatrixEntity))
			_turbineCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineEntity))
			_turbineManufacturerCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineManufacturerEntity))
			_turbineMarkVersionCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineMarkVersionEntity))
			_turbineNominelPowerCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineNominelPowerEntity))
			_turbineOldCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineOldEntity))
			_turbinePlacementCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbinePlacementEntity))
			_turbinePowerRegulationCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbinePowerRegulationEntity))
			_turbineRotorDiameterCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineRotorDiameterEntity))
			_turbineSmallGeneratorCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineSmallGeneratorEntity))
			_turbineTemperatureVariantCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineTemperatureVariantEntity))
			_turbineVoltageCollectionViaTurbineMatrix = CType(collectionsQueue.Dequeue(), EntityCollection(Of TurbineVoltageEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _turbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineManufacturerCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineMarkVersionCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineNominelPowerCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineOldCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbinePlacementCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbinePowerRegulationCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineRotorDiameterCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineSmallGeneratorCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineTemperatureVariantCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			If (Not _turbineVoltageCollectionViaTurbineMatrix Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMatrixEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineManufacturerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineManufacturerEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineMarkVersionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMarkVersionEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineNominelPowerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineNominelPowerEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineOldEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineOldEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbinePlacementEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePlacementEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbinePowerRegulationEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePowerRegulationEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineRotorDiameterEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineRotorDiameterEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineSmallGeneratorEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineSmallGeneratorEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineTemperatureVariantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineTemperatureVariantEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of TurbineVoltageEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineVoltageEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("TurbineMatrix", _turbineMatrix)
			toReturn.Add("TurbineCollectionViaTurbineMatrix", _turbineCollectionViaTurbineMatrix)
			toReturn.Add("TurbineManufacturerCollectionViaTurbineMatrix", _turbineManufacturerCollectionViaTurbineMatrix)
			toReturn.Add("TurbineMarkVersionCollectionViaTurbineMatrix", _turbineMarkVersionCollectionViaTurbineMatrix)
			toReturn.Add("TurbineNominelPowerCollectionViaTurbineMatrix", _turbineNominelPowerCollectionViaTurbineMatrix)
			toReturn.Add("TurbineOldCollectionViaTurbineMatrix", _turbineOldCollectionViaTurbineMatrix)
			toReturn.Add("TurbinePlacementCollectionViaTurbineMatrix", _turbinePlacementCollectionViaTurbineMatrix)
			toReturn.Add("TurbinePowerRegulationCollectionViaTurbineMatrix", _turbinePowerRegulationCollectionViaTurbineMatrix)
			toReturn.Add("TurbineRotorDiameterCollectionViaTurbineMatrix", _turbineRotorDiameterCollectionViaTurbineMatrix)
			toReturn.Add("TurbineSmallGeneratorCollectionViaTurbineMatrix", _turbineSmallGeneratorCollectionViaTurbineMatrix)
			toReturn.Add("TurbineTemperatureVariantCollectionViaTurbineMatrix", _turbineTemperatureVariantCollectionViaTurbineMatrix)
			toReturn.Add("TurbineVoltageCollectionViaTurbineMatrix", _turbineVoltageCollectionViaTurbineMatrix)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineFrequencyId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Frequency", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedBy", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeletedBy", fieldHashtable)
		End Sub





		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this TurbineFrequencyEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As TurbineFrequencyRelations
			Get	
				Return New TurbineFrequencyRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineMatrix'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineMatrix() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMatrixEntityFactory))), _
					CType(GetRelationsForField("TurbineMatrix")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Turbine' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineCollectionViaTurbineMatrix"), Nothing, "TurbineCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineManufacturer' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineManufacturerCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineManufacturerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineManufacturerEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineManufacturerEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineManufacturerCollectionViaTurbineMatrix"), Nothing, "TurbineManufacturerCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineMarkVersion' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineMarkVersionCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineMarkVersionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMarkVersionEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineMarkVersionEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineMarkVersionCollectionViaTurbineMatrix"), Nothing, "TurbineMarkVersionCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineNominelPower' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineNominelPowerCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineNominelPowerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineNominelPowerEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineNominelPowerEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineNominelPowerCollectionViaTurbineMatrix"), Nothing, "TurbineNominelPowerCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineOld' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineOldCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineOldEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineOldEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineOldEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineOldCollectionViaTurbineMatrix"), Nothing, "TurbineOldCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbinePlacement' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbinePlacementCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbinePlacementEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePlacementEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbinePlacementEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbinePlacementCollectionViaTurbineMatrix"), Nothing, "TurbinePlacementCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbinePowerRegulation' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbinePowerRegulationCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbinePowerRegulationEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePowerRegulationEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbinePowerRegulationEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbinePowerRegulationCollectionViaTurbineMatrix"), Nothing, "TurbinePowerRegulationCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineRotorDiameter' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineRotorDiameterCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineRotorDiameterEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineRotorDiameterEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineRotorDiameterEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineRotorDiameterCollectionViaTurbineMatrix"), Nothing, "TurbineRotorDiameterCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineSmallGenerator' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineSmallGeneratorCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineSmallGeneratorEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineSmallGeneratorEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineSmallGeneratorEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineSmallGeneratorCollectionViaTurbineMatrix"), Nothing, "TurbineSmallGeneratorCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineTemperatureVariant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineTemperatureVariantCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineTemperatureVariantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineTemperatureVariantEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineTemperatureVariantEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineTemperatureVariantCollectionViaTurbineMatrix"), Nothing, "TurbineTemperatureVariantCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineVoltage' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineVoltageCollectionViaTurbineMatrix() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineFrequencyEntity.Relations.TurbineMatrixEntityUsingTurbineFrequencyId
				intermediateRelation.SetAliases(String.Empty, "TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of TurbineVoltageEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineVoltageEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), CType(PManagement.Data.EntityType.TurbineVoltageEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("TurbineVoltageCollectionViaTurbineMatrix"), Nothing, "TurbineVoltageCollectionViaTurbineMatrix", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property



		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return TurbineFrequencyEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return TurbineFrequencyEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The TurbineFrequencyId property of the Entity TurbineFrequency<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineFrequency"."TurbineFrequencyId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, False</remarks>
		Public Overridable Property [TurbineFrequencyId]() As System.Int64
			Get
				Return CType(GetValue(CInt(TurbineFrequencyFieldIndex.TurbineFrequencyId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(TurbineFrequencyFieldIndex.TurbineFrequencyId), value)
			End Set
		End Property
		''' <summary>The Frequency property of the Entity TurbineFrequency<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineFrequency"."Frequency"<br/>
		''' Table field type characteristics (type, precision, scale, length): VarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Frequency]() As System.String
			Get
				Return CType(GetValue(CInt(TurbineFrequencyFieldIndex.Frequency), True), System.String)
			End Get
			Set
				SetValue(CInt(TurbineFrequencyFieldIndex.Frequency), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity TurbineFrequency<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineFrequency"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(TurbineFrequencyFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(TurbineFrequencyFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The CreatedBy property of the Entity TurbineFrequency<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineFrequency"."CreatedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedBy]() As System.String
			Get
				Return CType(GetValue(CInt(TurbineFrequencyFieldIndex.CreatedBy), True), System.String)
			End Get
			Set
				SetValue(CInt(TurbineFrequencyFieldIndex.CreatedBy), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity TurbineFrequency<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineFrequency"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(TurbineFrequencyFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(TurbineFrequencyFieldIndex.Deleted), value)
			End Set
		End Property
		''' <summary>The DeletedBy property of the Entity TurbineFrequency<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineFrequency"."DeletedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedBy]() As System.String
			Get
				Return CType(GetValue(CInt(TurbineFrequencyFieldIndex.DeletedBy), True), System.String)
			End Get
			Set
				SetValue(CInt(TurbineFrequencyFieldIndex.DeletedBy), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineMatrixEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineMatrixEntity))> _
		Public Overridable ReadOnly Property [TurbineMatrix]() As EntityCollection(Of TurbineMatrixEntity)
			Get
				If _turbineMatrix Is Nothing Then
					_turbineMatrix = New EntityCollection(Of TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMatrixEntityFactory)))
					_turbineMatrix.ActiveContext = Me.ActiveContext
					_turbineMatrix.SetContainingEntityInfo(Me, "TurbineFrequency")
				End If
				Return _turbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineEntity))> _
		Public Overridable ReadOnly Property [TurbineCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineEntity)
			Get
				If _turbineCollectionViaTurbineMatrix Is Nothing Then
					_turbineCollectionViaTurbineMatrix = New EntityCollection(Of TurbineEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineEntityFactory)))
					_turbineCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineManufacturerEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineManufacturerEntity))> _
		Public Overridable ReadOnly Property [TurbineManufacturerCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineManufacturerEntity)
			Get
				If _turbineManufacturerCollectionViaTurbineMatrix Is Nothing Then
					_turbineManufacturerCollectionViaTurbineMatrix = New EntityCollection(Of TurbineManufacturerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineManufacturerEntityFactory)))
					_turbineManufacturerCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineManufacturerCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineManufacturerCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineManufacturerCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineMarkVersionEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineMarkVersionEntity))> _
		Public Overridable ReadOnly Property [TurbineMarkVersionCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineMarkVersionEntity)
			Get
				If _turbineMarkVersionCollectionViaTurbineMatrix Is Nothing Then
					_turbineMarkVersionCollectionViaTurbineMatrix = New EntityCollection(Of TurbineMarkVersionEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMarkVersionEntityFactory)))
					_turbineMarkVersionCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineMarkVersionCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineMarkVersionCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineMarkVersionCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineNominelPowerEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineNominelPowerEntity))> _
		Public Overridable ReadOnly Property [TurbineNominelPowerCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineNominelPowerEntity)
			Get
				If _turbineNominelPowerCollectionViaTurbineMatrix Is Nothing Then
					_turbineNominelPowerCollectionViaTurbineMatrix = New EntityCollection(Of TurbineNominelPowerEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineNominelPowerEntityFactory)))
					_turbineNominelPowerCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineNominelPowerCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineNominelPowerCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineNominelPowerCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineOldEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineOldEntity))> _
		Public Overridable ReadOnly Property [TurbineOldCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineOldEntity)
			Get
				If _turbineOldCollectionViaTurbineMatrix Is Nothing Then
					_turbineOldCollectionViaTurbineMatrix = New EntityCollection(Of TurbineOldEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineOldEntityFactory)))
					_turbineOldCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineOldCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineOldCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineOldCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbinePlacementEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbinePlacementEntity))> _
		Public Overridable ReadOnly Property [TurbinePlacementCollectionViaTurbineMatrix]() As EntityCollection(Of TurbinePlacementEntity)
			Get
				If _turbinePlacementCollectionViaTurbineMatrix Is Nothing Then
					_turbinePlacementCollectionViaTurbineMatrix = New EntityCollection(Of TurbinePlacementEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePlacementEntityFactory)))
					_turbinePlacementCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbinePlacementCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbinePlacementCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbinePlacementCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbinePowerRegulationEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbinePowerRegulationEntity))> _
		Public Overridable ReadOnly Property [TurbinePowerRegulationCollectionViaTurbineMatrix]() As EntityCollection(Of TurbinePowerRegulationEntity)
			Get
				If _turbinePowerRegulationCollectionViaTurbineMatrix Is Nothing Then
					_turbinePowerRegulationCollectionViaTurbineMatrix = New EntityCollection(Of TurbinePowerRegulationEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePowerRegulationEntityFactory)))
					_turbinePowerRegulationCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbinePowerRegulationCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbinePowerRegulationCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbinePowerRegulationCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineRotorDiameterEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineRotorDiameterEntity))> _
		Public Overridable ReadOnly Property [TurbineRotorDiameterCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineRotorDiameterEntity)
			Get
				If _turbineRotorDiameterCollectionViaTurbineMatrix Is Nothing Then
					_turbineRotorDiameterCollectionViaTurbineMatrix = New EntityCollection(Of TurbineRotorDiameterEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineRotorDiameterEntityFactory)))
					_turbineRotorDiameterCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineRotorDiameterCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineRotorDiameterCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineRotorDiameterCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineSmallGeneratorEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineSmallGeneratorEntity))> _
		Public Overridable ReadOnly Property [TurbineSmallGeneratorCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineSmallGeneratorEntity)
			Get
				If _turbineSmallGeneratorCollectionViaTurbineMatrix Is Nothing Then
					_turbineSmallGeneratorCollectionViaTurbineMatrix = New EntityCollection(Of TurbineSmallGeneratorEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineSmallGeneratorEntityFactory)))
					_turbineSmallGeneratorCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineSmallGeneratorCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineSmallGeneratorCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineSmallGeneratorCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineTemperatureVariantEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineTemperatureVariantEntity))> _
		Public Overridable ReadOnly Property [TurbineTemperatureVariantCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineTemperatureVariantEntity)
			Get
				If _turbineTemperatureVariantCollectionViaTurbineMatrix Is Nothing Then
					_turbineTemperatureVariantCollectionViaTurbineMatrix = New EntityCollection(Of TurbineTemperatureVariantEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineTemperatureVariantEntityFactory)))
					_turbineTemperatureVariantCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineTemperatureVariantCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineTemperatureVariantCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineTemperatureVariantCollectionViaTurbineMatrix
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'TurbineVoltageEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(TurbineVoltageEntity))> _
		Public Overridable ReadOnly Property [TurbineVoltageCollectionViaTurbineMatrix]() As EntityCollection(Of TurbineVoltageEntity)
			Get
				If _turbineVoltageCollectionViaTurbineMatrix Is Nothing Then
					_turbineVoltageCollectionViaTurbineMatrix = New EntityCollection(Of TurbineVoltageEntity)(EntityFactoryCache2.GetEntityFactory(GetType(TurbineVoltageEntityFactory)))
					_turbineVoltageCollectionViaTurbineMatrix.ActiveContext = Me.ActiveContext
					_turbineVoltageCollectionViaTurbineMatrix.IsReadOnly = True
					CType(_turbineVoltageCollectionViaTurbineMatrix, IEntityCollectionCore).IsForMN = True
				End If
				Return _turbineVoltageCollectionViaTurbineMatrix
			End Get
		End Property


	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.TurbineFrequencyEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
