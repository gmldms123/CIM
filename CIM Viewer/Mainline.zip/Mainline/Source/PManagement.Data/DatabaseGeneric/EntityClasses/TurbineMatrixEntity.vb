﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports System.Xml.Serialization
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.EntityClasses

	''' <summary>Entity class which represents the entity 'TurbineMatrix'.<br/><br/></summary>
	<Serializable()> _
	Public Class TurbineMatrixEntity 
		Inherits CommonEntityBase

		' __LLBLGENPRO_USER_CODE_REGION_START AdditionalInterfaces
		' __LLBLGENPRO_USER_CODE_REGION_END	

#Region "Class Member Declarations"
		Private WithEvents _case2TurbineUnitType As EntityCollection(Of Case2TurbineMatrixEntity)
		Private WithEvents _caseCollectionViaCase2TurbineUnitType As EntityCollection(Of CaseEntity)
		Private WithEvents _turbine As TurbineEntity
		Private WithEvents _turbineFrequency As TurbineFrequencyEntity
		Private WithEvents _turbineManufacturer As TurbineManufacturerEntity
		Private WithEvents _turbineMarkVersion As TurbineMarkVersionEntity
		Private WithEvents _turbineNominelPower As TurbineNominelPowerEntity
		Private WithEvents _turbineOld As TurbineOldEntity
		Private WithEvents _turbinePlacement As TurbinePlacementEntity
		Private WithEvents _turbinePowerRegulation As TurbinePowerRegulationEntity
		Private WithEvents _turbineRotorDiameter As TurbineRotorDiameterEntity
		Private WithEvents _turbineSmallGenerator As TurbineSmallGeneratorEntity
		Private WithEvents _turbineTemperatureVariant As TurbineTemperatureVariantEntity
		Private WithEvents _turbineVoltage As TurbineVoltageEntity

		' __LLBLGENPRO_USER_CODE_REGION_START PrivateMembers
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Shared Members"
		Private Shared _customProperties As Dictionary(Of String, String)
		Private Shared _fieldsCustomProperties As Dictionary(Of String, Dictionary(Of String, String))

		''' <summary>All names of fields mapped onto a relation. Usable For In-memory filtering</summary>
		Public NotInheritable Class MemberNames
			Private Sub New()
			End Sub
			''' <summary>Member name Turbine</summary>
			Public Shared ReadOnly [Turbine] As String = "Turbine"
			''' <summary>Member name TurbineFrequency</summary>
			Public Shared ReadOnly [TurbineFrequency] As String = "TurbineFrequency"
			''' <summary>Member name TurbineManufacturer</summary>
			Public Shared ReadOnly [TurbineManufacturer] As String = "TurbineManufacturer"
			''' <summary>Member name TurbineMarkVersion</summary>
			Public Shared ReadOnly [TurbineMarkVersion] As String = "TurbineMarkVersion"
			''' <summary>Member name TurbineNominelPower</summary>
			Public Shared ReadOnly [TurbineNominelPower] As String = "TurbineNominelPower"
			''' <summary>Member name TurbineOld</summary>
			Public Shared ReadOnly [TurbineOld] As String = "TurbineOld"
			''' <summary>Member name TurbinePlacement</summary>
			Public Shared ReadOnly [TurbinePlacement] As String = "TurbinePlacement"
			''' <summary>Member name TurbinePowerRegulation</summary>
			Public Shared ReadOnly [TurbinePowerRegulation] As String = "TurbinePowerRegulation"
			''' <summary>Member name TurbineRotorDiameter</summary>
			Public Shared ReadOnly [TurbineRotorDiameter] As String = "TurbineRotorDiameter"
			''' <summary>Member name TurbineSmallGenerator</summary>
			Public Shared ReadOnly [TurbineSmallGenerator] As String = "TurbineSmallGenerator"
			''' <summary>Member name TurbineTemperatureVariant</summary>
			Public Shared ReadOnly [TurbineTemperatureVariant] As String = "TurbineTemperatureVariant"
			''' <summary>Member name TurbineVoltage</summary>
			Public Shared ReadOnly [TurbineVoltage] As String = "TurbineVoltage"
			''' <summary>Member name Case2TurbineUnitType</summary>
			Public Shared ReadOnly [Case2TurbineUnitType] As String  = "Case2TurbineUnitType"
			''' <summary>Member name CaseCollectionViaCase2TurbineUnitType</summary>
			Public Shared ReadOnly [CaseCollectionViaCase2TurbineUnitType] As String  = "CaseCollectionViaCase2TurbineUnitType"
		End Class
#End Region

		''' <summary>Static CTor for setting up custom property hashtables. Is executed before the first instance of this entity class or derived classes is constructed. </summary>
		Shared Sub New()
			SetupCustomPropertyHashtables()
		End Sub

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineMatrixEntity")
			InitClassEmpty(Nothing, Nothing)
		End Sub

		''' <summary>CTor</summary>
		''' <remarks>For framework usage.</remarks>
		''' <param name="fields">Fields object to set as the fields for this entity.</param>
		Public Sub New(fields As IEntityFields2)
			MyBase.New("TurbineMatrixEntity")
			InitClassEmpty(Nothing, fields)
		End Sub

		''' <summary>CTor</summary>
		''' <param name="validator">The custom validator object for this TurbineMatrixEntity</param>
		Public Sub New(validator As IValidator)
			MyBase.New("TurbineMatrixEntity")
			InitClassEmpty(validator, Nothing)
		End Sub
				
		''' <summary>CTor</summary>
		''' <param name="turbineMatrixId">PK value for TurbineMatrix which data should be fetched into this TurbineMatrix object</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(turbineMatrixId As System.Int64)
			MyBase.New("TurbineMatrixEntity")
			InitClassEmpty(Nothing, Nothing)
			Me.TurbineMatrixId = turbineMatrixId
		End Sub

		''' <summary>CTor</summary>
		''' <param name="turbineMatrixId">PK value for TurbineMatrix which data should be fetched into this TurbineMatrix object</param>
		''' <param name="validator">The custom validator object for this TurbineMatrixEntity</param>
		''' <remarks>The entity is not fetched by this constructor. Use a DataAccessAdapter for that.</remarks>
		Public Sub New(turbineMatrixId As System.Int64, validator As IValidator)
			MyBase.New("TurbineMatrixEntity")
			InitClassEmpty(validator, Nothing)
			Me.TurbineMatrixId = turbineMatrixId
		End Sub

		''' <summary>Protected CTor for deserialization</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				_case2TurbineUnitType = CType(info.GetValue("_case2TurbineUnitType", GetType(EntityCollection(Of Case2TurbineMatrixEntity))), EntityCollection(Of Case2TurbineMatrixEntity))
				_caseCollectionViaCase2TurbineUnitType = CType(info.GetValue("_caseCollectionViaCase2TurbineUnitType", GetType(EntityCollection(Of CaseEntity))), EntityCollection(Of CaseEntity))
				_turbine = CType(info.GetValue("_turbine", GetType(TurbineEntity)), TurbineEntity)
				If Not _turbine Is Nothing Then
					AddHandler _turbine.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineFrequency = CType(info.GetValue("_turbineFrequency", GetType(TurbineFrequencyEntity)), TurbineFrequencyEntity)
				If Not _turbineFrequency Is Nothing Then
					AddHandler _turbineFrequency.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineManufacturer = CType(info.GetValue("_turbineManufacturer", GetType(TurbineManufacturerEntity)), TurbineManufacturerEntity)
				If Not _turbineManufacturer Is Nothing Then
					AddHandler _turbineManufacturer.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineMarkVersion = CType(info.GetValue("_turbineMarkVersion", GetType(TurbineMarkVersionEntity)), TurbineMarkVersionEntity)
				If Not _turbineMarkVersion Is Nothing Then
					AddHandler _turbineMarkVersion.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineNominelPower = CType(info.GetValue("_turbineNominelPower", GetType(TurbineNominelPowerEntity)), TurbineNominelPowerEntity)
				If Not _turbineNominelPower Is Nothing Then
					AddHandler _turbineNominelPower.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineOld = CType(info.GetValue("_turbineOld", GetType(TurbineOldEntity)), TurbineOldEntity)
				If Not _turbineOld Is Nothing Then
					AddHandler _turbineOld.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbinePlacement = CType(info.GetValue("_turbinePlacement", GetType(TurbinePlacementEntity)), TurbinePlacementEntity)
				If Not _turbinePlacement Is Nothing Then
					AddHandler _turbinePlacement.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbinePowerRegulation = CType(info.GetValue("_turbinePowerRegulation", GetType(TurbinePowerRegulationEntity)), TurbinePowerRegulationEntity)
				If Not _turbinePowerRegulation Is Nothing Then
					AddHandler _turbinePowerRegulation.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineRotorDiameter = CType(info.GetValue("_turbineRotorDiameter", GetType(TurbineRotorDiameterEntity)), TurbineRotorDiameterEntity)
				If Not _turbineRotorDiameter Is Nothing Then
					AddHandler _turbineRotorDiameter.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineSmallGenerator = CType(info.GetValue("_turbineSmallGenerator", GetType(TurbineSmallGeneratorEntity)), TurbineSmallGeneratorEntity)
				If Not _turbineSmallGenerator Is Nothing Then
					AddHandler _turbineSmallGenerator.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineTemperatureVariant = CType(info.GetValue("_turbineTemperatureVariant", GetType(TurbineTemperatureVariantEntity)), TurbineTemperatureVariantEntity)
				If Not _turbineTemperatureVariant Is Nothing Then
					AddHandler _turbineTemperatureVariant.AfterSave, AddressOf OnEntityAfterSave
				End If
				_turbineVoltage = CType(info.GetValue("_turbineVoltage", GetType(TurbineVoltageEntity)), TurbineVoltageEntity)
				If Not _turbineVoltage Is Nothing Then
					AddHandler _turbineVoltage.AfterSave, AddressOf OnEntityAfterSave
				End If
				Me.FixupDeserialization(FieldInfoProviderSingleton.GetInstance())
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START DeserializationConstructor
			' __LLBLGENPRO_USER_CODE_REGION_END
		End Sub

		
		''' <summary>Performs the desync setup when an FK field has been changed. The entity referenced based On the FK field will be dereferenced And sync info will be removed.</summary>
		''' <param name="fieldIndex">The fieldindex.</param>
		Protected Overrides Sub PerformDesyncSetupFKFieldChange(fieldIndex As Integer)
			Select Case CType(fieldIndex, TurbineMatrixFieldIndex)

				Case TurbineMatrixFieldIndex.TurbineId
					DesetupSyncTurbine(True, False)
				Case TurbineMatrixFieldIndex.TurbineRotorDiameterId
					DesetupSyncTurbineRotorDiameter(True, False)
				Case TurbineMatrixFieldIndex.TurbineNominelPowerId
					DesetupSyncTurbineNominelPower(True, False)
				Case TurbineMatrixFieldIndex.TurbineVoltageId
					DesetupSyncTurbineVoltage(True, False)
				Case TurbineMatrixFieldIndex.TurbineFrequencyId
					DesetupSyncTurbineFrequency(True, False)
				Case TurbineMatrixFieldIndex.TurbinePowerRegulationId
					DesetupSyncTurbinePowerRegulation(True, False)
				Case TurbineMatrixFieldIndex.TurbineSmallGeneratorId
					DesetupSyncTurbineSmallGenerator(True, False)
				Case TurbineMatrixFieldIndex.TurbineTemperatureVariantId
					DesetupSyncTurbineTemperatureVariant(True, False)
				Case TurbineMatrixFieldIndex.TurbineMarkVersionId
					DesetupSyncTurbineMarkVersion(True, False)
				Case TurbineMatrixFieldIndex.TurbinePlacementId
					DesetupSyncTurbinePlacement(True, False)
				Case TurbineMatrixFieldIndex.TurbineManufacturerId
					DesetupSyncTurbineManufacturer(True, False)
				Case TurbineMatrixFieldIndex.TurbineOldId
					DesetupSyncTurbineOld(True, False)





				Case Else
					MyBase.PerformDesyncSetupFKFieldChange(fieldIndex)
			End Select
		End Sub


		''' <summary>Sets the related entity property to the entity specified. If the property is a collection, it will add the entity specified to that collection.</summary>
		''' <param name="propertyName">Name of the property.</param>
		''' <param name="entity">Entity to set as an related entity</param>
		''' <remarks>Used by prefetch path logic.</remarks>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub SetRelatedEntityProperty(propertyName As String, entity As IEntityCore)
			Select Case propertyName
				Case "Turbine"
					Me.Turbine = CType(entity, TurbineEntity)
				Case "TurbineFrequency"
					Me.TurbineFrequency = CType(entity, TurbineFrequencyEntity)
				Case "TurbineManufacturer"
					Me.TurbineManufacturer = CType(entity, TurbineManufacturerEntity)
				Case "TurbineMarkVersion"
					Me.TurbineMarkVersion = CType(entity, TurbineMarkVersionEntity)
				Case "TurbineNominelPower"
					Me.TurbineNominelPower = CType(entity, TurbineNominelPowerEntity)
				Case "TurbineOld"
					Me.TurbineOld = CType(entity, TurbineOldEntity)
				Case "TurbinePlacement"
					Me.TurbinePlacement = CType(entity, TurbinePlacementEntity)
				Case "TurbinePowerRegulation"
					Me.TurbinePowerRegulation = CType(entity, TurbinePowerRegulationEntity)
				Case "TurbineRotorDiameter"
					Me.TurbineRotorDiameter = CType(entity, TurbineRotorDiameterEntity)
				Case "TurbineSmallGenerator"
					Me.TurbineSmallGenerator = CType(entity, TurbineSmallGeneratorEntity)
				Case "TurbineTemperatureVariant"
					Me.TurbineTemperatureVariant = CType(entity, TurbineTemperatureVariantEntity)
				Case "TurbineVoltage"
					Me.TurbineVoltage = CType(entity, TurbineVoltageEntity)
				Case "Case2TurbineUnitType"
					Me.Case2TurbineUnitType.Add(CType(entity, Case2TurbineMatrixEntity))
				Case "CaseCollectionViaCase2TurbineUnitType"
					Me.CaseCollectionViaCase2TurbineUnitType.IsReadOnly = False
					Me.CaseCollectionViaCase2TurbineUnitType.Add(CType(entity, CaseEntity))
					Me.CaseCollectionViaCase2TurbineUnitType.IsReadOnly = True

				Case Else
					Me.OnSetRelatedEntityProperty(propertyName, entity)
			End Select
		End Sub
		
		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Protected Overrides Function GetRelationsForFieldOfType(fieldName As String ) As RelationCollection 
			Return TurbineMatrixEntity.GetRelationsForField(fieldName)
		End Function

		''' <summary>Gets the relation objects which represent the relation the fieldName specified Is mapped On. </summary>
		''' <param name="fieldName">Name of the field mapped onto the relation of which the relation objects have To be obtained.</param>
		''' <returns>RelationCollection With relation Object(s) which represent the relation the field Is maped On</returns>
		Friend Shared Function GetRelationsForField(fieldName As String) As RelationCollection 
			Dim toReturn As New RelationCollection()
			Select Case fieldName
				Case "Turbine"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineEntityUsingTurbineId)
				Case "TurbineFrequency"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineFrequencyEntityUsingTurbineFrequencyId)
				Case "TurbineManufacturer"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineManufacturerEntityUsingTurbineManufacturerId)
				Case "TurbineMarkVersion"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineMarkVersionEntityUsingTurbineMarkVersionId)
				Case "TurbineNominelPower"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineNominelPowerEntityUsingTurbineNominelPowerId)
				Case "TurbineOld"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineOldEntityUsingTurbineOldId)
				Case "TurbinePlacement"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbinePlacementEntityUsingTurbinePlacementId)
				Case "TurbinePowerRegulation"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbinePowerRegulationEntityUsingTurbinePowerRegulationId)
				Case "TurbineRotorDiameter"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineRotorDiameterEntityUsingTurbineRotorDiameterId)
				Case "TurbineSmallGenerator"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineSmallGeneratorEntityUsingTurbineSmallGeneratorId)
				Case "TurbineTemperatureVariant"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineTemperatureVariantEntityUsingTurbineTemperatureVariantId)
				Case "TurbineVoltage"
					toReturn.Add(TurbineMatrixEntity.Relations.TurbineVoltageEntityUsingTurbineVoltageId)
				Case "Case2TurbineUnitType"
					toReturn.Add(TurbineMatrixEntity.Relations.Case2TurbineMatrixEntityUsingTurbineMatrixId)
				Case "CaseCollectionViaCase2TurbineUnitType"
					toReturn.Add(TurbineMatrixEntity.Relations.Case2TurbineMatrixEntityUsingTurbineMatrixId, "TurbineMatrixEntity__", "Case2TurbineMatrix_", JoinHint.None)
					toReturn.Add(Case2TurbineMatrixEntity.Relations.CaseEntityUsingCaseId, "Case2TurbineMatrix_", String.Empty, JoinHint.None)
				Case Else
			End Select
			Return toReturn
		End Function
#If Not CF Then		
		''' <summary>Checks If the relation mapped by the Property With the name specified Is a one way / Single sided relation. If the passed In name Is null, it will Return True If the entity has any Single-sided relation</summary>
		''' <param name="propertyName">Name of the Property which Is mapped onto the relation To check, Or null To check If the entity has any relation/ which Is Single sided</param>
		''' <returns>True If the relation Is Single sided / one way (so the opposite relation isn't present), false otherwise</returns>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Function CheckOneWayRelations(propertyName As String) As Boolean
			Dim numberOfOneWayRelations As Integer = 0
			Select Case propertyName
				Case Nothing
					Return ((numberOfOneWayRelations > 0) Or MyBase.CheckOneWayRelations(Nothing))
				Case Else
					Return MyBase.CheckOneWayRelations(propertyName)
			End Select
		End Function
#End If
		''' <summary>Sets the internal parameter related to the fieldname passed to the instance relatedEntity. </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Sub SetRelatedEntity(relatedEntity As IEntityCore, fieldName As String)
			Select Case fieldName
				Case "Turbine"
					SetupSyncTurbine(relatedEntity)
				Case "TurbineFrequency"
					SetupSyncTurbineFrequency(relatedEntity)
				Case "TurbineManufacturer"
					SetupSyncTurbineManufacturer(relatedEntity)
				Case "TurbineMarkVersion"
					SetupSyncTurbineMarkVersion(relatedEntity)
				Case "TurbineNominelPower"
					SetupSyncTurbineNominelPower(relatedEntity)
				Case "TurbineOld"
					SetupSyncTurbineOld(relatedEntity)
				Case "TurbinePlacement"
					SetupSyncTurbinePlacement(relatedEntity)
				Case "TurbinePowerRegulation"
					SetupSyncTurbinePowerRegulation(relatedEntity)
				Case "TurbineRotorDiameter"
					SetupSyncTurbineRotorDiameter(relatedEntity)
				Case "TurbineSmallGenerator"
					SetupSyncTurbineSmallGenerator(relatedEntity)
				Case "TurbineTemperatureVariant"
					SetupSyncTurbineTemperatureVariant(relatedEntity)
				Case "TurbineVoltage"
					SetupSyncTurbineVoltage(relatedEntity)
				Case "Case2TurbineUnitType"
					Me.Case2TurbineUnitType.Add(CType(relatedEntity, Case2TurbineMatrixEntity))

				Case Else
			End Select
		End Sub

		''' <summary>Unsets the internal parameter related to the fieldname passed to the instance relatedEntity. Reverses the actions taken by SetRelatedEntity() </summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		''' <param name="fieldName">Name of field mapped onto the relation which resolves in the instance relatedEntity</param>
		''' <param name="signalRelatedEntityManyToOne">if set to true it will notify the manytoone side, if applicable.</param>
		<EditorBrowsable(EditorBrowsableState.Never)> _
		Protected Overrides Overloads Sub UnsetRelatedEntity(relatedEntity As IEntityCore, fieldName As String, signalRelatedEntityManyToOne As Boolean)
			Select Case fieldName
				Case "Turbine"
					DesetupSyncTurbine(False, True)
				Case "TurbineFrequency"
					DesetupSyncTurbineFrequency(False, True)
				Case "TurbineManufacturer"
					DesetupSyncTurbineManufacturer(False, True)
				Case "TurbineMarkVersion"
					DesetupSyncTurbineMarkVersion(False, True)
				Case "TurbineNominelPower"
					DesetupSyncTurbineNominelPower(False, True)
				Case "TurbineOld"
					DesetupSyncTurbineOld(False, True)
				Case "TurbinePlacement"
					DesetupSyncTurbinePlacement(False, True)
				Case "TurbinePowerRegulation"
					DesetupSyncTurbinePowerRegulation(False, True)
				Case "TurbineRotorDiameter"
					DesetupSyncTurbineRotorDiameter(False, True)
				Case "TurbineSmallGenerator"
					DesetupSyncTurbineSmallGenerator(False, True)
				Case "TurbineTemperatureVariant"
					DesetupSyncTurbineTemperatureVariant(False, True)
				Case "TurbineVoltage"
					DesetupSyncTurbineVoltage(False, True)
				Case "Case2TurbineUnitType"
					Me.PerformRelatedEntityRemoval(Me.Case2TurbineUnitType, relatedEntity, signalRelatedEntityManyToOne)
				Case Else
			End Select
		End Sub

		''' <summary>Gets a collection of related entities referenced by this entity which depend on this entity (this entity is the PK side of their FK fields). </summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependingRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			Return toReturn
		End Function

		''' <summary>Gets a collection of related entities referenced by this entity which this entity depends on (this entity is the FK side of their PK fields).</summary>
		''' <returns>Collection with 0 or more IEntity2 objects, referenced by this entity</returns>
		Protected Overrides Function GetDependentRelatedEntities() As List(Of IEntity2)
			Dim toReturn As New List(Of IEntity2)()
			If Not _turbine Is Nothing Then
				toReturn.Add(_turbine)
			End If
			If Not _turbineFrequency Is Nothing Then
				toReturn.Add(_turbineFrequency)
			End If
			If Not _turbineManufacturer Is Nothing Then
				toReturn.Add(_turbineManufacturer)
			End If
			If Not _turbineMarkVersion Is Nothing Then
				toReturn.Add(_turbineMarkVersion)
			End If
			If Not _turbineNominelPower Is Nothing Then
				toReturn.Add(_turbineNominelPower)
			End If
			If Not _turbineOld Is Nothing Then
				toReturn.Add(_turbineOld)
			End If
			If Not _turbinePlacement Is Nothing Then
				toReturn.Add(_turbinePlacement)
			End If
			If Not _turbinePowerRegulation Is Nothing Then
				toReturn.Add(_turbinePowerRegulation)
			End If
			If Not _turbineRotorDiameter Is Nothing Then
				toReturn.Add(_turbineRotorDiameter)
			End If
			If Not _turbineSmallGenerator Is Nothing Then
				toReturn.Add(_turbineSmallGenerator)
			End If
			If Not _turbineTemperatureVariant Is Nothing Then
				toReturn.Add(_turbineTemperatureVariant)
			End If
			If Not _turbineVoltage Is Nothing Then
				toReturn.Add(_turbineVoltage)
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets an ArrayList of all entity collections stored as member variables in this entity. Only 1:n related collections are returned.</summary>
		''' <returns>Collection with 0 or more IEntityCollection2 objects, referenced by this entity</returns>
		Protected Overrides Function GetMemberEntityCollections() As List(Of IEntityCollection2)
			Dim toReturn As New List(Of IEntityCollection2)()
			toReturn.Add(Me.Case2TurbineUnitType)
			Return toReturn
		End Function


		''' <summary>ISerializable member. Does custom serialization so event handlers do not get serialized. Serializes members of this entity class and uses the base class' implementation to serialize the rest.</summary>
		''' <param name="info"></param>
		''' <param name="context"></param>
		Protected Overrides Sub GetObjectData(info As SerializationInfo, context As StreamingContext)
			If SerializationHelper.Optimization <> SerializationOptimization.Fast Then
				Dim value As IEntityCollection2 = Nothing
				Dim entityValue As IEntity2 = Nothing
				value = Nothing 
				If (Not (_case2TurbineUnitType Is Nothing)) AndAlso (_case2TurbineUnitType.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _case2TurbineUnitType 
				End If
				info.AddValue("_case2TurbineUnitType", value)
				value = Nothing 
				If (Not (_caseCollectionViaCase2TurbineUnitType Is Nothing)) AndAlso (_caseCollectionViaCase2TurbineUnitType.Count>0) AndAlso Not Me.MarkedForDeletion Then 
					value = _caseCollectionViaCase2TurbineUnitType 
				End If
				info.AddValue("_caseCollectionViaCase2TurbineUnitType", value)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbine
				End If
				info.AddValue("_turbine", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineFrequency
				End If
				info.AddValue("_turbineFrequency", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineManufacturer
				End If
				info.AddValue("_turbineManufacturer", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineMarkVersion
				End If
				info.AddValue("_turbineMarkVersion", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineNominelPower
				End If
				info.AddValue("_turbineNominelPower", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineOld
				End If
				info.AddValue("_turbineOld", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbinePlacement
				End If
				info.AddValue("_turbinePlacement", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbinePowerRegulation
				End If
				info.AddValue("_turbinePowerRegulation", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineRotorDiameter
				End If
				info.AddValue("_turbineRotorDiameter", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineSmallGenerator
				End If
				info.AddValue("_turbineSmallGenerator", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineTemperatureVariant
				End If
				info.AddValue("_turbineTemperatureVariant", entityValue)
				entityValue = Nothing
				If Not Me.MarkedForDeletion Then
					entityValue = _turbineVoltage
				End If
				info.AddValue("_turbineVoltage", entityValue)
			End If
			' __LLBLGENPRO_USER_CODE_REGION_START GetObjectInfo
			' __LLBLGENPRO_USER_CODE_REGION_END
			MyBase.GetObjectData(info, context)
		End Sub


		''' <summary>Gets a list of all the EntityRelation objects the type of this instance has.</summary>
		''' <returns>A list of all the EntityRelation objects the type of this instance has. Hierarchy relations are excluded.</returns>
		Protected Overrides Overloads Function GetAllRelations() As List(Of IEntityRelation)
			Return New TurbineMatrixRelations().GetAllRelations()
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case2TurbineMatrix' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCase2TurbineUnitType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(Case2TurbineMatrixFields.TurbineMatrixId, Nothing, ComparisonOperator.Equal, Me.TurbineMatrixId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entities of type 'Case' to this entity. </summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoCaseCollectionViaCase2TurbineUnitType() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.Relations.AddRange(GetRelationsForFieldOfType("CaseCollectionViaCase2TurbineUnitType"))
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineMatrixFields.TurbineMatrixId, Nothing, ComparisonOperator.Equal, Me.TurbineMatrixId, "TurbineMatrixEntity__"))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'Turbine' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbine() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFields.TurbineId, Nothing, ComparisonOperator.Equal, Me.TurbineId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineFrequency' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineFrequency() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineFrequencyFields.TurbineFrequencyId, Nothing, ComparisonOperator.Equal, Me.TurbineFrequencyId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineManufacturer' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineManufacturer() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineManufacturerFields.TurbineManufacturerId, Nothing, ComparisonOperator.Equal, Me.TurbineManufacturerId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineMarkVersion' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineMarkVersion() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineMarkVersionFields.TurbineMarkVersionId, Nothing, ComparisonOperator.Equal, Me.TurbineMarkVersionId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineNominelPower' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineNominelPower() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineNominelPowerFields.TurbineNominelPowerId, Nothing, ComparisonOperator.Equal, Me.TurbineNominelPowerId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineOld' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineOld() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineOldFields.TurbineOldId, Nothing, ComparisonOperator.Equal, Me.TurbineOldId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbinePlacement' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbinePlacement() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbinePlacementFields.TurbinePlacementId, Nothing, ComparisonOperator.Equal, Me.TurbinePlacementId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbinePowerRegulation' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbinePowerRegulation() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbinePowerRegulationFields.TurbinePowerRegulationId, Nothing, ComparisonOperator.Equal, Me.TurbinePowerRegulationId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineRotorDiameter' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineRotorDiameter() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineRotorDiameterFields.TurbineRotorDiameterId, Nothing, ComparisonOperator.Equal, Me.TurbineRotorDiameterId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineSmallGenerator' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineSmallGenerator() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineSmallGeneratorFields.TurbineSmallGeneratorId, Nothing, ComparisonOperator.Equal, Me.TurbineSmallGeneratorId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineTemperatureVariant' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineTemperatureVariant() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineTemperatureVariantFields.TurbineTemperatureVariantId, Nothing, ComparisonOperator.Equal, Me.TurbineTemperatureVariantId))
			Return bucket
		End Function

		''' <summary>Creates a new IRelationPredicateBucket object which contains the predicate expression and relation collection to fetch the related entity of type 'TurbineVoltage' to this entity.</summary>
		''' <returns></returns>
		Public Overridable Function GetRelationInfoTurbineVoltage() As IRelationPredicateBucket
			Dim bucket As IRelationPredicateBucket = New RelationPredicateBucket()
			bucket.PredicateExpression.Add(New FieldCompareValuePredicate(TurbineVoltageFields.TurbineVoltageId, Nothing, ComparisonOperator.Equal, Me.TurbineVoltageId))
			Return bucket
		End Function

		''' <summary>Creates a New instance of the factory related To this entity</summary>
		Protected Overrides Function CreateEntityFactory() As IEntityFactory2 
			Return EntityFactoryCache2.GetEntityFactory(GetType(TurbineMatrixEntityFactory))
		End Function
#If Not CF Then
		''' <summary>Adds the member collections To the collections queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub AddToMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2)) 
			MyBase.AddToMemberEntityCollectionsQueue(collectionsQueue)
			collectionsQueue.Enqueue(_case2TurbineUnitType)
			collectionsQueue.Enqueue(_caseCollectionViaCase2TurbineUnitType)
		End Sub
		
		''' <summary>Gets the member collections queue from the queue (base first)</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		Protected Overrides Sub GetFromMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2))
			MyBase.GetFromMemberEntityCollectionsQueue(collectionsQueue)
			_case2TurbineUnitType = CType(collectionsQueue.Dequeue(), EntityCollection(Of Case2TurbineMatrixEntity))
			_caseCollectionViaCase2TurbineUnitType = CType(collectionsQueue.Dequeue(), EntityCollection(Of CaseEntity))
		End Sub
		
		''' <summary>Determines whether the entity has populated member collections</summary>
		''' <returns>True If the entity has populated member collections.</returns>
		Protected Overrides Function HasPopulatedMemberEntityCollections() As Boolean
			If (Not _case2TurbineUnitType Is Nothing) Then
				Return True
			End If
			If (Not _caseCollectionViaCase2TurbineUnitType Is Nothing) Then
				Return True
			End If
			Return MyBase.HasPopulatedMemberEntityCollections()
		End Function
		
		''' <summary>Creates the member entity collections queue.</summary>
		''' <param name="collectionsQueue">The collections queue.</param>
		''' <param name="requiredQueue">The required queue.</param>
		Protected Overrides Overloads Sub CreateMemberEntityCollectionsQueue(collectionsQueue As Queue(Of IEntityCollection2), requiredQueue As Queue(Of Boolean)) 
			MyBase.CreateMemberEntityCollectionsQueue(collectionsQueue, requiredQueue)
			Dim toAdd As IEntityCollection2 = Nothing
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of Case2TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2TurbineMatrixEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
			If requiredQueue.Dequeue() Then
				toAdd = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
			Else
				toAdd = Nothing
			End If
			collectionsQueue.Enqueue(toAdd)
		End Sub
#End If
		''' <summary>Gets all related data objects, stored by name. The name Is the field name mapped onto the relation For that particular data element. </summary>
		''' <returns>Dictionary With per name the related referenced data element, which can be an entity collection Or an entity Or null</returns>
		Protected Overrides Overloads Function GetRelatedData() As Dictionary(Of String, Object)
			Dim toReturn As New Dictionary(Of String, Object)()
			toReturn.Add("Turbine", _turbine)
			toReturn.Add("TurbineFrequency", _turbineFrequency)
			toReturn.Add("TurbineManufacturer", _turbineManufacturer)
			toReturn.Add("TurbineMarkVersion", _turbineMarkVersion)
			toReturn.Add("TurbineNominelPower", _turbineNominelPower)
			toReturn.Add("TurbineOld", _turbineOld)
			toReturn.Add("TurbinePlacement", _turbinePlacement)
			toReturn.Add("TurbinePowerRegulation", _turbinePowerRegulation)
			toReturn.Add("TurbineRotorDiameter", _turbineRotorDiameter)
			toReturn.Add("TurbineSmallGenerator", _turbineSmallGenerator)
			toReturn.Add("TurbineTemperatureVariant", _turbineTemperatureVariant)
			toReturn.Add("TurbineVoltage", _turbineVoltage)
			toReturn.Add("Case2TurbineUnitType", _case2TurbineUnitType)
			toReturn.Add("CaseCollectionViaCase2TurbineUnitType", _caseCollectionViaCase2TurbineUnitType)
			Return toReturn
		End Function

		''' <summary>Initializes the class members</summary>
		Private Sub InitClassMembers()
			PerformDependencyInjection()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassMembers
			' __LLBLGENPRO_USER_CODE_REGION_END
			OnInitClassMembersComplete()
		End Sub

		''' <summary>Initializes the hashtables for the entity type and entity field custom properties. </summary>
		Private Shared Sub SetupCustomPropertyHashtables()
			_customProperties = New Dictionary(Of String, String)()
			_fieldsCustomProperties = New Dictionary(Of String, Dictionary(Of String, String))()
			Dim fieldHashtable As Dictionary(Of String, String)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineMatrixId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineRotorDiameterId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineNominelPowerId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineVoltageId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineFrequencyId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbinePowerRegulationId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineSmallGeneratorId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineTemperatureVariantId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineMarkVersionId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbinePlacementId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineManufacturerId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("TurbineOldId", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Comment", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Created", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("CreatedBy", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("Deleted", fieldHashtable)
			fieldHashtable = New Dictionary(Of String, String)()
			_fieldsCustomProperties.Add("DeletedBy", fieldHashtable)
		End Sub


		''' <summary>Removes the sync logic for member _turbine</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbine(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbine, AddressOf OnTurbinePropertyChanged, "Turbine", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineEntityUsingTurbineIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineId) } )
			_turbine = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbine</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbine(relatedEntity As IEntityCore)
			If Not _turbine Is relatedEntity Then
				DesetupSyncTurbine(True, True)
				_turbine = CType(relatedEntity, TurbineEntity)
				Me.PerformSetupSyncRelatedEntity( _turbine, AddressOf OnTurbinePropertyChanged, "Turbine", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineEntityUsingTurbineIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbinePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineFrequency</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineFrequency(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineFrequency, AddressOf OnTurbineFrequencyPropertyChanged, "TurbineFrequency", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineFrequencyEntityUsingTurbineFrequencyIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineFrequencyId) } )
			_turbineFrequency = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineFrequency</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineFrequency(relatedEntity As IEntityCore)
			If Not _turbineFrequency Is relatedEntity Then
				DesetupSyncTurbineFrequency(True, True)
				_turbineFrequency = CType(relatedEntity, TurbineFrequencyEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineFrequency, AddressOf OnTurbineFrequencyPropertyChanged, "TurbineFrequency", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineFrequencyEntityUsingTurbineFrequencyIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineFrequencyPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineManufacturer</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineManufacturer(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineManufacturer, AddressOf OnTurbineManufacturerPropertyChanged, "TurbineManufacturer", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineManufacturerEntityUsingTurbineManufacturerIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineManufacturerId) } )
			_turbineManufacturer = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineManufacturer</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineManufacturer(relatedEntity As IEntityCore)
			If Not _turbineManufacturer Is relatedEntity Then
				DesetupSyncTurbineManufacturer(True, True)
				_turbineManufacturer = CType(relatedEntity, TurbineManufacturerEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineManufacturer, AddressOf OnTurbineManufacturerPropertyChanged, "TurbineManufacturer", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineManufacturerEntityUsingTurbineManufacturerIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineManufacturerPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineMarkVersion</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineMarkVersion(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineMarkVersion, AddressOf OnTurbineMarkVersionPropertyChanged, "TurbineMarkVersion", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineMarkVersionEntityUsingTurbineMarkVersionIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineMarkVersionId) } )
			_turbineMarkVersion = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineMarkVersion</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineMarkVersion(relatedEntity As IEntityCore)
			If Not _turbineMarkVersion Is relatedEntity Then
				DesetupSyncTurbineMarkVersion(True, True)
				_turbineMarkVersion = CType(relatedEntity, TurbineMarkVersionEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineMarkVersion, AddressOf OnTurbineMarkVersionPropertyChanged, "TurbineMarkVersion", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineMarkVersionEntityUsingTurbineMarkVersionIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineMarkVersionPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineNominelPower</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineNominelPower(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineNominelPower, AddressOf OnTurbineNominelPowerPropertyChanged, "TurbineNominelPower", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineNominelPowerEntityUsingTurbineNominelPowerIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineNominelPowerId) } )
			_turbineNominelPower = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineNominelPower</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineNominelPower(relatedEntity As IEntityCore)
			If Not _turbineNominelPower Is relatedEntity Then
				DesetupSyncTurbineNominelPower(True, True)
				_turbineNominelPower = CType(relatedEntity, TurbineNominelPowerEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineNominelPower, AddressOf OnTurbineNominelPowerPropertyChanged, "TurbineNominelPower", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineNominelPowerEntityUsingTurbineNominelPowerIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineNominelPowerPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineOld</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineOld(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineOld, AddressOf OnTurbineOldPropertyChanged, "TurbineOld", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineOldEntityUsingTurbineOldIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineOldId) } )
			_turbineOld = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineOld</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineOld(relatedEntity As IEntityCore)
			If Not _turbineOld Is relatedEntity Then
				DesetupSyncTurbineOld(True, True)
				_turbineOld = CType(relatedEntity, TurbineOldEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineOld, AddressOf OnTurbineOldPropertyChanged, "TurbineOld", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineOldEntityUsingTurbineOldIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineOldPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbinePlacement</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbinePlacement(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbinePlacement, AddressOf OnTurbinePlacementPropertyChanged, "TurbinePlacement", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbinePlacementEntityUsingTurbinePlacementIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbinePlacementId) } )
			_turbinePlacement = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbinePlacement</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbinePlacement(relatedEntity As IEntityCore)
			If Not _turbinePlacement Is relatedEntity Then
				DesetupSyncTurbinePlacement(True, True)
				_turbinePlacement = CType(relatedEntity, TurbinePlacementEntity)
				Me.PerformSetupSyncRelatedEntity( _turbinePlacement, AddressOf OnTurbinePlacementPropertyChanged, "TurbinePlacement", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbinePlacementEntityUsingTurbinePlacementIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbinePlacementPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbinePowerRegulation</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbinePowerRegulation(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbinePowerRegulation, AddressOf OnTurbinePowerRegulationPropertyChanged, "TurbinePowerRegulation", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbinePowerRegulationEntityUsingTurbinePowerRegulationIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbinePowerRegulationId) } )
			_turbinePowerRegulation = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbinePowerRegulation</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbinePowerRegulation(relatedEntity As IEntityCore)
			If Not _turbinePowerRegulation Is relatedEntity Then
				DesetupSyncTurbinePowerRegulation(True, True)
				_turbinePowerRegulation = CType(relatedEntity, TurbinePowerRegulationEntity)
				Me.PerformSetupSyncRelatedEntity( _turbinePowerRegulation, AddressOf OnTurbinePowerRegulationPropertyChanged, "TurbinePowerRegulation", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbinePowerRegulationEntityUsingTurbinePowerRegulationIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbinePowerRegulationPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineRotorDiameter</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineRotorDiameter(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineRotorDiameter, AddressOf OnTurbineRotorDiameterPropertyChanged, "TurbineRotorDiameter", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineRotorDiameterEntityUsingTurbineRotorDiameterIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineRotorDiameterId) } )
			_turbineRotorDiameter = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineRotorDiameter</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineRotorDiameter(relatedEntity As IEntityCore)
			If Not _turbineRotorDiameter Is relatedEntity Then
				DesetupSyncTurbineRotorDiameter(True, True)
				_turbineRotorDiameter = CType(relatedEntity, TurbineRotorDiameterEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineRotorDiameter, AddressOf OnTurbineRotorDiameterPropertyChanged, "TurbineRotorDiameter", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineRotorDiameterEntityUsingTurbineRotorDiameterIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineRotorDiameterPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineSmallGenerator</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineSmallGenerator(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineSmallGenerator, AddressOf OnTurbineSmallGeneratorPropertyChanged, "TurbineSmallGenerator", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineSmallGeneratorEntityUsingTurbineSmallGeneratorIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineSmallGeneratorId) } )
			_turbineSmallGenerator = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineSmallGenerator</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineSmallGenerator(relatedEntity As IEntityCore)
			If Not _turbineSmallGenerator Is relatedEntity Then
				DesetupSyncTurbineSmallGenerator(True, True)
				_turbineSmallGenerator = CType(relatedEntity, TurbineSmallGeneratorEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineSmallGenerator, AddressOf OnTurbineSmallGeneratorPropertyChanged, "TurbineSmallGenerator", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineSmallGeneratorEntityUsingTurbineSmallGeneratorIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineSmallGeneratorPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineTemperatureVariant</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineTemperatureVariant(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineTemperatureVariant, AddressOf OnTurbineTemperatureVariantPropertyChanged, "TurbineTemperatureVariant", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineTemperatureVariantEntityUsingTurbineTemperatureVariantIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineTemperatureVariantId) } )
			_turbineTemperatureVariant = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineTemperatureVariant</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineTemperatureVariant(relatedEntity As IEntityCore)
			If Not _turbineTemperatureVariant Is relatedEntity Then
				DesetupSyncTurbineTemperatureVariant(True, True)
				_turbineTemperatureVariant = CType(relatedEntity, TurbineTemperatureVariantEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineTemperatureVariant, AddressOf OnTurbineTemperatureVariantPropertyChanged, "TurbineTemperatureVariant", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineTemperatureVariantEntityUsingTurbineTemperatureVariantIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineTemperatureVariantPropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub

		''' <summary>Removes the sync logic for member _turbineVoltage</summary>
		''' <param name="signalRelatedEntity">If set to true, it will call the related entity's UnsetRelatedEntity method</param>
		''' <param name="resetFKFields">if set to true it will also reset the FK fields pointing to the related entity</param>
		Private Sub DesetupSyncTurbineVoltage(signalRelatedEntity As Boolean, resetFKFields As Boolean)
			Me.PerformDesetupSyncRelatedEntity( _turbineVoltage, AddressOf OnTurbineVoltagePropertyChanged, "TurbineVoltage", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineVoltageEntityUsingTurbineVoltageIdStatic, True, signalRelatedEntity, "TurbineMatrix", resetFKFields, New Integer() { CInt(TurbineMatrixFieldIndex.TurbineVoltageId) } )
			_turbineVoltage = Nothing
		End Sub

		''' <summary>setups the sync logic for member _turbineVoltage</summary>
		''' <param name="relatedEntity">Instance to set as the related entity of type entityType</param>
		Private Sub SetupSyncTurbineVoltage(relatedEntity As IEntityCore)
			If Not _turbineVoltage Is relatedEntity Then
				DesetupSyncTurbineVoltage(True, True)
				_turbineVoltage = CType(relatedEntity, TurbineVoltageEntity)
				Me.PerformSetupSyncRelatedEntity( _turbineVoltage, AddressOf OnTurbineVoltagePropertyChanged, "TurbineVoltage", PManagement.Data.RelationClasses.StaticTurbineMatrixRelations.TurbineVoltageEntityUsingTurbineVoltageIdStatic, True, New String() {  } )
			End If
		End Sub
		
		''' <summary>Handles Property change events of properties In a related entity.</summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		Private Sub OnTurbineVoltagePropertyChanged( sender As Object, e As PropertyChangedEventArgs)
			Select Case e.PropertyName

				Case Else
					' Emtpy
			End Select
		End Sub



		''' <summary>Initializes the class with empty data, as if it is a new Entity.</summary>
		''' <param name="validator">The validator object for this TurbineMatrixEntity</param>
		''' <param name="fields">Fields of this entity</param>
		Private Sub InitClassEmpty(validator As IValidator, fields As IEntityFields2)
			OnInitializing()
			If fields Is Nothing Then
				Me.Fields = CreateFields()
			Else
				Me.Fields = fields
			End If
			Me.Validator = validator
			InitClassMembers()

			' __LLBLGENPRO_USER_CODE_REGION_START InitClassEmpty
			' __LLBLGENPRO_USER_CODE_REGION_END

			OnInitialized()
		End Sub

#Region "Class Property Declarations"
		''' <summary>The relations Object holding all relations of this entity with other entity classes.</summary>
		Public  Shared ReadOnly Property Relations() As TurbineMatrixRelations
			Get	
				Return New TurbineMatrixRelations() 
			End Get
		End Property
		
		''' <summary>The custom properties for this entity type.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property CustomProperties() As Dictionary(Of String, String)
			Get
				Return _customProperties
			End Get
		End Property


		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case2TurbineMatrix'  for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCase2TurbineUnitType() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(Of Case2TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2TurbineMatrixEntityFactory))), _
					CType(GetRelationsForField("Case2TurbineUnitType")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.Case2TurbineMatrixEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Case2TurbineUnitType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Case' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathCaseCollectionViaCase2TurbineUnitType() As IPrefetchPathElement2
			Get
				Dim intermediateRelation As IEntityRelation = TurbineMatrixEntity.Relations.Case2TurbineMatrixEntityUsingTurbineMatrixId
				intermediateRelation.SetAliases(String.Empty, "Case2TurbineMatrix_")
				Return New PrefetchPathElement2( New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory))), _
					intermediateRelation, CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.CaseEntity, Integer), 0, Nothing, Nothing, GetRelationsForField("CaseCollectionViaCase2TurbineUnitType"), Nothing, "CaseCollectionViaCase2TurbineUnitType", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToMany)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'Turbine' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbine() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineEntityFactory))), _
					CType(GetRelationsForField("Turbine")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "Turbine", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineFrequency' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineFrequency() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineFrequencyEntityFactory))), _
					CType(GetRelationsForField("TurbineFrequency")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineFrequencyEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineFrequency", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineManufacturer' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineManufacturer() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineManufacturerEntityFactory))), _
					CType(GetRelationsForField("TurbineManufacturer")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineManufacturerEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineManufacturer", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineMarkVersion' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineMarkVersion() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineMarkVersionEntityFactory))), _
					CType(GetRelationsForField("TurbineMarkVersion")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineMarkVersionEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineMarkVersion", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineNominelPower' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineNominelPower() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineNominelPowerEntityFactory))), _
					CType(GetRelationsForField("TurbineNominelPower")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineNominelPowerEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineNominelPower", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineOld' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineOld() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineOldEntityFactory))), _
					CType(GetRelationsForField("TurbineOld")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineOldEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineOld", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbinePlacement' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbinePlacement() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePlacementEntityFactory))), _
					CType(GetRelationsForField("TurbinePlacement")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbinePlacementEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbinePlacement", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbinePowerRegulation' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbinePowerRegulation() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbinePowerRegulationEntityFactory))), _
					CType(GetRelationsForField("TurbinePowerRegulation")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbinePowerRegulationEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbinePowerRegulation", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineRotorDiameter' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineRotorDiameter() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineRotorDiameterEntityFactory))), _
					CType(GetRelationsForField("TurbineRotorDiameter")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineRotorDiameterEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineRotorDiameter", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineSmallGenerator' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineSmallGenerator() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineSmallGeneratorEntityFactory))), _
					CType(GetRelationsForField("TurbineSmallGenerator")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineSmallGeneratorEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineSmallGenerator", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineTemperatureVariant' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineTemperatureVariant() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineTemperatureVariantEntityFactory))), _
					CType(GetRelationsForField("TurbineTemperatureVariant")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineTemperatureVariantEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineTemperatureVariant", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property

		''' <summary>Creates a New PrefetchPathElement2 object which contains all the information to prefetch the related entities of type 'TurbineVoltage' for this entity.</summary>
		''' <Returns>Ready to use IPrefetchPathElement2 implementation.</Returns>
		Public Shared ReadOnly Property PrefetchPathTurbineVoltage() As IPrefetchPathElement2
			Get
				Return New PrefetchPathElement2( New EntityCollection(EntityFactoryCache2.GetEntityFactory(GetType(TurbineVoltageEntityFactory))), _
					CType(GetRelationsForField("TurbineVoltage")(0), IEntityRelation), CType(PManagement.Data.EntityType.TurbineMatrixEntity, Integer), CType(PManagement.Data.EntityType.TurbineVoltageEntity, Integer), 0, Nothing, Nothing, Nothing, Nothing, "TurbineVoltage", SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne)
			End Get
		End Property


		''' <summary>The custom properties for the type of this entity instance.</summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property CustomPropertiesOfType() As Dictionary(Of String, String)
			Get
				Return TurbineMatrixEntity.CustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of this entity type. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		Public  Shared ReadOnly Property FieldsCustomProperties() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return _fieldsCustomProperties
			End Get
		End Property

		''' <summary>The custom properties for the fields of the type of this entity instance. The returned Hashtable contains per fieldname a hashtable of name-value pairs. </summary>
		''' <remarks>The data returned from this property should be considered read-only: it is not thread safe to alter this data at runtime.</remarks>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property FieldsCustomPropertiesOfType() As Dictionary(Of String, Dictionary(Of String, String))
			Get
				Return TurbineMatrixEntity.FieldsCustomProperties
			End Get
		End Property

		''' <summary>The TurbineMatrixId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineMatrixId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, True, False</remarks>
		Public Overridable Property [TurbineMatrixId]() As System.Int64
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineMatrixId), True), System.Int64)
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineMatrixId), value)
			End Set
		End Property
		''' <summary>The TurbineId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineId), value)
			End Set
		End Property
		''' <summary>The TurbineRotorDiameterId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineRotorDiameterId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineRotorDiameterId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineRotorDiameterId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineRotorDiameterId), value)
			End Set
		End Property
		''' <summary>The TurbineNominelPowerId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineNominelPowerId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineNominelPowerId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineNominelPowerId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineNominelPowerId), value)
			End Set
		End Property
		''' <summary>The TurbineVoltageId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineVoltageId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineVoltageId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineVoltageId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineVoltageId), value)
			End Set
		End Property
		''' <summary>The TurbineFrequencyId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineFrequencyId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineFrequencyId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineFrequencyId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineFrequencyId), value)
			End Set
		End Property
		''' <summary>The TurbinePowerRegulationId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbinePowerRegulationId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbinePowerRegulationId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbinePowerRegulationId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbinePowerRegulationId), value)
			End Set
		End Property
		''' <summary>The TurbineSmallGeneratorId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineSmallGeneratorId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineSmallGeneratorId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineSmallGeneratorId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineSmallGeneratorId), value)
			End Set
		End Property
		''' <summary>The TurbineTemperatureVariantId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineTemperatureVariantId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineTemperatureVariantId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineTemperatureVariantId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineTemperatureVariantId), value)
			End Set
		End Property
		''' <summary>The TurbineMarkVersionId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineMarkVersionId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineMarkVersionId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineMarkVersionId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineMarkVersionId), value)
			End Set
		End Property
		''' <summary>The TurbinePlacementId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbinePlacementId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbinePlacementId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbinePlacementId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbinePlacementId), value)
			End Set
		End Property
		''' <summary>The TurbineManufacturerId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineManufacturerId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineManufacturerId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineManufacturerId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineManufacturerId), value)
			End Set
		End Property
		''' <summary>The TurbineOldId property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."TurbineOldId"<br/>
		''' Table field type characteristics (type, precision, scale, length): BigInt, 19, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [TurbineOldId]() As Nullable(Of System.Int64)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.TurbineOldId), False), Nullable(Of System.Int64))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.TurbineOldId), value)
			End Set
		End Property
		''' <summary>The Comment property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."Comment"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Comment]() As System.String
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.Comment), True), System.String)
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.Comment), value)
			End Set
		End Property
		''' <summary>The Created property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."Created"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [Created]() As System.DateTime
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.Created), True), System.DateTime)
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.Created), value)
			End Set
		End Property
		''' <summary>The CreatedBy property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."CreatedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): False, False, False</remarks>
		Public Overridable Property [CreatedBy]() As System.String
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.CreatedBy), True), System.String)
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.CreatedBy), value)
			End Set
		End Property
		''' <summary>The Deleted property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."Deleted"<br/>
		''' Table field type characteristics (type, precision, scale, length): SmallDateTime, 0, 0, 0<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [Deleted]() As Nullable(Of System.DateTime)
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.Deleted), False), Nullable(Of System.DateTime))
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.Deleted), value)
			End Set
		End Property
		''' <summary>The DeletedBy property of the Entity TurbineMatrix<br/><br/></summary>
		''' <remarks> Mapped on  table field: "TurbineMatrix"."DeletedBy"<br/>
		''' Table field type characteristics (type, precision, scale, length): NVarChar, 0, 0, 50<br/>
		''' Table field behavior characteristics (is nullable, is PK, is identity): True, False, False</remarks>
		Public Overridable Property [DeletedBy]() As System.String
			Get
				Return CType(GetValue(CInt(TurbineMatrixFieldIndex.DeletedBy), True), System.String)
			End Get
			Set
				SetValue(CInt(TurbineMatrixFieldIndex.DeletedBy), value)
			End Set
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'Case2TurbineMatrixEntity' which are related to this entity via a relation of type '1:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(Case2TurbineMatrixEntity))> _
		Public Overridable ReadOnly Property [Case2TurbineUnitType]() As EntityCollection(Of Case2TurbineMatrixEntity)
			Get
				If _case2TurbineUnitType Is Nothing Then
					_case2TurbineUnitType = New EntityCollection(Of Case2TurbineMatrixEntity)(EntityFactoryCache2.GetEntityFactory(GetType(Case2TurbineMatrixEntityFactory)))
					_case2TurbineUnitType.ActiveContext = Me.ActiveContext
					_case2TurbineUnitType.SetContainingEntityInfo(Me, "TurbineMatrix")
				End If
				Return _case2TurbineUnitType
			End Get
		End Property

		''' <summary>Gets the EntityCollection with the related entities of type 'CaseEntity' which are related to this entity via a relation of type 'm:n'. If the EntityCollection hasn't been fetched yet, the collection returned will be empty.<br/><br/>
		''' </summary>
		<TypeContainedAttribute(GetType(CaseEntity))> _
		Public Overridable ReadOnly Property [CaseCollectionViaCase2TurbineUnitType]() As EntityCollection(Of CaseEntity)
			Get
				If _caseCollectionViaCase2TurbineUnitType Is Nothing Then
					_caseCollectionViaCase2TurbineUnitType = New EntityCollection(Of CaseEntity)(EntityFactoryCache2.GetEntityFactory(GetType(CaseEntityFactory)))
					_caseCollectionViaCase2TurbineUnitType.ActiveContext = Me.ActiveContext
					_caseCollectionViaCase2TurbineUnitType.IsReadOnly = True
					CType(_caseCollectionViaCase2TurbineUnitType, IEntityCollectionCore).IsForMN = True
				End If
				Return _caseCollectionViaCase2TurbineUnitType
			End Get
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [Turbine]() As TurbineEntity
			Get
				Return _turbine
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbine(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "Turbine", _turbine, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineFrequencyEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineFrequency]() As TurbineFrequencyEntity
			Get
				Return _turbineFrequency
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineFrequency(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineFrequency", _turbineFrequency, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineManufacturerEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineManufacturer]() As TurbineManufacturerEntity
			Get
				Return _turbineManufacturer
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineManufacturer(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineManufacturer", _turbineManufacturer, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineMarkVersionEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineMarkVersion]() As TurbineMarkVersionEntity
			Get
				Return _turbineMarkVersion
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineMarkVersion(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineMarkVersion", _turbineMarkVersion, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineNominelPowerEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineNominelPower]() As TurbineNominelPowerEntity
			Get
				Return _turbineNominelPower
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineNominelPower(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineNominelPower", _turbineNominelPower, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineOldEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineOld]() As TurbineOldEntity
			Get
				Return _turbineOld
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineOld(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineOld", _turbineOld, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbinePlacementEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbinePlacement]() As TurbinePlacementEntity
			Get
				Return _turbinePlacement
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbinePlacement(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbinePlacement", _turbinePlacement, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbinePowerRegulationEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbinePowerRegulation]() As TurbinePowerRegulationEntity
			Get
				Return _turbinePowerRegulation
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbinePowerRegulation(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbinePowerRegulation", _turbinePowerRegulation, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineRotorDiameterEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineRotorDiameter]() As TurbineRotorDiameterEntity
			Get
				Return _turbineRotorDiameter
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineRotorDiameter(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineRotorDiameter", _turbineRotorDiameter, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineSmallGeneratorEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineSmallGenerator]() As TurbineSmallGeneratorEntity
			Get
				Return _turbineSmallGenerator
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineSmallGenerator(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineSmallGenerator", _turbineSmallGenerator, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineTemperatureVariantEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineTemperatureVariant]() As TurbineTemperatureVariantEntity
			Get
				Return _turbineTemperatureVariant
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineTemperatureVariant(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineTemperatureVariant", _turbineTemperatureVariant, True) 
				End If
			End Set
		End Property

		''' <summary>Gets / sets related entity of type 'TurbineVoltageEntity' which has to be set Imports a fetch action earlier. If no related entity is set for this property, null is returned.
		''' This property is not visible in databound grids.<br/><br/>
		''' </summary>
		<Browsable(True)> _
		Public Overridable Property [TurbineVoltage]() As TurbineVoltageEntity
			Get
				Return _turbineVoltage
			End Get
			Set
				If MyBase.IsDeserializing Then
					SetupSyncTurbineVoltage(value)
				Else
					SetSingleRelatedEntityNavigator(value, "TurbineMatrix", "TurbineVoltage", _turbineVoltage, True) 
				End If
			End Set
		End Property

	

		''' <summary>Gets the type of the hierarchy this entity Is In. </summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsInHierarchyOfType() As  InheritanceHierarchyType
			Get 
				Return InheritanceHierarchyType.None
			End Get
		End Property

		''' <summary>Gets Or sets a value indicating whether this entity Is a subtype</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProIsSubType As Boolean
			Get 
				Return False
			End Get
		End Property

		''' <summary>Returns the PManagement.Data.EntityType Enum value For this entity.</summary>
		<Browsable(False), XmlIgnore> _
		Protected Overrides ReadOnly Property LLBLGenProEntityTypeValue As Integer
			Get 
				Return CInt(PManagement.Data.EntityType.TurbineMatrixEntity)
			End Get
		End Property
#End Region


#Region "Custom Entity Code"
		
		' __LLBLGENPRO_USER_CODE_REGION_START CustomEntityCode
		' __LLBLGENPRO_USER_CODE_REGION_END
#End Region

#Region "Included Code"

#End Region
	End Class
End Namespace
