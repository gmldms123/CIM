﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports System.Collections.Generic
Imports PManagement.Data.EntityClasses
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.RelationClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.FactoryClasses

	''' <summary>general base Class For the generated factories</summary>
	<Serializable()> _
	Public Class EntityFactoryBase2(Of TEntity As {EntityBase2, IEntity2})
			Inherits EntityFactoryCore2
		Private _typeOfEntity As PManagement.Data.EntityType
		Private _isInHierarchy As Boolean
		
		''' <summary>CTor</summary>
		''' <param name="entityName">Name of the entity.</param>
		''' <param name="typeOfEntity">The type of entity.</param>
		''' <param name="isInHierarchy">If True, the entity Of this factory Is In an inheritance hierarchy, False otherwise</param>
		Public Sub New(entityName As String, typeOfEntity As PManagement.Data.EntityType, isInHierarchy As Boolean)
			MyBase.New(entityName)
			_isInHierarchy = isInHierarchy
			_typeOfEntity = typeOfEntity
		End Sub
		
		''' <summary>Creates a New entity instance using the GeneralEntityFactory In the generated code, using the passed In entitytype value</summary>
		''' <param name="entityTypeValue">The entity type value of the entity To create an instance For.</param>
		''' <returns>New IEntity instance</returns>
		Public Overrides Overloads Function CreateEntityFromEntityTypeValue(entityTypeValue As Integer) As IEntity2
			Return GeneralEntityFactory.Create(CType(entityTypeValue, PManagement.Data.EntityType))
		End Function
		
		''' <summary>Creates, using the generated EntityFieldsFactory, the IEntityFields2 object for the entity to create.</summary>
		''' <returns>Empty IEntityFields2 object.</returns>
		Public Overrides Function CreateFields() As IEntityFields2
			Return EntityFieldsFactory.CreateEntityFieldsObject(_typeOfEntity)
		End Function
		
		''' <summary>Creates the relations collection To the entity To Join all targets so this entity can be fetched. </summary>
		''' <param name="objectAlias">The object alias to use for the elements in the relations.</param>
		''' <returns>null If the entity isn't in a hierarchy of type TargetPerEntity, otherwise the relations collection needed to
		''' Join all targets together To fetch all subtypes of this entity And this entity itself</returns>
		Public Overrides Function  CreateHierarchyRelations(objectAlias As String) As IRelationCollection
			Return InheritanceInfoProviderSingleton.GetInstance().GetHierarchyRelations(ForEntityName, objectAlias)
		End Function

		''' <summary>This method retrieves, using the InheritanceInfoprovider, the factory For the entity represented by the values passed In.</summary>
		''' <param name="fieldValues">Field values read from the db, To determine which factory To Return, based On the field values passed In.</param>
		''' <param name="entityFieldStartIndexesPerEntity">indexes into values where per entity type their own fields start.</param>
		''' <returns>the factory For the entity which Is represented by the values passed In.</returns>
		Public Overrides Function GetEntityFactory(fieldValues As Object(), entityFieldStartIndexesPerEntity As Dictionary(Of String, Integer)) As IEntityFactory2
			Dim toReturn As IEntityFactory2 =  CType(InheritanceInfoProviderSingleton.GetInstance().GetEntityFactory(ForEntityName, fieldValues, entityFieldStartIndexesPerEntity), IEntityFactory2)
			If toReturn Is Nothing Then
				toReturn = Me
			End If
			Return toReturn
		End Function
		
		''' <summary>Gets a predicateexpression which filters On the entity With type belonging To this factory.</summary>
		''' <param name="objectAlias">The object alias to use for the predicate(s).</param>
		''' <param name="negate">Flag To produce a Not filter, (True), Or a normal filter (False). </param>
		''' <returns>ready To use predicateexpression, Or an empty predicate expression If the belonging entity isn't a hierarchical type.</returns>
		Public Overrides Function GetEntityTypeFilter(negate As Boolean, objectAlias As String) As IPredicateExpression
			Return InheritanceInfoProviderSingleton.GetInstance().GetEntityTypeFilter(ForEntityName, objectAlias, negate)
		End Function
										
		''' <summary>Creates a New generic EntityCollection(Of T) For the entity which this factory belongs To.</summary>
		''' <returns>ready To use generic EntityCollection(Of T) With this factory Set As the factory</returns>
		Public Overrides Function CreateEntityCollection() As IEntityCollection2 
			Return New EntityCollection(Of TEntity)(Me)
		End Function
		
		''' <summary>Creates the hierarchy fields For the entity To which this factory belongs.</summary>
		''' <returns>IEntityFields2 Object With the fields Of all the entities In teh hierarchy Of this entity Or the fields Of this entity If the entity isn't in a hierarchy.</returns>
		Public Overrides Function CreateHierarchyFields() As IEntityFields2 
			If _isInHierarchy Then
				Return New EntityFields2(InheritanceInfoProviderSingleton.GetInstance().GetHierarchyFields(ForEntityName), InheritanceInfoProviderSingleton.GetInstance(), Nothing)
			Else
				Return MyBase.CreateHierarchyFields()
			End If
		End Function
	End Class
	
	''' <summary>Factory to create new, empty AlertCategoryEntity objects.</summary>
	<Serializable()> _
	Public Class AlertCategoryEntityFactory 
		Inherits EntityFactoryBase2(Of AlertCategoryEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertCategoryEntity", PManagement.Data.EntityType.AlertCategoryEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertCategoryEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertCategoryEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertCategoryUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertCategoryCriteriaEntity objects.</summary>
	<Serializable()> _
	Public Class AlertCategoryCriteriaEntityFactory 
		Inherits EntityFactoryBase2(Of AlertCategoryCriteriaEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertCategoryCriteriaEntity", PManagement.Data.EntityType.AlertCategoryCriteriaEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertCategoryCriteriaEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertCategoryCriteriaEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertCategoryCriteriaUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertChangeTypeCriteriaEntity objects.</summary>
	<Serializable()> _
	Public Class AlertChangeTypeCriteriaEntityFactory 
		Inherits EntityFactoryBase2(Of AlertChangeTypeCriteriaEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertChangeTypeCriteriaEntity", PManagement.Data.EntityType.AlertChangeTypeCriteriaEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertChangeTypeCriteriaEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertChangeTypeCriteriaUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertConfigEntity objects.</summary>
	<Serializable()> _
	Public Class AlertConfigEntityFactory 
		Inherits EntityFactoryBase2(Of AlertConfigEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertConfigEntity", PManagement.Data.EntityType.AlertConfigEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertConfigEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertConfigEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertConfigUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertConfigCircountEntity objects.</summary>
	<Serializable()> _
	Public Class AlertConfigCircountEntityFactory 
		Inherits EntityFactoryBase2(Of AlertConfigCircountEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertConfigCircountEntity", PManagement.Data.EntityType.AlertConfigCircountEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertConfigCircountEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertConfigCircountEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertConfigCircountUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertFrequencyEntity objects.</summary>
	<Serializable()> _
	Public Class AlertFrequencyEntityFactory 
		Inherits EntityFactoryBase2(Of AlertFrequencyEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertFrequencyEntity", PManagement.Data.EntityType.AlertFrequencyEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertFrequencyEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertFrequencyEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertFrequencyUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertReceiverEntity objects.</summary>
	<Serializable()> _
	Public Class AlertReceiverEntityFactory 
		Inherits EntityFactoryBase2(Of AlertReceiverEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertReceiverEntity", PManagement.Data.EntityType.AlertReceiverEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertReceiverEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertReceiverEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertReceiverUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertReceiverRoleTypeEntity objects.</summary>
	<Serializable()> _
	Public Class AlertReceiverRoleTypeEntityFactory 
		Inherits EntityFactoryBase2(Of AlertReceiverRoleTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertReceiverRoleTypeEntity", PManagement.Data.EntityType.AlertReceiverRoleTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertReceiverRoleTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertReceiverRoleTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertReceiverRoleTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertReceiverTypeEntity objects.</summary>
	<Serializable()> _
	Public Class AlertReceiverTypeEntityFactory 
		Inherits EntityFactoryBase2(Of AlertReceiverTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertReceiverTypeEntity", PManagement.Data.EntityType.AlertReceiverTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertReceiverTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertReceiverTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertReceiverTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AlertServiceSettingsEntity objects.</summary>
	<Serializable()> _
	Public Class AlertServiceSettingsEntityFactory 
		Inherits EntityFactoryBase2(Of AlertServiceSettingsEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AlertServiceSettingsEntity", PManagement.Data.EntityType.AlertServiceSettingsEntity, False)
		End Sub
	
		''' <summary>Creates a new AlertServiceSettingsEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AlertServiceSettingsEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAlertServiceSettingsUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty AnyChangesEntity objects.</summary>
	<Serializable()> _
	Public Class AnyChangesEntityFactory 
		Inherits EntityFactoryBase2(Of AnyChangesEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("AnyChangesEntity", PManagement.Data.EntityType.AnyChangesEntity, False)
		End Sub
	
		''' <summary>Creates a new AnyChangesEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New AnyChangesEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewAnyChangesUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty BrandEntity objects.</summary>
	<Serializable()> _
	Public Class BrandEntityFactory 
		Inherits EntityFactoryBase2(Of BrandEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("BrandEntity", PManagement.Data.EntityType.BrandEntity, False)
		End Sub
	
		''' <summary>Creates a new BrandEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New BrandEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewBrandUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Brand2DocumentTemplateEntity objects.</summary>
	<Serializable()> _
	Public Class Brand2DocumentTemplateEntityFactory 
		Inherits EntityFactoryBase2(Of Brand2DocumentTemplateEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Brand2DocumentTemplateEntity", PManagement.Data.EntityType.Brand2DocumentTemplateEntity, False)
		End Sub
	
		''' <summary>Creates a new Brand2DocumentTemplateEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Brand2DocumentTemplateEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewBrand2DocumentTemplateUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Brand2FeatureEntity objects.</summary>
	<Serializable()> _
	Public Class Brand2FeatureEntityFactory 
		Inherits EntityFactoryBase2(Of Brand2FeatureEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Brand2FeatureEntity", PManagement.Data.EntityType.Brand2FeatureEntity, False)
		End Sub
	
		''' <summary>Creates a new Brand2FeatureEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Brand2FeatureEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewBrand2FeatureUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Brand2StandardMilestoneEntity objects.</summary>
	<Serializable()> _
	Public Class Brand2StandardMilestoneEntityFactory 
		Inherits EntityFactoryBase2(Of Brand2StandardMilestoneEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Brand2StandardMilestoneEntity", PManagement.Data.EntityType.Brand2StandardMilestoneEntity, False)
		End Sub
	
		''' <summary>Creates a new Brand2StandardMilestoneEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Brand2StandardMilestoneEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewBrand2StandardMilestoneUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty BusinessProcessEntity objects.</summary>
	<Serializable()> _
	Public Class BusinessProcessEntityFactory 
		Inherits EntityFactoryBase2(Of BusinessProcessEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("BusinessProcessEntity", PManagement.Data.EntityType.BusinessProcessEntity, False)
		End Sub
	
		''' <summary>Creates a new BusinessProcessEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New BusinessProcessEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewBusinessProcessUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty CaseEntity objects.</summary>
	<Serializable()> _
	Public Class CaseEntityFactory 
		Inherits EntityFactoryBase2(Of CaseEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CaseEntity", PManagement.Data.EntityType.CaseEntity, False)
		End Sub
	
		''' <summary>Creates a new CaseEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New CaseEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCaseUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2CaseBundleEntity objects.</summary>
	<Serializable()> _
	Public Class Case2CaseBundleEntityFactory 
		Inherits EntityFactoryBase2(Of Case2CaseBundleEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2CaseBundleEntity", PManagement.Data.EntityType.Case2CaseBundleEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2CaseBundleEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2CaseBundleEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2CaseBundleUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2ComponentTypeEntity objects.</summary>
	<Serializable()> _
	Public Class Case2ComponentTypeEntityFactory 
		Inherits EntityFactoryBase2(Of Case2ComponentTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2ComponentTypeEntity", PManagement.Data.EntityType.Case2ComponentTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2ComponentTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2ComponentTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2ComponentTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2ItemEntity objects.</summary>
	<Serializable()> _
	Public Class Case2ItemEntityFactory 
		Inherits EntityFactoryBase2(Of Case2ItemEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2ItemEntity", PManagement.Data.EntityType.Case2ItemEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2ItemEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2ItemEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2ItemUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2KPIRatingEntity objects.</summary>
	<Serializable()> _
	Public Class Case2KPIRatingEntityFactory 
		Inherits EntityFactoryBase2(Of Case2KPIRatingEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2KPIRatingEntity", PManagement.Data.EntityType.Case2KPIRatingEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2KPIRatingEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2KPIRatingEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2KPIRatingUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2LogInfoEntity objects.</summary>
	<Serializable()> _
	Public Class Case2LogInfoEntityFactory 
		Inherits EntityFactoryBase2(Of Case2LogInfoEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2LogInfoEntity", PManagement.Data.EntityType.Case2LogInfoEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2LogInfoEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2LogInfoEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2LogInfoUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2ParticipantEntity objects.</summary>
	<Serializable()> _
	Public Class Case2ParticipantEntityFactory 
		Inherits EntityFactoryBase2(Of Case2ParticipantEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2ParticipantEntity", PManagement.Data.EntityType.Case2ParticipantEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2ParticipantEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2ParticipantEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2ParticipantUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2PhaseEntity objects.</summary>
	<Serializable()> _
	Public Class Case2PhaseEntityFactory 
		Inherits EntityFactoryBase2(Of Case2PhaseEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2PhaseEntity", PManagement.Data.EntityType.Case2PhaseEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2PhaseEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2PhaseEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2PhaseUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2ReasonCodeEntity objects.</summary>
	<Serializable()> _
	Public Class Case2ReasonCodeEntityFactory 
		Inherits EntityFactoryBase2(Of Case2ReasonCodeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2ReasonCodeEntity", PManagement.Data.EntityType.Case2ReasonCodeEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2ReasonCodeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2ReasonCodeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2ReasonCodeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2SbuEntity objects.</summary>
	<Serializable()> _
	Public Class Case2SbuEntityFactory 
		Inherits EntityFactoryBase2(Of Case2SbuEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2SbuEntity", PManagement.Data.EntityType.Case2SbuEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2SbuEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2SbuEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2SbuUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2ServiceCodeEntity objects.</summary>
	<Serializable()> _
	Public Class Case2ServiceCodeEntityFactory 
		Inherits EntityFactoryBase2(Of Case2ServiceCodeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2ServiceCodeEntity", PManagement.Data.EntityType.Case2ServiceCodeEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2ServiceCodeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2ServiceCodeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2ServiceCodeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2SupplierEntity objects.</summary>
	<Serializable()> _
	Public Class Case2SupplierEntityFactory 
		Inherits EntityFactoryBase2(Of Case2SupplierEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2SupplierEntity", PManagement.Data.EntityType.Case2SupplierEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2SupplierEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2SupplierEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2SupplierUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2Supplier2StageEntity objects.</summary>
	<Serializable()> _
	Public Class Case2Supplier2StageEntityFactory 
		Inherits EntityFactoryBase2(Of Case2Supplier2StageEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2Supplier2StageEntity", PManagement.Data.EntityType.Case2Supplier2StageEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2Supplier2StageEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2Supplier2StageEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2Supplier2StageUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2SystemEntity objects.</summary>
	<Serializable()> _
	Public Class Case2SystemEntityFactory 
		Inherits EntityFactoryBase2(Of Case2SystemEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2SystemEntity", PManagement.Data.EntityType.Case2SystemEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2SystemEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2SystemEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2SystemUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2TurbineMatrixEntity objects.</summary>
	<Serializable()> _
	Public Class Case2TurbineMatrixEntityFactory 
		Inherits EntityFactoryBase2(Of Case2TurbineMatrixEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2TurbineMatrixEntity", PManagement.Data.EntityType.Case2TurbineMatrixEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2TurbineMatrixEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2TurbineMatrixEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2TurbineMatrixUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Case2TurbineMatrix2Case2ItemEntity objects.</summary>
	<Serializable()> _
	Public Class Case2TurbineMatrix2Case2ItemEntityFactory 
		Inherits EntityFactoryBase2(Of Case2TurbineMatrix2Case2ItemEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Case2TurbineMatrix2Case2ItemEntity", PManagement.Data.EntityType.Case2TurbineMatrix2Case2ItemEntity, False)
		End Sub
	
		''' <summary>Creates a new Case2TurbineMatrix2Case2ItemEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Case2TurbineMatrix2Case2ItemEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCase2TurbineMatrix2Case2ItemUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty CaseBundleEntity objects.</summary>
	<Serializable()> _
	Public Class CaseBundleEntityFactory 
		Inherits EntityFactoryBase2(Of CaseBundleEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CaseBundleEntity", PManagement.Data.EntityType.CaseBundleEntity, False)
		End Sub
	
		''' <summary>Creates a new CaseBundleEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New CaseBundleEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCaseBundleUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty CaseRelationEntity objects.</summary>
	<Serializable()> _
	Public Class CaseRelationEntityFactory 
		Inherits EntityFactoryBase2(Of CaseRelationEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CaseRelationEntity", PManagement.Data.EntityType.CaseRelationEntity, False)
		End Sub
	
		''' <summary>Creates a new CaseRelationEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New CaseRelationEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCaseRelationUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty CategoryEntity objects.</summary>
	<Serializable()> _
	Public Class CategoryEntityFactory 
		Inherits EntityFactoryBase2(Of CategoryEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CategoryEntity", PManagement.Data.EntityType.CategoryEntity, False)
		End Sub
	
		''' <summary>Creates a new CategoryEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New CategoryEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCategoryUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ChangeLogEntity objects.</summary>
	<Serializable()> _
	Public Class ChangeLogEntityFactory 
		Inherits EntityFactoryBase2(Of ChangeLogEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ChangeLogEntity", PManagement.Data.EntityType.ChangeLogEntity, False)
		End Sub
	
		''' <summary>Creates a new ChangeLogEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ChangeLogEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewChangeLogUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ChangeTypeEntity objects.</summary>
	<Serializable()> _
	Public Class ChangeTypeEntityFactory 
		Inherits EntityFactoryBase2(Of ChangeTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ChangeTypeEntity", PManagement.Data.EntityType.ChangeTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new ChangeTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ChangeTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewChangeTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty CirEntity objects.</summary>
	<Serializable()> _
	Public Class CirEntityFactory 
		Inherits EntityFactoryBase2(Of CirEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CirEntity", PManagement.Data.EntityType.CirEntity, False)
		End Sub
	
		''' <summary>Creates a new CirEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New CirEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCirUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ClaimStatusEntity objects.</summary>
	<Serializable()> _
	Public Class ClaimStatusEntityFactory 
		Inherits EntityFactoryBase2(Of ClaimStatusEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ClaimStatusEntity", PManagement.Data.EntityType.ClaimStatusEntity, False)
		End Sub
	
		''' <summary>Creates a new ClaimStatusEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ClaimStatusEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewClaimStatusUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ComponentEntity objects.</summary>
	<Serializable()> _
	Public Class ComponentEntityFactory 
		Inherits EntityFactoryBase2(Of ComponentEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ComponentEntity", PManagement.Data.EntityType.ComponentEntity, False)
		End Sub
	
		''' <summary>Creates a new ComponentEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ComponentEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewComponentUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ComponentTypeEntity objects.</summary>
	<Serializable()> _
	Public Class ComponentTypeEntityFactory 
		Inherits EntityFactoryBase2(Of ComponentTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ComponentTypeEntity", PManagement.Data.EntityType.ComponentTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new ComponentTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ComponentTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewComponentTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ControlEntity objects.</summary>
	<Serializable()> _
	Public Class ControlEntityFactory 
		Inherits EntityFactoryBase2(Of ControlEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ControlEntity", PManagement.Data.EntityType.ControlEntity, False)
		End Sub
	
		''' <summary>Creates a new ControlEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ControlEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewControlUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty CustomColumnsNameEntity objects.</summary>
	<Serializable()> _
	Public Class CustomColumnsNameEntityFactory 
		Inherits EntityFactoryBase2(Of CustomColumnsNameEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CustomColumnsNameEntity", PManagement.Data.EntityType.CustomColumnsNameEntity, False)
		End Sub
	
		''' <summary>Creates a new CustomColumnsNameEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New CustomColumnsNameEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCustomColumnsNameUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty CustomColumnsValueEntity objects.</summary>
	<Serializable()> _
	Public Class CustomColumnsValueEntityFactory 
		Inherits EntityFactoryBase2(Of CustomColumnsValueEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("CustomColumnsValueEntity", PManagement.Data.EntityType.CustomColumnsValueEntity, False)
		End Sub
	
		''' <summary>Creates a new CustomColumnsValueEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New CustomColumnsValueEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewCustomColumnsValueUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty DiscussionEntity objects.</summary>
	<Serializable()> _
	Public Class DiscussionEntityFactory 
		Inherits EntityFactoryBase2(Of DiscussionEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DiscussionEntity", PManagement.Data.EntityType.DiscussionEntity, False)
		End Sub
	
		''' <summary>Creates a new DiscussionEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New DiscussionEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewDiscussionUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty DocumentEntity objects.</summary>
	<Serializable()> _
	Public Class DocumentEntityFactory 
		Inherits EntityFactoryBase2(Of DocumentEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentEntity", PManagement.Data.EntityType.DocumentEntity, False)
		End Sub
	
		''' <summary>Creates a new DocumentEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New DocumentEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewDocumentUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty DocumentBinaryEntity objects.</summary>
	<Serializable()> _
	Public Class DocumentBinaryEntityFactory 
		Inherits EntityFactoryBase2(Of DocumentBinaryEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentBinaryEntity", PManagement.Data.EntityType.DocumentBinaryEntity, False)
		End Sub
	
		''' <summary>Creates a new DocumentBinaryEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New DocumentBinaryEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewDocumentBinaryUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty DocumentClassificationEntity objects.</summary>
	<Serializable()> _
	Public Class DocumentClassificationEntityFactory 
		Inherits EntityFactoryBase2(Of DocumentClassificationEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentClassificationEntity", PManagement.Data.EntityType.DocumentClassificationEntity, False)
		End Sub
	
		''' <summary>Creates a new DocumentClassificationEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New DocumentClassificationEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewDocumentClassificationUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty DocumentStatusEntity objects.</summary>
	<Serializable()> _
	Public Class DocumentStatusEntityFactory 
		Inherits EntityFactoryBase2(Of DocumentStatusEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentStatusEntity", PManagement.Data.EntityType.DocumentStatusEntity, False)
		End Sub
	
		''' <summary>Creates a new DocumentStatusEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New DocumentStatusEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewDocumentStatusUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty DocumentTemplateEntity objects.</summary>
	<Serializable()> _
	Public Class DocumentTemplateEntityFactory 
		Inherits EntityFactoryBase2(Of DocumentTemplateEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentTemplateEntity", PManagement.Data.EntityType.DocumentTemplateEntity, False)
		End Sub
	
		''' <summary>Creates a new DocumentTemplateEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New DocumentTemplateEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewDocumentTemplateUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty DocumentVersionEntity objects.</summary>
	<Serializable()> _
	Public Class DocumentVersionEntityFactory 
		Inherits EntityFactoryBase2(Of DocumentVersionEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("DocumentVersionEntity", PManagement.Data.EntityType.DocumentVersionEntity, False)
		End Sub
	
		''' <summary>Creates a new DocumentVersionEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New DocumentVersionEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewDocumentVersionUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ErpsystemEntity objects.</summary>
	<Serializable()> _
	Public Class ErpsystemEntityFactory 
		Inherits EntityFactoryBase2(Of ErpsystemEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ErpsystemEntity", PManagement.Data.EntityType.ErpsystemEntity, False)
		End Sub
	
		''' <summary>Creates a new ErpsystemEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ErpsystemEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewErpsystemUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty FeatureEntity objects.</summary>
	<Serializable()> _
	Public Class FeatureEntityFactory 
		Inherits EntityFactoryBase2(Of FeatureEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("FeatureEntity", PManagement.Data.EntityType.FeatureEntity, False)
		End Sub
	
		''' <summary>Creates a new FeatureEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New FeatureEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewFeatureUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty FolderEntity objects.</summary>
	<Serializable()> _
	Public Class FolderEntityFactory 
		Inherits EntityFactoryBase2(Of FolderEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("FolderEntity", PManagement.Data.EntityType.FolderEntity, False)
		End Sub
	
		''' <summary>Creates a new FolderEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New FolderEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewFolderUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Folder2DocumentEntity objects.</summary>
	<Serializable()> _
	Public Class Folder2DocumentEntityFactory 
		Inherits EntityFactoryBase2(Of Folder2DocumentEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Folder2DocumentEntity", PManagement.Data.EntityType.Folder2DocumentEntity, False)
		End Sub
	
		''' <summary>Creates a new Folder2DocumentEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Folder2DocumentEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewFolder2DocumentUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty FolderTypeEntity objects.</summary>
	<Serializable()> _
	Public Class FolderTypeEntityFactory 
		Inherits EntityFactoryBase2(Of FolderTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("FolderTypeEntity", PManagement.Data.EntityType.FolderTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new FolderTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New FolderTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewFolderTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty HelpEntity objects.</summary>
	<Serializable()> _
	Public Class HelpEntityFactory 
		Inherits EntityFactoryBase2(Of HelpEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("HelpEntity", PManagement.Data.EntityType.HelpEntity, False)
		End Sub
	
		''' <summary>Creates a new HelpEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New HelpEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewHelpUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty InlineHelpEntity objects.</summary>
	<Serializable()> _
	Public Class InlineHelpEntityFactory 
		Inherits EntityFactoryBase2(Of InlineHelpEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("InlineHelpEntity", PManagement.Data.EntityType.InlineHelpEntity, False)
		End Sub
	
		''' <summary>Creates a new InlineHelpEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New InlineHelpEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewInlineHelpUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty InlineHelpTextEntity objects.</summary>
	<Serializable()> _
	Public Class InlineHelpTextEntityFactory 
		Inherits EntityFactoryBase2(Of InlineHelpTextEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("InlineHelpTextEntity", PManagement.Data.EntityType.InlineHelpTextEntity, False)
		End Sub
	
		''' <summary>Creates a new InlineHelpTextEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New InlineHelpTextEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewInlineHelpTextUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ItemEntity objects.</summary>
	<Serializable()> _
	Public Class ItemEntityFactory 
		Inherits EntityFactoryBase2(Of ItemEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ItemEntity", PManagement.Data.EntityType.ItemEntity, False)
		End Sub
	
		''' <summary>Creates a new ItemEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ItemEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewItemUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ItemStatusEntity objects.</summary>
	<Serializable()> _
	Public Class ItemStatusEntityFactory 
		Inherits EntityFactoryBase2(Of ItemStatusEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ItemStatusEntity", PManagement.Data.EntityType.ItemStatusEntity, False)
		End Sub
	
		''' <summary>Creates a new ItemStatusEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ItemStatusEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewItemStatusUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ItemSystemMappingEntity objects.</summary>
	<Serializable()> _
	Public Class ItemSystemMappingEntityFactory 
		Inherits EntityFactoryBase2(Of ItemSystemMappingEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ItemSystemMappingEntity", PManagement.Data.EntityType.ItemSystemMappingEntity, False)
		End Sub
	
		''' <summary>Creates a new ItemSystemMappingEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ItemSystemMappingEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewItemSystemMappingUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ItemSystemMappingStagingTableEntity objects.</summary>
	<Serializable()> _
	Public Class ItemSystemMappingStagingTableEntityFactory 
		Inherits EntityFactoryBase2(Of ItemSystemMappingStagingTableEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ItemSystemMappingStagingTableEntity", PManagement.Data.EntityType.ItemSystemMappingStagingTableEntity, False)
		End Sub
	
		''' <summary>Creates a new ItemSystemMappingStagingTableEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ItemSystemMappingStagingTableEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewItemSystemMappingStagingTableUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty LanguageEntity objects.</summary>
	<Serializable()> _
	Public Class LanguageEntityFactory 
		Inherits EntityFactoryBase2(Of LanguageEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("LanguageEntity", PManagement.Data.EntityType.LanguageEntity, False)
		End Sub
	
		''' <summary>Creates a new LanguageEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New LanguageEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewLanguageUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty LogInfoEntity objects.</summary>
	<Serializable()> _
	Public Class LogInfoEntityFactory 
		Inherits EntityFactoryBase2(Of LogInfoEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("LogInfoEntity", PManagement.Data.EntityType.LogInfoEntity, False)
		End Sub
	
		''' <summary>Creates a new LogInfoEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New LogInfoEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewLogInfoUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty LogInfo2LogTxtEntity objects.</summary>
	<Serializable()> _
	Public Class LogInfo2LogTxtEntityFactory 
		Inherits EntityFactoryBase2(Of LogInfo2LogTxtEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("LogInfo2LogTxtEntity", PManagement.Data.EntityType.LogInfo2LogTxtEntity, False)
		End Sub
	
		''' <summary>Creates a new LogInfo2LogTxtEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New LogInfo2LogTxtEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewLogInfo2LogTxtUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty LogTxtEntity objects.</summary>
	<Serializable()> _
	Public Class LogTxtEntityFactory 
		Inherits EntityFactoryBase2(Of LogTxtEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("LogTxtEntity", PManagement.Data.EntityType.LogTxtEntity, False)
		End Sub
	
		''' <summary>Creates a new LogTxtEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New LogTxtEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewLogTxtUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty MilestoneEntity objects.</summary>
	<Serializable()> _
	Public Class MilestoneEntityFactory 
		Inherits EntityFactoryBase2(Of MilestoneEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("MilestoneEntity", PManagement.Data.EntityType.MilestoneEntity, False)
		End Sub
	
		''' <summary>Creates a new MilestoneEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New MilestoneEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewMilestoneUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ModuleEntity objects.</summary>
	<Serializable()> _
	Public Class ModuleEntityFactory 
		Inherits EntityFactoryBase2(Of ModuleEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ModuleEntity", PManagement.Data.EntityType.ModuleEntity, False)
		End Sub
	
		''' <summary>Creates a new ModuleEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ModuleEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewModuleUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty NewsEntity objects.</summary>
	<Serializable()> _
	Public Class NewsEntityFactory 
		Inherits EntityFactoryBase2(Of NewsEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("NewsEntity", PManagement.Data.EntityType.NewsEntity, False)
		End Sub
	
		''' <summary>Creates a new NewsEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New NewsEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewNewsUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty News2ParticipantEntity objects.</summary>
	<Serializable()> _
	Public Class News2ParticipantEntityFactory 
		Inherits EntityFactoryBase2(Of News2ParticipantEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("News2ParticipantEntity", PManagement.Data.EntityType.News2ParticipantEntity, False)
		End Sub
	
		''' <summary>Creates a new News2ParticipantEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New News2ParticipantEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewNews2ParticipantUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty OldCimturbineEntity objects.</summary>
	<Serializable()> _
	Public Class OldCimturbineEntityFactory 
		Inherits EntityFactoryBase2(Of OldCimturbineEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("OldCimturbineEntity", PManagement.Data.EntityType.OldCimturbineEntity, False)
		End Sub
	
		''' <summary>Creates a new OldCimturbineEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New OldCimturbineEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewOldCimturbineUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ParticipantEntity objects.</summary>
	<Serializable()> _
	Public Class ParticipantEntityFactory 
		Inherits EntityFactoryBase2(Of ParticipantEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ParticipantEntity", PManagement.Data.EntityType.ParticipantEntity, False)
		End Sub
	
		''' <summary>Creates a new ParticipantEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ParticipantEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewParticipantUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Participant2RoleEntity objects.</summary>
	<Serializable()> _
	Public Class Participant2RoleEntityFactory 
		Inherits EntityFactoryBase2(Of Participant2RoleEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Participant2RoleEntity", PManagement.Data.EntityType.Participant2RoleEntity, False)
		End Sub
	
		''' <summary>Creates a new Participant2RoleEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Participant2RoleEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewParticipant2RoleUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ParticipantLogEntity objects.</summary>
	<Serializable()> _
	Public Class ParticipantLogEntityFactory 
		Inherits EntityFactoryBase2(Of ParticipantLogEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ParticipantLogEntity", PManagement.Data.EntityType.ParticipantLogEntity, False)
		End Sub
	
		''' <summary>Creates a new ParticipantLogEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ParticipantLogEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewParticipantLogUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ParticipationTypeEntity objects.</summary>
	<Serializable()> _
	Public Class ParticipationTypeEntityFactory 
		Inherits EntityFactoryBase2(Of ParticipationTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ParticipationTypeEntity", PManagement.Data.EntityType.ParticipationTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new ParticipationTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ParticipationTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewParticipationTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PayeeEntity objects.</summary>
	<Serializable()> _
	Public Class PayeeEntityFactory 
		Inherits EntityFactoryBase2(Of PayeeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PayeeEntity", PManagement.Data.EntityType.PayeeEntity, False)
		End Sub
	
		''' <summary>Creates a new PayeeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PayeeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPayeeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PbuEntity objects.</summary>
	<Serializable()> _
	Public Class PbuEntityFactory 
		Inherits EntityFactoryBase2(Of PbuEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PbuEntity", PManagement.Data.EntityType.PbuEntity, False)
		End Sub
	
		''' <summary>Creates a new PbuEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PbuEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPbuUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PerformanceActionEntity objects.</summary>
	<Serializable()> _
	Public Class PerformanceActionEntityFactory 
		Inherits EntityFactoryBase2(Of PerformanceActionEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PerformanceActionEntity", PManagement.Data.EntityType.PerformanceActionEntity, False)
		End Sub
	
		''' <summary>Creates a new PerformanceActionEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PerformanceActionEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPerformanceActionUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PerformanceDataEntity objects.</summary>
	<Serializable()> _
	Public Class PerformanceDataEntityFactory 
		Inherits EntityFactoryBase2(Of PerformanceDataEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PerformanceDataEntity", PManagement.Data.EntityType.PerformanceDataEntity, False)
		End Sub
	
		''' <summary>Creates a new PerformanceDataEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PerformanceDataEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPerformanceDataUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PerformanceUtilitySettingEntity objects.</summary>
	<Serializable()> _
	Public Class PerformanceUtilitySettingEntityFactory 
		Inherits EntityFactoryBase2(Of PerformanceUtilitySettingEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PerformanceUtilitySettingEntity", PManagement.Data.EntityType.PerformanceUtilitySettingEntity, False)
		End Sub
	
		''' <summary>Creates a new PerformanceUtilitySettingEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PerformanceUtilitySettingEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPerformanceUtilitySettingUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PermissionEntity objects.</summary>
	<Serializable()> _
	Public Class PermissionEntityFactory 
		Inherits EntityFactoryBase2(Of PermissionEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PermissionEntity", PManagement.Data.EntityType.PermissionEntity, False)
		End Sub
	
		''' <summary>Creates a new PermissionEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PermissionEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPermissionUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PersonalSafetyEntity objects.</summary>
	<Serializable()> _
	Public Class PersonalSafetyEntityFactory 
		Inherits EntityFactoryBase2(Of PersonalSafetyEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PersonalSafetyEntity", PManagement.Data.EntityType.PersonalSafetyEntity, False)
		End Sub
	
		''' <summary>Creates a new PersonalSafetyEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PersonalSafetyEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPersonalSafetyUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PhaseEntity objects.</summary>
	<Serializable()> _
	Public Class PhaseEntityFactory 
		Inherits EntityFactoryBase2(Of PhaseEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PhaseEntity", PManagement.Data.EntityType.PhaseEntity, False)
		End Sub
	
		''' <summary>Creates a new PhaseEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PhaseEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPhaseUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Phase2StatusEntity objects.</summary>
	<Serializable()> _
	Public Class Phase2StatusEntityFactory 
		Inherits EntityFactoryBase2(Of Phase2StatusEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Phase2StatusEntity", PManagement.Data.EntityType.Phase2StatusEntity, False)
		End Sub
	
		''' <summary>Creates a new Phase2StatusEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Phase2StatusEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPhase2StatusUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PlatformEntity objects.</summary>
	<Serializable()> _
	Public Class PlatformEntityFactory 
		Inherits EntityFactoryBase2(Of PlatformEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PlatformEntity", PManagement.Data.EntityType.PlatformEntity, False)
		End Sub
	
		''' <summary>Creates a new PlatformEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PlatformEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPlatformUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PopulationlistEntity objects.</summary>
	<Serializable()> _
	Public Class PopulationlistEntityFactory 
		Inherits EntityFactoryBase2(Of PopulationlistEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PopulationlistEntity", PManagement.Data.EntityType.PopulationlistEntity, False)
		End Sub
	
		''' <summary>Creates a new PopulationlistEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PopulationlistEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPopulationlistUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PopulationlistDocumentEntity objects.</summary>
	<Serializable()> _
	Public Class PopulationlistDocumentEntityFactory 
		Inherits EntityFactoryBase2(Of PopulationlistDocumentEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PopulationlistDocumentEntity", PManagement.Data.EntityType.PopulationlistDocumentEntity, False)
		End Sub
	
		''' <summary>Creates a new PopulationlistDocumentEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PopulationlistDocumentEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPopulationlistDocumentUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PopulationlistItemEntity objects.</summary>
	<Serializable()> _
	Public Class PopulationlistItemEntityFactory 
		Inherits EntityFactoryBase2(Of PopulationlistItemEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PopulationlistItemEntity", PManagement.Data.EntityType.PopulationlistItemEntity, False)
		End Sub
	
		''' <summary>Creates a new PopulationlistItemEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PopulationlistItemEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPopulationlistItemUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty PortfolioEntity objects.</summary>
	<Serializable()> _
	Public Class PortfolioEntityFactory 
		Inherits EntityFactoryBase2(Of PortfolioEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("PortfolioEntity", PManagement.Data.EntityType.PortfolioEntity, False)
		End Sub
	
		''' <summary>Creates a new PortfolioEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New PortfolioEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewPortfolioUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ProjectEntity objects.</summary>
	<Serializable()> _
	Public Class ProjectEntityFactory 
		Inherits EntityFactoryBase2(Of ProjectEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ProjectEntity", PManagement.Data.EntityType.ProjectEntity, False)
		End Sub
	
		''' <summary>Creates a new ProjectEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ProjectEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewProjectUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ProjectScopeEntity objects.</summary>
	<Serializable()> _
	Public Class ProjectScopeEntityFactory 
		Inherits EntityFactoryBase2(Of ProjectScopeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ProjectScopeEntity", PManagement.Data.EntityType.ProjectScopeEntity, False)
		End Sub
	
		''' <summary>Creates a new ProjectScopeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ProjectScopeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewProjectScopeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RcEntity objects.</summary>
	<Serializable()> _
	Public Class RcEntityFactory 
		Inherits EntityFactoryBase2(Of RcEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RcEntity", PManagement.Data.EntityType.RcEntity, False)
		End Sub
	
		''' <summary>Creates a new RcEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RcEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRcUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RccomponentOwnerEntity objects.</summary>
	<Serializable()> _
	Public Class RccomponentOwnerEntityFactory 
		Inherits EntityFactoryBase2(Of RccomponentOwnerEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RccomponentOwnerEntity", PManagement.Data.EntityType.RccomponentOwnerEntity, False)
		End Sub
	
		''' <summary>Creates a new RccomponentOwnerEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RccomponentOwnerEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRccomponentOwnerUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RcoriginEntity objects.</summary>
	<Serializable()> _
	Public Class RcoriginEntityFactory 
		Inherits EntityFactoryBase2(Of RcoriginEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RcoriginEntity", PManagement.Data.EntityType.RcoriginEntity, False)
		End Sub
	
		''' <summary>Creates a new RcoriginEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RcoriginEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRcoriginUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RcoriginRelationEntity objects.</summary>
	<Serializable()> _
	Public Class RcoriginRelationEntityFactory 
		Inherits EntityFactoryBase2(Of RcoriginRelationEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RcoriginRelationEntity", PManagement.Data.EntityType.RcoriginRelationEntity, False)
		End Sub
	
		''' <summary>Creates a new RcoriginRelationEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RcoriginRelationEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRcoriginRelationUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RcoriginResponsibleEntity objects.</summary>
	<Serializable()> _
	Public Class RcoriginResponsibleEntityFactory 
		Inherits EntityFactoryBase2(Of RcoriginResponsibleEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RcoriginResponsibleEntity", PManagement.Data.EntityType.RcoriginResponsibleEntity, False)
		End Sub
	
		''' <summary>Creates a new RcoriginResponsibleEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RcoriginResponsibleEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRcoriginResponsibleUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RcoriginUnitEntity objects.</summary>
	<Serializable()> _
	Public Class RcoriginUnitEntityFactory 
		Inherits EntityFactoryBase2(Of RcoriginUnitEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RcoriginUnitEntity", PManagement.Data.EntityType.RcoriginUnitEntity, False)
		End Sub
	
		''' <summary>Creates a new RcoriginUnitEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RcoriginUnitEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRcoriginUnitUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ReasonCodeEntity objects.</summary>
	<Serializable()> _
	Public Class ReasonCodeEntityFactory 
		Inherits EntityFactoryBase2(Of ReasonCodeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ReasonCodeEntity", PManagement.Data.EntityType.ReasonCodeEntity, False)
		End Sub
	
		''' <summary>Creates a new ReasonCodeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ReasonCodeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewReasonCodeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RelatedCaseEntity objects.</summary>
	<Serializable()> _
	Public Class RelatedCaseEntityFactory 
		Inherits EntityFactoryBase2(Of RelatedCaseEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RelatedCaseEntity", PManagement.Data.EntityType.RelatedCaseEntity, False)
		End Sub
	
		''' <summary>Creates a new RelatedCaseEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RelatedCaseEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRelatedCaseUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RelatedCase2CaseRelationEntity objects.</summary>
	<Serializable()> _
	Public Class RelatedCase2CaseRelationEntityFactory 
		Inherits EntityFactoryBase2(Of RelatedCase2CaseRelationEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RelatedCase2CaseRelationEntity", PManagement.Data.EntityType.RelatedCase2CaseRelationEntity, False)
		End Sub
	
		''' <summary>Creates a new RelatedCase2CaseRelationEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RelatedCase2CaseRelationEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRelatedCase2CaseRelationUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RelatedItemEntity objects.</summary>
	<Serializable()> _
	Public Class RelatedItemEntityFactory 
		Inherits EntityFactoryBase2(Of RelatedItemEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RelatedItemEntity", PManagement.Data.EntityType.RelatedItemEntity, False)
		End Sub
	
		''' <summary>Creates a new RelatedItemEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RelatedItemEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRelatedItemUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ReportTypeEntity objects.</summary>
	<Serializable()> _
	Public Class ReportTypeEntityFactory 
		Inherits EntityFactoryBase2(Of ReportTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ReportTypeEntity", PManagement.Data.EntityType.ReportTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new ReportTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ReportTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewReportTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty RoleEntity objects.</summary>
	<Serializable()> _
	Public Class RoleEntityFactory 
		Inherits EntityFactoryBase2(Of RoleEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("RoleEntity", PManagement.Data.EntityType.RoleEntity, False)
		End Sub
	
		''' <summary>Creates a new RoleEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New RoleEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRoleUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty Role2PermissionEntity objects.</summary>
	<Serializable()> _
	Public Class Role2PermissionEntityFactory 
		Inherits EntityFactoryBase2(Of Role2PermissionEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("Role2PermissionEntity", PManagement.Data.EntityType.Role2PermissionEntity, False)
		End Sub
	
		''' <summary>Creates a new Role2PermissionEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New Role2PermissionEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewRole2PermissionUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty SbuEntity objects.</summary>
	<Serializable()> _
	Public Class SbuEntityFactory 
		Inherits EntityFactoryBase2(Of SbuEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("SbuEntity", PManagement.Data.EntityType.SbuEntity, False)
		End Sub
	
		''' <summary>Creates a new SbuEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New SbuEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewSbuUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty SbucloneEntity objects.</summary>
	<Serializable()> _
	Public Class SbucloneEntityFactory 
		Inherits EntityFactoryBase2(Of SbucloneEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("SbucloneEntity", PManagement.Data.EntityType.SbucloneEntity, False)
		End Sub
	
		''' <summary>Creates a new SbucloneEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New SbucloneEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewSbucloneUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty SearchProfileEntity objects.</summary>
	<Serializable()> _
	Public Class SearchProfileEntityFactory 
		Inherits EntityFactoryBase2(Of SearchProfileEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("SearchProfileEntity", PManagement.Data.EntityType.SearchProfileEntity, False)
		End Sub
	
		''' <summary>Creates a new SearchProfileEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New SearchProfileEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewSearchProfileUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty SearchProfileDetailEntity objects.</summary>
	<Serializable()> _
	Public Class SearchProfileDetailEntityFactory 
		Inherits EntityFactoryBase2(Of SearchProfileDetailEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("SearchProfileDetailEntity", PManagement.Data.EntityType.SearchProfileDetailEntity, False)
		End Sub
	
		''' <summary>Creates a new SearchProfileDetailEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New SearchProfileDetailEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewSearchProfileDetailUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ServiceCodeEntity objects.</summary>
	<Serializable()> _
	Public Class ServiceCodeEntityFactory 
		Inherits EntityFactoryBase2(Of ServiceCodeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ServiceCodeEntity", PManagement.Data.EntityType.ServiceCodeEntity, False)
		End Sub
	
		''' <summary>Creates a new ServiceCodeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ServiceCodeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewServiceCodeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ServiceGroupEntity objects.</summary>
	<Serializable()> _
	Public Class ServiceGroupEntityFactory 
		Inherits EntityFactoryBase2(Of ServiceGroupEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ServiceGroupEntity", PManagement.Data.EntityType.ServiceGroupEntity, False)
		End Sub
	
		''' <summary>Creates a new ServiceGroupEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ServiceGroupEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewServiceGroupUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty ServiceTypeEntity objects.</summary>
	<Serializable()> _
	Public Class ServiceTypeEntityFactory 
		Inherits EntityFactoryBase2(Of ServiceTypeEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("ServiceTypeEntity", PManagement.Data.EntityType.ServiceTypeEntity, False)
		End Sub
	
		''' <summary>Creates a new ServiceTypeEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New ServiceTypeEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewServiceTypeUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty StageEntity objects.</summary>
	<Serializable()> _
	Public Class StageEntityFactory 
		Inherits EntityFactoryBase2(Of StageEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StageEntity", PManagement.Data.EntityType.StageEntity, False)
		End Sub
	
		''' <summary>Creates a new StageEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New StageEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewStageUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty StandardFolderEntity objects.</summary>
	<Serializable()> _
	Public Class StandardFolderEntityFactory 
		Inherits EntityFactoryBase2(Of StandardFolderEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StandardFolderEntity", PManagement.Data.EntityType.StandardFolderEntity, False)
		End Sub
	
		''' <summary>Creates a new StandardFolderEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New StandardFolderEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewStandardFolderUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty StandardMilestoneEntity objects.</summary>
	<Serializable()> _
	Public Class StandardMilestoneEntityFactory 
		Inherits EntityFactoryBase2(Of StandardMilestoneEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StandardMilestoneEntity", PManagement.Data.EntityType.StandardMilestoneEntity, False)
		End Sub
	
		''' <summary>Creates a new StandardMilestoneEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New StandardMilestoneEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewStandardMilestoneUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty StandardTaskEntity objects.</summary>
	<Serializable()> _
	Public Class StandardTaskEntityFactory 
		Inherits EntityFactoryBase2(Of StandardTaskEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StandardTaskEntity", PManagement.Data.EntityType.StandardTaskEntity, False)
		End Sub
	
		''' <summary>Creates a new StandardTaskEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New StandardTaskEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewStandardTaskUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty StandardTask2StatusEntity objects.</summary>
	<Serializable()> _
	Public Class StandardTask2StatusEntityFactory 
		Inherits EntityFactoryBase2(Of StandardTask2StatusEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StandardTask2StatusEntity", PManagement.Data.EntityType.StandardTask2StatusEntity, False)
		End Sub
	
		''' <summary>Creates a new StandardTask2StatusEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New StandardTask2StatusEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewStandardTask2StatusUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty StateEntity objects.</summary>
	<Serializable()> _
	Public Class StateEntityFactory 
		Inherits EntityFactoryBase2(Of StateEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StateEntity", PManagement.Data.EntityType.StateEntity, False)
		End Sub
	
		''' <summary>Creates a new StateEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New StateEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewStateUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty StatusEntity objects.</summary>
	<Serializable()> _
	Public Class StatusEntityFactory 
		Inherits EntityFactoryBase2(Of StatusEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("StatusEntity", PManagement.Data.EntityType.StatusEntity, False)
		End Sub
	
		''' <summary>Creates a new StatusEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New StatusEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewStatusUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty SupplierEntity objects.</summary>
	<Serializable()> _
	Public Class SupplierEntityFactory 
		Inherits EntityFactoryBase2(Of SupplierEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("SupplierEntity", PManagement.Data.EntityType.SupplierEntity, False)
		End Sub
	
		''' <summary>Creates a new SupplierEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New SupplierEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewSupplierUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty SupplierEnvironmentEntity objects.</summary>
	<Serializable()> _
	Public Class SupplierEnvironmentEntityFactory 
		Inherits EntityFactoryBase2(Of SupplierEnvironmentEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("SupplierEnvironmentEntity", PManagement.Data.EntityType.SupplierEnvironmentEntity, False)
		End Sub
	
		''' <summary>Creates a new SupplierEnvironmentEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New SupplierEnvironmentEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewSupplierEnvironmentUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty SystemDescriptionEntity objects.</summary>
	<Serializable()> _
	Public Class SystemDescriptionEntityFactory 
		Inherits EntityFactoryBase2(Of SystemDescriptionEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("SystemDescriptionEntity", PManagement.Data.EntityType.SystemDescriptionEntity, False)
		End Sub
	
		''' <summary>Creates a new SystemDescriptionEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New SystemDescriptionEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewSystemDescriptionUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TaskEntity objects.</summary>
	<Serializable()> _
	Public Class TaskEntityFactory 
		Inherits EntityFactoryBase2(Of TaskEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TaskEntity", PManagement.Data.EntityType.TaskEntity, False)
		End Sub
	
		''' <summary>Creates a new TaskEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TaskEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTaskUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TaskMilestoneEntity objects.</summary>
	<Serializable()> _
	Public Class TaskMilestoneEntityFactory 
		Inherits EntityFactoryBase2(Of TaskMilestoneEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TaskMilestoneEntity", PManagement.Data.EntityType.TaskMilestoneEntity, False)
		End Sub
	
		''' <summary>Creates a new TaskMilestoneEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TaskMilestoneEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTaskMilestoneUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TimelineEntity objects.</summary>
	<Serializable()> _
	Public Class TimelineEntityFactory 
		Inherits EntityFactoryBase2(Of TimelineEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TimelineEntity", PManagement.Data.EntityType.TimelineEntity, False)
		End Sub
	
		''' <summary>Creates a new TimelineEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TimelineEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTimelineUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineEntity", PManagement.Data.EntityType.TurbineEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineFrequencyEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineFrequencyEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineFrequencyEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineFrequencyEntity", PManagement.Data.EntityType.TurbineFrequencyEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineFrequencyEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineFrequencyEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineFrequencyUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineManufacturerEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineManufacturerEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineManufacturerEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineManufacturerEntity", PManagement.Data.EntityType.TurbineManufacturerEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineManufacturerEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineManufacturerEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineManufacturerUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineMarkVersionEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineMarkVersionEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineMarkVersionEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineMarkVersionEntity", PManagement.Data.EntityType.TurbineMarkVersionEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineMarkVersionEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineMarkVersionEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineMarkVersionUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineMatrixEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineMatrixEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineMatrixEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineMatrixEntity", PManagement.Data.EntityType.TurbineMatrixEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineMatrixEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineMatrixEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineMatrixUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineNominelPowerEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineNominelPowerEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineNominelPowerEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineNominelPowerEntity", PManagement.Data.EntityType.TurbineNominelPowerEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineNominelPowerEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineNominelPowerEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineNominelPowerUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineOldEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineOldEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineOldEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineOldEntity", PManagement.Data.EntityType.TurbineOldEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineOldEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineOldEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineOldUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbinePlacementEntity objects.</summary>
	<Serializable()> _
	Public Class TurbinePlacementEntityFactory 
		Inherits EntityFactoryBase2(Of TurbinePlacementEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbinePlacementEntity", PManagement.Data.EntityType.TurbinePlacementEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbinePlacementEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbinePlacementEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbinePlacementUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbinePowerRegulationEntity objects.</summary>
	<Serializable()> _
	Public Class TurbinePowerRegulationEntityFactory 
		Inherits EntityFactoryBase2(Of TurbinePowerRegulationEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbinePowerRegulationEntity", PManagement.Data.EntityType.TurbinePowerRegulationEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbinePowerRegulationEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbinePowerRegulationEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbinePowerRegulationUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineRotorDiameterEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineRotorDiameterEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineRotorDiameterEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineRotorDiameterEntity", PManagement.Data.EntityType.TurbineRotorDiameterEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineRotorDiameterEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineRotorDiameterEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineRotorDiameterUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineSmallGeneratorEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineSmallGeneratorEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineSmallGeneratorEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineSmallGeneratorEntity", PManagement.Data.EntityType.TurbineSmallGeneratorEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineSmallGeneratorEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineSmallGeneratorEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineSmallGeneratorUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineTemperatureVariantEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineTemperatureVariantEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineTemperatureVariantEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineTemperatureVariantEntity", PManagement.Data.EntityType.TurbineTemperatureVariantEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineTemperatureVariantEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineTemperatureVariantEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineTemperatureVariantUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty TurbineVoltageEntity objects.</summary>
	<Serializable()> _
	Public Class TurbineVoltageEntityFactory 
		Inherits EntityFactoryBase2(Of TurbineVoltageEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("TurbineVoltageEntity", PManagement.Data.EntityType.TurbineVoltageEntity, False)
		End Sub
	
		''' <summary>Creates a new TurbineVoltageEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New TurbineVoltageEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewTurbineVoltageUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class	
	''' <summary>Factory to create new, empty VisitsEntity objects.</summary>
	<Serializable()> _
	Public Class VisitsEntityFactory 
		Inherits EntityFactoryBase2(Of VisitsEntity)

		''' <summary>CTor</summary>
		Public Sub New()
			MyBase.New("VisitsEntity", PManagement.Data.EntityType.VisitsEntity, False)
		End Sub
	
		''' <summary>Creates a new VisitsEntity instance and will set the Fields object of the new IEntity2 instance to the passed in fields object.</summary>
		''' <param name="fields">Populated IEntityFields2 object for the new IEntity2 to create</param>
		''' <returns>Fully created and populated (due to the IEntityFields2 object) IEntity2 object</returns>
		Public Overrides Overloads Function Create(fields As IEntityFields2) As IEntity2
			Dim toReturn As IEntity2 = New VisitsEntity(fields)
			' __LLBLGENPRO_USER_CODE_REGION_START CreateNewVisitsUsingFields
			' __LLBLGENPRO_USER_CODE_REGION_END		
			Return toReturn
		End Function
#Region "Included Code"

#End Region
	End Class

	''' <summary>Factory to create new, empty Entity objects based on the entity type specified. Uses entity specific factory objects</summary>
	<Serializable()> _
	Public Class GeneralEntityFactory
		''' <summary>Creates a new, empty Entity object of the type specified</summary>
		''' <param name="entityTypeToCreate">The entity type to create.</param>
		''' <returns>A new, empty Entity object.</returns>
		Public Shared Function Create(entityTypeToCreate As PManagement.Data.EntityType) As IEntity2 
			Dim factoryToUse As IEntityFactory2 = Nothing
			Select Case entityTypeToCreate
				Case PManagement.Data.EntityType.AlertCategoryEntity
					factoryToUse = New AlertCategoryEntityFactory()
				Case PManagement.Data.EntityType.AlertCategoryCriteriaEntity
					factoryToUse = New AlertCategoryCriteriaEntityFactory()
				Case PManagement.Data.EntityType.AlertChangeTypeCriteriaEntity
					factoryToUse = New AlertChangeTypeCriteriaEntityFactory()
				Case PManagement.Data.EntityType.AlertConfigEntity
					factoryToUse = New AlertConfigEntityFactory()
				Case PManagement.Data.EntityType.AlertConfigCircountEntity
					factoryToUse = New AlertConfigCircountEntityFactory()
				Case PManagement.Data.EntityType.AlertFrequencyEntity
					factoryToUse = New AlertFrequencyEntityFactory()
				Case PManagement.Data.EntityType.AlertReceiverEntity
					factoryToUse = New AlertReceiverEntityFactory()
				Case PManagement.Data.EntityType.AlertReceiverRoleTypeEntity
					factoryToUse = New AlertReceiverRoleTypeEntityFactory()
				Case PManagement.Data.EntityType.AlertReceiverTypeEntity
					factoryToUse = New AlertReceiverTypeEntityFactory()
				Case PManagement.Data.EntityType.AlertServiceSettingsEntity
					factoryToUse = New AlertServiceSettingsEntityFactory()
				Case PManagement.Data.EntityType.AnyChangesEntity
					factoryToUse = New AnyChangesEntityFactory()
				Case PManagement.Data.EntityType.BrandEntity
					factoryToUse = New BrandEntityFactory()
				Case PManagement.Data.EntityType.Brand2DocumentTemplateEntity
					factoryToUse = New Brand2DocumentTemplateEntityFactory()
				Case PManagement.Data.EntityType.Brand2FeatureEntity
					factoryToUse = New Brand2FeatureEntityFactory()
				Case PManagement.Data.EntityType.Brand2StandardMilestoneEntity
					factoryToUse = New Brand2StandardMilestoneEntityFactory()
				Case PManagement.Data.EntityType.BusinessProcessEntity
					factoryToUse = New BusinessProcessEntityFactory()
				Case PManagement.Data.EntityType.CaseEntity
					factoryToUse = New CaseEntityFactory()
				Case PManagement.Data.EntityType.Case2CaseBundleEntity
					factoryToUse = New Case2CaseBundleEntityFactory()
				Case PManagement.Data.EntityType.Case2ComponentTypeEntity
					factoryToUse = New Case2ComponentTypeEntityFactory()
				Case PManagement.Data.EntityType.Case2ItemEntity
					factoryToUse = New Case2ItemEntityFactory()
				Case PManagement.Data.EntityType.Case2KPIRatingEntity
					factoryToUse = New Case2KPIRatingEntityFactory()
				Case PManagement.Data.EntityType.Case2LogInfoEntity
					factoryToUse = New Case2LogInfoEntityFactory()
				Case PManagement.Data.EntityType.Case2ParticipantEntity
					factoryToUse = New Case2ParticipantEntityFactory()
				Case PManagement.Data.EntityType.Case2PhaseEntity
					factoryToUse = New Case2PhaseEntityFactory()
				Case PManagement.Data.EntityType.Case2ReasonCodeEntity
					factoryToUse = New Case2ReasonCodeEntityFactory()
				Case PManagement.Data.EntityType.Case2SbuEntity
					factoryToUse = New Case2SbuEntityFactory()
				Case PManagement.Data.EntityType.Case2ServiceCodeEntity
					factoryToUse = New Case2ServiceCodeEntityFactory()
				Case PManagement.Data.EntityType.Case2SupplierEntity
					factoryToUse = New Case2SupplierEntityFactory()
				Case PManagement.Data.EntityType.Case2Supplier2StageEntity
					factoryToUse = New Case2Supplier2StageEntityFactory()
				Case PManagement.Data.EntityType.Case2SystemEntity
					factoryToUse = New Case2SystemEntityFactory()
				Case PManagement.Data.EntityType.Case2TurbineMatrixEntity
					factoryToUse = New Case2TurbineMatrixEntityFactory()
				Case PManagement.Data.EntityType.Case2TurbineMatrix2Case2ItemEntity
					factoryToUse = New Case2TurbineMatrix2Case2ItemEntityFactory()
				Case PManagement.Data.EntityType.CaseBundleEntity
					factoryToUse = New CaseBundleEntityFactory()
				Case PManagement.Data.EntityType.CaseRelationEntity
					factoryToUse = New CaseRelationEntityFactory()
				Case PManagement.Data.EntityType.CategoryEntity
					factoryToUse = New CategoryEntityFactory()
				Case PManagement.Data.EntityType.ChangeLogEntity
					factoryToUse = New ChangeLogEntityFactory()
				Case PManagement.Data.EntityType.ChangeTypeEntity
					factoryToUse = New ChangeTypeEntityFactory()
				Case PManagement.Data.EntityType.CirEntity
					factoryToUse = New CirEntityFactory()
				Case PManagement.Data.EntityType.ClaimStatusEntity
					factoryToUse = New ClaimStatusEntityFactory()
				Case PManagement.Data.EntityType.ComponentEntity
					factoryToUse = New ComponentEntityFactory()
				Case PManagement.Data.EntityType.ComponentTypeEntity
					factoryToUse = New ComponentTypeEntityFactory()
				Case PManagement.Data.EntityType.ControlEntity
					factoryToUse = New ControlEntityFactory()
				Case PManagement.Data.EntityType.CustomColumnsNameEntity
					factoryToUse = New CustomColumnsNameEntityFactory()
				Case PManagement.Data.EntityType.CustomColumnsValueEntity
					factoryToUse = New CustomColumnsValueEntityFactory()
				Case PManagement.Data.EntityType.DiscussionEntity
					factoryToUse = New DiscussionEntityFactory()
				Case PManagement.Data.EntityType.DocumentEntity
					factoryToUse = New DocumentEntityFactory()
				Case PManagement.Data.EntityType.DocumentBinaryEntity
					factoryToUse = New DocumentBinaryEntityFactory()
				Case PManagement.Data.EntityType.DocumentClassificationEntity
					factoryToUse = New DocumentClassificationEntityFactory()
				Case PManagement.Data.EntityType.DocumentStatusEntity
					factoryToUse = New DocumentStatusEntityFactory()
				Case PManagement.Data.EntityType.DocumentTemplateEntity
					factoryToUse = New DocumentTemplateEntityFactory()
				Case PManagement.Data.EntityType.DocumentVersionEntity
					factoryToUse = New DocumentVersionEntityFactory()
				Case PManagement.Data.EntityType.ErpsystemEntity
					factoryToUse = New ErpsystemEntityFactory()
				Case PManagement.Data.EntityType.FeatureEntity
					factoryToUse = New FeatureEntityFactory()
				Case PManagement.Data.EntityType.FolderEntity
					factoryToUse = New FolderEntityFactory()
				Case PManagement.Data.EntityType.Folder2DocumentEntity
					factoryToUse = New Folder2DocumentEntityFactory()
				Case PManagement.Data.EntityType.FolderTypeEntity
					factoryToUse = New FolderTypeEntityFactory()
				Case PManagement.Data.EntityType.HelpEntity
					factoryToUse = New HelpEntityFactory()
				Case PManagement.Data.EntityType.InlineHelpEntity
					factoryToUse = New InlineHelpEntityFactory()
				Case PManagement.Data.EntityType.InlineHelpTextEntity
					factoryToUse = New InlineHelpTextEntityFactory()
				Case PManagement.Data.EntityType.ItemEntity
					factoryToUse = New ItemEntityFactory()
				Case PManagement.Data.EntityType.ItemStatusEntity
					factoryToUse = New ItemStatusEntityFactory()
				Case PManagement.Data.EntityType.ItemSystemMappingEntity
					factoryToUse = New ItemSystemMappingEntityFactory()
				Case PManagement.Data.EntityType.ItemSystemMappingStagingTableEntity
					factoryToUse = New ItemSystemMappingStagingTableEntityFactory()
				Case PManagement.Data.EntityType.LanguageEntity
					factoryToUse = New LanguageEntityFactory()
				Case PManagement.Data.EntityType.LogInfoEntity
					factoryToUse = New LogInfoEntityFactory()
				Case PManagement.Data.EntityType.LogInfo2LogTxtEntity
					factoryToUse = New LogInfo2LogTxtEntityFactory()
				Case PManagement.Data.EntityType.LogTxtEntity
					factoryToUse = New LogTxtEntityFactory()
				Case PManagement.Data.EntityType.MilestoneEntity
					factoryToUse = New MilestoneEntityFactory()
				Case PManagement.Data.EntityType.ModuleEntity
					factoryToUse = New ModuleEntityFactory()
				Case PManagement.Data.EntityType.NewsEntity
					factoryToUse = New NewsEntityFactory()
				Case PManagement.Data.EntityType.News2ParticipantEntity
					factoryToUse = New News2ParticipantEntityFactory()
				Case PManagement.Data.EntityType.OldCimturbineEntity
					factoryToUse = New OldCimturbineEntityFactory()
				Case PManagement.Data.EntityType.ParticipantEntity
					factoryToUse = New ParticipantEntityFactory()
				Case PManagement.Data.EntityType.Participant2RoleEntity
					factoryToUse = New Participant2RoleEntityFactory()
				Case PManagement.Data.EntityType.ParticipantLogEntity
					factoryToUse = New ParticipantLogEntityFactory()
				Case PManagement.Data.EntityType.ParticipationTypeEntity
					factoryToUse = New ParticipationTypeEntityFactory()
				Case PManagement.Data.EntityType.PayeeEntity
					factoryToUse = New PayeeEntityFactory()
				Case PManagement.Data.EntityType.PbuEntity
					factoryToUse = New PbuEntityFactory()
				Case PManagement.Data.EntityType.PerformanceActionEntity
					factoryToUse = New PerformanceActionEntityFactory()
				Case PManagement.Data.EntityType.PerformanceDataEntity
					factoryToUse = New PerformanceDataEntityFactory()
				Case PManagement.Data.EntityType.PerformanceUtilitySettingEntity
					factoryToUse = New PerformanceUtilitySettingEntityFactory()
				Case PManagement.Data.EntityType.PermissionEntity
					factoryToUse = New PermissionEntityFactory()
				Case PManagement.Data.EntityType.PersonalSafetyEntity
					factoryToUse = New PersonalSafetyEntityFactory()
				Case PManagement.Data.EntityType.PhaseEntity
					factoryToUse = New PhaseEntityFactory()
				Case PManagement.Data.EntityType.Phase2StatusEntity
					factoryToUse = New Phase2StatusEntityFactory()
				Case PManagement.Data.EntityType.PlatformEntity
					factoryToUse = New PlatformEntityFactory()
				Case PManagement.Data.EntityType.PopulationlistEntity
					factoryToUse = New PopulationlistEntityFactory()
				Case PManagement.Data.EntityType.PopulationlistDocumentEntity
					factoryToUse = New PopulationlistDocumentEntityFactory()
				Case PManagement.Data.EntityType.PopulationlistItemEntity
					factoryToUse = New PopulationlistItemEntityFactory()
				Case PManagement.Data.EntityType.PortfolioEntity
					factoryToUse = New PortfolioEntityFactory()
				Case PManagement.Data.EntityType.ProjectEntity
					factoryToUse = New ProjectEntityFactory()
				Case PManagement.Data.EntityType.ProjectScopeEntity
					factoryToUse = New ProjectScopeEntityFactory()
				Case PManagement.Data.EntityType.RcEntity
					factoryToUse = New RcEntityFactory()
				Case PManagement.Data.EntityType.RccomponentOwnerEntity
					factoryToUse = New RccomponentOwnerEntityFactory()
				Case PManagement.Data.EntityType.RcoriginEntity
					factoryToUse = New RcoriginEntityFactory()
				Case PManagement.Data.EntityType.RcoriginRelationEntity
					factoryToUse = New RcoriginRelationEntityFactory()
				Case PManagement.Data.EntityType.RcoriginResponsibleEntity
					factoryToUse = New RcoriginResponsibleEntityFactory()
				Case PManagement.Data.EntityType.RcoriginUnitEntity
					factoryToUse = New RcoriginUnitEntityFactory()
				Case PManagement.Data.EntityType.ReasonCodeEntity
					factoryToUse = New ReasonCodeEntityFactory()
				Case PManagement.Data.EntityType.RelatedCaseEntity
					factoryToUse = New RelatedCaseEntityFactory()
				Case PManagement.Data.EntityType.RelatedCase2CaseRelationEntity
					factoryToUse = New RelatedCase2CaseRelationEntityFactory()
				Case PManagement.Data.EntityType.RelatedItemEntity
					factoryToUse = New RelatedItemEntityFactory()
				Case PManagement.Data.EntityType.ReportTypeEntity
					factoryToUse = New ReportTypeEntityFactory()
				Case PManagement.Data.EntityType.RoleEntity
					factoryToUse = New RoleEntityFactory()
				Case PManagement.Data.EntityType.Role2PermissionEntity
					factoryToUse = New Role2PermissionEntityFactory()
				Case PManagement.Data.EntityType.SbuEntity
					factoryToUse = New SbuEntityFactory()
				Case PManagement.Data.EntityType.SbucloneEntity
					factoryToUse = New SbucloneEntityFactory()
				Case PManagement.Data.EntityType.SearchProfileEntity
					factoryToUse = New SearchProfileEntityFactory()
				Case PManagement.Data.EntityType.SearchProfileDetailEntity
					factoryToUse = New SearchProfileDetailEntityFactory()
				Case PManagement.Data.EntityType.ServiceCodeEntity
					factoryToUse = New ServiceCodeEntityFactory()
				Case PManagement.Data.EntityType.ServiceGroupEntity
					factoryToUse = New ServiceGroupEntityFactory()
				Case PManagement.Data.EntityType.ServiceTypeEntity
					factoryToUse = New ServiceTypeEntityFactory()
				Case PManagement.Data.EntityType.StageEntity
					factoryToUse = New StageEntityFactory()
				Case PManagement.Data.EntityType.StandardFolderEntity
					factoryToUse = New StandardFolderEntityFactory()
				Case PManagement.Data.EntityType.StandardMilestoneEntity
					factoryToUse = New StandardMilestoneEntityFactory()
				Case PManagement.Data.EntityType.StandardTaskEntity
					factoryToUse = New StandardTaskEntityFactory()
				Case PManagement.Data.EntityType.StandardTask2StatusEntity
					factoryToUse = New StandardTask2StatusEntityFactory()
				Case PManagement.Data.EntityType.StateEntity
					factoryToUse = New StateEntityFactory()
				Case PManagement.Data.EntityType.StatusEntity
					factoryToUse = New StatusEntityFactory()
				Case PManagement.Data.EntityType.SupplierEntity
					factoryToUse = New SupplierEntityFactory()
				Case PManagement.Data.EntityType.SupplierEnvironmentEntity
					factoryToUse = New SupplierEnvironmentEntityFactory()
				Case PManagement.Data.EntityType.SystemDescriptionEntity
					factoryToUse = New SystemDescriptionEntityFactory()
				Case PManagement.Data.EntityType.TaskEntity
					factoryToUse = New TaskEntityFactory()
				Case PManagement.Data.EntityType.TaskMilestoneEntity
					factoryToUse = New TaskMilestoneEntityFactory()
				Case PManagement.Data.EntityType.TimelineEntity
					factoryToUse = New TimelineEntityFactory()
				Case PManagement.Data.EntityType.TurbineEntity
					factoryToUse = New TurbineEntityFactory()
				Case PManagement.Data.EntityType.TurbineFrequencyEntity
					factoryToUse = New TurbineFrequencyEntityFactory()
				Case PManagement.Data.EntityType.TurbineManufacturerEntity
					factoryToUse = New TurbineManufacturerEntityFactory()
				Case PManagement.Data.EntityType.TurbineMarkVersionEntity
					factoryToUse = New TurbineMarkVersionEntityFactory()
				Case PManagement.Data.EntityType.TurbineMatrixEntity
					factoryToUse = New TurbineMatrixEntityFactory()
				Case PManagement.Data.EntityType.TurbineNominelPowerEntity
					factoryToUse = New TurbineNominelPowerEntityFactory()
				Case PManagement.Data.EntityType.TurbineOldEntity
					factoryToUse = New TurbineOldEntityFactory()
				Case PManagement.Data.EntityType.TurbinePlacementEntity
					factoryToUse = New TurbinePlacementEntityFactory()
				Case PManagement.Data.EntityType.TurbinePowerRegulationEntity
					factoryToUse = New TurbinePowerRegulationEntityFactory()
				Case PManagement.Data.EntityType.TurbineRotorDiameterEntity
					factoryToUse = New TurbineRotorDiameterEntityFactory()
				Case PManagement.Data.EntityType.TurbineSmallGeneratorEntity
					factoryToUse = New TurbineSmallGeneratorEntityFactory()
				Case PManagement.Data.EntityType.TurbineTemperatureVariantEntity
					factoryToUse = New TurbineTemperatureVariantEntityFactory()
				Case PManagement.Data.EntityType.TurbineVoltageEntity
					factoryToUse = New TurbineVoltageEntityFactory()
				Case PManagement.Data.EntityType.VisitsEntity
					factoryToUse = New VisitsEntityFactory()
			End Select
			Dim toReturn As IEntity2 = Nothing
			If Not factoryToUse Is Nothing Then
				toReturn = factoryToUse.Create()
			End If
			Return toReturn
		End Function		
	End Class
	
	''' <summary>Class which Is used To obtain the entity factory based On the .NET type of the entity. </summary>
	<Serializable()> _
	Public Class EntityFactoryFactory
		Private Shared _factoryPerType As Dictionary(Of Type, IEntityFactory2) = New Dictionary(Of Type, IEntityFactory2)()

		''' <summary>Initializes the <see cref="EntityFactoryFactory"/> Class.</summary>
		Shared Sub New()
			Dim entityTypeValues As Array = [Enum].GetValues(GetType(PManagement.Data.EntityType))
			For Each entityTypeValue As Integer In entityTypeValues
				Dim dummy As IEntity2 = GeneralEntityFactory.Create(CType(entityTypeValue, PManagement.Data.EntityType))
				_factoryPerType.Add(CType(dummy, Object).GetType(), dummy.GetEntityFactory())
			Next
		End Sub

		''' <summary>Gets the factory of the entity With the .NET type specified</summary>
		''' <param name="typeOfEntity">The type of entity.</param>
		''' <returns>factory To use Or null If Not found</returns>
		Public Shared Function GetFactory(typeOfEntity As Type) As IEntityFactory2
			Dim toReturn As IEntityFactory2  = Nothing
			_factoryPerType.TryGetValue(typeOfEntity, toReturn)
			Return toReturn
		End Function

		''' <summary>Gets the factory of the entity With the PManagement.Data.EntityType specified</summary>
		''' <param name="typeOfEntity">The type of entity.</param>
		''' <returns>factory To use Or null If Not found</returns>
		Public Shared Function GetFactory(typeOfEntity As PManagement.Data.EntityType) As IEntityFactory2
			Return GetFactory(CType(GeneralEntityFactory.Create(typeOfEntity), Object).GetType())
		End Function
	End Class
		
	''' <summary>Element creator For creating project elements from somewhere Else, like inside Linq providers.</summary>
	Public Class ElementCreator 
		Inherits ElementCreatorBase
		Implements IElementCreator2
	
		''' <summary>Gets the factory of the Entity type with the PManagement.Data.EntityType value passed in</summary>
		''' <param name="entityTypeValue">The entity type value.</param>
		''' <returns>the entity factory of the entity type or null if not found</returns>
		Public Function GetFactory(entityTypeValue As Integer) As IEntityFactory2 Implements IElementCreator2.GetFactory
			Return CType(GetFactoryImpl(entityTypeValue), IEntityFactory2)
		End Function
		
		''' <summary>Gets the factory of the Entity type With the .NET type passed In</summary>
		''' <param name="typeOfEntity">The type of entity.</param>
		''' <returns>the entity factory of the entity type Or null If Not found</returns>
		Public Function GetFactory(typeOfEntity As Type) As IEntityFactory2 Implements IElementCreator2.GetFactory
			Return CType(GetFactoryImpl(typeOfEntity), IEntityFactory2)
		End Function

		''' <summary>Creates a New resultset fields Object With the number of field slots reserved As specified</summary>
		''' <param name="numberOfFields">The number of fields.</param>
		''' <returns>ready To use resultsetfields Object</returns>
		Public Function CreateResultsetFields(numberOfFields As Integer) As IEntityFields2  Implements IElementCreator2.CreateResultsetFields
			Return New ResultsetFields(numberOfFields)
		End Function
		
		''' <summary>Creates a New dynamic relation instance</summary>
		''' <param name="leftOperand">The Left operand.</param>
		''' <returns>ready To use dynamic relation</returns>
		Public Overrides Overloads Function CreateDynamicRelation(leftOperand As DerivedTableDefinition) As IDynamicRelation
			Return New DynamicRelation(leftOperand)
		End Function

		''' <summary>Creates a New dynamic relation instance</summary>
		''' <param name="leftOperand">The Left operand.</param>
		''' <param name="joinType">Type of the Join. If None Is specified, Inner Is assumed.</param>
		''' <param name="rightOperand">The Right operand.</param>
		''' <param name="onClause">The On clause For the Join.</param>
		''' <returns>ready To use dynamic relation</returns>
		Public Overrides Overloads Function CreateDynamicRelation(leftOperand As DerivedTableDefinition, joinType As JoinHint, rightOperand As DerivedTableDefinition, onClause As IPredicate) As IDynamicRelation
			Return New DynamicRelation(leftOperand, joinType, rightOperand, onClause)
		End Function
				
		''' <summary>Obtains the inheritance info provider instance from the singleton </summary>
		''' <returns>The singleton instance of the inheritance info provider</returns>
		Public Overrides Function ObtainInheritanceInfoProviderInstance() As IInheritanceInfoProvider
			Return InheritanceInfoProviderSingleton.GetInstance()
		End Function

		''' <summary>Creates a New dynamic relation instance</summary>
		''' <param name="leftOperand">The Left operand.</param>
		''' <param name="joinType">Type of the Join. If None Is specified, Inner Is assumed.</param>
		''' <param name="rightOperandEntityName">Name of the entity, which Is used As the Right operand.</param>
		''' <param name="aliasRightOperand">The Alias of the Right operand. If you don't want to / need to alias the right operand (only alias if you have to), specify string.Empty.</param>
		''' <param name="onClause">The On clause For the Join.</param>
		''' <returns>ready To use dynamic relation</returns>
		Public Overrides Overloads Function CreateDynamicRelation(leftOperand As DerivedTableDefinition, joinType As JoinHint, rightOperandEntityName As String, aliasRightOperand As String, onClause As IPredicate) As IDynamicRelation
			Return New DynamicRelation(leftOperand, joinType, CType([Enum].Parse(GetType(PManagement.Data.EntityType), rightOperandEntityName, False), PManagement.Data.EntityType), aliasRightOperand, onClause)
		End Function

		''' <summary>Creates a New dynamic relation instance</summary>
		''' <param name="leftOperandEntityName">Name of the entity which Is used As the Left operand.</param>
		''' <param name="joinType">Type of the Join. If None Is specified, Inner Is assumed.</param>
		''' <param name="rightOperandEntityName">Name of the entity, which Is used As the Right operand.</param>
		''' <param name="aliasLeftOperand">The Alias of the Left operand. If you don't want to / need to alias the right operand (only alias if you have to), specify string.Empty.</param>
		''' <param name="aliasRightOperand">The Alias of the Right operand. If you don't want to / need to alias the right operand (only alias if you have to), specify string.Empty.</param>
		''' <param name="onClause">The On clause For the Join.</param>
		''' <returns>ready To use dynamic relation</returns>
		Public Overrides Overloads Function CreateDynamicRelation(leftOperandEntityName As String, joinType As JoinHint, rightOperandEntityName As String, aliasLeftOperand As String, aliasRightOperand As String, onClause As IPredicate) As IDynamicRelation
			Return New DynamicRelation(CType([Enum].Parse(GetType(PManagement.Data.EntityType), leftOperandEntityName, False), PManagement.Data.EntityType), joinType, CType([Enum].Parse(GetType(PManagement.Data.EntityType), rightOperandEntityName, False), PManagement.Data.EntityType), aliasLeftOperand, aliasRightOperand, onClause)
		End Function

		''' <summary>Implementation of the routine which gets the factory of the Entity type With the PManagement.Data.EntityType value passed In</summary>
		''' <param name="entityTypeValue">The entity type value.</param>
		''' <returns>the entity factory of the entity type Or null If Not found</returns>
		Protected Overrides Function GetFactoryImpl(entityTypeValue As Integer) As IEntityFactoryCore
			Return EntityFactoryFactory.GetFactory(CType(entityTypeValue, PManagement.Data.EntityType))
		End Function

		''' <summary>Implementation of the routine which gets the factory of the Entity type With the .NET type passed In</summary>
		''' <param name="typeOfEntity">The type of entity.</param>
		''' <returns>the entity factory of the entity type Or null If Not found</returns>
		Protected Overrides Function GetFactoryImpl(typeOfEntity As Type) As IEntityFactoryCore 
			Return EntityFactoryFactory.GetFactory(typeOfEntity)
		End Function

	End Class
End Namespace
