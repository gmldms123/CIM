﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports PManagement.Data
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.FactoryClasses
	''' <summary>Factory class for IEntityField2 instances, used in IEntityFields2 instances.</summary>
	Public Class EntityFieldFactory
		''' <summary>Private CTor, no instantiation possible.</summary>
		Private Sub New()
		End Sub

		''' <summary>Creates a new IEntityField2 instance for usage in the EntityFields Object for the entity related to the field index specified.</summary>
		''' <param name="fieldIndex">The field which IEntityField2 instance should be created</param>
		''' <returns>The IEntityField2 instance for the field specified in fieldIndex</returns>
		Public Shared Function Create(fieldIndex As System.Enum) As IEntityField2
			Return New EntityField2(FieldInfoProviderSingleton.GetInstance().GetFieldInfo(fieldIndex))
		End Function
		
		''' <summary>Creates a New IEntityField2 instance, which represents the field objectName.fieldName</summary>
		''' <param name="objectName">the name of the Object the field belongs To, like CustomerEntity Or OrdersTypedView</param>
		''' <param name="fieldName">the name of the field To create</param>
		Public Shared Function Create(objectName As String, fieldName As String) As IEntityField2
			Return New EntityField2(FieldInfoProviderSingleton.GetInstance().GetFieldInfo(objectName, fieldName))
        End Function

#Region "Included Code"

#End Region
	End Class
End Namespace
