﻿'///////////////////////////////////////////////////////////////
'// This Is generated code. 
'//////////////////////////////////////////////////////////////
'// Code Is generated Using LLBLGen Pro version: 4.0
'// Code Is generated On: 
'// Code Is generated Using templates: SD.TemplateBindings.SharedTemplates
'// Templates vendor: Solutions Design.
'///////////////////////////////////////////////////////////''' 
Imports System
Imports System.Linq
Imports PManagement.Data.EntityClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses
Imports SD.LLBLGen.Pro.QuerySpec

Namespace PManagement.Data.FactoryClasses
	''' <summary>Factory Class To produce DynamicQuery instances And EntityQuery instances</summary>
	Public Class QueryFactory
		Dim _aliasCounter As Integer = 0

		''' <summary>Creates a New DynamicQuery instance With no Alias Set.</summary>
		''' <returns>Ready To use DynamicQuery instance</returns>
		Public Function Create() As DynamicQuery
			Return Create(String.Empty)
		End Function

		''' <summary>Creates a New DynamicQuery instance With the Alias specified As the Alias Set.</summary>
		''' <param name="alias">The Alias.</param>
		''' <returns>Ready To use DynamicQuery instance</returns>
		Public Function Create([Alias] As String) As DynamicQuery 
			Return New DynamicQuery(New ElementCreator(), [Alias], Me.GetNextAliasCounterValue())
		End Function

		''' <summary>Creates a new DynamicQuery which wraps the specified TableValuedFunction call</summary>
		''' <param name="toWrap">The table valued function call to wrap.</param>
		''' <returns>toWrap wrapped in a DynamicQuery.</returns>
		Public Function Create(toWrap As TableValuedFunctionCall) As DynamicQuery 
			Return Me.Create().From(New TvfCallWrapper(toWrap)).Select(toWrap.GetFieldsAsArray().Select(Function(f) Me.Field(toWrap.Alias, f.Alias)).ToArray())
		End Function

		''' <summary>Creates a New EntityQuery For the entity Of the type specified With no Alias Set.</summary>
		''' <typeparam name="TEntity">The type Of the entity To produce the query For.</typeparam>
		''' <returns>ready To use EntityQuery instance</returns>
		Public Function Create(Of TEntity As IEntityCore)() As EntityQuery(Of TEntity)
			Return Create(Of TEntity)(String.Empty)
		End Function

		''' <summary>Creates a New EntityQuery For the entity Of the type specified With the Alias specified As the Alias Set.</summary>
		''' <typeparam name="TEntity">The type Of the entity To produce the query For.</typeparam>
		''' <param name="alias">The Alias.</param>
		''' <returns>ready To use EntityQuery instance</returns>
		Public Function Create(Of TEntity As IEntityCore)([Alias] As String) As EntityQuery(Of TEntity)
			Return New EntityQuery(Of TEntity)(New ElementCreator(), [Alias], Me.GetNextAliasCounterValue())
		End Function

		''' <summary>Creates a New field Object With the name specified And Of resulttype 'object'. Used for referring to aliased fields in another projection.</summary>
		''' <param name="fieldName">Name Of the field.</param>
		''' <returns>Ready To use field Object</returns>
		Public Function Field(fieldName As String) As EntityField2
			Return Field(Of Object)(String.Empty, fieldName)
		End Function

		''' <summary>Creates a New field Object With the name specified And Of resulttype 'object'. Used for referring to aliased fields in another projection.</summary>
		''' <param name="targetAlias">The Alias Of the table/query To target.</param>
		''' <param name="fieldName">Name Of the field.</param>
		''' <returns>Ready To use field Object</returns>
		Public Function Field(targetAlias As String, fieldName As String) As EntityField2
			Return Field(Of Object)(targetAlias, fieldName)
		End Function

		''' <summary>Creates a New field Object With the name specified And Of resulttype 'TValue'. Used for referring to aliased fields in another projection.</summary>
		''' <typeparam name="TValue">The type Of the value represented by the field.</typeparam>
		''' <param name="fieldName">Name Of the field.</param>
		''' <returns>Ready To use field Object</returns>
		Public Function Field(Of TValue)(fieldName As String) As EntityField2 
			Return Field(Of TValue)(String.Empty, fieldName)
		End Function

		''' <summary>Creates a New field Object With the name specified And Of resulttype 'TValue'. Used for referring to aliased fields in another projection.</summary>
		''' <typeparam name="TValue">The type Of the value represented by the field.</typeparam>
		''' <param name="targetAlias">The Alias Of the table/query To target.</param>
		''' <param name="fieldName">Name Of the field.</param>
		''' <returns>Ready To use field Object</returns>
		Public Function Field(Of TValue)(targetAlias As String, fieldName As String) As EntityField2 
			Return New EntityField2(fieldName, targetAlias, GetType(TValue))
		End Function

		''' <summary>Gets the Next Alias counter value To produce artifical aliases With</summary>
		Protected Function GetNextAliasCounterValue() As Integer
			_aliasCounter+=1
			Return _aliasCounter
		End Function

		''' <summary>Creates And returns a New EntityQuery For the AlertCategory entity</summary>
		Public ReadOnly Property [AlertCategory] As EntityQuery(Of AlertCategoryEntity)
			Get
				Return Create(Of AlertCategoryEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertCategoryCriteria entity</summary>
		Public ReadOnly Property [AlertCategoryCriteria] As EntityQuery(Of AlertCategoryCriteriaEntity)
			Get
				Return Create(Of AlertCategoryCriteriaEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertChangeTypeCriteria entity</summary>
		Public ReadOnly Property [AlertChangeTypeCriteria] As EntityQuery(Of AlertChangeTypeCriteriaEntity)
			Get
				Return Create(Of AlertChangeTypeCriteriaEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertConfig entity</summary>
		Public ReadOnly Property [AlertConfig] As EntityQuery(Of AlertConfigEntity)
			Get
				Return Create(Of AlertConfigEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertConfigCircount entity</summary>
		Public ReadOnly Property [AlertConfigCircount] As EntityQuery(Of AlertConfigCircountEntity)
			Get
				Return Create(Of AlertConfigCircountEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertFrequency entity</summary>
		Public ReadOnly Property [AlertFrequency] As EntityQuery(Of AlertFrequencyEntity)
			Get
				Return Create(Of AlertFrequencyEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertReceiver entity</summary>
		Public ReadOnly Property [AlertReceiver] As EntityQuery(Of AlertReceiverEntity)
			Get
				Return Create(Of AlertReceiverEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertReceiverRoleType entity</summary>
		Public ReadOnly Property [AlertReceiverRoleType] As EntityQuery(Of AlertReceiverRoleTypeEntity)
			Get
				Return Create(Of AlertReceiverRoleTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertReceiverType entity</summary>
		Public ReadOnly Property [AlertReceiverType] As EntityQuery(Of AlertReceiverTypeEntity)
			Get
				Return Create(Of AlertReceiverTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AlertServiceSettings entity</summary>
		Public ReadOnly Property [AlertServiceSettings] As EntityQuery(Of AlertServiceSettingsEntity)
			Get
				Return Create(Of AlertServiceSettingsEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the AnyChanges entity</summary>
		Public ReadOnly Property [AnyChanges] As EntityQuery(Of AnyChangesEntity)
			Get
				Return Create(Of AnyChangesEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Brand entity</summary>
		Public ReadOnly Property [Brand] As EntityQuery(Of BrandEntity)
			Get
				Return Create(Of BrandEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Brand2DocumentTemplate entity</summary>
		Public ReadOnly Property [Brand2DocumentTemplate] As EntityQuery(Of Brand2DocumentTemplateEntity)
			Get
				Return Create(Of Brand2DocumentTemplateEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Brand2Feature entity</summary>
		Public ReadOnly Property [Brand2Feature] As EntityQuery(Of Brand2FeatureEntity)
			Get
				Return Create(Of Brand2FeatureEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Brand2StandardMilestone entity</summary>
		Public ReadOnly Property [Brand2StandardMilestone] As EntityQuery(Of Brand2StandardMilestoneEntity)
			Get
				Return Create(Of Brand2StandardMilestoneEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the BusinessProcess entity</summary>
		Public ReadOnly Property [BusinessProcess] As EntityQuery(Of BusinessProcessEntity)
			Get
				Return Create(Of BusinessProcessEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case entity</summary>
		Public ReadOnly Property [Case] As EntityQuery(Of CaseEntity)
			Get
				Return Create(Of CaseEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2CaseBundle entity</summary>
		Public ReadOnly Property [Case2CaseBundle] As EntityQuery(Of Case2CaseBundleEntity)
			Get
				Return Create(Of Case2CaseBundleEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2ComponentType entity</summary>
		Public ReadOnly Property [Case2ComponentType] As EntityQuery(Of Case2ComponentTypeEntity)
			Get
				Return Create(Of Case2ComponentTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2Item entity</summary>
		Public ReadOnly Property [Case2Item] As EntityQuery(Of Case2ItemEntity)
			Get
				Return Create(Of Case2ItemEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2KPIRating entity</summary>
		Public ReadOnly Property [Case2KPIRating] As EntityQuery(Of Case2KPIRatingEntity)
			Get
				Return Create(Of Case2KPIRatingEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2LogInfo entity</summary>
		Public ReadOnly Property [Case2LogInfo] As EntityQuery(Of Case2LogInfoEntity)
			Get
				Return Create(Of Case2LogInfoEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2Participant entity</summary>
		Public ReadOnly Property [Case2Participant] As EntityQuery(Of Case2ParticipantEntity)
			Get
				Return Create(Of Case2ParticipantEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2Phase entity</summary>
		Public ReadOnly Property [Case2Phase] As EntityQuery(Of Case2PhaseEntity)
			Get
				Return Create(Of Case2PhaseEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2ReasonCode entity</summary>
		Public ReadOnly Property [Case2ReasonCode] As EntityQuery(Of Case2ReasonCodeEntity)
			Get
				Return Create(Of Case2ReasonCodeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2Sbu entity</summary>
		Public ReadOnly Property [Case2Sbu] As EntityQuery(Of Case2SbuEntity)
			Get
				Return Create(Of Case2SbuEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2ServiceCode entity</summary>
		Public ReadOnly Property [Case2ServiceCode] As EntityQuery(Of Case2ServiceCodeEntity)
			Get
				Return Create(Of Case2ServiceCodeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2Supplier entity</summary>
		Public ReadOnly Property [Case2Supplier] As EntityQuery(Of Case2SupplierEntity)
			Get
				Return Create(Of Case2SupplierEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2Supplier2Stage entity</summary>
		Public ReadOnly Property [Case2Supplier2Stage] As EntityQuery(Of Case2Supplier2StageEntity)
			Get
				Return Create(Of Case2Supplier2StageEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2System entity</summary>
		Public ReadOnly Property [Case2System] As EntityQuery(Of Case2SystemEntity)
			Get
				Return Create(Of Case2SystemEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2TurbineMatrix entity</summary>
		Public ReadOnly Property [Case2TurbineMatrix] As EntityQuery(Of Case2TurbineMatrixEntity)
			Get
				Return Create(Of Case2TurbineMatrixEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Case2TurbineMatrix2Case2Item entity</summary>
		Public ReadOnly Property [Case2TurbineMatrix2Case2Item] As EntityQuery(Of Case2TurbineMatrix2Case2ItemEntity)
			Get
				Return Create(Of Case2TurbineMatrix2Case2ItemEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the CaseBundle entity</summary>
		Public ReadOnly Property [CaseBundle] As EntityQuery(Of CaseBundleEntity)
			Get
				Return Create(Of CaseBundleEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the CaseRelation entity</summary>
		Public ReadOnly Property [CaseRelation] As EntityQuery(Of CaseRelationEntity)
			Get
				Return Create(Of CaseRelationEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Category entity</summary>
		Public ReadOnly Property [Category] As EntityQuery(Of CategoryEntity)
			Get
				Return Create(Of CategoryEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ChangeLog entity</summary>
		Public ReadOnly Property [ChangeLog] As EntityQuery(Of ChangeLogEntity)
			Get
				Return Create(Of ChangeLogEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ChangeType entity</summary>
		Public ReadOnly Property [ChangeType] As EntityQuery(Of ChangeTypeEntity)
			Get
				Return Create(Of ChangeTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Cir entity</summary>
		Public ReadOnly Property [Cir] As EntityQuery(Of CirEntity)
			Get
				Return Create(Of CirEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ClaimStatus entity</summary>
		Public ReadOnly Property [ClaimStatus] As EntityQuery(Of ClaimStatusEntity)
			Get
				Return Create(Of ClaimStatusEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Component entity</summary>
		Public ReadOnly Property [Component] As EntityQuery(Of ComponentEntity)
			Get
				Return Create(Of ComponentEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ComponentType entity</summary>
		Public ReadOnly Property [ComponentType] As EntityQuery(Of ComponentTypeEntity)
			Get
				Return Create(Of ComponentTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Control entity</summary>
		Public ReadOnly Property [Control] As EntityQuery(Of ControlEntity)
			Get
				Return Create(Of ControlEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the CustomColumnsName entity</summary>
		Public ReadOnly Property [CustomColumnsName] As EntityQuery(Of CustomColumnsNameEntity)
			Get
				Return Create(Of CustomColumnsNameEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the CustomColumnsValue entity</summary>
		Public ReadOnly Property [CustomColumnsValue] As EntityQuery(Of CustomColumnsValueEntity)
			Get
				Return Create(Of CustomColumnsValueEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Discussion entity</summary>
		Public ReadOnly Property [Discussion] As EntityQuery(Of DiscussionEntity)
			Get
				Return Create(Of DiscussionEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Document entity</summary>
		Public ReadOnly Property [Document] As EntityQuery(Of DocumentEntity)
			Get
				Return Create(Of DocumentEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the DocumentBinary entity</summary>
		Public ReadOnly Property [DocumentBinary] As EntityQuery(Of DocumentBinaryEntity)
			Get
				Return Create(Of DocumentBinaryEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the DocumentClassification entity</summary>
		Public ReadOnly Property [DocumentClassification] As EntityQuery(Of DocumentClassificationEntity)
			Get
				Return Create(Of DocumentClassificationEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the DocumentStatus entity</summary>
		Public ReadOnly Property [DocumentStatus] As EntityQuery(Of DocumentStatusEntity)
			Get
				Return Create(Of DocumentStatusEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the DocumentTemplate entity</summary>
		Public ReadOnly Property [DocumentTemplate] As EntityQuery(Of DocumentTemplateEntity)
			Get
				Return Create(Of DocumentTemplateEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the DocumentVersion entity</summary>
		Public ReadOnly Property [DocumentVersion] As EntityQuery(Of DocumentVersionEntity)
			Get
				Return Create(Of DocumentVersionEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Erpsystem entity</summary>
		Public ReadOnly Property [Erpsystem] As EntityQuery(Of ErpsystemEntity)
			Get
				Return Create(Of ErpsystemEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Feature entity</summary>
		Public ReadOnly Property [Feature] As EntityQuery(Of FeatureEntity)
			Get
				Return Create(Of FeatureEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Folder entity</summary>
		Public ReadOnly Property [Folder] As EntityQuery(Of FolderEntity)
			Get
				Return Create(Of FolderEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Folder2Document entity</summary>
		Public ReadOnly Property [Folder2Document] As EntityQuery(Of Folder2DocumentEntity)
			Get
				Return Create(Of Folder2DocumentEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the FolderType entity</summary>
		Public ReadOnly Property [FolderType] As EntityQuery(Of FolderTypeEntity)
			Get
				Return Create(Of FolderTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Help entity</summary>
		Public ReadOnly Property [Help] As EntityQuery(Of HelpEntity)
			Get
				Return Create(Of HelpEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the InlineHelp entity</summary>
		Public ReadOnly Property [InlineHelp] As EntityQuery(Of InlineHelpEntity)
			Get
				Return Create(Of InlineHelpEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the InlineHelpText entity</summary>
		Public ReadOnly Property [InlineHelpText] As EntityQuery(Of InlineHelpTextEntity)
			Get
				Return Create(Of InlineHelpTextEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Item entity</summary>
		Public ReadOnly Property [Item] As EntityQuery(Of ItemEntity)
			Get
				Return Create(Of ItemEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ItemStatus entity</summary>
		Public ReadOnly Property [ItemStatus] As EntityQuery(Of ItemStatusEntity)
			Get
				Return Create(Of ItemStatusEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ItemSystemMapping entity</summary>
		Public ReadOnly Property [ItemSystemMapping] As EntityQuery(Of ItemSystemMappingEntity)
			Get
				Return Create(Of ItemSystemMappingEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ItemSystemMappingStagingTable entity</summary>
		Public ReadOnly Property [ItemSystemMappingStagingTable] As EntityQuery(Of ItemSystemMappingStagingTableEntity)
			Get
				Return Create(Of ItemSystemMappingStagingTableEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Language entity</summary>
		Public ReadOnly Property [Language] As EntityQuery(Of LanguageEntity)
			Get
				Return Create(Of LanguageEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the LogInfo entity</summary>
		Public ReadOnly Property [LogInfo] As EntityQuery(Of LogInfoEntity)
			Get
				Return Create(Of LogInfoEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the LogInfo2LogTxt entity</summary>
		Public ReadOnly Property [LogInfo2LogTxt] As EntityQuery(Of LogInfo2LogTxtEntity)
			Get
				Return Create(Of LogInfo2LogTxtEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the LogTxt entity</summary>
		Public ReadOnly Property [LogTxt] As EntityQuery(Of LogTxtEntity)
			Get
				Return Create(Of LogTxtEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Milestone entity</summary>
		Public ReadOnly Property [Milestone] As EntityQuery(Of MilestoneEntity)
			Get
				Return Create(Of MilestoneEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Module entity</summary>
		Public ReadOnly Property [Module] As EntityQuery(Of ModuleEntity)
			Get
				Return Create(Of ModuleEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the News entity</summary>
		Public ReadOnly Property [News] As EntityQuery(Of NewsEntity)
			Get
				Return Create(Of NewsEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the News2Participant entity</summary>
		Public ReadOnly Property [News2Participant] As EntityQuery(Of News2ParticipantEntity)
			Get
				Return Create(Of News2ParticipantEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the OldCimturbine entity</summary>
		Public ReadOnly Property [OldCimturbine] As EntityQuery(Of OldCimturbineEntity)
			Get
				Return Create(Of OldCimturbineEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Participant entity</summary>
		Public ReadOnly Property [Participant] As EntityQuery(Of ParticipantEntity)
			Get
				Return Create(Of ParticipantEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Participant2Role entity</summary>
		Public ReadOnly Property [Participant2Role] As EntityQuery(Of Participant2RoleEntity)
			Get
				Return Create(Of Participant2RoleEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ParticipantLog entity</summary>
		Public ReadOnly Property [ParticipantLog] As EntityQuery(Of ParticipantLogEntity)
			Get
				Return Create(Of ParticipantLogEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ParticipationType entity</summary>
		Public ReadOnly Property [ParticipationType] As EntityQuery(Of ParticipationTypeEntity)
			Get
				Return Create(Of ParticipationTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Payee entity</summary>
		Public ReadOnly Property [Payee] As EntityQuery(Of PayeeEntity)
			Get
				Return Create(Of PayeeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Pbu entity</summary>
		Public ReadOnly Property [Pbu] As EntityQuery(Of PbuEntity)
			Get
				Return Create(Of PbuEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the PerformanceAction entity</summary>
		Public ReadOnly Property [PerformanceAction] As EntityQuery(Of PerformanceActionEntity)
			Get
				Return Create(Of PerformanceActionEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the PerformanceData entity</summary>
		Public ReadOnly Property [PerformanceData] As EntityQuery(Of PerformanceDataEntity)
			Get
				Return Create(Of PerformanceDataEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the PerformanceUtilitySetting entity</summary>
		Public ReadOnly Property [PerformanceUtilitySetting] As EntityQuery(Of PerformanceUtilitySettingEntity)
			Get
				Return Create(Of PerformanceUtilitySettingEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Permission entity</summary>
		Public ReadOnly Property [Permission] As EntityQuery(Of PermissionEntity)
			Get
				Return Create(Of PermissionEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the PersonalSafety entity</summary>
		Public ReadOnly Property [PersonalSafety] As EntityQuery(Of PersonalSafetyEntity)
			Get
				Return Create(Of PersonalSafetyEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Phase entity</summary>
		Public ReadOnly Property [Phase] As EntityQuery(Of PhaseEntity)
			Get
				Return Create(Of PhaseEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Phase2Status entity</summary>
		Public ReadOnly Property [Phase2Status] As EntityQuery(Of Phase2StatusEntity)
			Get
				Return Create(Of Phase2StatusEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Platform entity</summary>
		Public ReadOnly Property [Platform] As EntityQuery(Of PlatformEntity)
			Get
				Return Create(Of PlatformEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Populationlist entity</summary>
		Public ReadOnly Property [Populationlist] As EntityQuery(Of PopulationlistEntity)
			Get
				Return Create(Of PopulationlistEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the PopulationlistDocument entity</summary>
		Public ReadOnly Property [PopulationlistDocument] As EntityQuery(Of PopulationlistDocumentEntity)
			Get
				Return Create(Of PopulationlistDocumentEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the PopulationlistItem entity</summary>
		Public ReadOnly Property [PopulationlistItem] As EntityQuery(Of PopulationlistItemEntity)
			Get
				Return Create(Of PopulationlistItemEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Portfolio entity</summary>
		Public ReadOnly Property [Portfolio] As EntityQuery(Of PortfolioEntity)
			Get
				Return Create(Of PortfolioEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Project entity</summary>
		Public ReadOnly Property [Project] As EntityQuery(Of ProjectEntity)
			Get
				Return Create(Of ProjectEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ProjectScope entity</summary>
		Public ReadOnly Property [ProjectScope] As EntityQuery(Of ProjectScopeEntity)
			Get
				Return Create(Of ProjectScopeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Rc entity</summary>
		Public ReadOnly Property [Rc] As EntityQuery(Of RcEntity)
			Get
				Return Create(Of RcEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the RccomponentOwner entity</summary>
		Public ReadOnly Property [RccomponentOwner] As EntityQuery(Of RccomponentOwnerEntity)
			Get
				Return Create(Of RccomponentOwnerEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Rcorigin entity</summary>
		Public ReadOnly Property [Rcorigin] As EntityQuery(Of RcoriginEntity)
			Get
				Return Create(Of RcoriginEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the RcoriginRelation entity</summary>
		Public ReadOnly Property [RcoriginRelation] As EntityQuery(Of RcoriginRelationEntity)
			Get
				Return Create(Of RcoriginRelationEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the RcoriginResponsible entity</summary>
		Public ReadOnly Property [RcoriginResponsible] As EntityQuery(Of RcoriginResponsibleEntity)
			Get
				Return Create(Of RcoriginResponsibleEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the RcoriginUnit entity</summary>
		Public ReadOnly Property [RcoriginUnit] As EntityQuery(Of RcoriginUnitEntity)
			Get
				Return Create(Of RcoriginUnitEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ReasonCode entity</summary>
		Public ReadOnly Property [ReasonCode] As EntityQuery(Of ReasonCodeEntity)
			Get
				Return Create(Of ReasonCodeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the RelatedCase entity</summary>
		Public ReadOnly Property [RelatedCase] As EntityQuery(Of RelatedCaseEntity)
			Get
				Return Create(Of RelatedCaseEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the RelatedCase2CaseRelation entity</summary>
		Public ReadOnly Property [RelatedCase2CaseRelation] As EntityQuery(Of RelatedCase2CaseRelationEntity)
			Get
				Return Create(Of RelatedCase2CaseRelationEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the RelatedItem entity</summary>
		Public ReadOnly Property [RelatedItem] As EntityQuery(Of RelatedItemEntity)
			Get
				Return Create(Of RelatedItemEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ReportType entity</summary>
		Public ReadOnly Property [ReportType] As EntityQuery(Of ReportTypeEntity)
			Get
				Return Create(Of ReportTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Role entity</summary>
		Public ReadOnly Property [Role] As EntityQuery(Of RoleEntity)
			Get
				Return Create(Of RoleEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Role2Permission entity</summary>
		Public ReadOnly Property [Role2Permission] As EntityQuery(Of Role2PermissionEntity)
			Get
				Return Create(Of Role2PermissionEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Sbu entity</summary>
		Public ReadOnly Property [Sbu] As EntityQuery(Of SbuEntity)
			Get
				Return Create(Of SbuEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Sbuclone entity</summary>
		Public ReadOnly Property [Sbuclone] As EntityQuery(Of SbucloneEntity)
			Get
				Return Create(Of SbucloneEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the SearchProfile entity</summary>
		Public ReadOnly Property [SearchProfile] As EntityQuery(Of SearchProfileEntity)
			Get
				Return Create(Of SearchProfileEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the SearchProfileDetail entity</summary>
		Public ReadOnly Property [SearchProfileDetail] As EntityQuery(Of SearchProfileDetailEntity)
			Get
				Return Create(Of SearchProfileDetailEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ServiceCode entity</summary>
		Public ReadOnly Property [ServiceCode] As EntityQuery(Of ServiceCodeEntity)
			Get
				Return Create(Of ServiceCodeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ServiceGroup entity</summary>
		Public ReadOnly Property [ServiceGroup] As EntityQuery(Of ServiceGroupEntity)
			Get
				Return Create(Of ServiceGroupEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the ServiceType entity</summary>
		Public ReadOnly Property [ServiceType] As EntityQuery(Of ServiceTypeEntity)
			Get
				Return Create(Of ServiceTypeEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Stage entity</summary>
		Public ReadOnly Property [Stage] As EntityQuery(Of StageEntity)
			Get
				Return Create(Of StageEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the StandardFolder entity</summary>
		Public ReadOnly Property [StandardFolder] As EntityQuery(Of StandardFolderEntity)
			Get
				Return Create(Of StandardFolderEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the StandardMilestone entity</summary>
		Public ReadOnly Property [StandardMilestone] As EntityQuery(Of StandardMilestoneEntity)
			Get
				Return Create(Of StandardMilestoneEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the StandardTask entity</summary>
		Public ReadOnly Property [StandardTask] As EntityQuery(Of StandardTaskEntity)
			Get
				Return Create(Of StandardTaskEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the StandardTask2Status entity</summary>
		Public ReadOnly Property [StandardTask2Status] As EntityQuery(Of StandardTask2StatusEntity)
			Get
				Return Create(Of StandardTask2StatusEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the State entity</summary>
		Public ReadOnly Property [State] As EntityQuery(Of StateEntity)
			Get
				Return Create(Of StateEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Status entity</summary>
		Public ReadOnly Property [Status] As EntityQuery(Of StatusEntity)
			Get
				Return Create(Of StatusEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Supplier entity</summary>
		Public ReadOnly Property [Supplier] As EntityQuery(Of SupplierEntity)
			Get
				Return Create(Of SupplierEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the SupplierEnvironment entity</summary>
		Public ReadOnly Property [SupplierEnvironment] As EntityQuery(Of SupplierEnvironmentEntity)
			Get
				Return Create(Of SupplierEnvironmentEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the SystemDescription entity</summary>
		Public ReadOnly Property [SystemDescription] As EntityQuery(Of SystemDescriptionEntity)
			Get
				Return Create(Of SystemDescriptionEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Task entity</summary>
		Public ReadOnly Property [Task] As EntityQuery(Of TaskEntity)
			Get
				Return Create(Of TaskEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TaskMilestone entity</summary>
		Public ReadOnly Property [TaskMilestone] As EntityQuery(Of TaskMilestoneEntity)
			Get
				Return Create(Of TaskMilestoneEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Timeline entity</summary>
		Public ReadOnly Property [Timeline] As EntityQuery(Of TimelineEntity)
			Get
				Return Create(Of TimelineEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Turbine entity</summary>
		Public ReadOnly Property [Turbine] As EntityQuery(Of TurbineEntity)
			Get
				Return Create(Of TurbineEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineFrequency entity</summary>
		Public ReadOnly Property [TurbineFrequency] As EntityQuery(Of TurbineFrequencyEntity)
			Get
				Return Create(Of TurbineFrequencyEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineManufacturer entity</summary>
		Public ReadOnly Property [TurbineManufacturer] As EntityQuery(Of TurbineManufacturerEntity)
			Get
				Return Create(Of TurbineManufacturerEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineMarkVersion entity</summary>
		Public ReadOnly Property [TurbineMarkVersion] As EntityQuery(Of TurbineMarkVersionEntity)
			Get
				Return Create(Of TurbineMarkVersionEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineMatrix entity</summary>
		Public ReadOnly Property [TurbineMatrix] As EntityQuery(Of TurbineMatrixEntity)
			Get
				Return Create(Of TurbineMatrixEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineNominelPower entity</summary>
		Public ReadOnly Property [TurbineNominelPower] As EntityQuery(Of TurbineNominelPowerEntity)
			Get
				Return Create(Of TurbineNominelPowerEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineOld entity</summary>
		Public ReadOnly Property [TurbineOld] As EntityQuery(Of TurbineOldEntity)
			Get
				Return Create(Of TurbineOldEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbinePlacement entity</summary>
		Public ReadOnly Property [TurbinePlacement] As EntityQuery(Of TurbinePlacementEntity)
			Get
				Return Create(Of TurbinePlacementEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbinePowerRegulation entity</summary>
		Public ReadOnly Property [TurbinePowerRegulation] As EntityQuery(Of TurbinePowerRegulationEntity)
			Get
				Return Create(Of TurbinePowerRegulationEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineRotorDiameter entity</summary>
		Public ReadOnly Property [TurbineRotorDiameter] As EntityQuery(Of TurbineRotorDiameterEntity)
			Get
				Return Create(Of TurbineRotorDiameterEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineSmallGenerator entity</summary>
		Public ReadOnly Property [TurbineSmallGenerator] As EntityQuery(Of TurbineSmallGeneratorEntity)
			Get
				Return Create(Of TurbineSmallGeneratorEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineTemperatureVariant entity</summary>
		Public ReadOnly Property [TurbineTemperatureVariant] As EntityQuery(Of TurbineTemperatureVariantEntity)
			Get
				Return Create(Of TurbineTemperatureVariantEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the TurbineVoltage entity</summary>
		Public ReadOnly Property [TurbineVoltage] As EntityQuery(Of TurbineVoltageEntity)
			Get
				Return Create(Of TurbineVoltageEntity)()
			End Get
		End Property

		''' <summary>Creates And returns a New EntityQuery For the Visits entity</summary>
		Public ReadOnly Property [Visits] As EntityQuery(Of VisitsEntity)
			Get
				Return Create(Of VisitsEntity)()
			End Get
		End Property

  

	End Class
End Namespace