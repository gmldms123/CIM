﻿' ///////////////////////////////////////////////////////////////
' This is generated code. If you modify this code, be aware
' of the fact that when you re-generate the code, your changes
' are lost. If you want to keep your changes, make this file read-only
' when you have finished your changes, however it is recommended that
' you inherit from this class to extend the functionality of this generated
' class or you modify / extend the templates used to generate this code.
' //////////////////////////////////////////////////////////////
' Code is generated using LLBLGen Pro version: 4.0
' Code is generated on: 
' Code is generated using templates: SD.TemplateBindings.SharedTemplates
' Templates vendor: Solutions Design.
' Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
Imports SD.LLBLGen.Pro.ORMSupportClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data

Namespace PManagement.Data.HelperClasses

	''' <summary>Field Creation Class for entity AlertCategoryEntity</summary>
	Public Class AlertCategoryFields

		''' <summary>Creates a new AlertCategoryEntity.AlertCategoryId field instance</summary>
		Public Shared ReadOnly Property [AlertCategoryId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryFieldIndex.AlertCategoryId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertCategoryCriteriaEntity</summary>
	Public Class AlertCategoryCriteriaFields

		''' <summary>Creates a new AlertCategoryCriteriaEntity.AlertCategoryCriteriaId field instance</summary>
		Public Shared ReadOnly Property [AlertCategoryCriteriaId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.AlertCategoryCriteriaId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryCriteriaEntity.AlertConfigId field instance</summary>
		Public Shared ReadOnly Property [AlertConfigId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.AlertConfigId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryCriteriaEntity.AlertCategoryId field instance</summary>
		Public Shared ReadOnly Property [AlertCategoryId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.AlertCategoryId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryCriteriaEntity.Value field instance</summary>
		Public Shared ReadOnly Property [Value] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.Value), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryCriteriaEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryCriteriaEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryCriteriaEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertCategoryCriteriaEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertCategoryCriteriaFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertChangeTypeCriteriaEntity</summary>
	Public Class AlertChangeTypeCriteriaFields

		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.AlertChangeTypeCriteriaId field instance</summary>
		Public Shared ReadOnly Property [AlertChangeTypeCriteriaId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.AlertChangeTypeCriteriaId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.AlertConfigId field instance</summary>
		Public Shared ReadOnly Property [AlertConfigId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.AlertConfigId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.ChangeTypeId field instance</summary>
		Public Shared ReadOnly Property [ChangeTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.ChangeTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.Value field instance</summary>
		Public Shared ReadOnly Property [Value] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.Value), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertChangeTypeCriteriaEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertChangeTypeCriteriaFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertConfigEntity</summary>
	Public Class AlertConfigFields

		''' <summary>Creates a new AlertConfigEntity.AlertConfigId field instance</summary>
		Public Shared ReadOnly Property [AlertConfigId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigFieldIndex.AlertConfigId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigEntity.AlertFrequencyId field instance</summary>
		Public Shared ReadOnly Property [AlertFrequencyId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigFieldIndex.AlertFrequencyId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigEntity.LastHandled field instance</summary>
		Public Shared ReadOnly Property [LastHandled] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigFieldIndex.LastHandled), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertConfigCircountEntity</summary>
	Public Class AlertConfigCircountFields

		''' <summary>Creates a new AlertConfigCircountEntity.AlertConfigCircountId field instance</summary>
		Public Shared ReadOnly Property [AlertConfigCircountId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigCircountFieldIndex.AlertConfigCircountId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigCircountEntity.AlertConfigId field instance</summary>
		Public Shared ReadOnly Property [AlertConfigId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigCircountFieldIndex.AlertConfigId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertConfigCircountEntity.Count field instance</summary>
		Public Shared ReadOnly Property [Count] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertConfigCircountFieldIndex.Count), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertFrequencyEntity</summary>
	Public Class AlertFrequencyFields

		''' <summary>Creates a new AlertFrequencyEntity.AlertFrequencyId field instance</summary>
		Public Shared ReadOnly Property [AlertFrequencyId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.AlertFrequencyId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.HandleDay field instance</summary>
		Public Shared ReadOnly Property [HandleDay] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.HandleDay), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.HandleFrequency field instance</summary>
		Public Shared ReadOnly Property [HandleFrequency] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.HandleFrequency), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.HandleTime field instance</summary>
		Public Shared ReadOnly Property [HandleTime] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.HandleTime), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertFrequencyEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertFrequencyFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertReceiverEntity</summary>
	Public Class AlertReceiverFields

		''' <summary>Creates a new AlertReceiverEntity.AlertReceiverId field instance</summary>
		Public Shared ReadOnly Property [AlertReceiverId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.AlertReceiverId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.AlertConfigId field instance</summary>
		Public Shared ReadOnly Property [AlertConfigId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.AlertConfigId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.Value field instance</summary>
		Public Shared ReadOnly Property [Value] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.Value), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.AlertReceiverTypeId field instance</summary>
		Public Shared ReadOnly Property [AlertReceiverTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.AlertReceiverTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverEntity.IsGroup field instance</summary>
		Public Shared ReadOnly Property [IsGroup] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverFieldIndex.IsGroup), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertReceiverRoleTypeEntity</summary>
	Public Class AlertReceiverRoleTypeFields

		''' <summary>Creates a new AlertReceiverRoleTypeEntity.AlertReceiverRoleTypeId field instance</summary>
		Public Shared ReadOnly Property [AlertReceiverRoleTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverRoleTypeFieldIndex.AlertReceiverRoleTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverRoleTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverRoleTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverRoleTypeEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverRoleTypeFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverRoleTypeEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverRoleTypeFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverRoleTypeEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverRoleTypeFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverRoleTypeEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverRoleTypeFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertReceiverTypeEntity</summary>
	Public Class AlertReceiverTypeFields

		''' <summary>Creates a new AlertReceiverTypeEntity.AlertReceiverTypeId field instance</summary>
		Public Shared ReadOnly Property [AlertReceiverTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverTypeFieldIndex.AlertReceiverTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverTypeEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverTypeFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverTypeEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverTypeFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverTypeEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverTypeFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertReceiverTypeEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertReceiverTypeFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AlertServiceSettingsEntity</summary>
	Public Class AlertServiceSettingsFields

		''' <summary>Creates a new AlertServiceSettingsEntity.AlertServiceSettingId field instance</summary>
		Public Shared ReadOnly Property [AlertServiceSettingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertServiceSettingsFieldIndex.AlertServiceSettingId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertServiceSettingsEntity.LastRun field instance</summary>
		Public Shared ReadOnly Property [LastRun] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertServiceSettingsFieldIndex.LastRun), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertServiceSettingsEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertServiceSettingsFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertServiceSettingsEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertServiceSettingsFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertServiceSettingsEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertServiceSettingsFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AlertServiceSettingsEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AlertServiceSettingsFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity AnyChangesEntity</summary>
	Public Class AnyChangesFields

		''' <summary>Creates a new AnyChangesEntity.AnyChangesId field instance</summary>
		Public Shared ReadOnly Property [AnyChangesId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AnyChangesFieldIndex.AnyChangesId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AnyChangesEntity.WindowNo field instance</summary>
		Public Shared ReadOnly Property [WindowNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AnyChangesFieldIndex.WindowNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new AnyChangesEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(AnyChangesFieldIndex.Description), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity BrandEntity</summary>
	Public Class BrandFields

		''' <summary>Creates a new BrandEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BrandFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new BrandEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BrandFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new BrandEntity.InitialPortfolioId field instance</summary>
		Public Shared ReadOnly Property [InitialPortfolioId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BrandFieldIndex.InitialPortfolioId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new BrandEntity.CaseStandbyTextUrl field instance</summary>
		Public Shared ReadOnly Property [CaseStandbyTextUrl] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BrandFieldIndex.CaseStandbyTextUrl), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new BrandEntity.PortalUrl field instance</summary>
		Public Shared ReadOnly Property [PortalUrl] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BrandFieldIndex.PortalUrl), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new BrandEntity.MasterMinorText field instance</summary>
		Public Shared ReadOnly Property [MasterMinorText] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BrandFieldIndex.MasterMinorText), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new BrandEntity.SharepointNewsChannelId field instance</summary>
		Public Shared ReadOnly Property [SharepointNewsChannelId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BrandFieldIndex.SharepointNewsChannelId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Brand2DocumentTemplateEntity</summary>
	Public Class Brand2DocumentTemplateFields

		''' <summary>Creates a new Brand2DocumentTemplateEntity.Brand2DocumentTemplateId field instance</summary>
		Public Shared ReadOnly Property [Brand2DocumentTemplateId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2DocumentTemplateFieldIndex.Brand2DocumentTemplateId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Brand2DocumentTemplateEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2DocumentTemplateFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Brand2DocumentTemplateEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2DocumentTemplateFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Brand2DocumentTemplateEntity.DocumentTemplateId field instance</summary>
		Public Shared ReadOnly Property [DocumentTemplateId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2DocumentTemplateFieldIndex.DocumentTemplateId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Brand2FeatureEntity</summary>
	Public Class Brand2FeatureFields

		''' <summary>Creates a new Brand2FeatureEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2FeatureFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Brand2FeatureEntity.FeatureId field instance</summary>
		Public Shared ReadOnly Property [FeatureId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2FeatureFieldIndex.FeatureId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Brand2FeatureEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2FeatureFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Brand2StandardMilestoneEntity</summary>
	Public Class Brand2StandardMilestoneFields

		''' <summary>Creates a new Brand2StandardMilestoneEntity.Brand2StandardMilestoneId field instance</summary>
		Public Shared ReadOnly Property [Brand2StandardMilestoneId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2StandardMilestoneFieldIndex.Brand2StandardMilestoneId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Brand2StandardMilestoneEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2StandardMilestoneFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Brand2StandardMilestoneEntity.StandardMilestoneId field instance</summary>
		Public Shared ReadOnly Property [StandardMilestoneId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Brand2StandardMilestoneFieldIndex.StandardMilestoneId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity BusinessProcessEntity</summary>
	Public Class BusinessProcessFields

		''' <summary>Creates a new BusinessProcessEntity.BusinessProcessId field instance</summary>
		Public Shared ReadOnly Property [BusinessProcessId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BusinessProcessFieldIndex.BusinessProcessId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new BusinessProcessEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(BusinessProcessFieldIndex.Description), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity CaseEntity</summary>
	Public Class CaseFields

		''' <summary>Creates a new CaseEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.CaseNo field instance</summary>
		Public Shared ReadOnly Property [CaseNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.CaseNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.StatusId field instance</summary>
		Public Shared ReadOnly Property [StatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.StatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ClaimStatusId field instance</summary>
		Public Shared ReadOnly Property [ClaimStatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ClaimStatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Pbuid field instance</summary>
		Public Shared ReadOnly Property [Pbuid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Pbuid), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ProjectPortalId field instance</summary>
		Public Shared ReadOnly Property [ProjectPortalId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ProjectPortalId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ManagerId field instance</summary>
		Public Shared ReadOnly Property [ManagerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ManagerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Uplink field instance</summary>
		Public Shared ReadOnly Property [Uplink] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Uplink), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.LastEdited field instance</summary>
		Public Shared ReadOnly Property [LastEdited] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.LastEdited), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.LastEditedById field instance</summary>
		Public Shared ReadOnly Property [LastEditedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.LastEditedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.StandbyText field instance</summary>
		Public Shared ReadOnly Property [StandbyText] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.StandbyText), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ConfirmedBySupplier field instance</summary>
		Public Shared ReadOnly Property [ConfirmedBySupplier] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ConfirmedBySupplier), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.HasProcessedMsprojectPlan field instance</summary>
		Public Shared ReadOnly Property [HasProcessedMsprojectPlan] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.HasProcessedMsprojectPlan), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.StartDate field instance</summary>
		Public Shared ReadOnly Property [StartDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.StartDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.FinishDate field instance</summary>
		Public Shared ReadOnly Property [FinishDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.FinishDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.DurationHours field instance</summary>
		Public Shared ReadOnly Property [DurationHours] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.DurationHours), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.PercentComplete field instance</summary>
		Public Shared ReadOnly Property [PercentComplete] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.PercentComplete), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.SalesOption field instance</summary>
		Public Shared ReadOnly Property [SalesOption] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.SalesOption), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Platform field instance</summary>
		Public Shared ReadOnly Property [Platform] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Platform), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ClosureDate field instance</summary>
		Public Shared ReadOnly Property [ClosureDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ClosureDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ReopenDate field instance</summary>
		Public Shared ReadOnly Property [ReopenDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ReopenDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.TechnicalSpecialistId field instance</summary>
		Public Shared ReadOnly Property [TechnicalSpecialistId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.TechnicalSpecialistId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ExecutionManagerId field instance</summary>
		Public Shared ReadOnly Property [ExecutionManagerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ExecutionManagerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ClosedForInvoicing field instance</summary>
		Public Shared ReadOnly Property [ClosedForInvoicing] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ClosedForInvoicing), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.PortfolioId field instance</summary>
		Public Shared ReadOnly Property [PortfolioId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.PortfolioId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.BusinessProcessId field instance</summary>
		Public Shared ReadOnly Property [BusinessProcessId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.BusinessProcessId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.StandardTaskId field instance</summary>
		Public Shared ReadOnly Property [StandardTaskId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.StandardTaskId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.StandardTask_ field instance</summary>
		Public Shared ReadOnly Property [StandardTask_] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.StandardTask_), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.StateChangedDate field instance</summary>
		Public Shared ReadOnly Property [StateChangedDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.StateChangedDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.CategoryId field instance</summary>
		Public Shared ReadOnly Property [CategoryId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.CategoryId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ComponentId field instance</summary>
		Public Shared ReadOnly Property [ComponentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ComponentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.PersonalSafetyId field instance</summary>
		Public Shared ReadOnly Property [PersonalSafetyId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.PersonalSafetyId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Bleeding field instance</summary>
		Public Shared ReadOnly Property [Bleeding] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Bleeding), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.SafetyAlert field instance</summary>
		Public Shared ReadOnly Property [SafetyAlert] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.SafetyAlert), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Dmsdocument field instance</summary>
		Public Shared ReadOnly Property [Dmsdocument] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Dmsdocument), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ReferenceNumber field instance</summary>
		Public Shared ReadOnly Property [ReferenceNumber] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ReferenceNumber), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.Econumber field instance</summary>
		Public Shared ReadOnly Property [Econumber] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.Econumber), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ContainmentLeadId field instance</summary>
		Public Shared ReadOnly Property [ContainmentLeadId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ContainmentLeadId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseEntity.ProjectScopeId field instance</summary>
		Public Shared ReadOnly Property [ProjectScopeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseFieldIndex.ProjectScopeId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2CaseBundleEntity</summary>
	Public Class Case2CaseBundleFields

		''' <summary>Creates a new Case2CaseBundleEntity.Case2CaseBundleId field instance</summary>
		Public Shared ReadOnly Property [Case2CaseBundleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2CaseBundleFieldIndex.Case2CaseBundleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2CaseBundleEntity.CaseBundleId field instance</summary>
		Public Shared ReadOnly Property [CaseBundleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2CaseBundleFieldIndex.CaseBundleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2CaseBundleEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2CaseBundleFieldIndex.CaseId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2ComponentTypeEntity</summary>
	Public Class Case2ComponentTypeFields

		''' <summary>Creates a new Case2ComponentTypeEntity.Case2ComponentTypeId field instance</summary>
		Public Shared ReadOnly Property [Case2ComponentTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ComponentTypeFieldIndex.Case2ComponentTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ComponentTypeEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ComponentTypeFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ComponentTypeEntity.ComponentTypeId field instance</summary>
		Public Shared ReadOnly Property [ComponentTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ComponentTypeFieldIndex.ComponentTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ComponentTypeEntity.SupplierLink field instance</summary>
		Public Shared ReadOnly Property [SupplierLink] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ComponentTypeFieldIndex.SupplierLink), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2ItemEntity</summary>
	Public Class Case2ItemFields

		''' <summary>Creates a new Case2ItemEntity.Case2ItemId field instance</summary>
		Public Shared ReadOnly Property [Case2ItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ItemFieldIndex.Case2ItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ItemEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ItemFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ItemEntity.ItemId field instance</summary>
		Public Shared ReadOnly Property [ItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ItemFieldIndex.ItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ItemEntity.Root field instance</summary>
		Public Shared ReadOnly Property [Root] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ItemFieldIndex.Root), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2KPIRatingEntity</summary>
	Public Class Case2KPIRatingFields

		''' <summary>Creates a new Case2KPIRatingEntity.Case2KPIRatingId field instance</summary>
		Public Shared ReadOnly Property [Case2KPIRatingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2KPIRatingFieldIndex.Case2KPIRatingId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2KPIRatingEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2KPIRatingFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2KPIRatingEntity.KPIRatingId field instance</summary>
		Public Shared ReadOnly Property [KPIRatingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2KPIRatingFieldIndex.KPIRatingId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2LogInfoEntity</summary>
	Public Class Case2LogInfoFields

		''' <summary>Creates a new Case2LogInfoEntity.Case2LogInfoId field instance</summary>
		Public Shared ReadOnly Property [Case2LogInfoId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2LogInfoFieldIndex.Case2LogInfoId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2LogInfoEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2LogInfoFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2LogInfoEntity.LogInfoId field instance</summary>
		Public Shared ReadOnly Property [LogInfoId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2LogInfoFieldIndex.LogInfoId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2ParticipantEntity</summary>
	Public Class Case2ParticipantFields

		''' <summary>Creates a new Case2ParticipantEntity.Case2ParticipantId field instance</summary>
		Public Shared ReadOnly Property [Case2ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ParticipantFieldIndex.Case2ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ParticipantEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ParticipantFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ParticipantEntity.ParticipantId field instance</summary>
		Public Shared ReadOnly Property [ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ParticipantFieldIndex.ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ParticipantEntity.ParticipationTypeId field instance</summary>
		Public Shared ReadOnly Property [ParticipationTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ParticipantFieldIndex.ParticipationTypeId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2PhaseEntity</summary>
	Public Class Case2PhaseFields

		''' <summary>Creates a new Case2PhaseEntity.Case2PhaseId field instance</summary>
		Public Shared ReadOnly Property [Case2PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.Case2PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.Relevant field instance</summary>
		Public Shared ReadOnly Property [Relevant] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.Relevant), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.Budget field instance</summary>
		Public Shared ReadOnly Property [Budget] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.Budget), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.Realised field instance</summary>
		Public Shared ReadOnly Property [Realised] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.Realised), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.StartDate field instance</summary>
		Public Shared ReadOnly Property [StartDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.StartDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.DeadlineDate field instance</summary>
		Public Shared ReadOnly Property [DeadlineDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.DeadlineDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.FinishDate field instance</summary>
		Public Shared ReadOnly Property [FinishDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.FinishDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.DurationHours field instance</summary>
		Public Shared ReadOnly Property [DurationHours] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.DurationHours), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.PercentComplete field instance</summary>
		Public Shared ReadOnly Property [PercentComplete] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.PercentComplete), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2PhaseEntity.ScheduleComments field instance</summary>
		Public Shared ReadOnly Property [ScheduleComments] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2PhaseFieldIndex.ScheduleComments), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2ReasonCodeEntity</summary>
	Public Class Case2ReasonCodeFields

		''' <summary>Creates a new Case2ReasonCodeEntity.Case2ReasonCodeId field instance</summary>
		Public Shared ReadOnly Property [Case2ReasonCodeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ReasonCodeFieldIndex.Case2ReasonCodeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ReasonCodeEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ReasonCodeFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ReasonCodeEntity.ReasonCodeId field instance</summary>
		Public Shared ReadOnly Property [ReasonCodeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ReasonCodeFieldIndex.ReasonCodeId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2SbuEntity</summary>
	Public Class Case2SbuFields

		''' <summary>Creates a new Case2SbuEntity.Case2Sbuid field instance</summary>
		Public Shared ReadOnly Property [Case2Sbuid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SbuFieldIndex.Case2Sbuid), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SbuEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SbuFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SbuEntity.Sbuid field instance</summary>
		Public Shared ReadOnly Property [Sbuid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SbuFieldIndex.Sbuid), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2ServiceCodeEntity</summary>
	Public Class Case2ServiceCodeFields

		''' <summary>Creates a new Case2ServiceCodeEntity.Case2ServiceCodeId field instance</summary>
		Public Shared ReadOnly Property [Case2ServiceCodeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ServiceCodeFieldIndex.Case2ServiceCodeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ServiceCodeEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ServiceCodeFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2ServiceCodeEntity.ServiceCodeId field instance</summary>
		Public Shared ReadOnly Property [ServiceCodeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2ServiceCodeFieldIndex.ServiceCodeId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2SupplierEntity</summary>
	Public Class Case2SupplierFields

		''' <summary>Creates a new Case2SupplierEntity.Case2SupplierId field instance</summary>
		Public Shared ReadOnly Property [Case2SupplierId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SupplierFieldIndex.Case2SupplierId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SupplierEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SupplierFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SupplierEntity.SupplierId field instance</summary>
		Public Shared ReadOnly Property [SupplierId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SupplierFieldIndex.SupplierId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SupplierEntity.FailedItem field instance</summary>
		Public Shared ReadOnly Property [FailedItem] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SupplierFieldIndex.FailedItem), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SupplierEntity.RootItem field instance</summary>
		Public Shared ReadOnly Property [RootItem] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SupplierFieldIndex.RootItem), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2Supplier2StageEntity</summary>
	Public Class Case2Supplier2StageFields

		''' <summary>Creates a new Case2Supplier2StageEntity.Case2Supplier2StageId field instance</summary>
		Public Shared ReadOnly Property [Case2Supplier2StageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2Supplier2StageFieldIndex.Case2Supplier2StageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2Supplier2StageEntity.Case2SupplierId field instance</summary>
		Public Shared ReadOnly Property [Case2SupplierId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2Supplier2StageFieldIndex.Case2SupplierId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2Supplier2StageEntity.StageId field instance</summary>
		Public Shared ReadOnly Property [StageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2Supplier2StageFieldIndex.StageId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2SystemEntity</summary>
	Public Class Case2SystemFields

		''' <summary>Creates a new Case2SystemEntity.Case2SystemId field instance</summary>
		Public Shared ReadOnly Property [Case2SystemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SystemFieldIndex.Case2SystemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SystemEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SystemFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SystemEntity.System field instance</summary>
		Public Shared ReadOnly Property [System] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SystemFieldIndex.System), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2SystemEntity.SystemChecked field instance</summary>
		Public Shared ReadOnly Property [SystemChecked] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2SystemFieldIndex.SystemChecked), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2TurbineMatrixEntity</summary>
	Public Class Case2TurbineMatrixFields

		''' <summary>Creates a new Case2TurbineMatrixEntity.Case2TurbineMatrixId field instance</summary>
		Public Shared ReadOnly Property [Case2TurbineMatrixId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrixFieldIndex.Case2TurbineMatrixId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrixEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrixFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrixEntity.TurbineMatrixId field instance</summary>
		Public Shared ReadOnly Property [TurbineMatrixId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrixFieldIndex.TurbineMatrixId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrixEntity.InitialFailed field instance</summary>
		Public Shared ReadOnly Property [InitialFailed] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrixFieldIndex.InitialFailed), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrixEntity.MkversionExpected field instance</summary>
		Public Shared ReadOnly Property [MkversionExpected] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrixFieldIndex.MkversionExpected), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrixEntity.MkversionActual field instance</summary>
		Public Shared ReadOnly Property [MkversionActual] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrixFieldIndex.MkversionActual), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Case2TurbineMatrix2Case2ItemEntity</summary>
	Public Class Case2TurbineMatrix2Case2ItemFields

		''' <summary>Creates a new Case2TurbineMatrix2Case2ItemEntity.Case2TurbineMatrix2Case2ItemId field instance</summary>
		Public Shared ReadOnly Property [Case2TurbineMatrix2Case2ItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrix2Case2ItemFieldIndex.Case2TurbineMatrix2Case2ItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrix2Case2ItemEntity.Case2TurbineMatrixId field instance</summary>
		Public Shared ReadOnly Property [Case2TurbineMatrixId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrix2Case2ItemFieldIndex.Case2TurbineMatrixId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrix2Case2ItemEntity.Case2ItemId field instance</summary>
		Public Shared ReadOnly Property [Case2ItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrix2Case2ItemFieldIndex.Case2ItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrix2Case2ItemEntity.StageId field instance</summary>
		Public Shared ReadOnly Property [StageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrix2Case2ItemFieldIndex.StageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrix2Case2ItemEntity.Count field instance</summary>
		Public Shared ReadOnly Property [Count] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrix2Case2ItemFieldIndex.Count), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Case2TurbineMatrix2Case2ItemEntity.InitialFailed field instance</summary>
		Public Shared ReadOnly Property [InitialFailed] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Case2TurbineMatrix2Case2ItemFieldIndex.InitialFailed), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity CaseBundleEntity</summary>
	Public Class CaseBundleFields

		''' <summary>Creates a new CaseBundleEntity.CaseBundleId field instance</summary>
		Public Shared ReadOnly Property [CaseBundleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseBundleFieldIndex.CaseBundleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseBundleEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseBundleFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity CaseRelationEntity</summary>
	Public Class CaseRelationFields

		''' <summary>Creates a new CaseRelationEntity.CaseRelationId field instance</summary>
		Public Shared ReadOnly Property [CaseRelationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseRelationFieldIndex.CaseRelationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseRelationEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseRelationFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseRelationEntity.DependencyWarning field instance</summary>
		Public Shared ReadOnly Property [DependencyWarning] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseRelationFieldIndex.DependencyWarning), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseRelationEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseRelationFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CaseRelationEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CaseRelationFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity CategoryEntity</summary>
	Public Class CategoryFields

		''' <summary>Creates a new CategoryEntity.CategoryId field instance</summary>
		Public Shared ReadOnly Property [CategoryId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CategoryFieldIndex.CategoryId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CategoryEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CategoryFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CategoryEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CategoryFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CategoryEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CategoryFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CategoryEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CategoryFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CategoryEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CategoryFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ChangeLogEntity</summary>
	Public Class ChangeLogFields

		''' <summary>Creates a new ChangeLogEntity.ChangeLogId field instance</summary>
		Public Shared ReadOnly Property [ChangeLogId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.ChangeLogId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.BeforeValue field instance</summary>
		Public Shared ReadOnly Property [BeforeValue] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.BeforeValue), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.AfterValue field instance</summary>
		Public Shared ReadOnly Property [AfterValue] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.AfterValue), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.ChangeTypeId field instance</summary>
		Public Shared ReadOnly Property [ChangeTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.ChangeTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeLogEntity.AdditionalInfo field instance</summary>
		Public Shared ReadOnly Property [AdditionalInfo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeLogFieldIndex.AdditionalInfo), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ChangeTypeEntity</summary>
	Public Class ChangeTypeFields

		''' <summary>Creates a new ChangeTypeEntity.ChangeTypeId field instance</summary>
		Public Shared ReadOnly Property [ChangeTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeTypeFieldIndex.ChangeTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeTypeEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeTypeFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeTypeEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeTypeFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeTypeEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeTypeFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ChangeTypeEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ChangeTypeFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity CirEntity</summary>
	Public Class CirFields

		''' <summary>Creates a new CirEntity.Cirid field instance</summary>
		Public Shared ReadOnly Property [Cirid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.Cirid), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.ComponentFailureReportId field instance</summary>
		Public Shared ReadOnly Property [ComponentFailureReportId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.ComponentFailureReportId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.TurbineNo field instance</summary>
		Public Shared ReadOnly Property [TurbineNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.TurbineNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.ProcessedDate field instance</summary>
		Public Shared ReadOnly Property [ProcessedDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.ProcessedDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.NewCir field instance</summary>
		Public Shared ReadOnly Property [NewCir] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.NewCir), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.ReportTypeId field instance</summary>
		Public Shared ReadOnly Property [ReportTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.ReportTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.Verified field instance</summary>
		Public Shared ReadOnly Property [Verified] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.Verified), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.VerifiedBy field instance</summary>
		Public Shared ReadOnly Property [VerifiedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.VerifiedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.Rejected field instance</summary>
		Public Shared ReadOnly Property [Rejected] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.Rejected), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.RejectedBy field instance</summary>
		Public Shared ReadOnly Property [RejectedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.RejectedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.DateOfInspection field instance</summary>
		Public Shared ReadOnly Property [DateOfInspection] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.DateOfInspection), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.DateOfFailure field instance</summary>
		Public Shared ReadOnly Property [DateOfFailure] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.DateOfFailure), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.SiteName field instance</summary>
		Public Shared ReadOnly Property [SiteName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.SiteName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CirEntity.ServiceReportNumber field instance</summary>
		Public Shared ReadOnly Property [ServiceReportNumber] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CirFieldIndex.ServiceReportNumber), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ClaimStatusEntity</summary>
	Public Class ClaimStatusFields

		''' <summary>Creates a new ClaimStatusEntity.ClaimStatusId field instance</summary>
		Public Shared ReadOnly Property [ClaimStatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ClaimStatusFieldIndex.ClaimStatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ClaimStatusEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ClaimStatusFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ClaimStatusEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ClaimStatusFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ComponentEntity</summary>
	Public Class ComponentFields

		''' <summary>Creates a new ComponentEntity.ComponentId field instance</summary>
		Public Shared ReadOnly Property [ComponentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentFieldIndex.ComponentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ComponentTypeEntity</summary>
	Public Class ComponentTypeFields

		''' <summary>Creates a new ComponentTypeEntity.ComponentTypeId field instance</summary>
		Public Shared ReadOnly Property [ComponentTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentTypeFieldIndex.ComponentTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentTypeEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentTypeFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentTypeEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentTypeFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentTypeEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentTypeFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ComponentTypeEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ComponentTypeFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ControlEntity</summary>
	Public Class ControlFields

		''' <summary>Creates a new ControlEntity.ControlId field instance</summary>
		Public Shared ReadOnly Property [ControlId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ControlFieldIndex.ControlId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ControlEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ControlFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ControlEntity.FriendlyName field instance</summary>
		Public Shared ReadOnly Property [FriendlyName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ControlFieldIndex.FriendlyName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ControlEntity.ModuleId field instance</summary>
		Public Shared ReadOnly Property [ModuleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ControlFieldIndex.ModuleId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity CustomColumnsNameEntity</summary>
	Public Class CustomColumnsNameFields

		''' <summary>Creates a new CustomColumnsNameEntity.CustomColumnsNameId field instance</summary>
		Public Shared ReadOnly Property [CustomColumnsNameId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsNameFieldIndex.CustomColumnsNameId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CustomColumnsNameEntity.PopulationlistId field instance</summary>
		Public Shared ReadOnly Property [PopulationlistId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsNameFieldIndex.PopulationlistId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CustomColumnsNameEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsNameFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CustomColumnsNameEntity.Order field instance</summary>
		Public Shared ReadOnly Property [Order] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsNameFieldIndex.Order), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity CustomColumnsValueEntity</summary>
	Public Class CustomColumnsValueFields

		''' <summary>Creates a new CustomColumnsValueEntity.CustomColumnsValueId field instance</summary>
		Public Shared ReadOnly Property [CustomColumnsValueId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsValueFieldIndex.CustomColumnsValueId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CustomColumnsValueEntity.PopulationlistItemId field instance</summary>
		Public Shared ReadOnly Property [PopulationlistItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsValueFieldIndex.PopulationlistItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CustomColumnsValueEntity.CustomColumnsNameId field instance</summary>
		Public Shared ReadOnly Property [CustomColumnsNameId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsValueFieldIndex.CustomColumnsNameId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new CustomColumnsValueEntity.Value field instance</summary>
		Public Shared ReadOnly Property [Value] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(CustomColumnsValueFieldIndex.Value), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity DiscussionEntity</summary>
	Public Class DiscussionFields

		''' <summary>Creates a new DiscussionEntity.DiscussionId field instance</summary>
		Public Shared ReadOnly Property [DiscussionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.DiscussionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.ReplyToDiscussionId field instance</summary>
		Public Shared ReadOnly Property [ReplyToDiscussionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.ReplyToDiscussionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.Modified field instance</summary>
		Public Shared ReadOnly Property [Modified] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.Modified), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DiscussionEntity.ModifiedById field instance</summary>
		Public Shared ReadOnly Property [ModifiedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DiscussionFieldIndex.ModifiedById), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity DocumentEntity</summary>
	Public Class DocumentFields

		''' <summary>Creates a new DocumentEntity.DocumentId field instance</summary>
		Public Shared ReadOnly Property [DocumentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.DocumentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.DocumentBinaryId field instance</summary>
		Public Shared ReadOnly Property [DocumentBinaryId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.DocumentBinaryId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.DocumentClassificationId field instance</summary>
		Public Shared ReadOnly Property [DocumentClassificationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.DocumentClassificationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.FileName field instance</summary>
		Public Shared ReadOnly Property [FileName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.FileName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.FileSize field instance</summary>
		Public Shared ReadOnly Property [FileSize] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.FileSize), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.FileDate field instance</summary>
		Public Shared ReadOnly Property [FileDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.FileDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.Title field instance</summary>
		Public Shared ReadOnly Property [Title] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.Title), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.Category field instance</summary>
		Public Shared ReadOnly Property [Category] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.Category), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.LinkNo field instance</summary>
		Public Shared ReadOnly Property [LinkNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.LinkNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.PictureHeight field instance</summary>
		Public Shared ReadOnly Property [PictureHeight] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.PictureHeight), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.PictureWidth field instance</summary>
		Public Shared ReadOnly Property [PictureWidth] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.PictureWidth), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.PictureDate field instance</summary>
		Public Shared ReadOnly Property [PictureDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.PictureDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.Thumbnail field instance</summary>
		Public Shared ReadOnly Property [Thumbnail] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.Thumbnail), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.TurbineNumber field instance</summary>
		Public Shared ReadOnly Property [TurbineNumber] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.TurbineNumber), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.Locked field instance</summary>
		Public Shared ReadOnly Property [Locked] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.Locked), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.LockedById field instance</summary>
		Public Shared ReadOnly Property [LockedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.LockedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity DocumentBinaryEntity</summary>
	Public Class DocumentBinaryFields

		''' <summary>Creates a new DocumentBinaryEntity.DocumentBinaryId field instance</summary>
		Public Shared ReadOnly Property [DocumentBinaryId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentBinaryFieldIndex.DocumentBinaryId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentBinaryEntity.Document field instance</summary>
		Public Shared ReadOnly Property [Document] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentBinaryFieldIndex.Document), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity DocumentClassificationEntity</summary>
	Public Class DocumentClassificationFields

		''' <summary>Creates a new DocumentClassificationEntity.DocumentClassificationId field instance</summary>
		Public Shared ReadOnly Property [DocumentClassificationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentClassificationFieldIndex.DocumentClassificationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentClassificationEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentClassificationFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity DocumentStatusEntity</summary>
	Public Class DocumentStatusFields

		''' <summary>Creates a new DocumentStatusEntity.DocumentStatusId field instance</summary>
		Public Shared ReadOnly Property [DocumentStatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentStatusFieldIndex.DocumentStatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentStatusEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentStatusFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentStatusEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentStatusFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity DocumentTemplateEntity</summary>
	Public Class DocumentTemplateFields

		''' <summary>Creates a new DocumentTemplateEntity.DocumentTemplateId field instance</summary>
		Public Shared ReadOnly Property [DocumentTemplateId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.DocumentTemplateId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentTemplateEntity.DocumentBinaryId field instance</summary>
		Public Shared ReadOnly Property [DocumentBinaryId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.DocumentBinaryId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentTemplateEntity.DocumentClassificationId field instance</summary>
		Public Shared ReadOnly Property [DocumentClassificationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.DocumentClassificationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentTemplateEntity.Title field instance</summary>
		Public Shared ReadOnly Property [Title] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.Title), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentTemplateEntity.FileName field instance</summary>
		Public Shared ReadOnly Property [FileName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.FileName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentTemplateEntity.FileSize field instance</summary>
		Public Shared ReadOnly Property [FileSize] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.FileSize), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentTemplateEntity.Thumbnail field instance</summary>
		Public Shared ReadOnly Property [Thumbnail] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.Thumbnail), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentTemplateEntity.Version field instance</summary>
		Public Shared ReadOnly Property [Version] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentTemplateFieldIndex.Version), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity DocumentVersionEntity</summary>
	Public Class DocumentVersionFields

		''' <summary>Creates a new DocumentVersionEntity.DocumentVersionId field instance</summary>
		Public Shared ReadOnly Property [DocumentVersionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentVersionFieldIndex.DocumentVersionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentVersionEntity.DocumentId field instance</summary>
		Public Shared ReadOnly Property [DocumentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentVersionFieldIndex.DocumentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new DocumentVersionEntity.Version field instance</summary>
		Public Shared ReadOnly Property [Version] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(DocumentVersionFieldIndex.Version), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ErpsystemEntity</summary>
	Public Class ErpsystemFields

		''' <summary>Creates a new ErpsystemEntity.ErpsystemId field instance</summary>
		Public Shared ReadOnly Property [ErpsystemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ErpsystemFieldIndex.ErpsystemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ErpsystemEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ErpsystemFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ErpsystemEntity.Priority field instance</summary>
		Public Shared ReadOnly Property [Priority] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ErpsystemFieldIndex.Priority), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ErpsystemEntity.ReadOnly field instance</summary>
		Public Shared ReadOnly Property [ReadOnly] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ErpsystemFieldIndex.ReadOnly), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity FeatureEntity</summary>
	Public Class FeatureFields

		''' <summary>Creates a new FeatureEntity.FeatureId field instance</summary>
		Public Shared ReadOnly Property [FeatureId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FeatureFieldIndex.FeatureId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FeatureEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FeatureFieldIndex.Description), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity FolderEntity</summary>
	Public Class FolderFields

		''' <summary>Creates a new FolderEntity.FolderId field instance</summary>
		Public Shared ReadOnly Property [FolderId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.FolderId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.FolderTypeId field instance</summary>
		Public Shared ReadOnly Property [FolderTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.FolderTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.ParentFolderId field instance</summary>
		Public Shared ReadOnly Property [ParentFolderId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.ParentFolderId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.Sort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.Locked field instance</summary>
		Public Shared ReadOnly Property [Locked] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.Locked), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.LockedBy field instance</summary>
		Public Shared ReadOnly Property [LockedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.LockedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Folder2DocumentEntity</summary>
	Public Class Folder2DocumentFields

		''' <summary>Creates a new Folder2DocumentEntity.Folder2DocumentId field instance</summary>
		Public Shared ReadOnly Property [Folder2DocumentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Folder2DocumentFieldIndex.Folder2DocumentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Folder2DocumentEntity.FolderId field instance</summary>
		Public Shared ReadOnly Property [FolderId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Folder2DocumentFieldIndex.FolderId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Folder2DocumentEntity.DocumentId field instance</summary>
		Public Shared ReadOnly Property [DocumentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Folder2DocumentFieldIndex.DocumentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Folder2DocumentEntity.DocumentStatusId field instance</summary>
		Public Shared ReadOnly Property [DocumentStatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Folder2DocumentFieldIndex.DocumentStatusId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity FolderTypeEntity</summary>
	Public Class FolderTypeFields

		''' <summary>Creates a new FolderTypeEntity.FolderTypeId field instance</summary>
		Public Shared ReadOnly Property [FolderTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderTypeFieldIndex.FolderTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new FolderTypeEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(FolderTypeFieldIndex.Description), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity HelpEntity</summary>
	Public Class HelpFields

		''' <summary>Creates a new HelpEntity.HelpId field instance</summary>
		Public Shared ReadOnly Property [HelpId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(HelpFieldIndex.HelpId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new HelpEntity.TopicId field instance</summary>
		Public Shared ReadOnly Property [TopicId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(HelpFieldIndex.TopicId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new HelpEntity.Text field instance</summary>
		Public Shared ReadOnly Property [Text] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(HelpFieldIndex.Text), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new HelpEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(HelpFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new HelpEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(HelpFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new HelpEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(HelpFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new HelpEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(HelpFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity InlineHelpEntity</summary>
	Public Class InlineHelpFields

		''' <summary>Creates a new InlineHelpEntity.InlineHelpId field instance</summary>
		Public Shared ReadOnly Property [InlineHelpId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpFieldIndex.InlineHelpId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new InlineHelpEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new InlineHelpEntity.ControlId field instance</summary>
		Public Shared ReadOnly Property [ControlId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpFieldIndex.ControlId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new InlineHelpEntity.SystemText field instance</summary>
		Public Shared ReadOnly Property [SystemText] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpFieldIndex.SystemText), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity InlineHelpTextEntity</summary>
	Public Class InlineHelpTextFields

		''' <summary>Creates a new InlineHelpTextEntity.InlineHelpTextId field instance</summary>
		Public Shared ReadOnly Property [InlineHelpTextId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpTextFieldIndex.InlineHelpTextId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new InlineHelpTextEntity.InlineHelpId field instance</summary>
		Public Shared ReadOnly Property [InlineHelpId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpTextFieldIndex.InlineHelpId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new InlineHelpTextEntity.LanguageId field instance</summary>
		Public Shared ReadOnly Property [LanguageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpTextFieldIndex.LanguageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new InlineHelpTextEntity.LocalizedText field instance</summary>
		Public Shared ReadOnly Property [LocalizedText] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(InlineHelpTextFieldIndex.LocalizedText), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ItemEntity</summary>
	Public Class ItemFields

		''' <summary>Creates a new ItemEntity.ItemId field instance</summary>
		Public Shared ReadOnly Property [ItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.ItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.ItemNo field instance</summary>
		Public Shared ReadOnly Property [ItemNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.ItemNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.ErpsystemId field instance</summary>
		Public Shared ReadOnly Property [ErpsystemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.ErpsystemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemEntity.ModifiedVersion field instance</summary>
		Public Shared ReadOnly Property [ModifiedVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemFieldIndex.ModifiedVersion), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ItemStatusEntity</summary>
	Public Class ItemStatusFields

		''' <summary>Creates a new ItemStatusEntity.ItemStatusId field instance</summary>
		Public Shared ReadOnly Property [ItemStatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.ItemStatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemStatusEntity.PopulationListItemId field instance</summary>
		Public Shared ReadOnly Property [PopulationListItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.PopulationListItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemStatusEntity.ServiceTypeId field instance</summary>
		Public Shared ReadOnly Property [ServiceTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.ServiceTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemStatusEntity.ServiceMessage field instance</summary>
		Public Shared ReadOnly Property [ServiceMessage] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.ServiceMessage), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemStatusEntity.Planned field instance</summary>
		Public Shared ReadOnly Property [Planned] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.Planned), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemStatusEntity.Done field instance</summary>
		Public Shared ReadOnly Property [Done] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.Done), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemStatusEntity.PaidById field instance</summary>
		Public Shared ReadOnly Property [PaidById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.PaidById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemStatusEntity.SaptaskId field instance</summary>
		Public Shared ReadOnly Property [SaptaskId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemStatusFieldIndex.SaptaskId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ItemSystemMappingEntity</summary>
	Public Class ItemSystemMappingFields

		''' <summary>Creates a new ItemSystemMappingEntity.MappingId field instance</summary>
		Public Shared ReadOnly Property [MappingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemSystemMappingFieldIndex.MappingId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemSystemMappingEntity.ItemNo field instance</summary>
		Public Shared ReadOnly Property [ItemNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemSystemMappingFieldIndex.ItemNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemSystemMappingEntity.System field instance</summary>
		Public Shared ReadOnly Property [System] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemSystemMappingFieldIndex.System), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ItemSystemMappingStagingTableEntity</summary>
	Public Class ItemSystemMappingStagingTableFields

		''' <summary>Creates a new ItemSystemMappingStagingTableEntity.MappingId field instance</summary>
		Public Shared ReadOnly Property [MappingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemSystemMappingStagingTableFieldIndex.MappingId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemSystemMappingStagingTableEntity.ItemNo field instance</summary>
		Public Shared ReadOnly Property [ItemNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemSystemMappingStagingTableFieldIndex.ItemNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ItemSystemMappingStagingTableEntity.System field instance</summary>
		Public Shared ReadOnly Property [System] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ItemSystemMappingStagingTableFieldIndex.System), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity LanguageEntity</summary>
	Public Class LanguageFields

		''' <summary>Creates a new LanguageEntity.LanguageId field instance</summary>
		Public Shared ReadOnly Property [LanguageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LanguageFieldIndex.LanguageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LanguageEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LanguageFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LanguageEntity.SaplanguageId field instance</summary>
		Public Shared ReadOnly Property [SaplanguageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LanguageFieldIndex.SaplanguageId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity LogInfoEntity</summary>
	Public Class LogInfoFields

		''' <summary>Creates a new LogInfoEntity.LogInfoId field instance</summary>
		Public Shared ReadOnly Property [LogInfoId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.LogInfoId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.CtrlTypeId field instance</summary>
		Public Shared ReadOnly Property [CtrlTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.CtrlTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.Release field instance</summary>
		Public Shared ReadOnly Property [Release] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.Release), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.LogNo field instance</summary>
		Public Shared ReadOnly Property [LogNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.LogNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfoEntity.ModifiedVersion field instance</summary>
		Public Shared ReadOnly Property [ModifiedVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfoFieldIndex.ModifiedVersion), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity LogInfo2LogTxtEntity</summary>
	Public Class LogInfo2LogTxtFields

		''' <summary>Creates a new LogInfo2LogTxtEntity.LogInfo2LogTxtId field instance</summary>
		Public Shared ReadOnly Property [LogInfo2LogTxtId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfo2LogTxtFieldIndex.LogInfo2LogTxtId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfo2LogTxtEntity.LogInfoId field instance</summary>
		Public Shared ReadOnly Property [LogInfoId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfo2LogTxtFieldIndex.LogInfoId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfo2LogTxtEntity.LogTxtId field instance</summary>
		Public Shared ReadOnly Property [LogTxtId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfo2LogTxtFieldIndex.LogTxtId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogInfo2LogTxtEntity.ModifiedVersion field instance</summary>
		Public Shared ReadOnly Property [ModifiedVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogInfo2LogTxtFieldIndex.ModifiedVersion), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity LogTxtEntity</summary>
	Public Class LogTxtFields

		''' <summary>Creates a new LogTxtEntity.LogTxtId field instance</summary>
		Public Shared ReadOnly Property [LogTxtId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.LogTxtId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.CtrlTypeId field instance</summary>
		Public Shared ReadOnly Property [CtrlTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.CtrlTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.CtrlTypeText field instance</summary>
		Public Shared ReadOnly Property [CtrlTypeText] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.CtrlTypeText), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.LogNo field instance</summary>
		Public Shared ReadOnly Property [LogNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.LogNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.Text field instance</summary>
		Public Shared ReadOnly Property [Text] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.Text), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new LogTxtEntity.ModifiedVersion field instance</summary>
		Public Shared ReadOnly Property [ModifiedVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(LogTxtFieldIndex.ModifiedVersion), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity MilestoneEntity</summary>
	Public Class MilestoneFields

		''' <summary>Creates a new MilestoneEntity.MilestoneId field instance</summary>
		Public Shared ReadOnly Property [MilestoneId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(MilestoneFieldIndex.MilestoneId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new MilestoneEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(MilestoneFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new MilestoneEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(MilestoneFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new MilestoneEntity.DeadlineDate field instance</summary>
		Public Shared ReadOnly Property [DeadlineDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(MilestoneFieldIndex.DeadlineDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new MilestoneEntity.ResponsiblePersonId field instance</summary>
		Public Shared ReadOnly Property [ResponsiblePersonId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(MilestoneFieldIndex.ResponsiblePersonId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new MilestoneEntity.FinishDate field instance</summary>
		Public Shared ReadOnly Property [FinishDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(MilestoneFieldIndex.FinishDate), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ModuleEntity</summary>
	Public Class ModuleFields

		''' <summary>Creates a new ModuleEntity.ModuleId field instance</summary>
		Public Shared ReadOnly Property [ModuleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ModuleFieldIndex.ModuleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ModuleEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ModuleFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity NewsEntity</summary>
	Public Class NewsFields

		''' <summary>Creates a new NewsEntity.NewsId field instance</summary>
		Public Shared ReadOnly Property [NewsId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.NewsId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new NewsEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new NewsEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new NewsEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new NewsEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new NewsEntity.CreatedbyId field instance</summary>
		Public Shared ReadOnly Property [CreatedbyId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.CreatedbyId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new NewsEntity.Modified field instance</summary>
		Public Shared ReadOnly Property [Modified] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.Modified), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new NewsEntity.ModifiedById field instance</summary>
		Public Shared ReadOnly Property [ModifiedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(NewsFieldIndex.ModifiedById), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity News2ParticipantEntity</summary>
	Public Class News2ParticipantFields

		''' <summary>Creates a new News2ParticipantEntity.News2ParticipantId field instance</summary>
		Public Shared ReadOnly Property [News2ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(News2ParticipantFieldIndex.News2ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new News2ParticipantEntity.NewsId field instance</summary>
		Public Shared ReadOnly Property [NewsId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(News2ParticipantFieldIndex.NewsId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new News2ParticipantEntity.ParticipantId field instance</summary>
		Public Shared ReadOnly Property [ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(News2ParticipantFieldIndex.ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new News2ParticipantEntity.SendOn field instance</summary>
		Public Shared ReadOnly Property [SendOn] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(News2ParticipantFieldIndex.SendOn), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity OldCimturbineEntity</summary>
	Public Class OldCimturbineFields

		''' <summary>Creates a new OldCimturbineEntity.OldCimturbineId field instance</summary>
		Public Shared ReadOnly Property [OldCimturbineId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(OldCimturbineFieldIndex.OldCimturbineId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new OldCimturbineEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(OldCimturbineFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new OldCimturbineEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(OldCimturbineFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ParticipantEntity</summary>
	Public Class ParticipantFields

		''' <summary>Creates a new ParticipantEntity.ParticipantId field instance</summary>
		Public Shared ReadOnly Property [ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.VppersonId field instance</summary>
		Public Shared ReadOnly Property [VppersonId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.VppersonId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.VestasInitials field instance</summary>
		Public Shared ReadOnly Property [VestasInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.VestasInitials), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.LoginInitials field instance</summary>
		Public Shared ReadOnly Property [LoginInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.LoginInitials), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.Phone field instance</summary>
		Public Shared ReadOnly Property [Phone] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.Phone), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.Email field instance</summary>
		Public Shared ReadOnly Property [Email] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.Email), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.HasLeft field instance</summary>
		Public Shared ReadOnly Property [HasLeft] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.HasLeft), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.FormattedName field instance</summary>
		Public Shared ReadOnly Property [FormattedName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.FormattedName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.DepartmentId field instance</summary>
		Public Shared ReadOnly Property [DepartmentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.DepartmentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.SiteId field instance</summary>
		Public Shared ReadOnly Property [SiteId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.SiteId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.Title field instance</summary>
		Public Shared ReadOnly Property [Title] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.Title), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.Department field instance</summary>
		Public Shared ReadOnly Property [Department] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.Department), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.BusinessUnitId field instance</summary>
		Public Shared ReadOnly Property [BusinessUnitId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.BusinessUnitId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.BusinessUnit field instance</summary>
		Public Shared ReadOnly Property [BusinessUnit] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.BusinessUnit), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.BusinessUnitShortName field instance</summary>
		Public Shared ReadOnly Property [BusinessUnitShortName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.BusinessUnitShortName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantEntity.Sbuid field instance</summary>
		Public Shared ReadOnly Property [Sbuid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantFieldIndex.Sbuid), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Participant2RoleEntity</summary>
	Public Class Participant2RoleFields

		''' <summary>Creates a new Participant2RoleEntity.Participant2RoleId field instance</summary>
		Public Shared ReadOnly Property [Participant2RoleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Participant2RoleFieldIndex.Participant2RoleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Participant2RoleEntity.ParticipantId field instance</summary>
		Public Shared ReadOnly Property [ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Participant2RoleFieldIndex.ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Participant2RoleEntity.RoleId field instance</summary>
		Public Shared ReadOnly Property [RoleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Participant2RoleFieldIndex.RoleId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ParticipantLogEntity</summary>
	Public Class ParticipantLogFields

		''' <summary>Creates a new ParticipantLogEntity.ParticipantLogId field instance</summary>
		Public Shared ReadOnly Property [ParticipantLogId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantLogFieldIndex.ParticipantLogId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantLogEntity.ParticipantId field instance</summary>
		Public Shared ReadOnly Property [ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantLogFieldIndex.ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantLogEntity.Timestamp field instance</summary>
		Public Shared ReadOnly Property [Timestamp] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantLogFieldIndex.Timestamp), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipantLogEntity.Platform field instance</summary>
		Public Shared ReadOnly Property [Platform] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipantLogFieldIndex.Platform), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ParticipationTypeEntity</summary>
	Public Class ParticipationTypeFields

		''' <summary>Creates a new ParticipationTypeEntity.ParticipationTypeId field instance</summary>
		Public Shared ReadOnly Property [ParticipationTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipationTypeFieldIndex.ParticipationTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ParticipationTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ParticipationTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PayeeEntity</summary>
	Public Class PayeeFields

		''' <summary>Creates a new PayeeEntity.PayeeId field instance</summary>
		Public Shared ReadOnly Property [PayeeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PayeeFieldIndex.PayeeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PayeeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PayeeFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PbuEntity</summary>
	Public Class PbuFields

		''' <summary>Creates a new PbuEntity.Pbuid field instance</summary>
		Public Shared ReadOnly Property [Pbuid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.Pbuid), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PbuEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PbuEntity.ShortName field instance</summary>
		Public Shared ReadOnly Property [ShortName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.ShortName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PbuEntity.VpdptId field instance</summary>
		Public Shared ReadOnly Property [VpdptId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.VpdptId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PbuEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PbuEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PbuEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PbuEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PbuFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PerformanceActionEntity</summary>
	Public Class PerformanceActionFields

		''' <summary>Creates a new PerformanceActionEntity.PerformanceActionId field instance</summary>
		Public Shared ReadOnly Property [PerformanceActionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.PerformanceActionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceActionEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceActionEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceActionEntity.Enabled field instance</summary>
		Public Shared ReadOnly Property [Enabled] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.Enabled), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceActionEntity.CreatedDateTime field instance</summary>
		Public Shared ReadOnly Property [CreatedDateTime] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.CreatedDateTime), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceActionEntity.CreatedInitials field instance</summary>
		Public Shared ReadOnly Property [CreatedInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.CreatedInitials), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceActionEntity.DeletedDateTime field instance</summary>
		Public Shared ReadOnly Property [DeletedDateTime] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.DeletedDateTime), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceActionEntity.DeletedInitials field instance</summary>
		Public Shared ReadOnly Property [DeletedInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceActionFieldIndex.DeletedInitials), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PerformanceDataEntity</summary>
	Public Class PerformanceDataFields

		''' <summary>Creates a new PerformanceDataEntity.PerformanceDataId field instance</summary>
		Public Shared ReadOnly Property [PerformanceDataId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.PerformanceDataId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.PerformanceActionId field instance</summary>
		Public Shared ReadOnly Property [PerformanceActionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.PerformanceActionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.Duration field instance</summary>
		Public Shared ReadOnly Property [Duration] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.Duration), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.ComputerName field instance</summary>
		Public Shared ReadOnly Property [ComputerName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.ComputerName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.IpAdress field instance</summary>
		Public Shared ReadOnly Property [IpAdress] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.IpAdress), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.ConnectionType field instance</summary>
		Public Shared ReadOnly Property [ConnectionType] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.ConnectionType), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.ProcessId field instance</summary>
		Public Shared ReadOnly Property [ProcessId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.ProcessId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.MemoryUsage field instance</summary>
		Public Shared ReadOnly Property [MemoryUsage] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.MemoryUsage), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.AvailableMemory field instance</summary>
		Public Shared ReadOnly Property [AvailableMemory] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.AvailableMemory), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.TotalMemory field instance</summary>
		Public Shared ReadOnly Property [TotalMemory] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.TotalMemory), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.RunningProcesses field instance</summary>
		Public Shared ReadOnly Property [RunningProcesses] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.RunningProcesses), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.AdditionalInfo field instance</summary>
		Public Shared ReadOnly Property [AdditionalInfo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.AdditionalInfo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.CreatedDateTime field instance</summary>
		Public Shared ReadOnly Property [CreatedDateTime] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.CreatedDateTime), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceDataEntity.CreatedInitials field instance</summary>
		Public Shared ReadOnly Property [CreatedInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceDataFieldIndex.CreatedInitials), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PerformanceUtilitySettingEntity</summary>
	Public Class PerformanceUtilitySettingFields

		''' <summary>Creates a new PerformanceUtilitySettingEntity.PerformanceUtilitySettingId field instance</summary>
		Public Shared ReadOnly Property [PerformanceUtilitySettingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceUtilitySettingFieldIndex.PerformanceUtilitySettingId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceUtilitySettingEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceUtilitySettingFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceUtilitySettingEntity.Value field instance</summary>
		Public Shared ReadOnly Property [Value] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceUtilitySettingFieldIndex.Value), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceUtilitySettingEntity.CreatedDateTime field instance</summary>
		Public Shared ReadOnly Property [CreatedDateTime] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceUtilitySettingFieldIndex.CreatedDateTime), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceUtilitySettingEntity.CreatedInitials field instance</summary>
		Public Shared ReadOnly Property [CreatedInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceUtilitySettingFieldIndex.CreatedInitials), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceUtilitySettingEntity.DeletedDateTime field instance</summary>
		Public Shared ReadOnly Property [DeletedDateTime] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceUtilitySettingFieldIndex.DeletedDateTime), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PerformanceUtilitySettingEntity.DeletedInitials field instance</summary>
		Public Shared ReadOnly Property [DeletedInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PerformanceUtilitySettingFieldIndex.DeletedInitials), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PermissionEntity</summary>
	Public Class PermissionFields

		''' <summary>Creates a new PermissionEntity.PermissionId field instance</summary>
		Public Shared ReadOnly Property [PermissionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PermissionFieldIndex.PermissionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PermissionEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PermissionFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PermissionEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PermissionFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PermissionEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PermissionFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PermissionEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PermissionFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PersonalSafetyEntity</summary>
	Public Class PersonalSafetyFields

		''' <summary>Creates a new PersonalSafetyEntity.PersonalSafetyId field instance</summary>
		Public Shared ReadOnly Property [PersonalSafetyId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.PersonalSafetyId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PersonalSafetyEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PersonalSafetyEntity.Color field instance</summary>
		Public Shared ReadOnly Property [Color] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.Color), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PersonalSafetyEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.Sort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PersonalSafetyEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PersonalSafetyEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PersonalSafetyEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PersonalSafetyEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PersonalSafetyFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PhaseEntity</summary>
	Public Class PhaseFields

		''' <summary>Creates a new PhaseEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.Sort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.DeadlineInDays field instance</summary>
		Public Shared ReadOnly Property [DeadlineInDays] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.DeadlineInDays), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.ProjectPlanVersionId field instance</summary>
		Public Shared ReadOnly Property [ProjectPlanVersionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.ProjectPlanVersionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.MappingId field instance</summary>
		Public Shared ReadOnly Property [MappingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.MappingId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.AllowBundling field instance</summary>
		Public Shared ReadOnly Property [AllowBundling] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.AllowBundling), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PhaseEntity.Vissort field instance</summary>
		Public Shared ReadOnly Property [Vissort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PhaseFieldIndex.Vissort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Phase2StatusEntity</summary>
	Public Class Phase2StatusFields

		''' <summary>Creates a new Phase2StatusEntity.Phase2StatusId field instance</summary>
		Public Shared ReadOnly Property [Phase2StatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Phase2StatusFieldIndex.Phase2StatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Phase2StatusEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Phase2StatusFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Phase2StatusEntity.StatusId field instance</summary>
		Public Shared ReadOnly Property [StatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Phase2StatusFieldIndex.StatusId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PlatformEntity</summary>
	Public Class PlatformFields

		''' <summary>Creates a new PlatformEntity.PlatformId field instance</summary>
		Public Shared ReadOnly Property [PlatformId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PlatformFieldIndex.PlatformId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PlatformEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PlatformFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PlatformEntity.Coordinator field instance</summary>
		Public Shared ReadOnly Property [Coordinator] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PlatformFieldIndex.Coordinator), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PopulationlistEntity</summary>
	Public Class PopulationlistFields

		''' <summary>Creates a new PopulationlistEntity.PopulationListId field instance</summary>
		Public Shared ReadOnly Property [PopulationListId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.PopulationListId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.Version field instance</summary>
		Public Shared ReadOnly Property [Version] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.Version), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.StateId field instance</summary>
		Public Shared ReadOnly Property [StateId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.StateId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.Comment field instance</summary>
		Public Shared ReadOnly Property [Comment] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.Comment), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistEntity.StatusId field instance</summary>
		Public Shared ReadOnly Property [StatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistFieldIndex.StatusId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PopulationlistDocumentEntity</summary>
	Public Class PopulationlistDocumentFields

		''' <summary>Creates a new PopulationlistDocumentEntity.DocumentId field instance</summary>
		Public Shared ReadOnly Property [DocumentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.DocumentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistDocumentEntity.PopulationListId field instance</summary>
		Public Shared ReadOnly Property [PopulationListId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.PopulationListId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistDocumentEntity.FileName field instance</summary>
		Public Shared ReadOnly Property [FileName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.FileName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistDocumentEntity.FileSize field instance</summary>
		Public Shared ReadOnly Property [FileSize] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.FileSize), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistDocumentEntity.FileDate field instance</summary>
		Public Shared ReadOnly Property [FileDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.FileDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistDocumentEntity.Locked field instance</summary>
		Public Shared ReadOnly Property [Locked] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.Locked), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistDocumentEntity.LockedById field instance</summary>
		Public Shared ReadOnly Property [LockedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.LockedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistDocumentEntity.DocumentClassificationId field instance</summary>
		Public Shared ReadOnly Property [DocumentClassificationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistDocumentFieldIndex.DocumentClassificationId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PopulationlistItemEntity</summary>
	Public Class PopulationlistItemFields

		''' <summary>Creates a new PopulationlistItemEntity.PopulationlistItemId field instance</summary>
		Public Shared ReadOnly Property [PopulationlistItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.PopulationlistItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.PopulationlistId field instance</summary>
		Public Shared ReadOnly Property [PopulationlistId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.PopulationlistId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.UnitId field instance</summary>
		Public Shared ReadOnly Property [UnitId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.UnitId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.UnitTypeId field instance</summary>
		Public Shared ReadOnly Property [UnitTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.UnitTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.MarkVersion field instance</summary>
		Public Shared ReadOnly Property [MarkVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.MarkVersion), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.Sitename field instance</summary>
		Public Shared ReadOnly Property [Sitename] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.Sitename), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.SbushortName field instance</summary>
		Public Shared ReadOnly Property [SbushortName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.SbushortName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.SapwarrentyStart field instance</summary>
		Public Shared ReadOnly Property [SapwarrentyStart] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.SapwarrentyStart), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.SapwarrentyEnd field instance</summary>
		Public Shared ReadOnly Property [SapwarrentyEnd] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.SapwarrentyEnd), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.SapsubscriptionStart field instance</summary>
		Public Shared ReadOnly Property [SapsubscriptionStart] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.SapsubscriptionStart), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.SapsubscriptionEnd field instance</summary>
		Public Shared ReadOnly Property [SapsubscriptionEnd] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.SapsubscriptionEnd), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.Country field instance</summary>
		Public Shared ReadOnly Property [Country] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.Country), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PopulationlistItemEntity.ItemWtg field instance</summary>
		Public Shared ReadOnly Property [ItemWtg] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PopulationlistItemFieldIndex.ItemWtg), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity PortfolioEntity</summary>
	Public Class PortfolioFields

		''' <summary>Creates a new PortfolioEntity.PortfolioId field instance</summary>
		Public Shared ReadOnly Property [PortfolioId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PortfolioFieldIndex.PortfolioId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PortfolioEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PortfolioFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PortfolioEntity.ManagerInitials field instance</summary>
		Public Shared ReadOnly Property [ManagerInitials] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PortfolioFieldIndex.ManagerInitials), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new PortfolioEntity.ManagerName field instance</summary>
		Public Shared ReadOnly Property [ManagerName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(PortfolioFieldIndex.ManagerName), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ProjectEntity</summary>
	Public Class ProjectFields

		''' <summary>Creates a new ProjectEntity.ProjectId field instance</summary>
		Public Shared ReadOnly Property [ProjectId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectFieldIndex.ProjectId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ProjectEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ProjectEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ProjectScopeEntity</summary>
	Public Class ProjectScopeFields

		''' <summary>Creates a new ProjectScopeEntity.ProjectScopeId field instance</summary>
		Public Shared ReadOnly Property [ProjectScopeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectScopeFieldIndex.ProjectScopeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ProjectScopeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectScopeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ProjectScopeEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectScopeFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ProjectScopeEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectScopeFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ProjectScopeEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectScopeFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ProjectScopeEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ProjectScopeFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RcEntity</summary>
	Public Class RcFields

		''' <summary>Creates a new RcEntity.Rcid field instance</summary>
		Public Shared ReadOnly Property [Rcid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.Rcid), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.RcoriginId field instance</summary>
		Public Shared ReadOnly Property [RcoriginId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.RcoriginId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.RcoriginResponsibleId field instance</summary>
		Public Shared ReadOnly Property [RcoriginResponsibleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.RcoriginResponsibleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.RcoriginUnitId field instance</summary>
		Public Shared ReadOnly Property [RcoriginUnitId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.RcoriginUnitId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.RccomponentOwnerId field instance</summary>
		Public Shared ReadOnly Property [RccomponentOwnerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.RccomponentOwnerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.Accepted field instance</summary>
		Public Shared ReadOnly Property [Accepted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.Accepted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.Comment field instance</summary>
		Public Shared ReadOnly Property [Comment] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.Comment), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RccomponentOwnerEntity</summary>
	Public Class RccomponentOwnerFields

		''' <summary>Creates a new RccomponentOwnerEntity.RccomponentOwnerId field instance</summary>
		Public Shared ReadOnly Property [RccomponentOwnerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RccomponentOwnerFieldIndex.RccomponentOwnerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RccomponentOwnerEntity.RccomponentOwner field instance</summary>
		Public Shared ReadOnly Property [RccomponentOwner] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RccomponentOwnerFieldIndex.RccomponentOwner), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RccomponentOwnerEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RccomponentOwnerFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RccomponentOwnerEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RccomponentOwnerFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RccomponentOwnerEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RccomponentOwnerFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RccomponentOwnerEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RccomponentOwnerFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RccomponentOwnerEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RccomponentOwnerFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RcoriginEntity</summary>
	Public Class RcoriginFields

		''' <summary>Creates a new RcoriginEntity.RcoriginId field instance</summary>
		Public Shared ReadOnly Property [RcoriginId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.RcoriginId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginEntity.Rcorigin field instance</summary>
		Public Shared ReadOnly Property [Rcorigin] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.Rcorigin), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginEntity.RcoriginTooltip field instance</summary>
		Public Shared ReadOnly Property [RcoriginTooltip] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.RcoriginTooltip), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RcoriginRelationEntity</summary>
	Public Class RcoriginRelationFields

		''' <summary>Creates a new RcoriginRelationEntity.RcoriginRelationId field instance</summary>
		Public Shared ReadOnly Property [RcoriginRelationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.RcoriginRelationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginRelationEntity.RcoriginId field instance</summary>
		Public Shared ReadOnly Property [RcoriginId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.RcoriginId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginRelationEntity.RcoriginResponsibleId field instance</summary>
		Public Shared ReadOnly Property [RcoriginResponsibleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.RcoriginResponsibleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginRelationEntity.RcoriginUnitId field instance</summary>
		Public Shared ReadOnly Property [RcoriginUnitId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.RcoriginUnitId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginRelationEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginRelationEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginRelationEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginRelationEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginRelationFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RcoriginResponsibleEntity</summary>
	Public Class RcoriginResponsibleFields

		''' <summary>Creates a new RcoriginResponsibleEntity.RcoriginResponsibleId field instance</summary>
		Public Shared ReadOnly Property [RcoriginResponsibleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginResponsibleFieldIndex.RcoriginResponsibleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginResponsibleEntity.RcoriginResponsible field instance</summary>
		Public Shared ReadOnly Property [RcoriginResponsible] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginResponsibleFieldIndex.RcoriginResponsible), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginResponsibleEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginResponsibleFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginResponsibleEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginResponsibleFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginResponsibleEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginResponsibleFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginResponsibleEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginResponsibleFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginResponsibleEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginResponsibleFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RcoriginUnitEntity</summary>
	Public Class RcoriginUnitFields

		''' <summary>Creates a new RcoriginUnitEntity.RcoriginUnitId field instance</summary>
		Public Shared ReadOnly Property [RcoriginUnitId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.RcoriginUnitId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.RcoriginUnit field instance</summary>
		Public Shared ReadOnly Property [RcoriginUnit] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.RcoriginUnit), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.VpDptId field instance</summary>
		Public Shared ReadOnly Property [VpDptId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.VpDptId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.IsSbu field instance</summary>
		Public Shared ReadOnly Property [IsSbu] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.IsSbu), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.IsPbu field instance</summary>
		Public Shared ReadOnly Property [IsPbu] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.IsPbu), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RcoriginUnitEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RcoriginUnitFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ReasonCodeEntity</summary>
	Public Class ReasonCodeFields

		''' <summary>Creates a new ReasonCodeEntity.ReasonCodeId field instance</summary>
		Public Shared ReadOnly Property [ReasonCodeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReasonCodeFieldIndex.ReasonCodeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ReasonCodeEntity.ReasonCodeNo field instance</summary>
		Public Shared ReadOnly Property [ReasonCodeNo] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReasonCodeFieldIndex.ReasonCodeNo), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ReasonCodeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReasonCodeFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RelatedCaseEntity</summary>
	Public Class RelatedCaseFields

		''' <summary>Creates a new RelatedCaseEntity.RelatedCaseId field instance</summary>
		Public Shared ReadOnly Property [RelatedCaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedCaseFieldIndex.RelatedCaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RelatedCaseEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedCaseFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RelatedCaseEntity.CaseIdRelated field instance</summary>
		Public Shared ReadOnly Property [CaseIdRelated] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedCaseFieldIndex.CaseIdRelated), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RelatedCase2CaseRelationEntity</summary>
	Public Class RelatedCase2CaseRelationFields

		''' <summary>Creates a new RelatedCase2CaseRelationEntity.RelatedCase2CaseRelationId field instance</summary>
		Public Shared ReadOnly Property [RelatedCase2CaseRelationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedCase2CaseRelationFieldIndex.RelatedCase2CaseRelationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RelatedCase2CaseRelationEntity.RelatedCaseId field instance</summary>
		Public Shared ReadOnly Property [RelatedCaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedCase2CaseRelationFieldIndex.RelatedCaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RelatedCase2CaseRelationEntity.CaseRelationId field instance</summary>
		Public Shared ReadOnly Property [CaseRelationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedCase2CaseRelationFieldIndex.CaseRelationId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RelatedItemEntity</summary>
	Public Class RelatedItemFields

		''' <summary>Creates a new RelatedItemEntity.RelatedItemId field instance</summary>
		Public Shared ReadOnly Property [RelatedItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedItemFieldIndex.RelatedItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RelatedItemEntity.ItemId field instance</summary>
		Public Shared ReadOnly Property [ItemId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedItemFieldIndex.ItemId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RelatedItemEntity.ItemIdRelated field instance</summary>
		Public Shared ReadOnly Property [ItemIdRelated] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RelatedItemFieldIndex.ItemIdRelated), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ReportTypeEntity</summary>
	Public Class ReportTypeFields

		''' <summary>Creates a new ReportTypeEntity.ReportTypeId field instance</summary>
		Public Shared ReadOnly Property [ReportTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReportTypeFieldIndex.ReportTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ReportTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReportTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ReportTypeEntity.LanguageId field instance</summary>
		Public Shared ReadOnly Property [LanguageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReportTypeFieldIndex.LanguageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ReportTypeEntity.ParentReportTypeId field instance</summary>
		Public Shared ReadOnly Property [ParentReportTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReportTypeFieldIndex.ParentReportTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ReportTypeEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ReportTypeFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity RoleEntity</summary>
	Public Class RoleFields

		''' <summary>Creates a new RoleEntity.RoleId field instance</summary>
		Public Shared ReadOnly Property [RoleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.RoleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.Description), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.GrantToProjectManager field instance</summary>
		Public Shared ReadOnly Property [GrantToProjectManager] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.GrantToProjectManager), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.GrantToTechnicalSpecialist field instance</summary>
		Public Shared ReadOnly Property [GrantToTechnicalSpecialist] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.GrantToTechnicalSpecialist), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.GrantToExecutionManager field instance</summary>
		Public Shared ReadOnly Property [GrantToExecutionManager] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.GrantToExecutionManager), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.GrantToCaseCreator field instance</summary>
		Public Shared ReadOnly Property [GrantToCaseCreator] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.GrantToCaseCreator), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.GrantToPlatformManager field instance</summary>
		Public Shared ReadOnly Property [GrantToPlatformManager] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.GrantToPlatformManager), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.GrantToProjectParticipant field instance</summary>
		Public Shared ReadOnly Property [GrantToProjectParticipant] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.GrantToProjectParticipant), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.GrantToEveryone field instance</summary>
		Public Shared ReadOnly Property [GrantToEveryone] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.GrantToEveryone), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.Updated field instance</summary>
		Public Shared ReadOnly Property [Updated] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.Updated), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.UpdatedBy field instance</summary>
		Public Shared ReadOnly Property [UpdatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.UpdatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new RoleEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(RoleFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity Role2PermissionEntity</summary>
	Public Class Role2PermissionFields

		''' <summary>Creates a new Role2PermissionEntity.Role2PermissionId field instance</summary>
		Public Shared ReadOnly Property [Role2PermissionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Role2PermissionFieldIndex.Role2PermissionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Role2PermissionEntity.RoleId field instance</summary>
		Public Shared ReadOnly Property [RoleId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Role2PermissionFieldIndex.RoleId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new Role2PermissionEntity.PermissionId field instance</summary>
		Public Shared ReadOnly Property [PermissionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(Role2PermissionFieldIndex.PermissionId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity SbuEntity</summary>
	Public Class SbuFields

		''' <summary>Creates a new SbuEntity.Sbuid field instance</summary>
		Public Shared ReadOnly Property [Sbuid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.Sbuid), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbuEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbuEntity.ShortName field instance</summary>
		Public Shared ReadOnly Property [ShortName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.ShortName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbuEntity.VpdptId field instance</summary>
		Public Shared ReadOnly Property [VpdptId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.VpdptId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbuEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbuEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbuEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbuEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbuFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity SbucloneEntity</summary>
	Public Class SbucloneFields

		''' <summary>Creates a new SbucloneEntity.Sbuid field instance</summary>
		Public Shared ReadOnly Property [Sbuid] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.Sbuid), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbucloneEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbucloneEntity.ShortName field instance</summary>
		Public Shared ReadOnly Property [ShortName] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.ShortName), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbucloneEntity.VpdptId field instance</summary>
		Public Shared ReadOnly Property [VpdptId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.VpdptId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbucloneEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbucloneEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbucloneEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SbucloneEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SbucloneFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity SearchProfileEntity</summary>
	Public Class SearchProfileFields

		''' <summary>Creates a new SearchProfileEntity.SearchProfileId field instance</summary>
		Public Shared ReadOnly Property [SearchProfileId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileFieldIndex.SearchProfileId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SearchProfileEntity.UserId field instance</summary>
		Public Shared ReadOnly Property [UserId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileFieldIndex.UserId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SearchProfileEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SearchProfileEntity.IsPublic field instance</summary>
		Public Shared ReadOnly Property [IsPublic] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileFieldIndex.IsPublic), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity SearchProfileDetailEntity</summary>
	Public Class SearchProfileDetailFields

		''' <summary>Creates a new SearchProfileDetailEntity.SearchProfileDetailId field instance</summary>
		Public Shared ReadOnly Property [SearchProfileDetailId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileDetailFieldIndex.SearchProfileDetailId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SearchProfileDetailEntity.SearchProfileId field instance</summary>
		Public Shared ReadOnly Property [SearchProfileId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileDetailFieldIndex.SearchProfileId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SearchProfileDetailEntity.InputId field instance</summary>
		Public Shared ReadOnly Property [InputId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileDetailFieldIndex.InputId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SearchProfileDetailEntity.Value field instance</summary>
		Public Shared ReadOnly Property [Value] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileDetailFieldIndex.Value), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SearchProfileDetailEntity.InputType field instance</summary>
		Public Shared ReadOnly Property [InputType] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SearchProfileDetailFieldIndex.InputType), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ServiceCodeEntity</summary>
	Public Class ServiceCodeFields

		''' <summary>Creates a new ServiceCodeEntity.ServiceCodeId field instance</summary>
		Public Shared ReadOnly Property [ServiceCodeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.ServiceCodeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.ServiceGroupId field instance</summary>
		Public Shared ReadOnly Property [ServiceGroupId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.ServiceGroupId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.VdbserviceCodeId field instance</summary>
		Public Shared ReadOnly Property [VdbserviceCodeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.VdbserviceCodeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.Sort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceCodeEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceCodeFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ServiceGroupEntity</summary>
	Public Class ServiceGroupFields

		''' <summary>Creates a new ServiceGroupEntity.ServiceGroupId field instance</summary>
		Public Shared ReadOnly Property [ServiceGroupId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.ServiceGroupId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceGroupEntity.VdbmainGroupId field instance</summary>
		Public Shared ReadOnly Property [VdbmainGroupId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.VdbmainGroupId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceGroupEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceGroupEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.Sort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceGroupEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceGroupEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceGroupEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceGroupEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceGroupFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity ServiceTypeEntity</summary>
	Public Class ServiceTypeFields

		''' <summary>Creates a new ServiceTypeEntity.ServiceTypeId field instance</summary>
		Public Shared ReadOnly Property [ServiceTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceTypeFieldIndex.ServiceTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new ServiceTypeEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(ServiceTypeFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity StageEntity</summary>
	Public Class StageFields

		''' <summary>Creates a new StageEntity.StageId field instance</summary>
		Public Shared ReadOnly Property [StageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StageFieldIndex.StageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StageEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StageFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StageEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StageFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity StandardFolderEntity</summary>
	Public Class StandardFolderFields

		''' <summary>Creates a new StandardFolderEntity.StandardFolderId field instance</summary>
		Public Shared ReadOnly Property [StandardFolderId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardFolderFieldIndex.StandardFolderId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardFolderEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardFolderFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardFolderEntity.FolderTypeId field instance</summary>
		Public Shared ReadOnly Property [FolderTypeId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardFolderFieldIndex.FolderTypeId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardFolderEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardFolderFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardFolderEntity.ParentStandardFolderId field instance</summary>
		Public Shared ReadOnly Property [ParentStandardFolderId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardFolderFieldIndex.ParentStandardFolderId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardFolderEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardFolderFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity StandardMilestoneEntity</summary>
	Public Class StandardMilestoneFields

		''' <summary>Creates a new StandardMilestoneEntity.StandardMilestoneId field instance</summary>
		Public Shared ReadOnly Property [StandardMilestoneId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardMilestoneFieldIndex.StandardMilestoneId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardMilestoneEntity.DeadlineOffset field instance</summary>
		Public Shared ReadOnly Property [DeadlineOffset] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardMilestoneFieldIndex.DeadlineOffset), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardMilestoneEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardMilestoneFieldIndex.Description), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity StandardTaskEntity</summary>
	Public Class StandardTaskFields

		''' <summary>Creates a new StandardTaskEntity.StandardTaskId field instance</summary>
		Public Shared ReadOnly Property [StandardTaskId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.StandardTaskId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.BrandId field instance</summary>
		Public Shared ReadOnly Property [BrandId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.BrandId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.TemplateVersion field instance</summary>
		Public Shared ReadOnly Property [TemplateVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.TemplateVersion), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.IsGate field instance</summary>
		Public Shared ReadOnly Property [IsGate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.IsGate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.Sort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.PhaseId field instance</summary>
		Public Shared ReadOnly Property [PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.MappingId field instance</summary>
		Public Shared ReadOnly Property [MappingId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.MappingId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.Vissort field instance</summary>
		Public Shared ReadOnly Property [Vissort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.Vissort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTaskEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTaskFieldIndex.Created), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity StandardTask2StatusEntity</summary>
	Public Class StandardTask2StatusFields

		''' <summary>Creates a new StandardTask2StatusEntity.StandardTask2StatusId field instance</summary>
		Public Shared ReadOnly Property [StandardTask2StatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTask2StatusFieldIndex.StandardTask2StatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTask2StatusEntity.StandardTaskId field instance</summary>
		Public Shared ReadOnly Property [StandardTaskId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTask2StatusFieldIndex.StandardTaskId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTask2StatusEntity.StatusId field instance</summary>
		Public Shared ReadOnly Property [StatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTask2StatusFieldIndex.StatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StandardTask2StatusEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StandardTask2StatusFieldIndex.Sort), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity StateEntity</summary>
	Public Class StateFields

		''' <summary>Creates a new StateEntity.StateId field instance</summary>
		Public Shared ReadOnly Property [StateId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StateFieldIndex.StateId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StateEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StateFieldIndex.Name), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity StatusEntity</summary>
	Public Class StatusFields

		''' <summary>Creates a new StatusEntity.StatusId field instance</summary>
		Public Shared ReadOnly Property [StatusId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StatusFieldIndex.StatusId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StatusEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StatusFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StatusEntity.Sort field instance</summary>
		Public Shared ReadOnly Property [Sort] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StatusFieldIndex.Sort), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StatusEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StatusFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StatusEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StatusFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StatusEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StatusFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new StatusEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(StatusFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity SupplierEntity</summary>
	Public Class SupplierFields

		''' <summary>Creates a new SupplierEntity.SupplierId field instance</summary>
		Public Shared ReadOnly Property [SupplierId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.SupplierId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.SupplierEnvironmentId field instance</summary>
		Public Shared ReadOnly Property [SupplierEnvironmentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.SupplierEnvironmentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.VendorId field instance</summary>
		Public Shared ReadOnly Property [VendorId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.VendorId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.VirtualId field instance</summary>
		Public Shared ReadOnly Property [VirtualId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.VirtualId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.Address1 field instance</summary>
		Public Shared ReadOnly Property [Address1] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.Address1), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.Address2 field instance</summary>
		Public Shared ReadOnly Property [Address2] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.Address2), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.Phone field instance</summary>
		Public Shared ReadOnly Property [Phone] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.Phone), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.Email field instance</summary>
		Public Shared ReadOnly Property [Email] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.Email), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEntity.ModifiedVersion field instance</summary>
		Public Shared ReadOnly Property [ModifiedVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierFieldIndex.ModifiedVersion), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity SupplierEnvironmentEntity</summary>
	Public Class SupplierEnvironmentFields

		''' <summary>Creates a new SupplierEnvironmentEntity.SupplierEnvironmentId field instance</summary>
		Public Shared ReadOnly Property [SupplierEnvironmentId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierEnvironmentFieldIndex.SupplierEnvironmentId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEnvironmentEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierEnvironmentFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEnvironmentEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierEnvironmentFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEnvironmentEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierEnvironmentFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEnvironmentEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierEnvironmentFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SupplierEnvironmentEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SupplierEnvironmentFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity SystemDescriptionEntity</summary>
	Public Class SystemDescriptionFields

		''' <summary>Creates a new SystemDescriptionEntity.System field instance</summary>
		Public Shared ReadOnly Property [System] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SystemDescriptionFieldIndex.System), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new SystemDescriptionEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(SystemDescriptionFieldIndex.Description), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TaskEntity</summary>
	Public Class TaskFields

		''' <summary>Creates a new TaskEntity.TaskId field instance</summary>
		Public Shared ReadOnly Property [TaskId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.TaskId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.StandardTaskId field instance</summary>
		Public Shared ReadOnly Property [StandardTaskId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.StandardTaskId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.Case2PhaseId field instance</summary>
		Public Shared ReadOnly Property [Case2PhaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.Case2PhaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.StartDate field instance</summary>
		Public Shared ReadOnly Property [StartDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.StartDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.FinishDate field instance</summary>
		Public Shared ReadOnly Property [FinishDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.FinishDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.DurationHours field instance</summary>
		Public Shared ReadOnly Property [DurationHours] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.DurationHours), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.PercentComplete field instance</summary>
		Public Shared ReadOnly Property [PercentComplete] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.PercentComplete), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.ScheduleComments field instance</summary>
		Public Shared ReadOnly Property [ScheduleComments] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.ScheduleComments), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.ResponsiblePersonId field instance</summary>
		Public Shared ReadOnly Property [ResponsiblePersonId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.ResponsiblePersonId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskEntity.Description field instance</summary>
		Public Shared ReadOnly Property [Description] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskFieldIndex.Description), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TaskMilestoneEntity</summary>
	Public Class TaskMilestoneFields

		''' <summary>Creates a new TaskMilestoneEntity.TaskMilestoneId field instance</summary>
		Public Shared ReadOnly Property [TaskMilestoneId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskMilestoneFieldIndex.TaskMilestoneId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskMilestoneEntity.TaskId field instance</summary>
		Public Shared ReadOnly Property [TaskId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskMilestoneFieldIndex.TaskId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskMilestoneEntity.Name field instance</summary>
		Public Shared ReadOnly Property [Name] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskMilestoneFieldIndex.Name), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskMilestoneEntity.FinishDate field instance</summary>
		Public Shared ReadOnly Property [FinishDate] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskMilestoneFieldIndex.FinishDate), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskMilestoneEntity.PercentComplete field instance</summary>
		Public Shared ReadOnly Property [PercentComplete] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskMilestoneFieldIndex.PercentComplete), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskMilestoneEntity.ScheduleComments field instance</summary>
		Public Shared ReadOnly Property [ScheduleComments] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskMilestoneFieldIndex.ScheduleComments), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TaskMilestoneEntity.ResponsiblePersonId field instance</summary>
		Public Shared ReadOnly Property [ResponsiblePersonId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TaskMilestoneFieldIndex.ResponsiblePersonId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TimelineEntity</summary>
	Public Class TimelineFields

		''' <summary>Creates a new TimelineEntity.TimelineId field instance</summary>
		Public Shared ReadOnly Property [TimelineId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TimelineFieldIndex.TimelineId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TimelineEntity.Text field instance</summary>
		Public Shared ReadOnly Property [Text] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TimelineFieldIndex.Text), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TimelineEntity.Changed field instance</summary>
		Public Shared ReadOnly Property [Changed] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TimelineFieldIndex.Changed), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TimelineEntity.ChangedBy field instance</summary>
		Public Shared ReadOnly Property [ChangedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TimelineFieldIndex.ChangedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TimelineEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TimelineFieldIndex.CaseId), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineEntity</summary>
	Public Class TurbineFields

		''' <summary>Creates a new TurbineEntity.TurbineId field instance</summary>
		Public Shared ReadOnly Property [TurbineId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFieldIndex.TurbineId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineEntity.Turbine field instance</summary>
		Public Shared ReadOnly Property [Turbine] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFieldIndex.Turbine), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineFrequencyEntity</summary>
	Public Class TurbineFrequencyFields

		''' <summary>Creates a new TurbineFrequencyEntity.TurbineFrequencyId field instance</summary>
		Public Shared ReadOnly Property [TurbineFrequencyId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFrequencyFieldIndex.TurbineFrequencyId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineFrequencyEntity.Frequency field instance</summary>
		Public Shared ReadOnly Property [Frequency] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFrequencyFieldIndex.Frequency), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineFrequencyEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFrequencyFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineFrequencyEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFrequencyFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineFrequencyEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFrequencyFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineFrequencyEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineFrequencyFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineManufacturerEntity</summary>
	Public Class TurbineManufacturerFields

		''' <summary>Creates a new TurbineManufacturerEntity.TurbineManufacturerId field instance</summary>
		Public Shared ReadOnly Property [TurbineManufacturerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineManufacturerFieldIndex.TurbineManufacturerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineManufacturerEntity.Manufacturer field instance</summary>
		Public Shared ReadOnly Property [Manufacturer] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineManufacturerFieldIndex.Manufacturer), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineManufacturerEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineManufacturerFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineManufacturerEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineManufacturerFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineManufacturerEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineManufacturerFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineManufacturerEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineManufacturerFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineMarkVersionEntity</summary>
	Public Class TurbineMarkVersionFields

		''' <summary>Creates a new TurbineMarkVersionEntity.TurbineMarkVersionId field instance</summary>
		Public Shared ReadOnly Property [TurbineMarkVersionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMarkVersionFieldIndex.TurbineMarkVersionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMarkVersionEntity.MarkVersion field instance</summary>
		Public Shared ReadOnly Property [MarkVersion] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMarkVersionFieldIndex.MarkVersion), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMarkVersionEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMarkVersionFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMarkVersionEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMarkVersionFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMarkVersionEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMarkVersionFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMarkVersionEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMarkVersionFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineMatrixEntity</summary>
	Public Class TurbineMatrixFields

		''' <summary>Creates a new TurbineMatrixEntity.TurbineMatrixId field instance</summary>
		Public Shared ReadOnly Property [TurbineMatrixId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineMatrixId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineId field instance</summary>
		Public Shared ReadOnly Property [TurbineId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineRotorDiameterId field instance</summary>
		Public Shared ReadOnly Property [TurbineRotorDiameterId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineRotorDiameterId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineNominelPowerId field instance</summary>
		Public Shared ReadOnly Property [TurbineNominelPowerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineNominelPowerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineVoltageId field instance</summary>
		Public Shared ReadOnly Property [TurbineVoltageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineVoltageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineFrequencyId field instance</summary>
		Public Shared ReadOnly Property [TurbineFrequencyId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineFrequencyId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbinePowerRegulationId field instance</summary>
		Public Shared ReadOnly Property [TurbinePowerRegulationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbinePowerRegulationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineSmallGeneratorId field instance</summary>
		Public Shared ReadOnly Property [TurbineSmallGeneratorId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineSmallGeneratorId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineTemperatureVariantId field instance</summary>
		Public Shared ReadOnly Property [TurbineTemperatureVariantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineTemperatureVariantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineMarkVersionId field instance</summary>
		Public Shared ReadOnly Property [TurbineMarkVersionId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineMarkVersionId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbinePlacementId field instance</summary>
		Public Shared ReadOnly Property [TurbinePlacementId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbinePlacementId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineManufacturerId field instance</summary>
		Public Shared ReadOnly Property [TurbineManufacturerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineManufacturerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.TurbineOldId field instance</summary>
		Public Shared ReadOnly Property [TurbineOldId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.TurbineOldId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.Comment field instance</summary>
		Public Shared ReadOnly Property [Comment] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.Comment), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineMatrixEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineMatrixFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineNominelPowerEntity</summary>
	Public Class TurbineNominelPowerFields

		''' <summary>Creates a new TurbineNominelPowerEntity.TurbineNominelPowerId field instance</summary>
		Public Shared ReadOnly Property [TurbineNominelPowerId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineNominelPowerFieldIndex.TurbineNominelPowerId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineNominelPowerEntity.NominelPower field instance</summary>
		Public Shared ReadOnly Property [NominelPower] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineNominelPowerFieldIndex.NominelPower), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineNominelPowerEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineNominelPowerFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineNominelPowerEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineNominelPowerFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineNominelPowerEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineNominelPowerFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineNominelPowerEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineNominelPowerFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineOldEntity</summary>
	Public Class TurbineOldFields

		''' <summary>Creates a new TurbineOldEntity.TurbineOldId field instance</summary>
		Public Shared ReadOnly Property [TurbineOldId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineOldFieldIndex.TurbineOldId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineOldEntity.Turbine field instance</summary>
		Public Shared ReadOnly Property [Turbine] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineOldFieldIndex.Turbine), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineOldEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineOldFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineOldEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineOldFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineOldEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineOldFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineOldEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineOldFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbinePlacementEntity</summary>
	Public Class TurbinePlacementFields

		''' <summary>Creates a new TurbinePlacementEntity.TurbinePlacementId field instance</summary>
		Public Shared ReadOnly Property [TurbinePlacementId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePlacementFieldIndex.TurbinePlacementId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePlacementEntity.Placement field instance</summary>
		Public Shared ReadOnly Property [Placement] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePlacementFieldIndex.Placement), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePlacementEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePlacementFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePlacementEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePlacementFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePlacementEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePlacementFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePlacementEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePlacementFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbinePowerRegulationEntity</summary>
	Public Class TurbinePowerRegulationFields

		''' <summary>Creates a new TurbinePowerRegulationEntity.TurbinePowerRegulationId field instance</summary>
		Public Shared ReadOnly Property [TurbinePowerRegulationId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePowerRegulationFieldIndex.TurbinePowerRegulationId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePowerRegulationEntity.PowerRegulation field instance</summary>
		Public Shared ReadOnly Property [PowerRegulation] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePowerRegulationFieldIndex.PowerRegulation), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePowerRegulationEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePowerRegulationFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePowerRegulationEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePowerRegulationFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePowerRegulationEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePowerRegulationFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbinePowerRegulationEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbinePowerRegulationFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineRotorDiameterEntity</summary>
	Public Class TurbineRotorDiameterFields

		''' <summary>Creates a new TurbineRotorDiameterEntity.TurbineRotorDiameterId field instance</summary>
		Public Shared ReadOnly Property [TurbineRotorDiameterId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineRotorDiameterFieldIndex.TurbineRotorDiameterId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineRotorDiameterEntity.RotorDiameter field instance</summary>
		Public Shared ReadOnly Property [RotorDiameter] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineRotorDiameterFieldIndex.RotorDiameter), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineRotorDiameterEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineRotorDiameterFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineRotorDiameterEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineRotorDiameterFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineRotorDiameterEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineRotorDiameterFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineRotorDiameterEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineRotorDiameterFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineSmallGeneratorEntity</summary>
	Public Class TurbineSmallGeneratorFields

		''' <summary>Creates a new TurbineSmallGeneratorEntity.TurbineSmallGeneratorId field instance</summary>
		Public Shared ReadOnly Property [TurbineSmallGeneratorId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineSmallGeneratorFieldIndex.TurbineSmallGeneratorId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineSmallGeneratorEntity.SmallGenerator field instance</summary>
		Public Shared ReadOnly Property [SmallGenerator] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineSmallGeneratorFieldIndex.SmallGenerator), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineSmallGeneratorEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineSmallGeneratorFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineSmallGeneratorEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineSmallGeneratorFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineSmallGeneratorEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineSmallGeneratorFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineSmallGeneratorEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineSmallGeneratorFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineTemperatureVariantEntity</summary>
	Public Class TurbineTemperatureVariantFields

		''' <summary>Creates a new TurbineTemperatureVariantEntity.TurbineTemperatureVariantId field instance</summary>
		Public Shared ReadOnly Property [TurbineTemperatureVariantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineTemperatureVariantFieldIndex.TurbineTemperatureVariantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineTemperatureVariantEntity.TemperatureVariant field instance</summary>
		Public Shared ReadOnly Property [TemperatureVariant] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineTemperatureVariantFieldIndex.TemperatureVariant), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineTemperatureVariantEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineTemperatureVariantFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineTemperatureVariantEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineTemperatureVariantFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineTemperatureVariantEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineTemperatureVariantFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineTemperatureVariantEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineTemperatureVariantFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity TurbineVoltageEntity</summary>
	Public Class TurbineVoltageFields

		''' <summary>Creates a new TurbineVoltageEntity.TurbineVoltageId field instance</summary>
		Public Shared ReadOnly Property [TurbineVoltageId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineVoltageFieldIndex.TurbineVoltageId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineVoltageEntity.Voltage field instance</summary>
		Public Shared ReadOnly Property [Voltage] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineVoltageFieldIndex.Voltage), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineVoltageEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineVoltageFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineVoltageEntity.CreatedBy field instance</summary>
		Public Shared ReadOnly Property [CreatedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineVoltageFieldIndex.CreatedBy), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineVoltageEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineVoltageFieldIndex.Deleted), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new TurbineVoltageEntity.DeletedBy field instance</summary>
		Public Shared ReadOnly Property [DeletedBy] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(TurbineVoltageFieldIndex.DeletedBy), EntityField2)
			End Get
		End Property
	End Class
	''' <summary>Field Creation Class for entity VisitsEntity</summary>
	Public Class VisitsFields

		''' <summary>Creates a new VisitsEntity.VisitsId field instance</summary>
		Public Shared ReadOnly Property [VisitsId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.VisitsId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.ParticipantId field instance</summary>
		Public Shared ReadOnly Property [ParticipantId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.ParticipantId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.CaseId field instance</summary>
		Public Shared ReadOnly Property [CaseId] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.CaseId), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.OpenCaseTimeStamp field instance</summary>
		Public Shared ReadOnly Property [OpenCaseTimeStamp] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.OpenCaseTimeStamp), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.Environment field instance</summary>
		Public Shared ReadOnly Property [Environment] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.Environment), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.CreatedById field instance</summary>
		Public Shared ReadOnly Property [CreatedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.CreatedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.Created field instance</summary>
		Public Shared ReadOnly Property [Created] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.Created), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.DeletedById field instance</summary>
		Public Shared ReadOnly Property [DeletedById] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.DeletedById), EntityField2)
			End Get
		End Property
		''' <summary>Creates a new VisitsEntity.Deleted field instance</summary>
		Public Shared ReadOnly Property [Deleted] As EntityField2
			Get 
				Return CType(EntityFieldFactory.Create(VisitsFieldIndex.Deleted), EntityField2)
			End Get
		End Property
	End Class
	

End Namespace