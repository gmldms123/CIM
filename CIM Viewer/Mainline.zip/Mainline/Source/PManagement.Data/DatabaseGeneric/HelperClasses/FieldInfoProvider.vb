﻿'///////////////////////////////////////////////////////////////
' This is generated code. If you modify this code, be aware
' of the fact that when you re-generate the code, your changes
' are lost. If you want to keep your changes, make this file read-only
' when you have finished your changes, however it is recommended that
' you inherit from this class to extend the functionality of this generated
' class or you modify / extend the templates used to generate this code.
'//////////////////////////////////////////////////////////////
' Code is generated using LLBLGen Pro version: 4.0
' Code is generated on: 
' Code is generated using templates: SD.TemplateBindings.SharedTemplates
' Templates vendor: Solutions Design.
' Templates version: 
'///////////////////////////////////////////////////////////////
Imports System
Imports SD.LLBLGen.Pro.ORMSupportClasses


' __LLBLGENPRO_USER_CODE_REGION_START AdditionalNamespaces
' __LLBLGENPRO_USER_CODE_REGION_END
Namespace PManagement.Data.HelperClasses
	''' <summary>Singleton implementation of the FieldInfoProvider. This Class Is the singleton wrapper through which the actual instance Is retrieved.</summary>
	''' <remarks>It uses a Single instance of an internal Class. The access isn't marked with locks as the FieldInfoProviderBase class is threadsafe.</remarks>
	Friend NotInheritable Class FieldInfoProviderSingleton
#Region "Class Member Declarations"
		Private Shared ReadOnly _providerInstance As IFieldInfoProvider = New FieldInfoProviderCore()
#End Region
		
		''' <summary>Private ctor To prevent instances of this Class.</summary>
		Private Sub New()
		End Sub

		''' <summary>Dummy Static constructor To make sure threadsafe initialization Is performed.</summary>
		Shared Sub New()
		End Sub

		''' <summary>Gets the singleton instance of the FieldInfoProviderCore</summary>
		''' <returns>Instance of the FieldInfoProvider.</returns>
		Public Shared Function GetInstance() As IFieldInfoProvider 
			Return _providerInstance
		End Function
	End Class

	''' <summary>Actual implementation of the FieldInfoProvider. Used by singleton wrapper.</summary>
	Friend Class FieldInfoProviderCore 
		Inherits FieldInfoProviderBase
		''' <summary>Initializes a New instance of the <see cref="FieldInfoProviderCore"/> Class.</summary>
		Friend Sub New()
			Init()
		End Sub

		''' <summary>Method which initializes the internal datastores</summary>
		Private Sub Init()
			MyBase.InitClass( (139 + 0))
			InitAlertCategoryEntityInfos()
			InitAlertCategoryCriteriaEntityInfos()
			InitAlertChangeTypeCriteriaEntityInfos()
			InitAlertConfigEntityInfos()
			InitAlertConfigCircountEntityInfos()
			InitAlertFrequencyEntityInfos()
			InitAlertReceiverEntityInfos()
			InitAlertReceiverRoleTypeEntityInfos()
			InitAlertReceiverTypeEntityInfos()
			InitAlertServiceSettingsEntityInfos()
			InitAnyChangesEntityInfos()
			InitBrandEntityInfos()
			InitBrand2DocumentTemplateEntityInfos()
			InitBrand2FeatureEntityInfos()
			InitBrand2StandardMilestoneEntityInfos()
			InitBusinessProcessEntityInfos()
			InitCaseEntityInfos()
			InitCase2CaseBundleEntityInfos()
			InitCase2ComponentTypeEntityInfos()
			InitCase2ItemEntityInfos()
			InitCase2KPIRatingEntityInfos()
			InitCase2LogInfoEntityInfos()
			InitCase2ParticipantEntityInfos()
			InitCase2PhaseEntityInfos()
			InitCase2ReasonCodeEntityInfos()
			InitCase2SbuEntityInfos()
			InitCase2ServiceCodeEntityInfos()
			InitCase2SupplierEntityInfos()
			InitCase2Supplier2StageEntityInfos()
			InitCase2SystemEntityInfos()
			InitCase2TurbineMatrixEntityInfos()
			InitCase2TurbineMatrix2Case2ItemEntityInfos()
			InitCaseBundleEntityInfos()
			InitCaseRelationEntityInfos()
			InitCategoryEntityInfos()
			InitChangeLogEntityInfos()
			InitChangeTypeEntityInfos()
			InitCirEntityInfos()
			InitClaimStatusEntityInfos()
			InitComponentEntityInfos()
			InitComponentTypeEntityInfos()
			InitControlEntityInfos()
			InitCustomColumnsNameEntityInfos()
			InitCustomColumnsValueEntityInfos()
			InitDiscussionEntityInfos()
			InitDocumentEntityInfos()
			InitDocumentBinaryEntityInfos()
			InitDocumentClassificationEntityInfos()
			InitDocumentStatusEntityInfos()
			InitDocumentTemplateEntityInfos()
			InitDocumentVersionEntityInfos()
			InitErpsystemEntityInfos()
			InitFeatureEntityInfos()
			InitFolderEntityInfos()
			InitFolder2DocumentEntityInfos()
			InitFolderTypeEntityInfos()
			InitHelpEntityInfos()
			InitInlineHelpEntityInfos()
			InitInlineHelpTextEntityInfos()
			InitItemEntityInfos()
			InitItemStatusEntityInfos()
			InitItemSystemMappingEntityInfos()
			InitItemSystemMappingStagingTableEntityInfos()
			InitLanguageEntityInfos()
			InitLogInfoEntityInfos()
			InitLogInfo2LogTxtEntityInfos()
			InitLogTxtEntityInfos()
			InitMilestoneEntityInfos()
			InitModuleEntityInfos()
			InitNewsEntityInfos()
			InitNews2ParticipantEntityInfos()
			InitOldCimturbineEntityInfos()
			InitParticipantEntityInfos()
			InitParticipant2RoleEntityInfos()
			InitParticipantLogEntityInfos()
			InitParticipationTypeEntityInfos()
			InitPayeeEntityInfos()
			InitPbuEntityInfos()
			InitPerformanceActionEntityInfos()
			InitPerformanceDataEntityInfos()
			InitPerformanceUtilitySettingEntityInfos()
			InitPermissionEntityInfos()
			InitPersonalSafetyEntityInfos()
			InitPhaseEntityInfos()
			InitPhase2StatusEntityInfos()
			InitPlatformEntityInfos()
			InitPopulationlistEntityInfos()
			InitPopulationlistDocumentEntityInfos()
			InitPopulationlistItemEntityInfos()
			InitPortfolioEntityInfos()
			InitProjectEntityInfos()
			InitProjectScopeEntityInfos()
			InitRcEntityInfos()
			InitRccomponentOwnerEntityInfos()
			InitRcoriginEntityInfos()
			InitRcoriginRelationEntityInfos()
			InitRcoriginResponsibleEntityInfos()
			InitRcoriginUnitEntityInfos()
			InitReasonCodeEntityInfos()
			InitRelatedCaseEntityInfos()
			InitRelatedCase2CaseRelationEntityInfos()
			InitRelatedItemEntityInfos()
			InitReportTypeEntityInfos()
			InitRoleEntityInfos()
			InitRole2PermissionEntityInfos()
			InitSbuEntityInfos()
			InitSbucloneEntityInfos()
			InitSearchProfileEntityInfos()
			InitSearchProfileDetailEntityInfos()
			InitServiceCodeEntityInfos()
			InitServiceGroupEntityInfos()
			InitServiceTypeEntityInfos()
			InitStageEntityInfos()
			InitStandardFolderEntityInfos()
			InitStandardMilestoneEntityInfos()
			InitStandardTaskEntityInfos()
			InitStandardTask2StatusEntityInfos()
			InitStateEntityInfos()
			InitStatusEntityInfos()
			InitSupplierEntityInfos()
			InitSupplierEnvironmentEntityInfos()
			InitSystemDescriptionEntityInfos()
			InitTaskEntityInfos()
			InitTaskMilestoneEntityInfos()
			InitTimelineEntityInfos()
			InitTurbineEntityInfos()
			InitTurbineFrequencyEntityInfos()
			InitTurbineManufacturerEntityInfos()
			InitTurbineMarkVersionEntityInfos()
			InitTurbineMatrixEntityInfos()
			InitTurbineNominelPowerEntityInfos()
			InitTurbineOldEntityInfos()
			InitTurbinePlacementEntityInfos()
			InitTurbinePowerRegulationEntityInfos()
			InitTurbineRotorDiameterEntityInfos()
			InitTurbineSmallGeneratorEntityInfos()
			InitTurbineTemperatureVariantEntityInfos()
			InitTurbineVoltageEntityInfos()
			InitVisitsEntityInfos()

			MyBase.ConstructElementFieldStructures(InheritanceInfoProviderSingleton.GetInstance())
		End Sub

		''' <summary>Inits AlertCategoryEntity's FieldInfo objects</summary>
		Private Sub InitAlertCategoryEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertCategoryFieldIndex), "AlertCategoryEntity")
			Me.AddElementFieldInfo("AlertCategoryEntity", "AlertCategoryId", GetType(System.Int64), True, False, True, False, CInt(AlertCategoryFieldIndex.AlertCategoryId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryEntity", "Name", GetType(System.String), False, False, False, False, CInt(AlertCategoryFieldIndex.Name), 200, 0, 0)
			Me.AddElementFieldInfo("AlertCategoryEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertCategoryFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertCategoryFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertCategoryEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertCategoryFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertCategoryFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertCategoryCriteriaEntity's FieldInfo objects</summary>
		Private Sub InitAlertCategoryCriteriaEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertCategoryCriteriaFieldIndex), "AlertCategoryCriteriaEntity")
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "AlertCategoryCriteriaId", GetType(System.Int64), True, False, True, False, CInt(AlertCategoryCriteriaFieldIndex.AlertCategoryCriteriaId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "AlertConfigId", GetType(System.Int64), False, True, False, False, CInt(AlertCategoryCriteriaFieldIndex.AlertConfigId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "AlertCategoryId", GetType(System.Int64), False, True, False, False, CInt(AlertCategoryCriteriaFieldIndex.AlertCategoryId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "Value", GetType(System.String), False, False, False, False, CInt(AlertCategoryCriteriaFieldIndex.Value), 50, 0, 0)
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertCategoryCriteriaFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertCategoryCriteriaFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertCategoryCriteriaFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertCategoryCriteriaEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertCategoryCriteriaFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertChangeTypeCriteriaEntity's FieldInfo objects</summary>
		Private Sub InitAlertChangeTypeCriteriaEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertChangeTypeCriteriaFieldIndex), "AlertChangeTypeCriteriaEntity")
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "AlertChangeTypeCriteriaId", GetType(System.Int64), True, False, True, False, CInt(AlertChangeTypeCriteriaFieldIndex.AlertChangeTypeCriteriaId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "AlertConfigId", GetType(System.Int64), False, True, False, False, CInt(AlertChangeTypeCriteriaFieldIndex.AlertConfigId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "ChangeTypeId", GetType(System.Int64), False, True, False, False, CInt(AlertChangeTypeCriteriaFieldIndex.ChangeTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "Value", GetType(System.String), False, False, False, False, CInt(AlertChangeTypeCriteriaFieldIndex.Value), 50, 0, 0)
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertChangeTypeCriteriaFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertChangeTypeCriteriaFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertChangeTypeCriteriaFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertChangeTypeCriteriaEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertChangeTypeCriteriaFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertConfigEntity's FieldInfo objects</summary>
		Private Sub InitAlertConfigEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertConfigFieldIndex), "AlertConfigEntity")
			Me.AddElementFieldInfo("AlertConfigEntity", "AlertConfigId", GetType(System.Int64), True, False, True, False, CInt(AlertConfigFieldIndex.AlertConfigId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertConfigEntity", "AlertFrequencyId", GetType(System.Int64), False, True, False, False, CInt(AlertConfigFieldIndex.AlertFrequencyId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertConfigEntity", "LastHandled", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertConfigFieldIndex.LastHandled), 0, 0, 0)
			Me.AddElementFieldInfo("AlertConfigEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertConfigFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertConfigEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertConfigFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertConfigEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertConfigFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertConfigEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertConfigFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertConfigCircountEntity's FieldInfo objects</summary>
		Private Sub InitAlertConfigCircountEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertConfigCircountFieldIndex), "AlertConfigCircountEntity")
			Me.AddElementFieldInfo("AlertConfigCircountEntity", "AlertConfigCircountId", GetType(System.Int64), True, False, True, False, CInt(AlertConfigCircountFieldIndex.AlertConfigCircountId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertConfigCircountEntity", "AlertConfigId", GetType(System.Int64), False, True, False, False, CInt(AlertConfigCircountFieldIndex.AlertConfigId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertConfigCircountEntity", "Count", GetType(System.Int64), False, False, False, False, CInt(AlertConfigCircountFieldIndex.Count), 0, 0, 19)
		End Sub
		''' <summary>Inits AlertFrequencyEntity's FieldInfo objects</summary>
		Private Sub InitAlertFrequencyEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertFrequencyFieldIndex), "AlertFrequencyEntity")
			Me.AddElementFieldInfo("AlertFrequencyEntity", "AlertFrequencyId", GetType(System.Int64), True, False, True, False, CInt(AlertFrequencyFieldIndex.AlertFrequencyId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "Name", GetType(System.String), False, False, False, False, CInt(AlertFrequencyFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "HandleDay", GetType(System.String), False, False, False, True, CInt(AlertFrequencyFieldIndex.HandleDay), 20, 0, 0)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "HandleFrequency", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(AlertFrequencyFieldIndex.HandleFrequency), 0, 0, 10)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "HandleTime", GetType(System.String), False, False, False, True, CInt(AlertFrequencyFieldIndex.HandleTime), 50, 0, 0)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertFrequencyFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertFrequencyFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertFrequencyFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertFrequencyEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertFrequencyFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertReceiverEntity's FieldInfo objects</summary>
		Private Sub InitAlertReceiverEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertReceiverFieldIndex), "AlertReceiverEntity")
			Me.AddElementFieldInfo("AlertReceiverEntity", "AlertReceiverId", GetType(System.Int64), True, False, True, False, CInt(AlertReceiverFieldIndex.AlertReceiverId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverEntity", "AlertConfigId", GetType(System.Int64), False, True, False, False, CInt(AlertReceiverFieldIndex.AlertConfigId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverEntity", "Value", GetType(System.String), False, False, False, True, CInt(AlertReceiverFieldIndex.Value), 50, 0, 0)
			Me.AddElementFieldInfo("AlertReceiverEntity", "AlertReceiverTypeId", GetType(System.Int64), False, True, False, False, CInt(AlertReceiverFieldIndex.AlertReceiverTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertReceiverFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertReceiverFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertReceiverEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertReceiverFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertReceiverFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("AlertReceiverEntity", "IsGroup", GetType(System.Boolean), False, False, False, False, CInt(AlertReceiverFieldIndex.IsGroup), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertReceiverRoleTypeEntity's FieldInfo objects</summary>
		Private Sub InitAlertReceiverRoleTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertReceiverRoleTypeFieldIndex), "AlertReceiverRoleTypeEntity")
			Me.AddElementFieldInfo("AlertReceiverRoleTypeEntity", "AlertReceiverRoleTypeId", GetType(System.Int64), True, False, True, False, CInt(AlertReceiverRoleTypeFieldIndex.AlertReceiverRoleTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverRoleTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(AlertReceiverRoleTypeFieldIndex.Name), 100, 0, 0)
			Me.AddElementFieldInfo("AlertReceiverRoleTypeEntity", "CreatedById", GetType(System.Int64), False, False, False, False, CInt(AlertReceiverRoleTypeFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverRoleTypeEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertReceiverRoleTypeFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertReceiverRoleTypeEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(AlertReceiverRoleTypeFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverRoleTypeEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertReceiverRoleTypeFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertReceiverTypeEntity's FieldInfo objects</summary>
		Private Sub InitAlertReceiverTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertReceiverTypeFieldIndex), "AlertReceiverTypeEntity")
			Me.AddElementFieldInfo("AlertReceiverTypeEntity", "AlertReceiverTypeId", GetType(System.Int64), True, False, True, False, CInt(AlertReceiverTypeFieldIndex.AlertReceiverTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(AlertReceiverTypeFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("AlertReceiverTypeEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertReceiverTypeFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverTypeEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertReceiverTypeFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertReceiverTypeEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertReceiverTypeFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertReceiverTypeEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertReceiverTypeFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AlertServiceSettingsEntity's FieldInfo objects</summary>
		Private Sub InitAlertServiceSettingsEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AlertServiceSettingsFieldIndex), "AlertServiceSettingsEntity")
			Me.AddElementFieldInfo("AlertServiceSettingsEntity", "AlertServiceSettingId", GetType(System.Int64), True, False, True, False, CInt(AlertServiceSettingsFieldIndex.AlertServiceSettingId), 0, 0, 19)
			Me.AddElementFieldInfo("AlertServiceSettingsEntity", "LastRun", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertServiceSettingsFieldIndex.LastRun), 0, 0, 0)
			Me.AddElementFieldInfo("AlertServiceSettingsEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(AlertServiceSettingsFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertServiceSettingsEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(AlertServiceSettingsFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("AlertServiceSettingsEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(AlertServiceSettingsFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("AlertServiceSettingsEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(AlertServiceSettingsFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits AnyChangesEntity's FieldInfo objects</summary>
		Private Sub InitAnyChangesEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(AnyChangesFieldIndex), "AnyChangesEntity")
			Me.AddElementFieldInfo("AnyChangesEntity", "AnyChangesId", GetType(System.Int64), True, False, True, False, CInt(AnyChangesFieldIndex.AnyChangesId), 0, 0, 19)
			Me.AddElementFieldInfo("AnyChangesEntity", "WindowNo", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(AnyChangesFieldIndex.WindowNo), 0, 0, 19)
			Me.AddElementFieldInfo("AnyChangesEntity", "Description", GetType(System.String), False, False, False, True, CInt(AnyChangesFieldIndex.Description), 50, 0, 0)
		End Sub
		''' <summary>Inits BrandEntity's FieldInfo objects</summary>
		Private Sub InitBrandEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(BrandFieldIndex), "BrandEntity")
			Me.AddElementFieldInfo("BrandEntity", "BrandId", GetType(System.Int64), True, False, False, False, CInt(BrandFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("BrandEntity", "Name", GetType(System.String), False, False, False, False, CInt(BrandFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("BrandEntity", "InitialPortfolioId", GetType(System.Int64), False, False, False, False, CInt(BrandFieldIndex.InitialPortfolioId), 0, 0, 19)
			Me.AddElementFieldInfo("BrandEntity", "CaseStandbyTextUrl", GetType(System.String), False, False, False, True, CInt(BrandFieldIndex.CaseStandbyTextUrl), 1000, 0, 0)
			Me.AddElementFieldInfo("BrandEntity", "PortalUrl", GetType(System.String), False, False, False, True, CInt(BrandFieldIndex.PortalUrl), 1000, 0, 0)
			Me.AddElementFieldInfo("BrandEntity", "MasterMinorText", GetType(System.String), False, False, False, True, CInt(BrandFieldIndex.MasterMinorText), 50, 0, 0)
			Me.AddElementFieldInfo("BrandEntity", "SharepointNewsChannelId", GetType(System.Int64), False, False, False, False, CInt(BrandFieldIndex.SharepointNewsChannelId), 0, 0, 19)
		End Sub
		''' <summary>Inits Brand2DocumentTemplateEntity's FieldInfo objects</summary>
		Private Sub InitBrand2DocumentTemplateEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Brand2DocumentTemplateFieldIndex), "Brand2DocumentTemplateEntity")
			Me.AddElementFieldInfo("Brand2DocumentTemplateEntity", "Brand2DocumentTemplateId", GetType(System.Int64), True, False, True, False, CInt(Brand2DocumentTemplateFieldIndex.Brand2DocumentTemplateId), 0, 0, 19)
			Me.AddElementFieldInfo("Brand2DocumentTemplateEntity", "BrandId", GetType(System.Int64), False, True, False, False, CInt(Brand2DocumentTemplateFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("Brand2DocumentTemplateEntity", "PhaseId", GetType(System.Int64), False, True, False, False, CInt(Brand2DocumentTemplateFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Brand2DocumentTemplateEntity", "DocumentTemplateId", GetType(System.Int64), False, True, False, False, CInt(Brand2DocumentTemplateFieldIndex.DocumentTemplateId), 0, 0, 19)
		End Sub
		''' <summary>Inits Brand2FeatureEntity's FieldInfo objects</summary>
		Private Sub InitBrand2FeatureEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Brand2FeatureFieldIndex), "Brand2FeatureEntity")
			Me.AddElementFieldInfo("Brand2FeatureEntity", "BrandId", GetType(System.Int64), True, True, False, False, CInt(Brand2FeatureFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("Brand2FeatureEntity", "FeatureId", GetType(System.Int16), True, True, False, False, CInt(Brand2FeatureFieldIndex.FeatureId), 0, 0, 5)
			Me.AddElementFieldInfo("Brand2FeatureEntity", "Sort", GetType(System.Int16), False, False, False, False, CInt(Brand2FeatureFieldIndex.Sort), 0, 0, 5)
		End Sub
		''' <summary>Inits Brand2StandardMilestoneEntity's FieldInfo objects</summary>
		Private Sub InitBrand2StandardMilestoneEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Brand2StandardMilestoneFieldIndex), "Brand2StandardMilestoneEntity")
			Me.AddElementFieldInfo("Brand2StandardMilestoneEntity", "Brand2StandardMilestoneId", GetType(System.Int64), True, False, True, False, CInt(Brand2StandardMilestoneFieldIndex.Brand2StandardMilestoneId), 0, 0, 19)
			Me.AddElementFieldInfo("Brand2StandardMilestoneEntity", "BrandId", GetType(System.Int64), False, True, False, False, CInt(Brand2StandardMilestoneFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("Brand2StandardMilestoneEntity", "StandardMilestoneId", GetType(System.Int64), False, True, False, False, CInt(Brand2StandardMilestoneFieldIndex.StandardMilestoneId), 0, 0, 19)
		End Sub
		''' <summary>Inits BusinessProcessEntity's FieldInfo objects</summary>
		Private Sub InitBusinessProcessEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(BusinessProcessFieldIndex), "BusinessProcessEntity")
			Me.AddElementFieldInfo("BusinessProcessEntity", "BusinessProcessId", GetType(System.Int64), True, False, False, False, CInt(BusinessProcessFieldIndex.BusinessProcessId), 0, 0, 19)
			Me.AddElementFieldInfo("BusinessProcessEntity", "Description", GetType(System.String), False, False, False, False, CInt(BusinessProcessFieldIndex.Description), 100, 0, 0)
		End Sub
		''' <summary>Inits CaseEntity's FieldInfo objects</summary>
		Private Sub InitCaseEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(CaseFieldIndex), "CaseEntity")
			Me.AddElementFieldInfo("CaseEntity", "CaseId", GetType(System.Int64), True, False, True, False, CInt(CaseFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "BrandId", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "CaseNo", GetType(System.Int64), False, False, False, False, CInt(CaseFieldIndex.CaseNo), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "PhaseId", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "StatusId", GetType(System.Byte), False, True, False, False, CInt(CaseFieldIndex.StatusId), 0, 0, 3)
			Me.AddElementFieldInfo("CaseEntity", "ClaimStatusId", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.ClaimStatusId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "Pbuid", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.Pbuid), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "ProjectPortalId", GetType(System.Int32), False, False, False, False, CInt(CaseFieldIndex.ProjectPortalId), 0, 0, 10)
			Me.AddElementFieldInfo("CaseEntity", "ManagerId", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.ManagerId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "Uplink", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.Uplink), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "Description", GetType(System.String), False, False, False, False, CInt(CaseFieldIndex.Description), 4000, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(CaseFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "LastEdited", GetType(System.DateTime), False, False, False, False, CInt(CaseFieldIndex.LastEdited), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "LastEditedById", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.LastEditedById), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "StandbyText", GetType(System.String), False, False, False, True, CInt(CaseFieldIndex.StandbyText), 100, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "ConfirmedBySupplier", GetType(System.Boolean), False, False, False, False, CInt(CaseFieldIndex.ConfirmedBySupplier), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "HasProcessedMsprojectPlan", GetType(System.Boolean), False, False, False, False, CInt(CaseFieldIndex.HasProcessedMsprojectPlan), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "StartDate", GetType(System.DateTime), False, False, False, False, CInt(CaseFieldIndex.StartDate), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "FinishDate", GetType(System.DateTime), False, False, False, False, CInt(CaseFieldIndex.FinishDate), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "DurationHours", GetType(System.Decimal), False, False, False, False, CInt(CaseFieldIndex.DurationHours), 0, 2, 7)
			Me.AddElementFieldInfo("CaseEntity", "PercentComplete", GetType(System.Byte), False, False, False, False, CInt(CaseFieldIndex.PercentComplete), 0, 0, 3)
			Me.AddElementFieldInfo("CaseEntity", "SalesOption", GetType(System.Boolean), False, False, False, False, CInt(CaseFieldIndex.SalesOption), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "Platform", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.Platform), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "ClosureDate", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CaseFieldIndex.ClosureDate), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "ReopenDate", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CaseFieldIndex.ReopenDate), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "TechnicalSpecialistId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.TechnicalSpecialistId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "ExecutionManagerId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.ExecutionManagerId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "ClosedForInvoicing", GetType(System.Boolean), False, False, False, False, CInt(CaseFieldIndex.ClosedForInvoicing), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "PortfolioId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.PortfolioId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "BusinessProcessId", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.BusinessProcessId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "StandardTaskId", GetType(System.Int64), False, True, False, False, CInt(CaseFieldIndex.StandardTaskId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "StandardTask_", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(CaseFieldIndex.StandardTask_), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "StateChangedDate", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CaseFieldIndex.StateChangedDate), 0, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "CategoryId", GetType(Nullable(Of System.Int32)), False, True, False, True, CInt(CaseFieldIndex.CategoryId), 0, 0, 10)
			Me.AddElementFieldInfo("CaseEntity", "ComponentId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.ComponentId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "PersonalSafetyId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.PersonalSafetyId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "Bleeding", GetType(System.String), False, False, False, True, CInt(CaseFieldIndex.Bleeding), 10, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "SafetyAlert", GetType(System.String), False, False, False, True, CInt(CaseFieldIndex.SafetyAlert), 10, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "Dmsdocument", GetType(System.String), False, False, False, True, CInt(CaseFieldIndex.Dmsdocument), 10, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "ReferenceNumber", GetType(System.String), False, False, False, True, CInt(CaseFieldIndex.ReferenceNumber), 50, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "Econumber", GetType(System.String), False, False, False, True, CInt(CaseFieldIndex.Econumber), 50, 0, 0)
			Me.AddElementFieldInfo("CaseEntity", "ContainmentLeadId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.ContainmentLeadId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseEntity", "ProjectScopeId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CaseFieldIndex.ProjectScopeId), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2CaseBundleEntity's FieldInfo objects</summary>
		Private Sub InitCase2CaseBundleEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2CaseBundleFieldIndex), "Case2CaseBundleEntity")
			Me.AddElementFieldInfo("Case2CaseBundleEntity", "Case2CaseBundleId", GetType(System.Int64), True, False, True, False, CInt(Case2CaseBundleFieldIndex.Case2CaseBundleId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2CaseBundleEntity", "CaseBundleId", GetType(System.Int64), False, True, False, False, CInt(Case2CaseBundleFieldIndex.CaseBundleId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2CaseBundleEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2CaseBundleFieldIndex.CaseId), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2ComponentTypeEntity's FieldInfo objects</summary>
		Private Sub InitCase2ComponentTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2ComponentTypeFieldIndex), "Case2ComponentTypeEntity")
			Me.AddElementFieldInfo("Case2ComponentTypeEntity", "Case2ComponentTypeId", GetType(System.Int64), True, False, True, False, CInt(Case2ComponentTypeFieldIndex.Case2ComponentTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ComponentTypeEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2ComponentTypeFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ComponentTypeEntity", "ComponentTypeId", GetType(System.Int64), False, True, False, False, CInt(Case2ComponentTypeFieldIndex.ComponentTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ComponentTypeEntity", "SupplierLink", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(Case2ComponentTypeFieldIndex.SupplierLink), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2ItemEntity's FieldInfo objects</summary>
		Private Sub InitCase2ItemEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2ItemFieldIndex), "Case2ItemEntity")
			Me.AddElementFieldInfo("Case2ItemEntity", "Case2ItemId", GetType(System.Int64), True, False, True, False, CInt(Case2ItemFieldIndex.Case2ItemId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ItemEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2ItemFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ItemEntity", "ItemId", GetType(System.Int64), False, True, False, False, CInt(Case2ItemFieldIndex.ItemId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ItemEntity", "Root", GetType(System.Boolean), False, False, False, False, CInt(Case2ItemFieldIndex.Root), 0, 0, 0)
		End Sub
		''' <summary>Inits Case2KPIRatingEntity's FieldInfo objects</summary>
		Private Sub InitCase2KPIRatingEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2KPIRatingFieldIndex), "Case2KPIRatingEntity")
			Me.AddElementFieldInfo("Case2KPIRatingEntity", "Case2KPIRatingId", GetType(System.Int64), True, False, True, False, CInt(Case2KPIRatingFieldIndex.Case2KPIRatingId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2KPIRatingEntity", "CaseId", GetType(System.Int64), True, False, False, False, CInt(Case2KPIRatingFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2KPIRatingEntity", "KPIRatingId", GetType(System.Int64), True, False, False, False, CInt(Case2KPIRatingFieldIndex.KPIRatingId), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2LogInfoEntity's FieldInfo objects</summary>
		Private Sub InitCase2LogInfoEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2LogInfoFieldIndex), "Case2LogInfoEntity")
			Me.AddElementFieldInfo("Case2LogInfoEntity", "Case2LogInfoId", GetType(System.Int64), True, False, True, False, CInt(Case2LogInfoFieldIndex.Case2LogInfoId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2LogInfoEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2LogInfoFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2LogInfoEntity", "LogInfoId", GetType(System.Int64), False, True, False, False, CInt(Case2LogInfoFieldIndex.LogInfoId), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2ParticipantEntity's FieldInfo objects</summary>
		Private Sub InitCase2ParticipantEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2ParticipantFieldIndex), "Case2ParticipantEntity")
			Me.AddElementFieldInfo("Case2ParticipantEntity", "Case2ParticipantId", GetType(System.Int64), True, False, True, False, CInt(Case2ParticipantFieldIndex.Case2ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ParticipantEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2ParticipantFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ParticipantEntity", "ParticipantId", GetType(System.Int64), False, True, False, False, CInt(Case2ParticipantFieldIndex.ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ParticipantEntity", "ParticipationTypeId", GetType(System.Int64), False, True, False, False, CInt(Case2ParticipantFieldIndex.ParticipationTypeId), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2PhaseEntity's FieldInfo objects</summary>
		Private Sub InitCase2PhaseEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2PhaseFieldIndex), "Case2PhaseEntity")
			Me.AddElementFieldInfo("Case2PhaseEntity", "Case2PhaseId", GetType(System.Int64), True, False, True, False, CInt(Case2PhaseFieldIndex.Case2PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2PhaseEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2PhaseFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2PhaseEntity", "PhaseId", GetType(System.Int64), False, True, False, False, CInt(Case2PhaseFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2PhaseEntity", "Relevant", GetType(System.Boolean), False, False, False, False, CInt(Case2PhaseFieldIndex.Relevant), 0, 0, 0)
			Me.AddElementFieldInfo("Case2PhaseEntity", "Budget", GetType(System.Decimal), False, False, False, False, CInt(Case2PhaseFieldIndex.Budget), 0, 2, 7)
			Me.AddElementFieldInfo("Case2PhaseEntity", "Realised", GetType(System.Decimal), False, False, False, False, CInt(Case2PhaseFieldIndex.Realised), 0, 2, 7)
			Me.AddElementFieldInfo("Case2PhaseEntity", "StartDate", GetType(System.DateTime), False, False, False, False, CInt(Case2PhaseFieldIndex.StartDate), 0, 0, 0)
			Me.AddElementFieldInfo("Case2PhaseEntity", "DeadlineDate", GetType(System.DateTime), False, False, False, False, CInt(Case2PhaseFieldIndex.DeadlineDate), 0, 0, 0)
			Me.AddElementFieldInfo("Case2PhaseEntity", "FinishDate", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(Case2PhaseFieldIndex.FinishDate), 0, 0, 0)
			Me.AddElementFieldInfo("Case2PhaseEntity", "DurationHours", GetType(System.Decimal), False, False, False, False, CInt(Case2PhaseFieldIndex.DurationHours), 0, 2, 7)
			Me.AddElementFieldInfo("Case2PhaseEntity", "PercentComplete", GetType(System.Byte), False, False, False, False, CInt(Case2PhaseFieldIndex.PercentComplete), 0, 0, 3)
			Me.AddElementFieldInfo("Case2PhaseEntity", "ScheduleComments", GetType(System.String), False, False, False, False, CInt(Case2PhaseFieldIndex.ScheduleComments), 1000, 0, 0)
		End Sub
		''' <summary>Inits Case2ReasonCodeEntity's FieldInfo objects</summary>
		Private Sub InitCase2ReasonCodeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2ReasonCodeFieldIndex), "Case2ReasonCodeEntity")
			Me.AddElementFieldInfo("Case2ReasonCodeEntity", "Case2ReasonCodeId", GetType(System.Int64), True, False, True, False, CInt(Case2ReasonCodeFieldIndex.Case2ReasonCodeId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ReasonCodeEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2ReasonCodeFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ReasonCodeEntity", "ReasonCodeId", GetType(System.Int64), False, True, False, False, CInt(Case2ReasonCodeFieldIndex.ReasonCodeId), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2SbuEntity's FieldInfo objects</summary>
		Private Sub InitCase2SbuEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2SbuFieldIndex), "Case2SbuEntity")
			Me.AddElementFieldInfo("Case2SbuEntity", "Case2Sbuid", GetType(System.Int64), True, False, True, False, CInt(Case2SbuFieldIndex.Case2Sbuid), 0, 0, 19)
			Me.AddElementFieldInfo("Case2SbuEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2SbuFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2SbuEntity", "Sbuid", GetType(System.Int64), False, True, False, False, CInt(Case2SbuFieldIndex.Sbuid), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2ServiceCodeEntity's FieldInfo objects</summary>
		Private Sub InitCase2ServiceCodeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2ServiceCodeFieldIndex), "Case2ServiceCodeEntity")
			Me.AddElementFieldInfo("Case2ServiceCodeEntity", "Case2ServiceCodeId", GetType(System.Int64), True, False, True, False, CInt(Case2ServiceCodeFieldIndex.Case2ServiceCodeId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ServiceCodeEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2ServiceCodeFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2ServiceCodeEntity", "ServiceCodeId", GetType(System.Int64), False, True, False, False, CInt(Case2ServiceCodeFieldIndex.ServiceCodeId), 0, 0, 19)
		End Sub
		''' <summary>Inits Case2SupplierEntity's FieldInfo objects</summary>
		Private Sub InitCase2SupplierEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2SupplierFieldIndex), "Case2SupplierEntity")
			Me.AddElementFieldInfo("Case2SupplierEntity", "Case2SupplierId", GetType(System.Int64), True, False, True, False, CInt(Case2SupplierFieldIndex.Case2SupplierId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2SupplierEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2SupplierFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2SupplierEntity", "SupplierId", GetType(System.Int64), False, True, False, False, CInt(Case2SupplierFieldIndex.SupplierId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2SupplierEntity", "FailedItem", GetType(System.Boolean), False, False, False, False, CInt(Case2SupplierFieldIndex.FailedItem), 0, 0, 0)
			Me.AddElementFieldInfo("Case2SupplierEntity", "RootItem", GetType(System.Boolean), False, False, False, False, CInt(Case2SupplierFieldIndex.RootItem), 0, 0, 0)
		End Sub
		''' <summary>Inits Case2Supplier2StageEntity's FieldInfo objects</summary>
		Private Sub InitCase2Supplier2StageEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2Supplier2StageFieldIndex), "Case2Supplier2StageEntity")
			Me.AddElementFieldInfo("Case2Supplier2StageEntity", "Case2Supplier2StageId", GetType(System.Int64), True, False, True, False, CInt(Case2Supplier2StageFieldIndex.Case2Supplier2StageId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2Supplier2StageEntity", "Case2SupplierId", GetType(System.Int64), False, True, False, False, CInt(Case2Supplier2StageFieldIndex.Case2SupplierId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2Supplier2StageEntity", "StageId", GetType(System.Byte), False, True, False, False, CInt(Case2Supplier2StageFieldIndex.StageId), 0, 0, 3)
		End Sub
		''' <summary>Inits Case2SystemEntity's FieldInfo objects</summary>
		Private Sub InitCase2SystemEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2SystemFieldIndex), "Case2SystemEntity")
			Me.AddElementFieldInfo("Case2SystemEntity", "Case2SystemId", GetType(System.Int64), True, False, True, False, CInt(Case2SystemFieldIndex.Case2SystemId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2SystemEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2SystemFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2SystemEntity", "System", GetType(System.String), False, True, False, True, CInt(Case2SystemFieldIndex.System), 255, 0, 0)
			Me.AddElementFieldInfo("Case2SystemEntity", "SystemChecked", GetType(System.Boolean), False, False, False, False, CInt(Case2SystemFieldIndex.SystemChecked), 0, 0, 0)
		End Sub
		''' <summary>Inits Case2TurbineMatrixEntity's FieldInfo objects</summary>
		Private Sub InitCase2TurbineMatrixEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2TurbineMatrixFieldIndex), "Case2TurbineMatrixEntity")
			Me.AddElementFieldInfo("Case2TurbineMatrixEntity", "Case2TurbineMatrixId", GetType(System.Int64), True, False, True, False, CInt(Case2TurbineMatrixFieldIndex.Case2TurbineMatrixId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2TurbineMatrixEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(Case2TurbineMatrixFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2TurbineMatrixEntity", "TurbineMatrixId", GetType(System.Int64), False, True, False, False, CInt(Case2TurbineMatrixFieldIndex.TurbineMatrixId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2TurbineMatrixEntity", "InitialFailed", GetType(System.Boolean), False, False, False, False, CInt(Case2TurbineMatrixFieldIndex.InitialFailed), 0, 0, 0)
			Me.AddElementFieldInfo("Case2TurbineMatrixEntity", "MkversionExpected", GetType(System.Int16), False, False, False, False, CInt(Case2TurbineMatrixFieldIndex.MkversionExpected), 0, 0, 5)
			Me.AddElementFieldInfo("Case2TurbineMatrixEntity", "MkversionActual", GetType(System.Int16), False, False, False, False, CInt(Case2TurbineMatrixFieldIndex.MkversionActual), 0, 0, 5)
		End Sub
		''' <summary>Inits Case2TurbineMatrix2Case2ItemEntity's FieldInfo objects</summary>
		Private Sub InitCase2TurbineMatrix2Case2ItemEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Case2TurbineMatrix2Case2ItemFieldIndex), "Case2TurbineMatrix2Case2ItemEntity")
			Me.AddElementFieldInfo("Case2TurbineMatrix2Case2ItemEntity", "Case2TurbineMatrix2Case2ItemId", GetType(System.Int64), True, False, True, False, CInt(Case2TurbineMatrix2Case2ItemFieldIndex.Case2TurbineMatrix2Case2ItemId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2TurbineMatrix2Case2ItemEntity", "Case2TurbineMatrixId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(Case2TurbineMatrix2Case2ItemFieldIndex.Case2TurbineMatrixId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2TurbineMatrix2Case2ItemEntity", "Case2ItemId", GetType(System.Int64), False, True, False, False, CInt(Case2TurbineMatrix2Case2ItemFieldIndex.Case2ItemId), 0, 0, 19)
			Me.AddElementFieldInfo("Case2TurbineMatrix2Case2ItemEntity", "StageId", GetType(Nullable(Of System.Byte)), False, True, False, True, CInt(Case2TurbineMatrix2Case2ItemFieldIndex.StageId), 0, 0, 3)
			Me.AddElementFieldInfo("Case2TurbineMatrix2Case2ItemEntity", "Count", GetType(System.Int32), False, False, False, False, CInt(Case2TurbineMatrix2Case2ItemFieldIndex.Count), 0, 0, 10)
			Me.AddElementFieldInfo("Case2TurbineMatrix2Case2ItemEntity", "InitialFailed", GetType(System.Boolean), False, False, False, False, CInt(Case2TurbineMatrix2Case2ItemFieldIndex.InitialFailed), 0, 0, 0)
		End Sub
		''' <summary>Inits CaseBundleEntity's FieldInfo objects</summary>
		Private Sub InitCaseBundleEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(CaseBundleFieldIndex), "CaseBundleEntity")
			Me.AddElementFieldInfo("CaseBundleEntity", "CaseBundleId", GetType(System.Int64), True, False, True, False, CInt(CaseBundleFieldIndex.CaseBundleId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseBundleEntity", "PhaseId", GetType(System.Int64), False, True, False, False, CInt(CaseBundleFieldIndex.PhaseId), 0, 0, 19)
		End Sub
		''' <summary>Inits CaseRelationEntity's FieldInfo objects</summary>
		Private Sub InitCaseRelationEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(CaseRelationFieldIndex), "CaseRelationEntity")
			Me.AddElementFieldInfo("CaseRelationEntity", "CaseRelationId", GetType(System.Int64), True, False, True, False, CInt(CaseRelationFieldIndex.CaseRelationId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseRelationEntity", "Name", GetType(System.String), False, False, False, False, CInt(CaseRelationFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("CaseRelationEntity", "DependencyWarning", GetType(System.Boolean), False, False, False, False, CInt(CaseRelationFieldIndex.DependencyWarning), 0, 0, 0)
			Me.AddElementFieldInfo("CaseRelationEntity", "PhaseId", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(CaseRelationFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("CaseRelationEntity", "Sort", GetType(System.Int64), False, False, False, False, CInt(CaseRelationFieldIndex.Sort), 0, 0, 19)
		End Sub
		''' <summary>Inits CategoryEntity's FieldInfo objects</summary>
		Private Sub InitCategoryEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(CategoryFieldIndex), "CategoryEntity")
			Me.AddElementFieldInfo("CategoryEntity", "CategoryId", GetType(System.Int32), True, False, True, False, CInt(CategoryFieldIndex.CategoryId), 0, 0, 10)
			Me.AddElementFieldInfo("CategoryEntity", "Name", GetType(System.String), False, False, False, False, CInt(CategoryFieldIndex.Name), 200, 0, 0)
			Me.AddElementFieldInfo("CategoryEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(CategoryFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("CategoryEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(CategoryFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("CategoryEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CategoryFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("CategoryEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CategoryFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits ChangeLogEntity's FieldInfo objects</summary>
		Private Sub InitChangeLogEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ChangeLogFieldIndex), "ChangeLogEntity")
			Me.AddElementFieldInfo("ChangeLogEntity", "ChangeLogId", GetType(System.Int64), True, False, True, False, CInt(ChangeLogFieldIndex.ChangeLogId), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeLogEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(ChangeLogFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeLogEntity", "BeforeValue", GetType(System.String), False, False, False, False, CInt(ChangeLogFieldIndex.BeforeValue), 50, 0, 0)
			Me.AddElementFieldInfo("ChangeLogEntity", "AfterValue", GetType(System.String), False, False, False, False, CInt(ChangeLogFieldIndex.AfterValue), 50, 0, 0)
			Me.AddElementFieldInfo("ChangeLogEntity", "ChangeTypeId", GetType(System.Int64), False, True, False, False, CInt(ChangeLogFieldIndex.ChangeTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeLogEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(ChangeLogFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeLogEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ChangeLogFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ChangeLogEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(ChangeLogFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeLogEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ChangeLogFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("ChangeLogEntity", "AdditionalInfo", GetType(System.String), False, False, False, True, CInt(ChangeLogFieldIndex.AdditionalInfo), 300, 0, 0)
		End Sub
		''' <summary>Inits ChangeTypeEntity's FieldInfo objects</summary>
		Private Sub InitChangeTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ChangeTypeFieldIndex), "ChangeTypeEntity")
			Me.AddElementFieldInfo("ChangeTypeEntity", "ChangeTypeId", GetType(System.Int64), True, False, True, False, CInt(ChangeTypeFieldIndex.ChangeTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ChangeTypeFieldIndex.Name), 200, 0, 0)
			Me.AddElementFieldInfo("ChangeTypeEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(ChangeTypeFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeTypeEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ChangeTypeFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ChangeTypeEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(ChangeTypeFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("ChangeTypeEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ChangeTypeFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits CirEntity's FieldInfo objects</summary>
		Private Sub InitCirEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(CirFieldIndex), "CirEntity")
			Me.AddElementFieldInfo("CirEntity", "Cirid", GetType(System.Int64), True, False, True, False, CInt(CirFieldIndex.Cirid), 0, 0, 19)
			Me.AddElementFieldInfo("CirEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(CirFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("CirEntity", "ComponentFailureReportId", GetType(System.Int64), False, False, False, False, CInt(CirFieldIndex.ComponentFailureReportId), 0, 0, 19)
			Me.AddElementFieldInfo("CirEntity", "TurbineNo", GetType(System.String), False, False, False, True, CInt(CirFieldIndex.TurbineNo), 10, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "ProcessedDate", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CirFieldIndex.ProcessedDate), 0, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(CirFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(CirFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CirFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(CirFieldIndex.DeletedBy), 50, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "NewCir", GetType(System.Int16), False, False, False, False, CInt(CirFieldIndex.NewCir), 0, 0, 5)
			Me.AddElementFieldInfo("CirEntity", "ReportTypeId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CirFieldIndex.ReportTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("CirEntity", "Verified", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CirFieldIndex.Verified), 0, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "VerifiedBy", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CirFieldIndex.VerifiedBy), 0, 0, 19)
			Me.AddElementFieldInfo("CirEntity", "Rejected", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CirFieldIndex.Rejected), 0, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "RejectedBy", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(CirFieldIndex.RejectedBy), 0, 0, 19)
			Me.AddElementFieldInfo("CirEntity", "DateOfInspection", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CirFieldIndex.DateOfInspection), 0, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "DateOfFailure", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(CirFieldIndex.DateOfFailure), 0, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "SiteName", GetType(System.String), False, False, False, True, CInt(CirFieldIndex.SiteName), 200, 0, 0)
			Me.AddElementFieldInfo("CirEntity", "ServiceReportNumber", GetType(System.String), False, False, False, False, CInt(CirFieldIndex.ServiceReportNumber), 200, 0, 0)
		End Sub
		''' <summary>Inits ClaimStatusEntity's FieldInfo objects</summary>
		Private Sub InitClaimStatusEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ClaimStatusFieldIndex), "ClaimStatusEntity")
			Me.AddElementFieldInfo("ClaimStatusEntity", "ClaimStatusId", GetType(System.Int64), True, False, True, False, CInt(ClaimStatusFieldIndex.ClaimStatusId), 0, 0, 19)
			Me.AddElementFieldInfo("ClaimStatusEntity", "Name", GetType(System.String), False, False, False, False, CInt(ClaimStatusFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("ClaimStatusEntity", "Sort", GetType(System.Int64), False, False, False, False, CInt(ClaimStatusFieldIndex.Sort), 0, 0, 19)
		End Sub
		''' <summary>Inits ComponentEntity's FieldInfo objects</summary>
		Private Sub InitComponentEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ComponentFieldIndex), "ComponentEntity")
			Me.AddElementFieldInfo("ComponentEntity", "ComponentId", GetType(System.Int64), True, False, True, False, CInt(ComponentFieldIndex.ComponentId), 0, 0, 19)
			Me.AddElementFieldInfo("ComponentEntity", "Name", GetType(System.String), False, False, False, False, CInt(ComponentFieldIndex.Name), 200, 0, 0)
			Me.AddElementFieldInfo("ComponentEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(ComponentFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("ComponentEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ComponentFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ComponentEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(ComponentFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("ComponentEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ComponentFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits ComponentTypeEntity's FieldInfo objects</summary>
		Private Sub InitComponentTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ComponentTypeFieldIndex), "ComponentTypeEntity")
			Me.AddElementFieldInfo("ComponentTypeEntity", "ComponentTypeId", GetType(System.Int64), True, False, True, False, CInt(ComponentTypeFieldIndex.ComponentTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ComponentTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ComponentTypeFieldIndex.Name), 200, 0, 0)
			Me.AddElementFieldInfo("ComponentTypeEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ComponentTypeFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ComponentTypeEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(ComponentTypeFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("ComponentTypeEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ComponentTypeFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("ComponentTypeEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(ComponentTypeFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits ControlEntity's FieldInfo objects</summary>
		Private Sub InitControlEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ControlFieldIndex), "ControlEntity")
			Me.AddElementFieldInfo("ControlEntity", "ControlId", GetType(System.Int64), True, False, True, False, CInt(ControlFieldIndex.ControlId), 0, 0, 19)
			Me.AddElementFieldInfo("ControlEntity", "Name", GetType(System.String), False, False, False, False, CInt(ControlFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("ControlEntity", "FriendlyName", GetType(System.String), False, False, False, False, CInt(ControlFieldIndex.FriendlyName), 50, 0, 0)
			Me.AddElementFieldInfo("ControlEntity", "ModuleId", GetType(System.Int64), False, True, False, False, CInt(ControlFieldIndex.ModuleId), 0, 0, 19)
		End Sub
		''' <summary>Inits CustomColumnsNameEntity's FieldInfo objects</summary>
		Private Sub InitCustomColumnsNameEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(CustomColumnsNameFieldIndex), "CustomColumnsNameEntity")
			Me.AddElementFieldInfo("CustomColumnsNameEntity", "CustomColumnsNameId", GetType(System.Int64), True, False, True, False, CInt(CustomColumnsNameFieldIndex.CustomColumnsNameId), 0, 0, 19)
			Me.AddElementFieldInfo("CustomColumnsNameEntity", "PopulationlistId", GetType(System.Int64), False, True, False, False, CInt(CustomColumnsNameFieldIndex.PopulationlistId), 0, 0, 19)
			Me.AddElementFieldInfo("CustomColumnsNameEntity", "Name", GetType(System.String), False, False, False, False, CInt(CustomColumnsNameFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("CustomColumnsNameEntity", "Order", GetType(System.Int32), False, False, False, False, CInt(CustomColumnsNameFieldIndex.Order), 0, 0, 10)
		End Sub
		''' <summary>Inits CustomColumnsValueEntity's FieldInfo objects</summary>
		Private Sub InitCustomColumnsValueEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(CustomColumnsValueFieldIndex), "CustomColumnsValueEntity")
			Me.AddElementFieldInfo("CustomColumnsValueEntity", "CustomColumnsValueId", GetType(System.Int64), False, False, True, False, CInt(CustomColumnsValueFieldIndex.CustomColumnsValueId), 0, 0, 19)
			Me.AddElementFieldInfo("CustomColumnsValueEntity", "PopulationlistItemId", GetType(System.Int64), True, True, False, False, CInt(CustomColumnsValueFieldIndex.PopulationlistItemId), 0, 0, 19)
			Me.AddElementFieldInfo("CustomColumnsValueEntity", "CustomColumnsNameId", GetType(System.Int64), True, True, False, False, CInt(CustomColumnsValueFieldIndex.CustomColumnsNameId), 0, 0, 19)
			Me.AddElementFieldInfo("CustomColumnsValueEntity", "Value", GetType(System.String), False, False, False, True, CInt(CustomColumnsValueFieldIndex.Value), 255, 0, 0)
		End Sub
		''' <summary>Inits DiscussionEntity's FieldInfo objects</summary>
		Private Sub InitDiscussionEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(DiscussionFieldIndex), "DiscussionEntity")
			Me.AddElementFieldInfo("DiscussionEntity", "DiscussionId", GetType(System.Int64), True, False, True, False, CInt(DiscussionFieldIndex.DiscussionId), 0, 0, 19)
			Me.AddElementFieldInfo("DiscussionEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(DiscussionFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("DiscussionEntity", "ReplyToDiscussionId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(DiscussionFieldIndex.ReplyToDiscussionId), 0, 0, 19)
			Me.AddElementFieldInfo("DiscussionEntity", "Name", GetType(System.String), False, False, False, False, CInt(DiscussionFieldIndex.Name), 100, 0, 0)
			Me.AddElementFieldInfo("DiscussionEntity", "Description", GetType(System.String), False, False, False, False, CInt(DiscussionFieldIndex.Description), 1073741823, 0, 0)
			Me.AddElementFieldInfo("DiscussionEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(DiscussionFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("DiscussionEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(DiscussionFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("DiscussionEntity", "Modified", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(DiscussionFieldIndex.Modified), 0, 0, 0)
			Me.AddElementFieldInfo("DiscussionEntity", "ModifiedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(DiscussionFieldIndex.ModifiedById), 0, 0, 19)
		End Sub
		''' <summary>Inits DocumentEntity's FieldInfo objects</summary>
		Private Sub InitDocumentEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(DocumentFieldIndex), "DocumentEntity")
			Me.AddElementFieldInfo("DocumentEntity", "DocumentId", GetType(System.Int64), True, False, True, False, CInt(DocumentFieldIndex.DocumentId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentEntity", "DocumentBinaryId", GetType(System.Int64), False, True, False, False, CInt(DocumentFieldIndex.DocumentBinaryId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentEntity", "DocumentClassificationId", GetType(System.Int64), False, True, False, False, CInt(DocumentFieldIndex.DocumentClassificationId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentEntity", "FileName", GetType(System.String), False, False, False, False, CInt(DocumentFieldIndex.FileName), 260, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "FileSize", GetType(System.Int64), False, False, False, False, CInt(DocumentFieldIndex.FileSize), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentEntity", "FileDate", GetType(System.DateTime), False, False, False, False, CInt(DocumentFieldIndex.FileDate), 0, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "Title", GetType(System.String), False, False, False, False, CInt(DocumentFieldIndex.Title), 260, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "Description", GetType(System.String), False, False, False, True, CInt(DocumentFieldIndex.Description), 2000, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "Category", GetType(System.String), False, False, False, True, CInt(DocumentFieldIndex.Category), 260, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "LinkNo", GetType(Nullable(Of System.Int16)), False, False, False, True, CInt(DocumentFieldIndex.LinkNo), 0, 0, 5)
			Me.AddElementFieldInfo("DocumentEntity", "PictureHeight", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(DocumentFieldIndex.PictureHeight), 0, 0, 10)
			Me.AddElementFieldInfo("DocumentEntity", "PictureWidth", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(DocumentFieldIndex.PictureWidth), 0, 0, 10)
			Me.AddElementFieldInfo("DocumentEntity", "PictureDate", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(DocumentFieldIndex.PictureDate), 0, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "Thumbnail", GetType(System.Byte()), False, False, False, False, CInt(DocumentFieldIndex.Thumbnail), 2147483647, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "TurbineNumber", GetType(System.String), False, False, False, True, CInt(DocumentFieldIndex.TurbineNumber), 50, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "Created", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(DocumentFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "CreatedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(DocumentFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentEntity", "Locked", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(DocumentFieldIndex.Locked), 0, 0, 0)
			Me.AddElementFieldInfo("DocumentEntity", "LockedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(DocumentFieldIndex.LockedById), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentEntity", "Deleted", GetType(System.Boolean), False, False, False, False, CInt(DocumentFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits DocumentBinaryEntity's FieldInfo objects</summary>
		Private Sub InitDocumentBinaryEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(DocumentBinaryFieldIndex), "DocumentBinaryEntity")
			Me.AddElementFieldInfo("DocumentBinaryEntity", "DocumentBinaryId", GetType(System.Int64), True, False, True, False, CInt(DocumentBinaryFieldIndex.DocumentBinaryId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentBinaryEntity", "Document", GetType(System.Byte()), False, False, False, True, CInt(DocumentBinaryFieldIndex.Document), 2147483647, 0, 0)
		End Sub
		''' <summary>Inits DocumentClassificationEntity's FieldInfo objects</summary>
		Private Sub InitDocumentClassificationEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(DocumentClassificationFieldIndex), "DocumentClassificationEntity")
			Me.AddElementFieldInfo("DocumentClassificationEntity", "DocumentClassificationId", GetType(System.Int64), True, False, True, False, CInt(DocumentClassificationFieldIndex.DocumentClassificationId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentClassificationEntity", "Name", GetType(System.String), False, False, False, False, CInt(DocumentClassificationFieldIndex.Name), 50, 0, 0)
		End Sub
		''' <summary>Inits DocumentStatusEntity's FieldInfo objects</summary>
		Private Sub InitDocumentStatusEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(DocumentStatusFieldIndex), "DocumentStatusEntity")
			Me.AddElementFieldInfo("DocumentStatusEntity", "DocumentStatusId", GetType(System.Int64), True, False, True, False, CInt(DocumentStatusFieldIndex.DocumentStatusId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentStatusEntity", "Name", GetType(System.String), False, False, False, False, CInt(DocumentStatusFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("DocumentStatusEntity", "Sort", GetType(System.Int64), False, False, False, False, CInt(DocumentStatusFieldIndex.Sort), 0, 0, 19)
		End Sub
		''' <summary>Inits DocumentTemplateEntity's FieldInfo objects</summary>
		Private Sub InitDocumentTemplateEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(DocumentTemplateFieldIndex), "DocumentTemplateEntity")
			Me.AddElementFieldInfo("DocumentTemplateEntity", "DocumentTemplateId", GetType(System.Int64), True, False, True, False, CInt(DocumentTemplateFieldIndex.DocumentTemplateId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentTemplateEntity", "DocumentBinaryId", GetType(System.Int64), False, True, False, False, CInt(DocumentTemplateFieldIndex.DocumentBinaryId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentTemplateEntity", "DocumentClassificationId", GetType(System.Int64), False, True, False, False, CInt(DocumentTemplateFieldIndex.DocumentClassificationId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentTemplateEntity", "Title", GetType(System.String), False, False, False, False, CInt(DocumentTemplateFieldIndex.Title), 260, 0, 0)
			Me.AddElementFieldInfo("DocumentTemplateEntity", "FileName", GetType(System.String), False, False, False, False, CInt(DocumentTemplateFieldIndex.FileName), 260, 0, 0)
			Me.AddElementFieldInfo("DocumentTemplateEntity", "FileSize", GetType(System.Int64), False, False, False, False, CInt(DocumentTemplateFieldIndex.FileSize), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentTemplateEntity", "Thumbnail", GetType(System.Byte()), False, False, False, False, CInt(DocumentTemplateFieldIndex.Thumbnail), 2147483647, 0, 0)
			Me.AddElementFieldInfo("DocumentTemplateEntity", "Version", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(DocumentTemplateFieldIndex.Version), 0, 0, 10)
		End Sub
		''' <summary>Inits DocumentVersionEntity's FieldInfo objects</summary>
		Private Sub InitDocumentVersionEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(DocumentVersionFieldIndex), "DocumentVersionEntity")
			Me.AddElementFieldInfo("DocumentVersionEntity", "DocumentVersionId", GetType(System.Int64), True, False, True, False, CInt(DocumentVersionFieldIndex.DocumentVersionId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentVersionEntity", "DocumentId", GetType(System.Int64), False, True, False, False, CInt(DocumentVersionFieldIndex.DocumentId), 0, 0, 19)
			Me.AddElementFieldInfo("DocumentVersionEntity", "Version", GetType(System.Int32), False, False, False, False, CInt(DocumentVersionFieldIndex.Version), 0, 0, 10)
		End Sub
		''' <summary>Inits ErpsystemEntity's FieldInfo objects</summary>
		Private Sub InitErpsystemEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ErpsystemFieldIndex), "ErpsystemEntity")
			Me.AddElementFieldInfo("ErpsystemEntity", "ErpsystemId", GetType(System.Byte), True, False, True, False, CInt(ErpsystemFieldIndex.ErpsystemId), 0, 0, 3)
			Me.AddElementFieldInfo("ErpsystemEntity", "Name", GetType(System.String), False, False, False, False, CInt(ErpsystemFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("ErpsystemEntity", "Priority", GetType(System.Byte), False, False, False, False, CInt(ErpsystemFieldIndex.Priority), 0, 0, 3)
			Me.AddElementFieldInfo("ErpsystemEntity", "ReadOnly", GetType(System.Boolean), False, False, False, False, CInt(ErpsystemFieldIndex.ReadOnly), 0, 0, 0)
		End Sub
		''' <summary>Inits FeatureEntity's FieldInfo objects</summary>
		Private Sub InitFeatureEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(FeatureFieldIndex), "FeatureEntity")
			Me.AddElementFieldInfo("FeatureEntity", "FeatureId", GetType(System.Int16), True, False, True, False, CInt(FeatureFieldIndex.FeatureId), 0, 0, 5)
			Me.AddElementFieldInfo("FeatureEntity", "Description", GetType(System.String), False, False, False, False, CInt(FeatureFieldIndex.Description), 50, 0, 0)
		End Sub
		''' <summary>Inits FolderEntity's FieldInfo objects</summary>
		Private Sub InitFolderEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(FolderFieldIndex), "FolderEntity")
			Me.AddElementFieldInfo("FolderEntity", "FolderId", GetType(System.Int64), True, False, True, False, CInt(FolderFieldIndex.FolderId), 0, 0, 19)
			Me.AddElementFieldInfo("FolderEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(FolderFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("FolderEntity", "FolderTypeId", GetType(System.Int64), False, True, False, False, CInt(FolderFieldIndex.FolderTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("FolderEntity", "Name", GetType(System.String), False, False, False, False, CInt(FolderFieldIndex.Name), 260, 0, 0)
			Me.AddElementFieldInfo("FolderEntity", "ParentFolderId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(FolderFieldIndex.ParentFolderId), 0, 0, 19)
			Me.AddElementFieldInfo("FolderEntity", "Sort", GetType(System.Int64), False, False, False, False, CInt(FolderFieldIndex.Sort), 0, 0, 19)
			Me.AddElementFieldInfo("FolderEntity", "Locked", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(FolderFieldIndex.Locked), 0, 0, 0)
			Me.AddElementFieldInfo("FolderEntity", "LockedBy", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(FolderFieldIndex.LockedBy), 0, 0, 19)
			Me.AddElementFieldInfo("FolderEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(FolderFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("FolderEntity", "CreatedBy", GetType(System.Int64), False, True, False, False, CInt(FolderFieldIndex.CreatedBy), 0, 0, 19)
			Me.AddElementFieldInfo("FolderEntity", "Deleted", GetType(System.Boolean), False, False, False, False, CInt(FolderFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits Folder2DocumentEntity's FieldInfo objects</summary>
		Private Sub InitFolder2DocumentEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Folder2DocumentFieldIndex), "Folder2DocumentEntity")
			Me.AddElementFieldInfo("Folder2DocumentEntity", "Folder2DocumentId", GetType(System.Int64), True, False, True, False, CInt(Folder2DocumentFieldIndex.Folder2DocumentId), 0, 0, 19)
			Me.AddElementFieldInfo("Folder2DocumentEntity", "FolderId", GetType(System.Int64), False, True, False, False, CInt(Folder2DocumentFieldIndex.FolderId), 0, 0, 19)
			Me.AddElementFieldInfo("Folder2DocumentEntity", "DocumentId", GetType(System.Int64), False, True, False, False, CInt(Folder2DocumentFieldIndex.DocumentId), 0, 0, 19)
			Me.AddElementFieldInfo("Folder2DocumentEntity", "DocumentStatusId", GetType(System.Int64), False, True, False, False, CInt(Folder2DocumentFieldIndex.DocumentStatusId), 0, 0, 19)
		End Sub
		''' <summary>Inits FolderTypeEntity's FieldInfo objects</summary>
		Private Sub InitFolderTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(FolderTypeFieldIndex), "FolderTypeEntity")
			Me.AddElementFieldInfo("FolderTypeEntity", "FolderTypeId", GetType(System.Int64), True, False, False, False, CInt(FolderTypeFieldIndex.FolderTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("FolderTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(FolderTypeFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("FolderTypeEntity", "Description", GetType(System.String), False, False, False, True, CInt(FolderTypeFieldIndex.Description), 500, 0, 0)
		End Sub
		''' <summary>Inits HelpEntity's FieldInfo objects</summary>
		Private Sub InitHelpEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(HelpFieldIndex), "HelpEntity")
			Me.AddElementFieldInfo("HelpEntity", "HelpId", GetType(System.Int32), True, False, True, False, CInt(HelpFieldIndex.HelpId), 0, 0, 10)
			Me.AddElementFieldInfo("HelpEntity", "TopicId", GetType(System.String), False, False, False, False, CInt(HelpFieldIndex.TopicId), 50, 0, 0)
			Me.AddElementFieldInfo("HelpEntity", "Text", GetType(System.String), False, False, False, False, CInt(HelpFieldIndex.Text), 2147483647, 0, 0)
			Me.AddElementFieldInfo("HelpEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(HelpFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("HelpEntity", "CreatedBy", GetType(System.Int64), False, False, False, False, CInt(HelpFieldIndex.CreatedBy), 0, 0, 19)
			Me.AddElementFieldInfo("HelpEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(HelpFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("HelpEntity", "DeletedBy", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(HelpFieldIndex.DeletedBy), 0, 0, 19)
		End Sub
		''' <summary>Inits InlineHelpEntity's FieldInfo objects</summary>
		Private Sub InitInlineHelpEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(InlineHelpFieldIndex), "InlineHelpEntity")
			Me.AddElementFieldInfo("InlineHelpEntity", "InlineHelpId", GetType(System.Int64), True, False, True, False, CInt(InlineHelpFieldIndex.InlineHelpId), 0, 0, 19)
			Me.AddElementFieldInfo("InlineHelpEntity", "BrandId", GetType(System.Int64), False, True, False, False, CInt(InlineHelpFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("InlineHelpEntity", "ControlId", GetType(System.Int64), False, True, False, False, CInt(InlineHelpFieldIndex.ControlId), 0, 0, 19)
			Me.AddElementFieldInfo("InlineHelpEntity", "SystemText", GetType(System.String), False, False, False, True, CInt(InlineHelpFieldIndex.SystemText), 2000, 0, 0)
		End Sub
		''' <summary>Inits InlineHelpTextEntity's FieldInfo objects</summary>
		Private Sub InitInlineHelpTextEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(InlineHelpTextFieldIndex), "InlineHelpTextEntity")
			Me.AddElementFieldInfo("InlineHelpTextEntity", "InlineHelpTextId", GetType(System.Int64), True, False, True, False, CInt(InlineHelpTextFieldIndex.InlineHelpTextId), 0, 0, 19)
			Me.AddElementFieldInfo("InlineHelpTextEntity", "InlineHelpId", GetType(System.Int64), False, True, False, False, CInt(InlineHelpTextFieldIndex.InlineHelpId), 0, 0, 19)
			Me.AddElementFieldInfo("InlineHelpTextEntity", "LanguageId", GetType(System.Int16), False, True, False, False, CInt(InlineHelpTextFieldIndex.LanguageId), 0, 0, 5)
			Me.AddElementFieldInfo("InlineHelpTextEntity", "LocalizedText", GetType(System.String), False, False, False, False, CInt(InlineHelpTextFieldIndex.LocalizedText), 2000, 0, 0)
		End Sub
		''' <summary>Inits ItemEntity's FieldInfo objects</summary>
		Private Sub InitItemEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ItemFieldIndex), "ItemEntity")
			Me.AddElementFieldInfo("ItemEntity", "ItemId", GetType(System.Int64), True, False, True, False, CInt(ItemFieldIndex.ItemId), 0, 0, 19)
			Me.AddElementFieldInfo("ItemEntity", "ItemNo", GetType(System.String), False, False, False, False, CInt(ItemFieldIndex.ItemNo), 50, 0, 0)
			Me.AddElementFieldInfo("ItemEntity", "Description", GetType(System.String), False, False, False, True, CInt(ItemFieldIndex.Description), 100, 0, 0)
			Me.AddElementFieldInfo("ItemEntity", "ErpsystemId", GetType(System.Byte), False, True, False, False, CInt(ItemFieldIndex.ErpsystemId), 0, 0, 3)
			Me.AddElementFieldInfo("ItemEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ItemFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ItemEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(ItemFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("ItemEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ItemFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("ItemEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(ItemFieldIndex.DeletedBy), 50, 0, 0)
			Me.AddElementFieldInfo("ItemEntity", "ModifiedVersion", GetType(System.Byte()), False, False, True, False, CInt(ItemFieldIndex.ModifiedVersion), 2147483647, 0, 0)
		End Sub
		''' <summary>Inits ItemStatusEntity's FieldInfo objects</summary>
		Private Sub InitItemStatusEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ItemStatusFieldIndex), "ItemStatusEntity")
			Me.AddElementFieldInfo("ItemStatusEntity", "ItemStatusId", GetType(System.Int64), True, False, True, False, CInt(ItemStatusFieldIndex.ItemStatusId), 0, 0, 19)
			Me.AddElementFieldInfo("ItemStatusEntity", "PopulationListItemId", GetType(System.Int64), False, True, False, False, CInt(ItemStatusFieldIndex.PopulationListItemId), 0, 0, 19)
			Me.AddElementFieldInfo("ItemStatusEntity", "ServiceTypeId", GetType(System.Int64), False, True, False, False, CInt(ItemStatusFieldIndex.ServiceTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ItemStatusEntity", "ServiceMessage", GetType(System.String), False, False, False, True, CInt(ItemStatusFieldIndex.ServiceMessage), 50, 0, 0)
			Me.AddElementFieldInfo("ItemStatusEntity", "Planned", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ItemStatusFieldIndex.Planned), 0, 0, 0)
			Me.AddElementFieldInfo("ItemStatusEntity", "Done", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ItemStatusFieldIndex.Done), 0, 0, 0)
			Me.AddElementFieldInfo("ItemStatusEntity", "PaidById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(ItemStatusFieldIndex.PaidById), 0, 0, 19)
			Me.AddElementFieldInfo("ItemStatusEntity", "SaptaskId", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(ItemStatusFieldIndex.SaptaskId), 0, 0, 19)
		End Sub
		''' <summary>Inits ItemSystemMappingEntity's FieldInfo objects</summary>
		Private Sub InitItemSystemMappingEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ItemSystemMappingFieldIndex), "ItemSystemMappingEntity")
			Me.AddElementFieldInfo("ItemSystemMappingEntity", "MappingId", GetType(System.Int64), True, False, True, False, CInt(ItemSystemMappingFieldIndex.MappingId), 0, 0, 19)
			Me.AddElementFieldInfo("ItemSystemMappingEntity", "ItemNo", GetType(System.String), False, False, False, False, CInt(ItemSystemMappingFieldIndex.ItemNo), 50, 0, 0)
			Me.AddElementFieldInfo("ItemSystemMappingEntity", "System", GetType(System.String), False, False, False, True, CInt(ItemSystemMappingFieldIndex.System), 255, 0, 0)
		End Sub
		''' <summary>Inits ItemSystemMappingStagingTableEntity's FieldInfo objects</summary>
		Private Sub InitItemSystemMappingStagingTableEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ItemSystemMappingStagingTableFieldIndex), "ItemSystemMappingStagingTableEntity")
			Me.AddElementFieldInfo("ItemSystemMappingStagingTableEntity", "MappingId", GetType(System.Int64), True, False, True, False, CInt(ItemSystemMappingStagingTableFieldIndex.MappingId), 0, 0, 19)
			Me.AddElementFieldInfo("ItemSystemMappingStagingTableEntity", "ItemNo", GetType(System.String), False, False, False, False, CInt(ItemSystemMappingStagingTableFieldIndex.ItemNo), 50, 0, 0)
			Me.AddElementFieldInfo("ItemSystemMappingStagingTableEntity", "System", GetType(System.String), False, False, False, True, CInt(ItemSystemMappingStagingTableFieldIndex.System), 255, 0, 0)
		End Sub
		''' <summary>Inits LanguageEntity's FieldInfo objects</summary>
		Private Sub InitLanguageEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(LanguageFieldIndex), "LanguageEntity")
			Me.AddElementFieldInfo("LanguageEntity", "LanguageId", GetType(System.Int16), True, False, True, False, CInt(LanguageFieldIndex.LanguageId), 0, 0, 5)
			Me.AddElementFieldInfo("LanguageEntity", "Name", GetType(System.String), False, False, False, False, CInt(LanguageFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("LanguageEntity", "SaplanguageId", GetType(System.String), False, False, False, False, CInt(LanguageFieldIndex.SaplanguageId), 2, 0, 0)
		End Sub
		''' <summary>Inits LogInfoEntity's FieldInfo objects</summary>
		Private Sub InitLogInfoEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(LogInfoFieldIndex), "LogInfoEntity")
			Me.AddElementFieldInfo("LogInfoEntity", "LogInfoId", GetType(System.Int64), True, False, True, False, CInt(LogInfoFieldIndex.LogInfoId), 0, 0, 19)
			Me.AddElementFieldInfo("LogInfoEntity", "CtrlTypeId", GetType(System.Int16), False, False, False, False, CInt(LogInfoFieldIndex.CtrlTypeId), 0, 0, 5)
			Me.AddElementFieldInfo("LogInfoEntity", "Release", GetType(System.Int32), False, False, False, False, CInt(LogInfoFieldIndex.Release), 0, 0, 10)
			Me.AddElementFieldInfo("LogInfoEntity", "LogNo", GetType(System.Int16), False, False, False, False, CInt(LogInfoFieldIndex.LogNo), 0, 0, 5)
			Me.AddElementFieldInfo("LogInfoEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(LogInfoFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("LogInfoEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(LogInfoFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("LogInfoEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(LogInfoFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("LogInfoEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(LogInfoFieldIndex.DeletedBy), 50, 0, 0)
			Me.AddElementFieldInfo("LogInfoEntity", "ModifiedVersion", GetType(System.Byte()), False, False, True, False, CInt(LogInfoFieldIndex.ModifiedVersion), 2147483647, 0, 0)
		End Sub
		''' <summary>Inits LogInfo2LogTxtEntity's FieldInfo objects</summary>
		Private Sub InitLogInfo2LogTxtEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(LogInfo2LogTxtFieldIndex), "LogInfo2LogTxtEntity")
			Me.AddElementFieldInfo("LogInfo2LogTxtEntity", "LogInfo2LogTxtId", GetType(System.Int64), True, False, True, False, CInt(LogInfo2LogTxtFieldIndex.LogInfo2LogTxtId), 0, 0, 19)
			Me.AddElementFieldInfo("LogInfo2LogTxtEntity", "LogInfoId", GetType(System.Int64), False, True, False, False, CInt(LogInfo2LogTxtFieldIndex.LogInfoId), 0, 0, 19)
			Me.AddElementFieldInfo("LogInfo2LogTxtEntity", "LogTxtId", GetType(System.Int64), False, True, False, False, CInt(LogInfo2LogTxtFieldIndex.LogTxtId), 0, 0, 19)
			Me.AddElementFieldInfo("LogInfo2LogTxtEntity", "ModifiedVersion", GetType(System.Byte()), False, False, True, False, CInt(LogInfo2LogTxtFieldIndex.ModifiedVersion), 2147483647, 0, 0)
		End Sub
		''' <summary>Inits LogTxtEntity's FieldInfo objects</summary>
		Private Sub InitLogTxtEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(LogTxtFieldIndex), "LogTxtEntity")
			Me.AddElementFieldInfo("LogTxtEntity", "LogTxtId", GetType(System.Int64), True, False, True, False, CInt(LogTxtFieldIndex.LogTxtId), 0, 0, 19)
			Me.AddElementFieldInfo("LogTxtEntity", "CtrlTypeId", GetType(System.Int16), False, False, False, False, CInt(LogTxtFieldIndex.CtrlTypeId), 0, 0, 5)
			Me.AddElementFieldInfo("LogTxtEntity", "CtrlTypeText", GetType(System.String), False, False, False, True, CInt(LogTxtFieldIndex.CtrlTypeText), 50, 0, 0)
			Me.AddElementFieldInfo("LogTxtEntity", "LogNo", GetType(System.Int16), False, False, False, False, CInt(LogTxtFieldIndex.LogNo), 0, 0, 5)
			Me.AddElementFieldInfo("LogTxtEntity", "Text", GetType(System.String), False, False, False, False, CInt(LogTxtFieldIndex.Text), 30, 0, 0)
			Me.AddElementFieldInfo("LogTxtEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(LogTxtFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("LogTxtEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(LogTxtFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("LogTxtEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(LogTxtFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("LogTxtEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(LogTxtFieldIndex.DeletedBy), 50, 0, 0)
			Me.AddElementFieldInfo("LogTxtEntity", "ModifiedVersion", GetType(System.Byte()), False, False, True, False, CInt(LogTxtFieldIndex.ModifiedVersion), 2147483647, 0, 0)
		End Sub
		''' <summary>Inits MilestoneEntity's FieldInfo objects</summary>
		Private Sub InitMilestoneEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(MilestoneFieldIndex), "MilestoneEntity")
			Me.AddElementFieldInfo("MilestoneEntity", "MilestoneId", GetType(System.Int64), True, False, True, False, CInt(MilestoneFieldIndex.MilestoneId), 0, 0, 19)
			Me.AddElementFieldInfo("MilestoneEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(MilestoneFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("MilestoneEntity", "Description", GetType(System.String), False, False, False, False, CInt(MilestoneFieldIndex.Description), 1600, 0, 0)
			Me.AddElementFieldInfo("MilestoneEntity", "DeadlineDate", GetType(System.DateTime), False, False, False, False, CInt(MilestoneFieldIndex.DeadlineDate), 0, 0, 0)
			Me.AddElementFieldInfo("MilestoneEntity", "ResponsiblePersonId", GetType(System.Int64), False, True, False, False, CInt(MilestoneFieldIndex.ResponsiblePersonId), 0, 0, 19)
			Me.AddElementFieldInfo("MilestoneEntity", "FinishDate", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(MilestoneFieldIndex.FinishDate), 0, 0, 0)
		End Sub
		''' <summary>Inits ModuleEntity's FieldInfo objects</summary>
		Private Sub InitModuleEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ModuleFieldIndex), "ModuleEntity")
			Me.AddElementFieldInfo("ModuleEntity", "ModuleId", GetType(System.Int64), True, False, True, False, CInt(ModuleFieldIndex.ModuleId), 0, 0, 19)
			Me.AddElementFieldInfo("ModuleEntity", "Name", GetType(System.String), False, False, False, False, CInt(ModuleFieldIndex.Name), 50, 0, 0)
		End Sub
		''' <summary>Inits NewsEntity's FieldInfo objects</summary>
		Private Sub InitNewsEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(NewsFieldIndex), "NewsEntity")
			Me.AddElementFieldInfo("NewsEntity", "NewsId", GetType(System.Int64), True, False, True, False, CInt(NewsFieldIndex.NewsId), 0, 0, 19)
			Me.AddElementFieldInfo("NewsEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(NewsFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("NewsEntity", "Name", GetType(System.String), False, False, False, False, CInt(NewsFieldIndex.Name), 100, 0, 0)
			Me.AddElementFieldInfo("NewsEntity", "Description", GetType(System.String), False, False, False, False, CInt(NewsFieldIndex.Description), 1073741823, 0, 0)
			Me.AddElementFieldInfo("NewsEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(NewsFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("NewsEntity", "CreatedbyId", GetType(System.Int64), False, True, False, False, CInt(NewsFieldIndex.CreatedbyId), 0, 0, 19)
			Me.AddElementFieldInfo("NewsEntity", "Modified", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(NewsFieldIndex.Modified), 0, 0, 0)
			Me.AddElementFieldInfo("NewsEntity", "ModifiedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(NewsFieldIndex.ModifiedById), 0, 0, 19)
		End Sub
		''' <summary>Inits News2ParticipantEntity's FieldInfo objects</summary>
		Private Sub InitNews2ParticipantEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(News2ParticipantFieldIndex), "News2ParticipantEntity")
			Me.AddElementFieldInfo("News2ParticipantEntity", "News2ParticipantId", GetType(System.Int64), True, False, True, False, CInt(News2ParticipantFieldIndex.News2ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("News2ParticipantEntity", "NewsId", GetType(System.Int64), False, True, False, False, CInt(News2ParticipantFieldIndex.NewsId), 0, 0, 19)
			Me.AddElementFieldInfo("News2ParticipantEntity", "ParticipantId", GetType(System.Int64), False, True, False, False, CInt(News2ParticipantFieldIndex.ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("News2ParticipantEntity", "SendOn", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(News2ParticipantFieldIndex.SendOn), 0, 0, 0)
		End Sub
		''' <summary>Inits OldCimturbineEntity's FieldInfo objects</summary>
		Private Sub InitOldCimturbineEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(OldCimturbineFieldIndex), "OldCimturbineEntity")
			Me.AddElementFieldInfo("OldCimturbineEntity", "OldCimturbineId", GetType(System.Int64), True, False, True, False, CInt(OldCimturbineFieldIndex.OldCimturbineId), 0, 0, 19)
			Me.AddElementFieldInfo("OldCimturbineEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(OldCimturbineFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("OldCimturbineEntity", "Name", GetType(System.String), False, False, False, False, CInt(OldCimturbineFieldIndex.Name), 50, 0, 0)
		End Sub
		''' <summary>Inits ParticipantEntity's FieldInfo objects</summary>
		Private Sub InitParticipantEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ParticipantFieldIndex), "ParticipantEntity")
			Me.AddElementFieldInfo("ParticipantEntity", "ParticipantId", GetType(System.Int64), True, False, True, False, CInt(ParticipantFieldIndex.ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("ParticipantEntity", "VppersonId", GetType(System.Int32), False, False, False, False, CInt(ParticipantFieldIndex.VppersonId), 0, 0, 10)
			Me.AddElementFieldInfo("ParticipantEntity", "VestasInitials", GetType(System.String), False, False, False, False, CInt(ParticipantFieldIndex.VestasInitials), 10, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "LoginInitials", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.LoginInitials), 25, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "Phone", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.Phone), 30, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "Email", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.Email), 50, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "HasLeft", GetType(System.Boolean), False, False, False, False, CInt(ParticipantFieldIndex.HasLeft), 0, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "FormattedName", GetType(System.String), False, False, False, False, CInt(ParticipantFieldIndex.FormattedName), 100, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "DepartmentId", GetType(System.Int32), False, False, False, False, CInt(ParticipantFieldIndex.DepartmentId), 0, 0, 10)
			Me.AddElementFieldInfo("ParticipantEntity", "SiteId", GetType(System.Int32), False, False, False, False, CInt(ParticipantFieldIndex.SiteId), 0, 0, 10)
			Me.AddElementFieldInfo("ParticipantEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ParticipantFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(ParticipantFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ParticipantFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.DeletedBy), 50, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "Title", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.Title), 50, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "Department", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.Department), 75, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "BusinessUnitId", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(ParticipantFieldIndex.BusinessUnitId), 0, 0, 10)
			Me.AddElementFieldInfo("ParticipantEntity", "BusinessUnit", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.BusinessUnit), 75, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "BusinessUnitShortName", GetType(System.String), False, False, False, True, CInt(ParticipantFieldIndex.BusinessUnitShortName), 50, 0, 0)
			Me.AddElementFieldInfo("ParticipantEntity", "Sbuid", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(ParticipantFieldIndex.Sbuid), 0, 0, 10)
		End Sub
		''' <summary>Inits Participant2RoleEntity's FieldInfo objects</summary>
		Private Sub InitParticipant2RoleEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Participant2RoleFieldIndex), "Participant2RoleEntity")
			Me.AddElementFieldInfo("Participant2RoleEntity", "Participant2RoleId", GetType(System.Int32), True, False, True, False, CInt(Participant2RoleFieldIndex.Participant2RoleId), 0, 0, 10)
			Me.AddElementFieldInfo("Participant2RoleEntity", "ParticipantId", GetType(System.Int64), False, True, False, False, CInt(Participant2RoleFieldIndex.ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("Participant2RoleEntity", "RoleId", GetType(System.Int32), False, True, False, False, CInt(Participant2RoleFieldIndex.RoleId), 0, 0, 10)
		End Sub
		''' <summary>Inits ParticipantLogEntity's FieldInfo objects</summary>
		Private Sub InitParticipantLogEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ParticipantLogFieldIndex), "ParticipantLogEntity")
			Me.AddElementFieldInfo("ParticipantLogEntity", "ParticipantLogId", GetType(System.Int64), True, False, True, False, CInt(ParticipantLogFieldIndex.ParticipantLogId), 0, 0, 19)
			Me.AddElementFieldInfo("ParticipantLogEntity", "ParticipantId", GetType(System.Int64), False, True, False, False, CInt(ParticipantLogFieldIndex.ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("ParticipantLogEntity", "Timestamp", GetType(System.DateTime), False, False, False, False, CInt(ParticipantLogFieldIndex.Timestamp), 0, 0, 0)
			Me.AddElementFieldInfo("ParticipantLogEntity", "Platform", GetType(System.String), False, False, False, False, CInt(ParticipantLogFieldIndex.Platform), 50, 0, 0)
		End Sub
		''' <summary>Inits ParticipationTypeEntity's FieldInfo objects</summary>
		Private Sub InitParticipationTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ParticipationTypeFieldIndex), "ParticipationTypeEntity")
			Me.AddElementFieldInfo("ParticipationTypeEntity", "ParticipationTypeId", GetType(System.Int64), True, False, True, False, CInt(ParticipationTypeFieldIndex.ParticipationTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ParticipationTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ParticipationTypeFieldIndex.Name), 25, 0, 0)
		End Sub
		''' <summary>Inits PayeeEntity's FieldInfo objects</summary>
		Private Sub InitPayeeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PayeeFieldIndex), "PayeeEntity")
			Me.AddElementFieldInfo("PayeeEntity", "PayeeId", GetType(System.Int64), True, False, True, False, CInt(PayeeFieldIndex.PayeeId), 0, 0, 19)
			Me.AddElementFieldInfo("PayeeEntity", "Name", GetType(System.String), False, False, False, False, CInt(PayeeFieldIndex.Name), 20, 0, 0)
		End Sub
		''' <summary>Inits PbuEntity's FieldInfo objects</summary>
		Private Sub InitPbuEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PbuFieldIndex), "PbuEntity")
			Me.AddElementFieldInfo("PbuEntity", "Pbuid", GetType(System.Int64), True, False, True, False, CInt(PbuFieldIndex.Pbuid), 0, 0, 19)
			Me.AddElementFieldInfo("PbuEntity", "Name", GetType(System.String), False, False, False, False, CInt(PbuFieldIndex.Name), 75, 0, 0)
			Me.AddElementFieldInfo("PbuEntity", "ShortName", GetType(System.String), False, False, False, False, CInt(PbuFieldIndex.ShortName), 50, 0, 0)
			Me.AddElementFieldInfo("PbuEntity", "VpdptId", GetType(System.Int32), False, False, False, False, CInt(PbuFieldIndex.VpdptId), 0, 0, 10)
			Me.AddElementFieldInfo("PbuEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(PbuFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("PbuEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(PbuFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("PbuEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PbuFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("PbuEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(PbuFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits PerformanceActionEntity's FieldInfo objects</summary>
		Private Sub InitPerformanceActionEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PerformanceActionFieldIndex), "PerformanceActionEntity")
			Me.AddElementFieldInfo("PerformanceActionEntity", "PerformanceActionId", GetType(System.Int64), True, False, True, False, CInt(PerformanceActionFieldIndex.PerformanceActionId), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceActionEntity", "Name", GetType(System.String), False, False, False, False, CInt(PerformanceActionFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("PerformanceActionEntity", "Description", GetType(System.String), False, False, False, False, CInt(PerformanceActionFieldIndex.Description), 500, 0, 0)
			Me.AddElementFieldInfo("PerformanceActionEntity", "Enabled", GetType(System.Boolean), False, False, False, False, CInt(PerformanceActionFieldIndex.Enabled), 0, 0, 0)
			Me.AddElementFieldInfo("PerformanceActionEntity", "CreatedDateTime", GetType(System.DateTime), False, False, False, False, CInt(PerformanceActionFieldIndex.CreatedDateTime), 0, 0, 0)
			Me.AddElementFieldInfo("PerformanceActionEntity", "CreatedInitials", GetType(System.String), False, False, False, False, CInt(PerformanceActionFieldIndex.CreatedInitials), 50, 0, 0)
			Me.AddElementFieldInfo("PerformanceActionEntity", "DeletedDateTime", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PerformanceActionFieldIndex.DeletedDateTime), 0, 0, 0)
			Me.AddElementFieldInfo("PerformanceActionEntity", "DeletedInitials", GetType(System.String), False, False, False, True, CInt(PerformanceActionFieldIndex.DeletedInitials), 50, 0, 0)
		End Sub
		''' <summary>Inits PerformanceDataEntity's FieldInfo objects</summary>
		Private Sub InitPerformanceDataEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PerformanceDataFieldIndex), "PerformanceDataEntity")
			Me.AddElementFieldInfo("PerformanceDataEntity", "PerformanceDataId", GetType(System.Int64), True, False, True, False, CInt(PerformanceDataFieldIndex.PerformanceDataId), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "PerformanceActionId", GetType(System.Int64), False, True, False, False, CInt(PerformanceDataFieldIndex.PerformanceActionId), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "Duration", GetType(System.Int64), False, False, False, False, CInt(PerformanceDataFieldIndex.Duration), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "ComputerName", GetType(System.String), False, False, False, True, CInt(PerformanceDataFieldIndex.ComputerName), 50, 0, 0)
			Me.AddElementFieldInfo("PerformanceDataEntity", "IpAdress", GetType(System.String), False, False, False, True, CInt(PerformanceDataFieldIndex.IpAdress), 50, 0, 0)
			Me.AddElementFieldInfo("PerformanceDataEntity", "ConnectionType", GetType(System.String), False, False, False, True, CInt(PerformanceDataFieldIndex.ConnectionType), 50, 0, 0)
			Me.AddElementFieldInfo("PerformanceDataEntity", "ProcessId", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(PerformanceDataFieldIndex.ProcessId), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "MemoryUsage", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(PerformanceDataFieldIndex.MemoryUsage), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "AvailableMemory", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(PerformanceDataFieldIndex.AvailableMemory), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "TotalMemory", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(PerformanceDataFieldIndex.TotalMemory), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "CaseId", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(PerformanceDataFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("PerformanceDataEntity", "RunningProcesses", GetType(System.String), False, False, False, False, CInt(PerformanceDataFieldIndex.RunningProcesses), 2147483647, 0, 0)
			Me.AddElementFieldInfo("PerformanceDataEntity", "AdditionalInfo", GetType(System.String), False, False, False, True, CInt(PerformanceDataFieldIndex.AdditionalInfo), 4000, 0, 0)
			Me.AddElementFieldInfo("PerformanceDataEntity", "CreatedDateTime", GetType(System.DateTime), False, False, False, False, CInt(PerformanceDataFieldIndex.CreatedDateTime), 0, 0, 0)
			Me.AddElementFieldInfo("PerformanceDataEntity", "CreatedInitials", GetType(System.String), False, False, False, True, CInt(PerformanceDataFieldIndex.CreatedInitials), 50, 0, 0)
		End Sub
		''' <summary>Inits PerformanceUtilitySettingEntity's FieldInfo objects</summary>
		Private Sub InitPerformanceUtilitySettingEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PerformanceUtilitySettingFieldIndex), "PerformanceUtilitySettingEntity")
			Me.AddElementFieldInfo("PerformanceUtilitySettingEntity", "PerformanceUtilitySettingId", GetType(System.Int32), True, False, True, False, CInt(PerformanceUtilitySettingFieldIndex.PerformanceUtilitySettingId), 0, 0, 10)
			Me.AddElementFieldInfo("PerformanceUtilitySettingEntity", "Name", GetType(System.String), False, False, False, False, CInt(PerformanceUtilitySettingFieldIndex.Name), 256, 0, 0)
			Me.AddElementFieldInfo("PerformanceUtilitySettingEntity", "Value", GetType(System.String), False, False, False, False, CInt(PerformanceUtilitySettingFieldIndex.Value), 4000, 0, 0)
			Me.AddElementFieldInfo("PerformanceUtilitySettingEntity", "CreatedDateTime", GetType(System.DateTime), False, False, False, False, CInt(PerformanceUtilitySettingFieldIndex.CreatedDateTime), 0, 0, 0)
			Me.AddElementFieldInfo("PerformanceUtilitySettingEntity", "CreatedInitials", GetType(System.String), False, False, False, False, CInt(PerformanceUtilitySettingFieldIndex.CreatedInitials), 50, 0, 0)
			Me.AddElementFieldInfo("PerformanceUtilitySettingEntity", "DeletedDateTime", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PerformanceUtilitySettingFieldIndex.DeletedDateTime), 0, 0, 0)
			Me.AddElementFieldInfo("PerformanceUtilitySettingEntity", "DeletedInitials", GetType(System.String), False, False, False, True, CInt(PerformanceUtilitySettingFieldIndex.DeletedInitials), 50, 0, 0)
		End Sub
		''' <summary>Inits PermissionEntity's FieldInfo objects</summary>
		Private Sub InitPermissionEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PermissionFieldIndex), "PermissionEntity")
			Me.AddElementFieldInfo("PermissionEntity", "PermissionId", GetType(System.Int32), True, False, True, False, CInt(PermissionFieldIndex.PermissionId), 0, 0, 10)
			Me.AddElementFieldInfo("PermissionEntity", "Name", GetType(System.String), False, False, False, False, CInt(PermissionFieldIndex.Name), 80, 0, 0)
			Me.AddElementFieldInfo("PermissionEntity", "Description", GetType(System.String), False, False, False, True, CInt(PermissionFieldIndex.Description), 400, 0, 0)
			Me.AddElementFieldInfo("PermissionEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PermissionFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("PermissionEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(PermissionFieldIndex.DeletedBy), 10, 0, 0)
		End Sub
		''' <summary>Inits PersonalSafetyEntity's FieldInfo objects</summary>
		Private Sub InitPersonalSafetyEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PersonalSafetyFieldIndex), "PersonalSafetyEntity")
			Me.AddElementFieldInfo("PersonalSafetyEntity", "PersonalSafetyId", GetType(System.Int64), True, False, True, False, CInt(PersonalSafetyFieldIndex.PersonalSafetyId), 0, 0, 19)
			Me.AddElementFieldInfo("PersonalSafetyEntity", "Name", GetType(System.String), False, False, False, False, CInt(PersonalSafetyFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("PersonalSafetyEntity", "Color", GetType(System.String), False, False, False, True, CInt(PersonalSafetyFieldIndex.Color), 50, 0, 0)
			Me.AddElementFieldInfo("PersonalSafetyEntity", "Sort", GetType(System.Int64), False, False, False, False, CInt(PersonalSafetyFieldIndex.Sort), 0, 0, 19)
			Me.AddElementFieldInfo("PersonalSafetyEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(PersonalSafetyFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("PersonalSafetyEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(PersonalSafetyFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("PersonalSafetyEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(PersonalSafetyFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("PersonalSafetyEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PersonalSafetyFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits PhaseEntity's FieldInfo objects</summary>
		Private Sub InitPhaseEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PhaseFieldIndex), "PhaseEntity")
			Me.AddElementFieldInfo("PhaseEntity", "PhaseId", GetType(System.Int64), True, False, True, False, CInt(PhaseFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("PhaseEntity", "BrandId", GetType(System.Int64), False, True, False, False, CInt(PhaseFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("PhaseEntity", "Name", GetType(System.String), False, False, False, False, CInt(PhaseFieldIndex.Name), 100, 0, 0)
			Me.AddElementFieldInfo("PhaseEntity", "Sort", GetType(System.Byte), False, False, False, False, CInt(PhaseFieldIndex.Sort), 0, 0, 3)
			Me.AddElementFieldInfo("PhaseEntity", "DeadlineInDays", GetType(System.Int32), False, False, False, False, CInt(PhaseFieldIndex.DeadlineInDays), 0, 0, 10)
			Me.AddElementFieldInfo("PhaseEntity", "ProjectPlanVersionId", GetType(System.Int64), False, False, False, False, CInt(PhaseFieldIndex.ProjectPlanVersionId), 0, 0, 19)
			Me.AddElementFieldInfo("PhaseEntity", "MappingId", GetType(System.Int64), False, False, False, False, CInt(PhaseFieldIndex.MappingId), 0, 0, 19)
			Me.AddElementFieldInfo("PhaseEntity", "AllowBundling", GetType(System.Boolean), False, False, False, False, CInt(PhaseFieldIndex.AllowBundling), 0, 0, 0)
			Me.AddElementFieldInfo("PhaseEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(PhaseFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("PhaseEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(PhaseFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("PhaseEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(PhaseFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("PhaseEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PhaseFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("PhaseEntity", "Vissort", GetType(Nullable(Of System.Byte)), False, False, False, True, CInt(PhaseFieldIndex.Vissort), 0, 0, 3)
		End Sub
		''' <summary>Inits Phase2StatusEntity's FieldInfo objects</summary>
		Private Sub InitPhase2StatusEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Phase2StatusFieldIndex), "Phase2StatusEntity")
			Me.AddElementFieldInfo("Phase2StatusEntity", "Phase2StatusId", GetType(System.Int64), True, False, True, False, CInt(Phase2StatusFieldIndex.Phase2StatusId), 0, 0, 19)
			Me.AddElementFieldInfo("Phase2StatusEntity", "PhaseId", GetType(System.Int64), False, True, False, False, CInt(Phase2StatusFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("Phase2StatusEntity", "StatusId", GetType(System.Byte), False, True, False, False, CInt(Phase2StatusFieldIndex.StatusId), 0, 0, 3)
		End Sub
		''' <summary>Inits PlatformEntity's FieldInfo objects</summary>
		Private Sub InitPlatformEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PlatformFieldIndex), "PlatformEntity")
			Me.AddElementFieldInfo("PlatformEntity", "PlatformId", GetType(System.Int64), True, False, True, False, CInt(PlatformFieldIndex.PlatformId), 0, 0, 19)
			Me.AddElementFieldInfo("PlatformEntity", "Name", GetType(System.String), False, False, False, False, CInt(PlatformFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("PlatformEntity", "Coordinator", GetType(System.Int64), False, True, False, False, CInt(PlatformFieldIndex.Coordinator), 0, 0, 19)
		End Sub
		''' <summary>Inits PopulationlistEntity's FieldInfo objects</summary>
		Private Sub InitPopulationlistEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PopulationlistFieldIndex), "PopulationlistEntity")
			Me.AddElementFieldInfo("PopulationlistEntity", "PopulationListId", GetType(System.Int64), True, False, True, False, CInt(PopulationlistFieldIndex.PopulationListId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistEntity", "Version", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(PopulationlistFieldIndex.Version), 0, 0, 10)
			Me.AddElementFieldInfo("PopulationlistEntity", "StateId", GetType(System.Int64), False, True, False, False, CInt(PopulationlistFieldIndex.StateId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistEntity", "Comment", GetType(System.String), False, False, False, True, CInt(PopulationlistFieldIndex.Comment), 1000, 0, 0)
			Me.AddElementFieldInfo("PopulationlistEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(PopulationlistFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistEntity", "CreatedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(PopulationlistFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistEntity", "Created", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PopulationlistFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("PopulationlistEntity", "PhaseId", GetType(System.Int64), False, True, False, False, CInt(PopulationlistFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistEntity", "StatusId", GetType(System.Byte), False, True, False, False, CInt(PopulationlistFieldIndex.StatusId), 0, 0, 3)
		End Sub
		''' <summary>Inits PopulationlistDocumentEntity's FieldInfo objects</summary>
		Private Sub InitPopulationlistDocumentEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PopulationlistDocumentFieldIndex), "PopulationlistDocumentEntity")
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "DocumentId", GetType(System.Int64), True, False, True, False, CInt(PopulationlistDocumentFieldIndex.DocumentId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "PopulationListId", GetType(System.Int64), False, True, False, False, CInt(PopulationlistDocumentFieldIndex.PopulationListId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "FileName", GetType(System.String), False, False, False, False, CInt(PopulationlistDocumentFieldIndex.FileName), 260, 0, 0)
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "FileSize", GetType(System.Int64), False, False, False, False, CInt(PopulationlistDocumentFieldIndex.FileSize), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "FileDate", GetType(System.DateTime), False, False, False, False, CInt(PopulationlistDocumentFieldIndex.FileDate), 0, 0, 0)
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "Locked", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PopulationlistDocumentFieldIndex.Locked), 0, 0, 0)
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "LockedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(PopulationlistDocumentFieldIndex.LockedById), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistDocumentEntity", "DocumentClassificationId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(PopulationlistDocumentFieldIndex.DocumentClassificationId), 0, 0, 19)
		End Sub
		''' <summary>Inits PopulationlistItemEntity's FieldInfo objects</summary>
		Private Sub InitPopulationlistItemEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PopulationlistItemFieldIndex), "PopulationlistItemEntity")
			Me.AddElementFieldInfo("PopulationlistItemEntity", "PopulationlistItemId", GetType(System.Int64), True, False, True, False, CInt(PopulationlistItemFieldIndex.PopulationlistItemId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "PopulationlistId", GetType(System.Int64), False, True, False, False, CInt(PopulationlistItemFieldIndex.PopulationlistId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "UnitId", GetType(System.Int64), False, False, False, False, CInt(PopulationlistItemFieldIndex.UnitId), 0, 0, 19)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "UnitTypeId", GetType(System.String), False, False, False, False, CInt(PopulationlistItemFieldIndex.UnitTypeId), 70, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "MarkVersion", GetType(System.String), False, False, False, True, CInt(PopulationlistItemFieldIndex.MarkVersion), 50, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "Sitename", GetType(System.String), False, False, False, True, CInt(PopulationlistItemFieldIndex.Sitename), 50, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "SbushortName", GetType(System.String), False, False, False, True, CInt(PopulationlistItemFieldIndex.SbushortName), 50, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "SapwarrentyStart", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PopulationlistItemFieldIndex.SapwarrentyStart), 0, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "SapwarrentyEnd", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PopulationlistItemFieldIndex.SapwarrentyEnd), 0, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "SapsubscriptionStart", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PopulationlistItemFieldIndex.SapsubscriptionStart), 0, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "SapsubscriptionEnd", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(PopulationlistItemFieldIndex.SapsubscriptionEnd), 0, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "Country", GetType(System.String), False, False, False, True, CInt(PopulationlistItemFieldIndex.Country), 100, 0, 0)
			Me.AddElementFieldInfo("PopulationlistItemEntity", "ItemWtg", GetType(System.String), False, False, False, False, CInt(PopulationlistItemFieldIndex.ItemWtg), 100, 0, 0)
		End Sub
		''' <summary>Inits PortfolioEntity's FieldInfo objects</summary>
		Private Sub InitPortfolioEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(PortfolioFieldIndex), "PortfolioEntity")
			Me.AddElementFieldInfo("PortfolioEntity", "PortfolioId", GetType(System.Int64), True, False, True, False, CInt(PortfolioFieldIndex.PortfolioId), 0, 0, 19)
			Me.AddElementFieldInfo("PortfolioEntity", "Name", GetType(System.String), False, False, False, False, CInt(PortfolioFieldIndex.Name), 70, 0, 0)
			Me.AddElementFieldInfo("PortfolioEntity", "ManagerInitials", GetType(System.String), False, False, False, False, CInt(PortfolioFieldIndex.ManagerInitials), 10, 0, 0)
			Me.AddElementFieldInfo("PortfolioEntity", "ManagerName", GetType(System.String), False, False, False, False, CInt(PortfolioFieldIndex.ManagerName), 100, 0, 0)
		End Sub
		''' <summary>Inits ProjectEntity's FieldInfo objects</summary>
		Private Sub InitProjectEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ProjectFieldIndex), "ProjectEntity")
			Me.AddElementFieldInfo("ProjectEntity", "ProjectId", GetType(System.Int64), True, False, True, False, CInt(ProjectFieldIndex.ProjectId), 0, 0, 19)
			Me.AddElementFieldInfo("ProjectEntity", "Name", GetType(System.String), False, False, False, False, CInt(ProjectFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("ProjectEntity", "Sort", GetType(System.Byte), False, False, False, False, CInt(ProjectFieldIndex.Sort), 0, 0, 3)
		End Sub
		''' <summary>Inits ProjectScopeEntity's FieldInfo objects</summary>
		Private Sub InitProjectScopeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ProjectScopeFieldIndex), "ProjectScopeEntity")
			Me.AddElementFieldInfo("ProjectScopeEntity", "ProjectScopeId", GetType(System.Int64), True, False, True, False, CInt(ProjectScopeFieldIndex.ProjectScopeId), 0, 0, 19)
			Me.AddElementFieldInfo("ProjectScopeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ProjectScopeFieldIndex.Name), 200, 0, 0)
			Me.AddElementFieldInfo("ProjectScopeEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(ProjectScopeFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("ProjectScopeEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ProjectScopeFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ProjectScopeEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(ProjectScopeFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("ProjectScopeEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ProjectScopeFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits RcEntity's FieldInfo objects</summary>
		Private Sub InitRcEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RcFieldIndex), "RcEntity")
			Me.AddElementFieldInfo("RcEntity", "Rcid", GetType(System.Int64), True, False, True, False, CInt(RcFieldIndex.Rcid), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(RcFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "RcoriginId", GetType(System.Int64), False, True, False, False, CInt(RcFieldIndex.RcoriginId), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "RcoriginResponsibleId", GetType(System.Int64), False, True, False, False, CInt(RcFieldIndex.RcoriginResponsibleId), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "RcoriginUnitId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RcFieldIndex.RcoriginUnitId), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "RccomponentOwnerId", GetType(System.Int64), False, True, False, False, CInt(RcFieldIndex.RccomponentOwnerId), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "Accepted", GetType(System.Boolean), False, False, False, False, CInt(RcFieldIndex.Accepted), 0, 0, 0)
			Me.AddElementFieldInfo("RcEntity", "Comment", GetType(System.String), False, False, False, True, CInt(RcFieldIndex.Comment), 30, 0, 0)
			Me.AddElementFieldInfo("RcEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(RcFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(RcFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("RcEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RcFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RcFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits RccomponentOwnerEntity's FieldInfo objects</summary>
		Private Sub InitRccomponentOwnerEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RccomponentOwnerFieldIndex), "RccomponentOwnerEntity")
			Me.AddElementFieldInfo("RccomponentOwnerEntity", "RccomponentOwnerId", GetType(System.Int64), True, False, True, False, CInt(RccomponentOwnerFieldIndex.RccomponentOwnerId), 0, 0, 19)
			Me.AddElementFieldInfo("RccomponentOwnerEntity", "RccomponentOwner", GetType(System.String), False, False, False, True, CInt(RccomponentOwnerFieldIndex.RccomponentOwner), 100, 0, 0)
			Me.AddElementFieldInfo("RccomponentOwnerEntity", "Created", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RccomponentOwnerFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("RccomponentOwnerEntity", "CreatedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RccomponentOwnerFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("RccomponentOwnerEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RccomponentOwnerFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("RccomponentOwnerEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RccomponentOwnerFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("RccomponentOwnerEntity", "Sort", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(RccomponentOwnerFieldIndex.Sort), 0, 0, 10)
		End Sub
		''' <summary>Inits RcoriginEntity's FieldInfo objects</summary>
		Private Sub InitRcoriginEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RcoriginFieldIndex), "RcoriginEntity")
			Me.AddElementFieldInfo("RcoriginEntity", "RcoriginId", GetType(System.Int64), True, False, True, False, CInt(RcoriginFieldIndex.RcoriginId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginEntity", "Rcorigin", GetType(System.String), False, False, False, False, CInt(RcoriginFieldIndex.Rcorigin), 50, 0, 0)
			Me.AddElementFieldInfo("RcoriginEntity", "RcoriginTooltip", GetType(System.String), False, False, False, True, CInt(RcoriginFieldIndex.RcoriginTooltip), 100, 0, 0)
			Me.AddElementFieldInfo("RcoriginEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(RcoriginFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(RcoriginFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RcoriginFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RcoriginFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginEntity", "Sort", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(RcoriginFieldIndex.Sort), 0, 0, 10)
		End Sub
		''' <summary>Inits RcoriginRelationEntity's FieldInfo objects</summary>
		Private Sub InitRcoriginRelationEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RcoriginRelationFieldIndex), "RcoriginRelationEntity")
			Me.AddElementFieldInfo("RcoriginRelationEntity", "RcoriginRelationId", GetType(System.Int64), True, False, True, False, CInt(RcoriginRelationFieldIndex.RcoriginRelationId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginRelationEntity", "RcoriginId", GetType(System.Int64), False, True, False, False, CInt(RcoriginRelationFieldIndex.RcoriginId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginRelationEntity", "RcoriginResponsibleId", GetType(System.Int64), False, True, False, False, CInt(RcoriginRelationFieldIndex.RcoriginResponsibleId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginRelationEntity", "RcoriginUnitId", GetType(System.Int64), False, True, False, False, CInt(RcoriginRelationFieldIndex.RcoriginUnitId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginRelationEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(RcoriginRelationFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginRelationEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(RcoriginRelationFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginRelationEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RcoriginRelationFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginRelationEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RcoriginRelationFieldIndex.DeletedById), 0, 0, 19)
		End Sub
		''' <summary>Inits RcoriginResponsibleEntity's FieldInfo objects</summary>
		Private Sub InitRcoriginResponsibleEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RcoriginResponsibleFieldIndex), "RcoriginResponsibleEntity")
			Me.AddElementFieldInfo("RcoriginResponsibleEntity", "RcoriginResponsibleId", GetType(System.Int64), True, False, True, False, CInt(RcoriginResponsibleFieldIndex.RcoriginResponsibleId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginResponsibleEntity", "RcoriginResponsible", GetType(System.String), False, False, False, False, CInt(RcoriginResponsibleFieldIndex.RcoriginResponsible), 50, 0, 0)
			Me.AddElementFieldInfo("RcoriginResponsibleEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(RcoriginResponsibleFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginResponsibleEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(RcoriginResponsibleFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginResponsibleEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RcoriginResponsibleFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginResponsibleEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RcoriginResponsibleFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginResponsibleEntity", "Sort", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(RcoriginResponsibleFieldIndex.Sort), 0, 0, 10)
		End Sub
		''' <summary>Inits RcoriginUnitEntity's FieldInfo objects</summary>
		Private Sub InitRcoriginUnitEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RcoriginUnitFieldIndex), "RcoriginUnitEntity")
			Me.AddElementFieldInfo("RcoriginUnitEntity", "RcoriginUnitId", GetType(System.Int64), True, False, True, False, CInt(RcoriginUnitFieldIndex.RcoriginUnitId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "RcoriginUnit", GetType(System.String), False, False, False, False, CInt(RcoriginUnitFieldIndex.RcoriginUnit), 50, 0, 0)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "VpDptId", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(RcoriginUnitFieldIndex.VpDptId), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "IsSbu", GetType(Nullable(Of System.Boolean)), False, False, False, True, CInt(RcoriginUnitFieldIndex.IsSbu), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "IsPbu", GetType(Nullable(Of System.Boolean)), False, False, False, True, CInt(RcoriginUnitFieldIndex.IsPbu), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(RcoriginUnitFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(RcoriginUnitFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RcoriginUnitFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(RcoriginUnitFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("RcoriginUnitEntity", "Sort", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(RcoriginUnitFieldIndex.Sort), 0, 0, 10)
		End Sub
		''' <summary>Inits ReasonCodeEntity's FieldInfo objects</summary>
		Private Sub InitReasonCodeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ReasonCodeFieldIndex), "ReasonCodeEntity")
			Me.AddElementFieldInfo("ReasonCodeEntity", "ReasonCodeId", GetType(System.Int64), True, False, True, False, CInt(ReasonCodeFieldIndex.ReasonCodeId), 0, 0, 19)
			Me.AddElementFieldInfo("ReasonCodeEntity", "ReasonCodeNo", GetType(System.String), False, False, False, False, CInt(ReasonCodeFieldIndex.ReasonCodeNo), 50, 0, 0)
			Me.AddElementFieldInfo("ReasonCodeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ReasonCodeFieldIndex.Name), 50, 0, 0)
		End Sub
		''' <summary>Inits RelatedCaseEntity's FieldInfo objects</summary>
		Private Sub InitRelatedCaseEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RelatedCaseFieldIndex), "RelatedCaseEntity")
			Me.AddElementFieldInfo("RelatedCaseEntity", "RelatedCaseId", GetType(System.Int64), True, False, True, False, CInt(RelatedCaseFieldIndex.RelatedCaseId), 0, 0, 19)
			Me.AddElementFieldInfo("RelatedCaseEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(RelatedCaseFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("RelatedCaseEntity", "CaseIdRelated", GetType(System.Int64), False, True, False, False, CInt(RelatedCaseFieldIndex.CaseIdRelated), 0, 0, 19)
		End Sub
		''' <summary>Inits RelatedCase2CaseRelationEntity's FieldInfo objects</summary>
		Private Sub InitRelatedCase2CaseRelationEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RelatedCase2CaseRelationFieldIndex), "RelatedCase2CaseRelationEntity")
			Me.AddElementFieldInfo("RelatedCase2CaseRelationEntity", "RelatedCase2CaseRelationId", GetType(System.Int64), True, False, True, False, CInt(RelatedCase2CaseRelationFieldIndex.RelatedCase2CaseRelationId), 0, 0, 19)
			Me.AddElementFieldInfo("RelatedCase2CaseRelationEntity", "RelatedCaseId", GetType(System.Int64), False, True, False, False, CInt(RelatedCase2CaseRelationFieldIndex.RelatedCaseId), 0, 0, 19)
			Me.AddElementFieldInfo("RelatedCase2CaseRelationEntity", "CaseRelationId", GetType(System.Int64), False, True, False, False, CInt(RelatedCase2CaseRelationFieldIndex.CaseRelationId), 0, 0, 19)
		End Sub
		''' <summary>Inits RelatedItemEntity's FieldInfo objects</summary>
		Private Sub InitRelatedItemEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RelatedItemFieldIndex), "RelatedItemEntity")
			Me.AddElementFieldInfo("RelatedItemEntity", "RelatedItemId", GetType(System.Int64), True, False, True, False, CInt(RelatedItemFieldIndex.RelatedItemId), 0, 0, 19)
			Me.AddElementFieldInfo("RelatedItemEntity", "ItemId", GetType(System.Int64), False, True, False, False, CInt(RelatedItemFieldIndex.ItemId), 0, 0, 19)
			Me.AddElementFieldInfo("RelatedItemEntity", "ItemIdRelated", GetType(System.Int64), False, True, False, False, CInt(RelatedItemFieldIndex.ItemIdRelated), 0, 0, 19)
		End Sub
		''' <summary>Inits ReportTypeEntity's FieldInfo objects</summary>
		Private Sub InitReportTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ReportTypeFieldIndex), "ReportTypeEntity")
			Me.AddElementFieldInfo("ReportTypeEntity", "ReportTypeId", GetType(System.Int64), True, False, False, False, CInt(ReportTypeFieldIndex.ReportTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ReportTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ReportTypeFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("ReportTypeEntity", "LanguageId", GetType(System.Int64), False, False, False, False, CInt(ReportTypeFieldIndex.LanguageId), 0, 0, 19)
			Me.AddElementFieldInfo("ReportTypeEntity", "ParentReportTypeId", GetType(Nullable(Of System.Int64)), False, False, False, True, CInt(ReportTypeFieldIndex.ParentReportTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ReportTypeEntity", "Sort", GetType(System.Int64), False, False, False, False, CInt(ReportTypeFieldIndex.Sort), 0, 0, 19)
		End Sub
		''' <summary>Inits RoleEntity's FieldInfo objects</summary>
		Private Sub InitRoleEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(RoleFieldIndex), "RoleEntity")
			Me.AddElementFieldInfo("RoleEntity", "RoleId", GetType(System.Int32), True, False, True, False, CInt(RoleFieldIndex.RoleId), 0, 0, 10)
			Me.AddElementFieldInfo("RoleEntity", "Name", GetType(System.String), False, False, False, False, CInt(RoleFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "Description", GetType(System.String), False, False, False, True, CInt(RoleFieldIndex.Description), 400, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "GrantToProjectManager", GetType(System.Boolean), False, False, False, False, CInt(RoleFieldIndex.GrantToProjectManager), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "GrantToTechnicalSpecialist", GetType(System.Boolean), False, False, False, False, CInt(RoleFieldIndex.GrantToTechnicalSpecialist), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "GrantToExecutionManager", GetType(System.Boolean), False, False, False, False, CInt(RoleFieldIndex.GrantToExecutionManager), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "GrantToCaseCreator", GetType(System.Boolean), False, False, False, False, CInt(RoleFieldIndex.GrantToCaseCreator), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "GrantToPlatformManager", GetType(System.Boolean), False, False, False, False, CInt(RoleFieldIndex.GrantToPlatformManager), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "GrantToProjectParticipant", GetType(System.Boolean), False, False, False, False, CInt(RoleFieldIndex.GrantToProjectParticipant), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "GrantToEveryone", GetType(System.Boolean), False, False, False, False, CInt(RoleFieldIndex.GrantToEveryone), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(RoleFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(RoleFieldIndex.CreatedBy), 10, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "Updated", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RoleFieldIndex.Updated), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "UpdatedBy", GetType(System.String), False, False, False, True, CInt(RoleFieldIndex.UpdatedBy), 10, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(RoleFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("RoleEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(RoleFieldIndex.DeletedBy), 10, 0, 0)
		End Sub
		''' <summary>Inits Role2PermissionEntity's FieldInfo objects</summary>
		Private Sub InitRole2PermissionEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(Role2PermissionFieldIndex), "Role2PermissionEntity")
			Me.AddElementFieldInfo("Role2PermissionEntity", "Role2PermissionId", GetType(System.Int32), True, False, True, False, CInt(Role2PermissionFieldIndex.Role2PermissionId), 0, 0, 10)
			Me.AddElementFieldInfo("Role2PermissionEntity", "RoleId", GetType(System.Int32), False, True, False, False, CInt(Role2PermissionFieldIndex.RoleId), 0, 0, 10)
			Me.AddElementFieldInfo("Role2PermissionEntity", "PermissionId", GetType(System.Int32), False, True, False, False, CInt(Role2PermissionFieldIndex.PermissionId), 0, 0, 10)
		End Sub
		''' <summary>Inits SbuEntity's FieldInfo objects</summary>
		Private Sub InitSbuEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(SbuFieldIndex), "SbuEntity")
			Me.AddElementFieldInfo("SbuEntity", "Sbuid", GetType(System.Int64), True, False, True, False, CInt(SbuFieldIndex.Sbuid), 0, 0, 19)
			Me.AddElementFieldInfo("SbuEntity", "Name", GetType(System.String), False, False, False, False, CInt(SbuFieldIndex.Name), 75, 0, 0)
			Me.AddElementFieldInfo("SbuEntity", "ShortName", GetType(System.String), False, False, False, False, CInt(SbuFieldIndex.ShortName), 50, 0, 0)
			Me.AddElementFieldInfo("SbuEntity", "VpdptId", GetType(System.Int32), False, False, False, False, CInt(SbuFieldIndex.VpdptId), 0, 0, 10)
			Me.AddElementFieldInfo("SbuEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(SbuFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("SbuEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(SbuFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("SbuEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(SbuFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("SbuEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(SbuFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits SbucloneEntity's FieldInfo objects</summary>
		Private Sub InitSbucloneEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(SbucloneFieldIndex), "SbucloneEntity")
			Me.AddElementFieldInfo("SbucloneEntity", "Sbuid", GetType(System.Int64), True, False, True, False, CInt(SbucloneFieldIndex.Sbuid), 0, 0, 19)
			Me.AddElementFieldInfo("SbucloneEntity", "Name", GetType(System.String), False, False, False, False, CInt(SbucloneFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("SbucloneEntity", "ShortName", GetType(System.String), False, False, False, False, CInt(SbucloneFieldIndex.ShortName), 50, 0, 0)
			Me.AddElementFieldInfo("SbucloneEntity", "VpdptId", GetType(System.Int32), False, False, False, False, CInt(SbucloneFieldIndex.VpdptId), 0, 0, 10)
			Me.AddElementFieldInfo("SbucloneEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(SbucloneFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("SbucloneEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(SbucloneFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("SbucloneEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(SbucloneFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("SbucloneEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(SbucloneFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits SearchProfileEntity's FieldInfo objects</summary>
		Private Sub InitSearchProfileEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(SearchProfileFieldIndex), "SearchProfileEntity")
			Me.AddElementFieldInfo("SearchProfileEntity", "SearchProfileId", GetType(System.Int64), True, False, True, False, CInt(SearchProfileFieldIndex.SearchProfileId), 0, 0, 19)
			Me.AddElementFieldInfo("SearchProfileEntity", "UserId", GetType(System.String), False, False, False, False, CInt(SearchProfileFieldIndex.UserId), 50, 0, 0)
			Me.AddElementFieldInfo("SearchProfileEntity", "Name", GetType(System.String), False, False, False, False, CInt(SearchProfileFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("SearchProfileEntity", "IsPublic", GetType(System.Boolean), False, False, False, False, CInt(SearchProfileFieldIndex.IsPublic), 0, 0, 0)
		End Sub
		''' <summary>Inits SearchProfileDetailEntity's FieldInfo objects</summary>
		Private Sub InitSearchProfileDetailEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(SearchProfileDetailFieldIndex), "SearchProfileDetailEntity")
			Me.AddElementFieldInfo("SearchProfileDetailEntity", "SearchProfileDetailId", GetType(System.Int64), True, False, True, False, CInt(SearchProfileDetailFieldIndex.SearchProfileDetailId), 0, 0, 19)
			Me.AddElementFieldInfo("SearchProfileDetailEntity", "SearchProfileId", GetType(System.Int64), False, True, False, False, CInt(SearchProfileDetailFieldIndex.SearchProfileId), 0, 0, 19)
			Me.AddElementFieldInfo("SearchProfileDetailEntity", "InputId", GetType(System.String), False, False, False, False, CInt(SearchProfileDetailFieldIndex.InputId), 256, 0, 0)
			Me.AddElementFieldInfo("SearchProfileDetailEntity", "Value", GetType(System.String), False, False, False, False, CInt(SearchProfileDetailFieldIndex.Value), 100, 0, 0)
			Me.AddElementFieldInfo("SearchProfileDetailEntity", "InputType", GetType(System.String), False, False, False, False, CInt(SearchProfileDetailFieldIndex.InputType), 50, 0, 0)
		End Sub
		''' <summary>Inits ServiceCodeEntity's FieldInfo objects</summary>
		Private Sub InitServiceCodeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ServiceCodeFieldIndex), "ServiceCodeEntity")
			Me.AddElementFieldInfo("ServiceCodeEntity", "ServiceCodeId", GetType(System.Int64), True, False, True, False, CInt(ServiceCodeFieldIndex.ServiceCodeId), 0, 0, 19)
			Me.AddElementFieldInfo("ServiceCodeEntity", "ServiceGroupId", GetType(System.Int64), False, True, False, False, CInt(ServiceCodeFieldIndex.ServiceGroupId), 0, 0, 19)
			Me.AddElementFieldInfo("ServiceCodeEntity", "VdbserviceCodeId", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(ServiceCodeFieldIndex.VdbserviceCodeId), 0, 0, 10)
			Me.AddElementFieldInfo("ServiceCodeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ServiceCodeFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("ServiceCodeEntity", "Sort", GetType(System.Int16), False, False, False, False, CInt(ServiceCodeFieldIndex.Sort), 0, 0, 5)
			Me.AddElementFieldInfo("ServiceCodeEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ServiceCodeFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ServiceCodeEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(ServiceCodeFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("ServiceCodeEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ServiceCodeFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("ServiceCodeEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(ServiceCodeFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits ServiceGroupEntity's FieldInfo objects</summary>
		Private Sub InitServiceGroupEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ServiceGroupFieldIndex), "ServiceGroupEntity")
			Me.AddElementFieldInfo("ServiceGroupEntity", "ServiceGroupId", GetType(System.Int64), True, False, True, False, CInt(ServiceGroupFieldIndex.ServiceGroupId), 0, 0, 19)
			Me.AddElementFieldInfo("ServiceGroupEntity", "VdbmainGroupId", GetType(Nullable(Of System.Int32)), False, False, False, True, CInt(ServiceGroupFieldIndex.VdbmainGroupId), 0, 0, 10)
			Me.AddElementFieldInfo("ServiceGroupEntity", "Name", GetType(System.String), False, False, False, False, CInt(ServiceGroupFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("ServiceGroupEntity", "Sort", GetType(System.Int16), False, False, False, False, CInt(ServiceGroupFieldIndex.Sort), 0, 0, 5)
			Me.AddElementFieldInfo("ServiceGroupEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(ServiceGroupFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("ServiceGroupEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(ServiceGroupFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("ServiceGroupEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(ServiceGroupFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("ServiceGroupEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(ServiceGroupFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits ServiceTypeEntity's FieldInfo objects</summary>
		Private Sub InitServiceTypeEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(ServiceTypeFieldIndex), "ServiceTypeEntity")
			Me.AddElementFieldInfo("ServiceTypeEntity", "ServiceTypeId", GetType(System.Int64), True, False, True, False, CInt(ServiceTypeFieldIndex.ServiceTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("ServiceTypeEntity", "Name", GetType(System.String), False, False, False, False, CInt(ServiceTypeFieldIndex.Name), 50, 0, 0)
		End Sub
		''' <summary>Inits StageEntity's FieldInfo objects</summary>
		Private Sub InitStageEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(StageFieldIndex), "StageEntity")
			Me.AddElementFieldInfo("StageEntity", "StageId", GetType(System.Byte), True, False, True, False, CInt(StageFieldIndex.StageId), 0, 0, 3)
			Me.AddElementFieldInfo("StageEntity", "Name", GetType(System.String), False, False, False, False, CInt(StageFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("StageEntity", "Sort", GetType(System.Byte), False, False, False, False, CInt(StageFieldIndex.Sort), 0, 0, 3)
		End Sub
		''' <summary>Inits StandardFolderEntity's FieldInfo objects</summary>
		Private Sub InitStandardFolderEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(StandardFolderFieldIndex), "StandardFolderEntity")
			Me.AddElementFieldInfo("StandardFolderEntity", "StandardFolderId", GetType(System.Int64), True, False, True, False, CInt(StandardFolderFieldIndex.StandardFolderId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardFolderEntity", "BrandId", GetType(System.Int64), False, True, False, False, CInt(StandardFolderFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardFolderEntity", "FolderTypeId", GetType(System.Int64), False, True, False, False, CInt(StandardFolderFieldIndex.FolderTypeId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardFolderEntity", "Name", GetType(System.String), False, False, False, False, CInt(StandardFolderFieldIndex.Name), 260, 0, 0)
			Me.AddElementFieldInfo("StandardFolderEntity", "ParentStandardFolderId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(StandardFolderFieldIndex.ParentStandardFolderId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardFolderEntity", "Sort", GetType(System.Int64), False, False, False, False, CInt(StandardFolderFieldIndex.Sort), 0, 0, 19)
		End Sub
		''' <summary>Inits StandardMilestoneEntity's FieldInfo objects</summary>
		Private Sub InitStandardMilestoneEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(StandardMilestoneFieldIndex), "StandardMilestoneEntity")
			Me.AddElementFieldInfo("StandardMilestoneEntity", "StandardMilestoneId", GetType(System.Int64), True, False, True, False, CInt(StandardMilestoneFieldIndex.StandardMilestoneId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardMilestoneEntity", "DeadlineOffset", GetType(System.Int32), False, False, False, False, CInt(StandardMilestoneFieldIndex.DeadlineOffset), 0, 0, 10)
			Me.AddElementFieldInfo("StandardMilestoneEntity", "Description", GetType(System.String), False, False, False, False, CInt(StandardMilestoneFieldIndex.Description), 100, 0, 0)
		End Sub
		''' <summary>Inits StandardTaskEntity's FieldInfo objects</summary>
		Private Sub InitStandardTaskEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(StandardTaskFieldIndex), "StandardTaskEntity")
			Me.AddElementFieldInfo("StandardTaskEntity", "StandardTaskId", GetType(System.Int64), True, False, True, False, CInt(StandardTaskFieldIndex.StandardTaskId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTaskEntity", "BrandId", GetType(System.Int64), False, True, False, False, CInt(StandardTaskFieldIndex.BrandId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTaskEntity", "Name", GetType(System.String), False, False, False, False, CInt(StandardTaskFieldIndex.Name), 100, 0, 0)
			Me.AddElementFieldInfo("StandardTaskEntity", "TemplateVersion", GetType(System.Int32), False, False, False, False, CInt(StandardTaskFieldIndex.TemplateVersion), 0, 0, 10)
			Me.AddElementFieldInfo("StandardTaskEntity", "IsGate", GetType(System.Boolean), False, False, False, False, CInt(StandardTaskFieldIndex.IsGate), 0, 0, 0)
			Me.AddElementFieldInfo("StandardTaskEntity", "Sort", GetType(System.Int32), False, False, False, False, CInt(StandardTaskFieldIndex.Sort), 0, 0, 10)
			Me.AddElementFieldInfo("StandardTaskEntity", "PhaseId", GetType(System.Int64), False, True, False, False, CInt(StandardTaskFieldIndex.PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTaskEntity", "MappingId", GetType(System.Int64), False, False, False, False, CInt(StandardTaskFieldIndex.MappingId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTaskEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(StandardTaskFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTaskEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(StandardTaskFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("StandardTaskEntity", "Vissort", GetType(Nullable(Of System.Byte)), False, False, False, True, CInt(StandardTaskFieldIndex.Vissort), 0, 0, 3)
			Me.AddElementFieldInfo("StandardTaskEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(StandardTaskFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTaskEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(StandardTaskFieldIndex.Created), 0, 0, 0)
		End Sub
		''' <summary>Inits StandardTask2StatusEntity's FieldInfo objects</summary>
		Private Sub InitStandardTask2StatusEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(StandardTask2StatusFieldIndex), "StandardTask2StatusEntity")
			Me.AddElementFieldInfo("StandardTask2StatusEntity", "StandardTask2StatusId", GetType(System.Int64), True, False, True, False, CInt(StandardTask2StatusFieldIndex.StandardTask2StatusId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTask2StatusEntity", "StandardTaskId", GetType(System.Int64), False, True, False, False, CInt(StandardTask2StatusFieldIndex.StandardTaskId), 0, 0, 19)
			Me.AddElementFieldInfo("StandardTask2StatusEntity", "StatusId", GetType(System.Byte), False, True, False, False, CInt(StandardTask2StatusFieldIndex.StatusId), 0, 0, 3)
			Me.AddElementFieldInfo("StandardTask2StatusEntity", "Sort", GetType(System.Byte), False, False, False, False, CInt(StandardTask2StatusFieldIndex.Sort), 0, 0, 3)
		End Sub
		''' <summary>Inits StateEntity's FieldInfo objects</summary>
		Private Sub InitStateEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(StateFieldIndex), "StateEntity")
			Me.AddElementFieldInfo("StateEntity", "StateId", GetType(System.Int64), True, False, True, False, CInt(StateFieldIndex.StateId), 0, 0, 19)
			Me.AddElementFieldInfo("StateEntity", "Name", GetType(System.String), False, False, False, False, CInt(StateFieldIndex.Name), 20, 0, 0)
		End Sub
		''' <summary>Inits StatusEntity's FieldInfo objects</summary>
		Private Sub InitStatusEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(StatusFieldIndex), "StatusEntity")
			Me.AddElementFieldInfo("StatusEntity", "StatusId", GetType(System.Byte), True, False, True, False, CInt(StatusFieldIndex.StatusId), 0, 0, 3)
			Me.AddElementFieldInfo("StatusEntity", "Name", GetType(System.String), False, False, False, False, CInt(StatusFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("StatusEntity", "Sort", GetType(System.Byte), False, False, False, False, CInt(StatusFieldIndex.Sort), 0, 0, 3)
			Me.AddElementFieldInfo("StatusEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(StatusFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("StatusEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(StatusFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("StatusEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(StatusFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("StatusEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(StatusFieldIndex.Deleted), 0, 0, 0)
		End Sub
		''' <summary>Inits SupplierEntity's FieldInfo objects</summary>
		Private Sub InitSupplierEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(SupplierFieldIndex), "SupplierEntity")
			Me.AddElementFieldInfo("SupplierEntity", "SupplierId", GetType(System.Int64), True, False, True, False, CInt(SupplierFieldIndex.SupplierId), 0, 0, 19)
			Me.AddElementFieldInfo("SupplierEntity", "SupplierEnvironmentId", GetType(System.String), False, True, False, False, CInt(SupplierFieldIndex.SupplierEnvironmentId), 10, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "VendorId", GetType(System.String), False, False, False, False, CInt(SupplierFieldIndex.VendorId), 10, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "VirtualId", GetType(System.Int32), False, False, False, False, CInt(SupplierFieldIndex.VirtualId), 0, 0, 10)
			Me.AddElementFieldInfo("SupplierEntity", "Name", GetType(System.String), False, False, False, False, CInt(SupplierFieldIndex.Name), 50, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "Address1", GetType(System.String), False, False, False, True, CInt(SupplierFieldIndex.Address1), 50, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "Address2", GetType(System.String), False, False, False, True, CInt(SupplierFieldIndex.Address2), 50, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "Phone", GetType(System.String), False, False, False, True, CInt(SupplierFieldIndex.Phone), 25, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "Email", GetType(System.String), False, False, False, True, CInt(SupplierFieldIndex.Email), 70, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(SupplierFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(SupplierFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(SupplierFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(SupplierFieldIndex.DeletedBy), 50, 0, 0)
			Me.AddElementFieldInfo("SupplierEntity", "ModifiedVersion", GetType(System.Byte()), False, False, True, False, CInt(SupplierFieldIndex.ModifiedVersion), 2147483647, 0, 0)
		End Sub
		''' <summary>Inits SupplierEnvironmentEntity's FieldInfo objects</summary>
		Private Sub InitSupplierEnvironmentEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(SupplierEnvironmentFieldIndex), "SupplierEnvironmentEntity")
			Me.AddElementFieldInfo("SupplierEnvironmentEntity", "SupplierEnvironmentId", GetType(System.String), True, False, False, False, CInt(SupplierEnvironmentFieldIndex.SupplierEnvironmentId), 10, 0, 0)
			Me.AddElementFieldInfo("SupplierEnvironmentEntity", "Name", GetType(System.String), False, False, False, False, CInt(SupplierEnvironmentFieldIndex.Name), 250, 0, 0)
			Me.AddElementFieldInfo("SupplierEnvironmentEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(SupplierEnvironmentFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("SupplierEnvironmentEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(SupplierEnvironmentFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("SupplierEnvironmentEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(SupplierEnvironmentFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("SupplierEnvironmentEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(SupplierEnvironmentFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits SystemDescriptionEntity's FieldInfo objects</summary>
		Private Sub InitSystemDescriptionEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(SystemDescriptionFieldIndex), "SystemDescriptionEntity")
			Me.AddElementFieldInfo("SystemDescriptionEntity", "System", GetType(System.String), True, False, False, False, CInt(SystemDescriptionFieldIndex.System), 255, 0, 0)
			Me.AddElementFieldInfo("SystemDescriptionEntity", "Description", GetType(System.String), False, False, False, True, CInt(SystemDescriptionFieldIndex.Description), 255, 0, 0)
		End Sub
		''' <summary>Inits TaskEntity's FieldInfo objects</summary>
		Private Sub InitTaskEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TaskFieldIndex), "TaskEntity")
			Me.AddElementFieldInfo("TaskEntity", "TaskId", GetType(System.Int64), True, False, True, False, CInt(TaskFieldIndex.TaskId), 0, 0, 19)
			Me.AddElementFieldInfo("TaskEntity", "StandardTaskId", GetType(System.Int64), False, True, False, False, CInt(TaskFieldIndex.StandardTaskId), 0, 0, 19)
			Me.AddElementFieldInfo("TaskEntity", "Case2PhaseId", GetType(System.Int64), False, True, False, False, CInt(TaskFieldIndex.Case2PhaseId), 0, 0, 19)
			Me.AddElementFieldInfo("TaskEntity", "StartDate", GetType(System.DateTime), False, False, False, False, CInt(TaskFieldIndex.StartDate), 0, 0, 0)
			Me.AddElementFieldInfo("TaskEntity", "FinishDate", GetType(System.DateTime), False, False, False, False, CInt(TaskFieldIndex.FinishDate), 0, 0, 0)
			Me.AddElementFieldInfo("TaskEntity", "DurationHours", GetType(System.Decimal), False, False, False, False, CInt(TaskFieldIndex.DurationHours), 0, 2, 7)
			Me.AddElementFieldInfo("TaskEntity", "PercentComplete", GetType(System.Byte), False, False, False, False, CInt(TaskFieldIndex.PercentComplete), 0, 0, 3)
			Me.AddElementFieldInfo("TaskEntity", "ScheduleComments", GetType(System.String), False, False, False, True, CInt(TaskFieldIndex.ScheduleComments), 1000, 0, 0)
			Me.AddElementFieldInfo("TaskEntity", "ResponsiblePersonId", GetType(System.Int64), False, True, False, False, CInt(TaskFieldIndex.ResponsiblePersonId), 0, 0, 19)
			Me.AddElementFieldInfo("TaskEntity", "Description", GetType(System.String), False, False, False, True, CInt(TaskFieldIndex.Description), 100, 0, 0)
		End Sub
		''' <summary>Inits TaskMilestoneEntity's FieldInfo objects</summary>
		Private Sub InitTaskMilestoneEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TaskMilestoneFieldIndex), "TaskMilestoneEntity")
			Me.AddElementFieldInfo("TaskMilestoneEntity", "TaskMilestoneId", GetType(System.Int64), True, False, True, False, CInt(TaskMilestoneFieldIndex.TaskMilestoneId), 0, 0, 19)
			Me.AddElementFieldInfo("TaskMilestoneEntity", "TaskId", GetType(System.Int64), False, True, False, False, CInt(TaskMilestoneFieldIndex.TaskId), 0, 0, 19)
			Me.AddElementFieldInfo("TaskMilestoneEntity", "Name", GetType(System.String), False, False, False, False, CInt(TaskMilestoneFieldIndex.Name), 250, 0, 0)
			Me.AddElementFieldInfo("TaskMilestoneEntity", "FinishDate", GetType(System.DateTime), False, False, False, False, CInt(TaskMilestoneFieldIndex.FinishDate), 0, 0, 0)
			Me.AddElementFieldInfo("TaskMilestoneEntity", "PercentComplete", GetType(System.Byte), False, False, False, False, CInt(TaskMilestoneFieldIndex.PercentComplete), 0, 0, 3)
			Me.AddElementFieldInfo("TaskMilestoneEntity", "ScheduleComments", GetType(System.String), False, False, False, True, CInt(TaskMilestoneFieldIndex.ScheduleComments), 1000, 0, 0)
			Me.AddElementFieldInfo("TaskMilestoneEntity", "ResponsiblePersonId", GetType(System.Int64), False, True, False, False, CInt(TaskMilestoneFieldIndex.ResponsiblePersonId), 0, 0, 19)
		End Sub
		''' <summary>Inits TimelineEntity's FieldInfo objects</summary>
		Private Sub InitTimelineEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TimelineFieldIndex), "TimelineEntity")
			Me.AddElementFieldInfo("TimelineEntity", "TimelineId", GetType(System.Int64), True, False, True, False, CInt(TimelineFieldIndex.TimelineId), 0, 0, 19)
			Me.AddElementFieldInfo("TimelineEntity", "Text", GetType(System.String), False, False, False, False, CInt(TimelineFieldIndex.Text), 150, 0, 0)
			Me.AddElementFieldInfo("TimelineEntity", "Changed", GetType(System.DateTime), False, False, False, False, CInt(TimelineFieldIndex.Changed), 0, 0, 0)
			Me.AddElementFieldInfo("TimelineEntity", "ChangedBy", GetType(System.Int64), False, True, False, False, CInt(TimelineFieldIndex.ChangedBy), 0, 0, 19)
			Me.AddElementFieldInfo("TimelineEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(TimelineFieldIndex.CaseId), 0, 0, 19)
		End Sub
		''' <summary>Inits TurbineEntity's FieldInfo objects</summary>
		Private Sub InitTurbineEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineFieldIndex), "TurbineEntity")
			Me.AddElementFieldInfo("TurbineEntity", "TurbineId", GetType(System.Int64), True, False, False, False, CInt(TurbineFieldIndex.TurbineId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineEntity", "Turbine", GetType(System.String), False, False, False, False, CInt(TurbineFieldIndex.Turbine), 20, 0, 0)
			Me.AddElementFieldInfo("TurbineEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineFrequencyEntity's FieldInfo objects</summary>
		Private Sub InitTurbineFrequencyEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineFrequencyFieldIndex), "TurbineFrequencyEntity")
			Me.AddElementFieldInfo("TurbineFrequencyEntity", "TurbineFrequencyId", GetType(System.Int64), True, False, False, False, CInt(TurbineFrequencyFieldIndex.TurbineFrequencyId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineFrequencyEntity", "Frequency", GetType(System.String), False, False, False, False, CInt(TurbineFrequencyFieldIndex.Frequency), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineFrequencyEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineFrequencyFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineFrequencyEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineFrequencyFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineFrequencyEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineFrequencyFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineFrequencyEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineFrequencyFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineManufacturerEntity's FieldInfo objects</summary>
		Private Sub InitTurbineManufacturerEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineManufacturerFieldIndex), "TurbineManufacturerEntity")
			Me.AddElementFieldInfo("TurbineManufacturerEntity", "TurbineManufacturerId", GetType(System.Int64), True, False, False, False, CInt(TurbineManufacturerFieldIndex.TurbineManufacturerId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineManufacturerEntity", "Manufacturer", GetType(System.String), False, False, False, False, CInt(TurbineManufacturerFieldIndex.Manufacturer), 100, 0, 0)
			Me.AddElementFieldInfo("TurbineManufacturerEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineManufacturerFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineManufacturerEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineManufacturerFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineManufacturerEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineManufacturerFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineManufacturerEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineManufacturerFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineMarkVersionEntity's FieldInfo objects</summary>
		Private Sub InitTurbineMarkVersionEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineMarkVersionFieldIndex), "TurbineMarkVersionEntity")
			Me.AddElementFieldInfo("TurbineMarkVersionEntity", "TurbineMarkVersionId", GetType(System.Int64), True, False, False, False, CInt(TurbineMarkVersionFieldIndex.TurbineMarkVersionId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMarkVersionEntity", "MarkVersion", GetType(System.String), False, False, False, False, CInt(TurbineMarkVersionFieldIndex.MarkVersion), 20, 0, 0)
			Me.AddElementFieldInfo("TurbineMarkVersionEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineMarkVersionFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineMarkVersionEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineMarkVersionFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineMarkVersionEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineMarkVersionFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineMarkVersionEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineMarkVersionFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineMatrixEntity's FieldInfo objects</summary>
		Private Sub InitTurbineMatrixEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineMatrixFieldIndex), "TurbineMatrixEntity")
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineMatrixId", GetType(System.Int64), True, False, False, False, CInt(TurbineMatrixFieldIndex.TurbineMatrixId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineRotorDiameterId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineRotorDiameterId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineNominelPowerId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineNominelPowerId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineVoltageId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineVoltageId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineFrequencyId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineFrequencyId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbinePowerRegulationId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbinePowerRegulationId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineSmallGeneratorId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineSmallGeneratorId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineTemperatureVariantId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineTemperatureVariantId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineMarkVersionId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineMarkVersionId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbinePlacementId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbinePlacementId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineManufacturerId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineManufacturerId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "TurbineOldId", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(TurbineMatrixFieldIndex.TurbineOldId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "Comment", GetType(System.String), False, False, False, True, CInt(TurbineMatrixFieldIndex.Comment), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineMatrixFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineMatrixFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineMatrixFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineMatrixEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineMatrixFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineNominelPowerEntity's FieldInfo objects</summary>
		Private Sub InitTurbineNominelPowerEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineNominelPowerFieldIndex), "TurbineNominelPowerEntity")
			Me.AddElementFieldInfo("TurbineNominelPowerEntity", "TurbineNominelPowerId", GetType(System.Int64), True, False, False, False, CInt(TurbineNominelPowerFieldIndex.TurbineNominelPowerId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineNominelPowerEntity", "NominelPower", GetType(System.Int32), False, False, False, False, CInt(TurbineNominelPowerFieldIndex.NominelPower), 0, 0, 10)
			Me.AddElementFieldInfo("TurbineNominelPowerEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineNominelPowerFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineNominelPowerEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineNominelPowerFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineNominelPowerEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineNominelPowerFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineNominelPowerEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineNominelPowerFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineOldEntity's FieldInfo objects</summary>
		Private Sub InitTurbineOldEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineOldFieldIndex), "TurbineOldEntity")
			Me.AddElementFieldInfo("TurbineOldEntity", "TurbineOldId", GetType(System.Int64), True, False, False, False, CInt(TurbineOldFieldIndex.TurbineOldId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineOldEntity", "Turbine", GetType(System.String), False, False, False, False, CInt(TurbineOldFieldIndex.Turbine), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineOldEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineOldFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineOldEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineOldFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineOldEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineOldFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineOldEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineOldFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbinePlacementEntity's FieldInfo objects</summary>
		Private Sub InitTurbinePlacementEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbinePlacementFieldIndex), "TurbinePlacementEntity")
			Me.AddElementFieldInfo("TurbinePlacementEntity", "TurbinePlacementId", GetType(System.Int64), True, False, False, False, CInt(TurbinePlacementFieldIndex.TurbinePlacementId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbinePlacementEntity", "Placement", GetType(System.String), False, False, False, False, CInt(TurbinePlacementFieldIndex.Placement), 20, 0, 0)
			Me.AddElementFieldInfo("TurbinePlacementEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbinePlacementFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbinePlacementEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbinePlacementFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbinePlacementEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbinePlacementFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbinePlacementEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbinePlacementFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbinePowerRegulationEntity's FieldInfo objects</summary>
		Private Sub InitTurbinePowerRegulationEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbinePowerRegulationFieldIndex), "TurbinePowerRegulationEntity")
			Me.AddElementFieldInfo("TurbinePowerRegulationEntity", "TurbinePowerRegulationId", GetType(System.Int64), True, False, False, False, CInt(TurbinePowerRegulationFieldIndex.TurbinePowerRegulationId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbinePowerRegulationEntity", "PowerRegulation", GetType(System.String), False, False, False, False, CInt(TurbinePowerRegulationFieldIndex.PowerRegulation), 20, 0, 0)
			Me.AddElementFieldInfo("TurbinePowerRegulationEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbinePowerRegulationFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbinePowerRegulationEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbinePowerRegulationFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbinePowerRegulationEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbinePowerRegulationFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbinePowerRegulationEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbinePowerRegulationFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineRotorDiameterEntity's FieldInfo objects</summary>
		Private Sub InitTurbineRotorDiameterEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineRotorDiameterFieldIndex), "TurbineRotorDiameterEntity")
			Me.AddElementFieldInfo("TurbineRotorDiameterEntity", "TurbineRotorDiameterId", GetType(System.Int64), True, False, False, False, CInt(TurbineRotorDiameterFieldIndex.TurbineRotorDiameterId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineRotorDiameterEntity", "RotorDiameter", GetType(System.Decimal), False, False, False, False, CInt(TurbineRotorDiameterFieldIndex.RotorDiameter), 0, 2, 5)
			Me.AddElementFieldInfo("TurbineRotorDiameterEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineRotorDiameterFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineRotorDiameterEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineRotorDiameterFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineRotorDiameterEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineRotorDiameterFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineRotorDiameterEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineRotorDiameterFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineSmallGeneratorEntity's FieldInfo objects</summary>
		Private Sub InitTurbineSmallGeneratorEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineSmallGeneratorFieldIndex), "TurbineSmallGeneratorEntity")
			Me.AddElementFieldInfo("TurbineSmallGeneratorEntity", "TurbineSmallGeneratorId", GetType(System.Int64), True, False, False, False, CInt(TurbineSmallGeneratorFieldIndex.TurbineSmallGeneratorId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineSmallGeneratorEntity", "SmallGenerator", GetType(System.Int32), False, False, False, False, CInt(TurbineSmallGeneratorFieldIndex.SmallGenerator), 0, 0, 10)
			Me.AddElementFieldInfo("TurbineSmallGeneratorEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineSmallGeneratorFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineSmallGeneratorEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineSmallGeneratorFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineSmallGeneratorEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineSmallGeneratorFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineSmallGeneratorEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineSmallGeneratorFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineTemperatureVariantEntity's FieldInfo objects</summary>
		Private Sub InitTurbineTemperatureVariantEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineTemperatureVariantFieldIndex), "TurbineTemperatureVariantEntity")
			Me.AddElementFieldInfo("TurbineTemperatureVariantEntity", "TurbineTemperatureVariantId", GetType(System.Int64), True, False, False, False, CInt(TurbineTemperatureVariantFieldIndex.TurbineTemperatureVariantId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineTemperatureVariantEntity", "TemperatureVariant", GetType(System.String), False, False, False, False, CInt(TurbineTemperatureVariantFieldIndex.TemperatureVariant), 20, 0, 0)
			Me.AddElementFieldInfo("TurbineTemperatureVariantEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineTemperatureVariantFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineTemperatureVariantEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineTemperatureVariantFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineTemperatureVariantEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineTemperatureVariantFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineTemperatureVariantEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineTemperatureVariantFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits TurbineVoltageEntity's FieldInfo objects</summary>
		Private Sub InitTurbineVoltageEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(TurbineVoltageFieldIndex), "TurbineVoltageEntity")
			Me.AddElementFieldInfo("TurbineVoltageEntity", "TurbineVoltageId", GetType(System.Int64), True, False, False, False, CInt(TurbineVoltageFieldIndex.TurbineVoltageId), 0, 0, 19)
			Me.AddElementFieldInfo("TurbineVoltageEntity", "Voltage", GetType(System.Int32), False, False, False, False, CInt(TurbineVoltageFieldIndex.Voltage), 0, 0, 10)
			Me.AddElementFieldInfo("TurbineVoltageEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(TurbineVoltageFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineVoltageEntity", "CreatedBy", GetType(System.String), False, False, False, False, CInt(TurbineVoltageFieldIndex.CreatedBy), 50, 0, 0)
			Me.AddElementFieldInfo("TurbineVoltageEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(TurbineVoltageFieldIndex.Deleted), 0, 0, 0)
			Me.AddElementFieldInfo("TurbineVoltageEntity", "DeletedBy", GetType(System.String), False, False, False, True, CInt(TurbineVoltageFieldIndex.DeletedBy), 50, 0, 0)
		End Sub
		''' <summary>Inits VisitsEntity's FieldInfo objects</summary>
		Private Sub InitVisitsEntityInfos()
			Me.AddFieldIndexEnumForElementName(GetType(VisitsFieldIndex), "VisitsEntity")
			Me.AddElementFieldInfo("VisitsEntity", "VisitsId", GetType(System.Int64), True, False, True, False, CInt(VisitsFieldIndex.VisitsId), 0, 0, 19)
			Me.AddElementFieldInfo("VisitsEntity", "ParticipantId", GetType(System.Int64), False, False, False, False, CInt(VisitsFieldIndex.ParticipantId), 0, 0, 19)
			Me.AddElementFieldInfo("VisitsEntity", "CaseId", GetType(System.Int64), False, True, False, False, CInt(VisitsFieldIndex.CaseId), 0, 0, 19)
			Me.AddElementFieldInfo("VisitsEntity", "OpenCaseTimeStamp", GetType(System.DateTime), False, False, False, False, CInt(VisitsFieldIndex.OpenCaseTimeStamp), 0, 0, 0)
			Me.AddElementFieldInfo("VisitsEntity", "Environment", GetType(System.String), False, False, False, False, CInt(VisitsFieldIndex.Environment), 6, 0, 0)
			Me.AddElementFieldInfo("VisitsEntity", "CreatedById", GetType(System.Int64), False, True, False, False, CInt(VisitsFieldIndex.CreatedById), 0, 0, 19)
			Me.AddElementFieldInfo("VisitsEntity", "Created", GetType(System.DateTime), False, False, False, False, CInt(VisitsFieldIndex.Created), 0, 0, 0)
			Me.AddElementFieldInfo("VisitsEntity", "DeletedById", GetType(Nullable(Of System.Int64)), False, True, False, True, CInt(VisitsFieldIndex.DeletedById), 0, 0, 19)
			Me.AddElementFieldInfo("VisitsEntity", "Deleted", GetType(Nullable(Of System.DateTime)), False, False, False, True, CInt(VisitsFieldIndex.Deleted), 0, 0, 0)
		End Sub

	End Class
End Namespace







