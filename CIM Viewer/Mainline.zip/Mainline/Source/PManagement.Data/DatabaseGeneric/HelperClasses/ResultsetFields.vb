﻿' ///////////////////////////////////////////////////////////////
' // This is generated code. 
' //////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' //////////////////////////////////////////////////////////////
Imports System
#If Not CF Then
Imports System.Runtime.Serialization
#End If
Imports System.Collections.Generic
Imports PManagement.Data.FactoryClasses

Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.HelperClasses
	''' <summary>
	''' Helper class which will eases the creation of custom made resultsets. Usable in typed lists
	''' and dynamic lists created Imports the dynamic query engine.
	''' </summary>
	<Serializable()> _
	Public Class ResultsetFields 
		Inherits EntityFields2
		Implements ISerializable
	
		''' <summary>CTor</summary>
		Public Sub New(amountFields As Integer)
			MyBase.New(amountFields, InheritanceInfoProviderSingleton.GetInstance(), Nothing)
		End Sub
				
		''' <summary>Deserialization constructor</summary>
		''' <param name="info">Info.</param>
		''' <param name="context">Context.</param>
		Protected Sub New(info As SerializationInfo, context As StreamingContext )
			MyBase.New(info.GetInt32("_amountFields"), InheritanceInfoProviderSingleton.GetInstance(), Nothing)
			Dim fields As List(Of IEntityField2) = CType(info.GetValue("_fields", GetType(List(Of IEntityField2))), List(Of IEntityField2))
			For i As Integer = 0 To fields.Count-1
				Me(i) = fields(i)
			Next i
		End Sub

		''' <summary>Populates a <see cref="T:System.Runtime.Serialization.SerializationInfo"/> With the data needed To serialize the target Object.</summary>
		''' <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> To populate With data.</param>
		''' <param name="context">The destination (see <see cref="T:System.Runtime.Serialization.StreamingContext"/>) For this serialization.</param>
		Public Overridable Sub GetObjectData(info As SerializationInfo, context As StreamingContext ) Implements ISerializable.GetObjectData
			info.AddValue("_amountFields", Me.Count)
			Dim fields As New List(Of IEntityField2)(Me.Count)
			For i As Integer = 0 To Me.Count-1
				fields.Add(Me(i))
			Next i
			info.AddValue("_fields", fields, GetType(List(Of IEntityField2)))
		End Sub

#Region "Included Code"

#End Region
	End Class
End Namespace
