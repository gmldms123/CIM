﻿'///////////////////////////////////////////////////////////////
'// This is generated code. 
'//////////////////////////////////////////////////////////////
'// Code is generated Imports LLBLGen Pro version: 4.0
'// Code is generated on: 
'// Code is generated Imports templates: SD.TemplateBindings.SharedTemplates
'// Templates vendor: Solutions Design.
'//////////////////////////////////////////////////////////////
Imports System
Imports System.Collections.Generic
Imports SD.LLBLGen.Pro.LinqSupportClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Imports PManagement.Data
Imports PManagement.Data.EntityClasses
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports PManagement.Data.RelationClasses

Namespace PManagement.Data.Linq
	''' <summary>Meta-data Class For the construction of Linq queries which are To be executed using LLBLGen Pro code.</summary>
	Public Class LinqMetaData
		Implements ILinqMetaData

#Region "Class Member Declarations"
		Private _adapterToUse As IDataAccessAdapter
		Private _customFunctionMappings As FunctionMappingStore
		Private _contextToUse As Context
#End Region
		
		''' <summary>CTor. Using this ctor will leave the IDataAccessAdapter Object To use empty. To be able To execute the query, an IDataAccessAdapter instance
		''' Is required, And has To be Set On the LLBLGenProProvider2 Object In the query To execute. </summary>
		Public Sub New()
			Me.New(Nothing, Nothing)
		End Sub
		
		''' <summary>CTor which accepts an IDataAccessAdapter implementing Object, which will be used To execute queries created With this metadata Class.</summary>
		''' <param name="adapterToUse">the IDataAccessAdapter To use In queries created With this meta data</param>
		''' <remarks> Be aware that the IDataAccessAdapter Object Set via this Property Is kept alive by the LLBLGenProQuery objects created With this meta data
		''' till they go out of scope.</remarks>
		Public Sub New(adapterToUse As IDataAccessAdapter)
			Me.New(adapterToUse, Nothing)
		End Sub

		''' <summary>CTor which accepts an IDataAccessAdapter implementing Object, which will be used To execute queries created With this metadata Class.</summary>
		''' <param name="adapterToUse">the IDataAccessAdapter To use In queries created With this meta data</param>
		''' <param name="customFunctionMappings">The custom Function mappings To use. These take higher precedence than the ones In the DQE To use.</param>
		''' <remarks> Be aware that the IDataAccessAdapter Object Set via this Property Is kept alive by the LLBLGenProQuery objects created With this meta data
		''' till they go out of scope.</remarks>
		Public Sub New(adapterToUse As IDataAccessAdapter, customFunctionMappings As FunctionMappingStore)
			_adapterToUse = adapterToUse
			_customFunctionMappings = customFunctionMappings
		End Sub
		
		''' <summary>returns the datasource To use In a Linq query For the entity type specified</summary>
		''' <param name="typeOfEntity">the type of the entity To Get the datasource For</param>
		''' <returns>the requested datasource</returns>
		Public Function GetQueryableForEntity(typeOfEntity As Integer) As IDataSource Implements ILinqMetaData.GetQueryableForEntity
			Dim toReturn As IDataSource = Nothing
			Select Case CType(typeOfEntity, PManagement.Data.EntityType)
				Case PManagement.Data.EntityType.AlertCategoryEntity
					toReturn = Me.AlertCategory
				Case PManagement.Data.EntityType.AlertCategoryCriteriaEntity
					toReturn = Me.AlertCategoryCriteria
				Case PManagement.Data.EntityType.AlertChangeTypeCriteriaEntity
					toReturn = Me.AlertChangeTypeCriteria
				Case PManagement.Data.EntityType.AlertConfigEntity
					toReturn = Me.AlertConfig
				Case PManagement.Data.EntityType.AlertConfigCircountEntity
					toReturn = Me.AlertConfigCircount
				Case PManagement.Data.EntityType.AlertFrequencyEntity
					toReturn = Me.AlertFrequency
				Case PManagement.Data.EntityType.AlertReceiverEntity
					toReturn = Me.AlertReceiver
				Case PManagement.Data.EntityType.AlertReceiverRoleTypeEntity
					toReturn = Me.AlertReceiverRoleType
				Case PManagement.Data.EntityType.AlertReceiverTypeEntity
					toReturn = Me.AlertReceiverType
				Case PManagement.Data.EntityType.AlertServiceSettingsEntity
					toReturn = Me.AlertServiceSettings
				Case PManagement.Data.EntityType.AnyChangesEntity
					toReturn = Me.AnyChanges
				Case PManagement.Data.EntityType.BrandEntity
					toReturn = Me.Brand
				Case PManagement.Data.EntityType.Brand2DocumentTemplateEntity
					toReturn = Me.Brand2DocumentTemplate
				Case PManagement.Data.EntityType.Brand2FeatureEntity
					toReturn = Me.Brand2Feature
				Case PManagement.Data.EntityType.Brand2StandardMilestoneEntity
					toReturn = Me.Brand2StandardMilestone
				Case PManagement.Data.EntityType.BusinessProcessEntity
					toReturn = Me.BusinessProcess
				Case PManagement.Data.EntityType.CaseEntity
					toReturn = Me.Case
				Case PManagement.Data.EntityType.Case2CaseBundleEntity
					toReturn = Me.Case2CaseBundle
				Case PManagement.Data.EntityType.Case2ComponentTypeEntity
					toReturn = Me.Case2ComponentType
				Case PManagement.Data.EntityType.Case2ItemEntity
					toReturn = Me.Case2Item
				Case PManagement.Data.EntityType.Case2KPIRatingEntity
					toReturn = Me.Case2KPIRating
				Case PManagement.Data.EntityType.Case2LogInfoEntity
					toReturn = Me.Case2LogInfo
				Case PManagement.Data.EntityType.Case2ParticipantEntity
					toReturn = Me.Case2Participant
				Case PManagement.Data.EntityType.Case2PhaseEntity
					toReturn = Me.Case2Phase
				Case PManagement.Data.EntityType.Case2ReasonCodeEntity
					toReturn = Me.Case2ReasonCode
				Case PManagement.Data.EntityType.Case2SbuEntity
					toReturn = Me.Case2Sbu
				Case PManagement.Data.EntityType.Case2ServiceCodeEntity
					toReturn = Me.Case2ServiceCode
				Case PManagement.Data.EntityType.Case2SupplierEntity
					toReturn = Me.Case2Supplier
				Case PManagement.Data.EntityType.Case2Supplier2StageEntity
					toReturn = Me.Case2Supplier2Stage
				Case PManagement.Data.EntityType.Case2SystemEntity
					toReturn = Me.Case2System
				Case PManagement.Data.EntityType.Case2TurbineMatrixEntity
					toReturn = Me.Case2TurbineMatrix
				Case PManagement.Data.EntityType.Case2TurbineMatrix2Case2ItemEntity
					toReturn = Me.Case2TurbineMatrix2Case2Item
				Case PManagement.Data.EntityType.CaseBundleEntity
					toReturn = Me.CaseBundle
				Case PManagement.Data.EntityType.CaseRelationEntity
					toReturn = Me.CaseRelation
				Case PManagement.Data.EntityType.CategoryEntity
					toReturn = Me.Category
				Case PManagement.Data.EntityType.ChangeLogEntity
					toReturn = Me.ChangeLog
				Case PManagement.Data.EntityType.ChangeTypeEntity
					toReturn = Me.ChangeType
				Case PManagement.Data.EntityType.CirEntity
					toReturn = Me.Cir
				Case PManagement.Data.EntityType.ClaimStatusEntity
					toReturn = Me.ClaimStatus
				Case PManagement.Data.EntityType.ComponentEntity
					toReturn = Me.Component
				Case PManagement.Data.EntityType.ComponentTypeEntity
					toReturn = Me.ComponentType
				Case PManagement.Data.EntityType.ControlEntity
					toReturn = Me.Control
				Case PManagement.Data.EntityType.CustomColumnsNameEntity
					toReturn = Me.CustomColumnsName
				Case PManagement.Data.EntityType.CustomColumnsValueEntity
					toReturn = Me.CustomColumnsValue
				Case PManagement.Data.EntityType.DiscussionEntity
					toReturn = Me.Discussion
				Case PManagement.Data.EntityType.DocumentEntity
					toReturn = Me.Document
				Case PManagement.Data.EntityType.DocumentBinaryEntity
					toReturn = Me.DocumentBinary
				Case PManagement.Data.EntityType.DocumentClassificationEntity
					toReturn = Me.DocumentClassification
				Case PManagement.Data.EntityType.DocumentStatusEntity
					toReturn = Me.DocumentStatus
				Case PManagement.Data.EntityType.DocumentTemplateEntity
					toReturn = Me.DocumentTemplate
				Case PManagement.Data.EntityType.DocumentVersionEntity
					toReturn = Me.DocumentVersion
				Case PManagement.Data.EntityType.ErpsystemEntity
					toReturn = Me.Erpsystem
				Case PManagement.Data.EntityType.FeatureEntity
					toReturn = Me.Feature
				Case PManagement.Data.EntityType.FolderEntity
					toReturn = Me.Folder
				Case PManagement.Data.EntityType.Folder2DocumentEntity
					toReturn = Me.Folder2Document
				Case PManagement.Data.EntityType.FolderTypeEntity
					toReturn = Me.FolderType
				Case PManagement.Data.EntityType.HelpEntity
					toReturn = Me.Help
				Case PManagement.Data.EntityType.InlineHelpEntity
					toReturn = Me.InlineHelp
				Case PManagement.Data.EntityType.InlineHelpTextEntity
					toReturn = Me.InlineHelpText
				Case PManagement.Data.EntityType.ItemEntity
					toReturn = Me.Item
				Case PManagement.Data.EntityType.ItemStatusEntity
					toReturn = Me.ItemStatus
				Case PManagement.Data.EntityType.ItemSystemMappingEntity
					toReturn = Me.ItemSystemMapping
				Case PManagement.Data.EntityType.ItemSystemMappingStagingTableEntity
					toReturn = Me.ItemSystemMappingStagingTable
				Case PManagement.Data.EntityType.LanguageEntity
					toReturn = Me.Language
				Case PManagement.Data.EntityType.LogInfoEntity
					toReturn = Me.LogInfo
				Case PManagement.Data.EntityType.LogInfo2LogTxtEntity
					toReturn = Me.LogInfo2LogTxt
				Case PManagement.Data.EntityType.LogTxtEntity
					toReturn = Me.LogTxt
				Case PManagement.Data.EntityType.MilestoneEntity
					toReturn = Me.Milestone
				Case PManagement.Data.EntityType.ModuleEntity
					toReturn = Me.Module
				Case PManagement.Data.EntityType.NewsEntity
					toReturn = Me.News
				Case PManagement.Data.EntityType.News2ParticipantEntity
					toReturn = Me.News2Participant
				Case PManagement.Data.EntityType.OldCimturbineEntity
					toReturn = Me.OldCimturbine
				Case PManagement.Data.EntityType.ParticipantEntity
					toReturn = Me.Participant
				Case PManagement.Data.EntityType.Participant2RoleEntity
					toReturn = Me.Participant2Role
				Case PManagement.Data.EntityType.ParticipantLogEntity
					toReturn = Me.ParticipantLog
				Case PManagement.Data.EntityType.ParticipationTypeEntity
					toReturn = Me.ParticipationType
				Case PManagement.Data.EntityType.PayeeEntity
					toReturn = Me.Payee
				Case PManagement.Data.EntityType.PbuEntity
					toReturn = Me.Pbu
				Case PManagement.Data.EntityType.PerformanceActionEntity
					toReturn = Me.PerformanceAction
				Case PManagement.Data.EntityType.PerformanceDataEntity
					toReturn = Me.PerformanceData
				Case PManagement.Data.EntityType.PerformanceUtilitySettingEntity
					toReturn = Me.PerformanceUtilitySetting
				Case PManagement.Data.EntityType.PermissionEntity
					toReturn = Me.Permission
				Case PManagement.Data.EntityType.PersonalSafetyEntity
					toReturn = Me.PersonalSafety
				Case PManagement.Data.EntityType.PhaseEntity
					toReturn = Me.Phase
				Case PManagement.Data.EntityType.Phase2StatusEntity
					toReturn = Me.Phase2Status
				Case PManagement.Data.EntityType.PlatformEntity
					toReturn = Me.Platform
				Case PManagement.Data.EntityType.PopulationlistEntity
					toReturn = Me.Populationlist
				Case PManagement.Data.EntityType.PopulationlistDocumentEntity
					toReturn = Me.PopulationlistDocument
				Case PManagement.Data.EntityType.PopulationlistItemEntity
					toReturn = Me.PopulationlistItem
				Case PManagement.Data.EntityType.PortfolioEntity
					toReturn = Me.Portfolio
				Case PManagement.Data.EntityType.ProjectEntity
					toReturn = Me.Project
				Case PManagement.Data.EntityType.ProjectScopeEntity
					toReturn = Me.ProjectScope
				Case PManagement.Data.EntityType.RcEntity
					toReturn = Me.Rc
				Case PManagement.Data.EntityType.RccomponentOwnerEntity
					toReturn = Me.RccomponentOwner
				Case PManagement.Data.EntityType.RcoriginEntity
					toReturn = Me.Rcorigin
				Case PManagement.Data.EntityType.RcoriginRelationEntity
					toReturn = Me.RcoriginRelation
				Case PManagement.Data.EntityType.RcoriginResponsibleEntity
					toReturn = Me.RcoriginResponsible
				Case PManagement.Data.EntityType.RcoriginUnitEntity
					toReturn = Me.RcoriginUnit
				Case PManagement.Data.EntityType.ReasonCodeEntity
					toReturn = Me.ReasonCode
				Case PManagement.Data.EntityType.RelatedCaseEntity
					toReturn = Me.RelatedCase
				Case PManagement.Data.EntityType.RelatedCase2CaseRelationEntity
					toReturn = Me.RelatedCase2CaseRelation
				Case PManagement.Data.EntityType.RelatedItemEntity
					toReturn = Me.RelatedItem
				Case PManagement.Data.EntityType.ReportTypeEntity
					toReturn = Me.ReportType
				Case PManagement.Data.EntityType.RoleEntity
					toReturn = Me.Role
				Case PManagement.Data.EntityType.Role2PermissionEntity
					toReturn = Me.Role2Permission
				Case PManagement.Data.EntityType.SbuEntity
					toReturn = Me.Sbu
				Case PManagement.Data.EntityType.SbucloneEntity
					toReturn = Me.Sbuclone
				Case PManagement.Data.EntityType.SearchProfileEntity
					toReturn = Me.SearchProfile
				Case PManagement.Data.EntityType.SearchProfileDetailEntity
					toReturn = Me.SearchProfileDetail
				Case PManagement.Data.EntityType.ServiceCodeEntity
					toReturn = Me.ServiceCode
				Case PManagement.Data.EntityType.ServiceGroupEntity
					toReturn = Me.ServiceGroup
				Case PManagement.Data.EntityType.ServiceTypeEntity
					toReturn = Me.ServiceType
				Case PManagement.Data.EntityType.StageEntity
					toReturn = Me.Stage
				Case PManagement.Data.EntityType.StandardFolderEntity
					toReturn = Me.StandardFolder
				Case PManagement.Data.EntityType.StandardMilestoneEntity
					toReturn = Me.StandardMilestone
				Case PManagement.Data.EntityType.StandardTaskEntity
					toReturn = Me.StandardTask
				Case PManagement.Data.EntityType.StandardTask2StatusEntity
					toReturn = Me.StandardTask2Status
				Case PManagement.Data.EntityType.StateEntity
					toReturn = Me.State
				Case PManagement.Data.EntityType.StatusEntity
					toReturn = Me.Status
				Case PManagement.Data.EntityType.SupplierEntity
					toReturn = Me.Supplier
				Case PManagement.Data.EntityType.SupplierEnvironmentEntity
					toReturn = Me.SupplierEnvironment
				Case PManagement.Data.EntityType.SystemDescriptionEntity
					toReturn = Me.SystemDescription
				Case PManagement.Data.EntityType.TaskEntity
					toReturn = Me.Task
				Case PManagement.Data.EntityType.TaskMilestoneEntity
					toReturn = Me.TaskMilestone
				Case PManagement.Data.EntityType.TimelineEntity
					toReturn = Me.Timeline
				Case PManagement.Data.EntityType.TurbineEntity
					toReturn = Me.Turbine
				Case PManagement.Data.EntityType.TurbineFrequencyEntity
					toReturn = Me.TurbineFrequency
				Case PManagement.Data.EntityType.TurbineManufacturerEntity
					toReturn = Me.TurbineManufacturer
				Case PManagement.Data.EntityType.TurbineMarkVersionEntity
					toReturn = Me.TurbineMarkVersion
				Case PManagement.Data.EntityType.TurbineMatrixEntity
					toReturn = Me.TurbineMatrix
				Case PManagement.Data.EntityType.TurbineNominelPowerEntity
					toReturn = Me.TurbineNominelPower
				Case PManagement.Data.EntityType.TurbineOldEntity
					toReturn = Me.TurbineOld
				Case PManagement.Data.EntityType.TurbinePlacementEntity
					toReturn = Me.TurbinePlacement
				Case PManagement.Data.EntityType.TurbinePowerRegulationEntity
					toReturn = Me.TurbinePowerRegulation
				Case PManagement.Data.EntityType.TurbineRotorDiameterEntity
					toReturn = Me.TurbineRotorDiameter
				Case PManagement.Data.EntityType.TurbineSmallGeneratorEntity
					toReturn = Me.TurbineSmallGenerator
				Case PManagement.Data.EntityType.TurbineTemperatureVariantEntity
					toReturn = Me.TurbineTemperatureVariant
				Case PManagement.Data.EntityType.TurbineVoltageEntity
					toReturn = Me.TurbineVoltage
				Case PManagement.Data.EntityType.VisitsEntity
					toReturn = Me.Visits
				Case Else
					toReturn = Nothing
			End Select
			Return toReturn
		End Function

		''' <summary>returns the datasource to use in a Linq query when targeting AlertCategoryEntity instances in the database.</summary>
		Public Readonly Property [AlertCategory] As DataSource2(Of AlertCategoryEntity)
			Get 
				Return New DataSource2(Of AlertCategoryEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertCategoryCriteriaEntity instances in the database.</summary>
		Public Readonly Property [AlertCategoryCriteria] As DataSource2(Of AlertCategoryCriteriaEntity)
			Get 
				Return New DataSource2(Of AlertCategoryCriteriaEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertChangeTypeCriteriaEntity instances in the database.</summary>
		Public Readonly Property [AlertChangeTypeCriteria] As DataSource2(Of AlertChangeTypeCriteriaEntity)
			Get 
				Return New DataSource2(Of AlertChangeTypeCriteriaEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertConfigEntity instances in the database.</summary>
		Public Readonly Property [AlertConfig] As DataSource2(Of AlertConfigEntity)
			Get 
				Return New DataSource2(Of AlertConfigEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertConfigCircountEntity instances in the database.</summary>
		Public Readonly Property [AlertConfigCircount] As DataSource2(Of AlertConfigCircountEntity)
			Get 
				Return New DataSource2(Of AlertConfigCircountEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertFrequencyEntity instances in the database.</summary>
		Public Readonly Property [AlertFrequency] As DataSource2(Of AlertFrequencyEntity)
			Get 
				Return New DataSource2(Of AlertFrequencyEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertReceiverEntity instances in the database.</summary>
		Public Readonly Property [AlertReceiver] As DataSource2(Of AlertReceiverEntity)
			Get 
				Return New DataSource2(Of AlertReceiverEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertReceiverRoleTypeEntity instances in the database.</summary>
		Public Readonly Property [AlertReceiverRoleType] As DataSource2(Of AlertReceiverRoleTypeEntity)
			Get 
				Return New DataSource2(Of AlertReceiverRoleTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertReceiverTypeEntity instances in the database.</summary>
		Public Readonly Property [AlertReceiverType] As DataSource2(Of AlertReceiverTypeEntity)
			Get 
				Return New DataSource2(Of AlertReceiverTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AlertServiceSettingsEntity instances in the database.</summary>
		Public Readonly Property [AlertServiceSettings] As DataSource2(Of AlertServiceSettingsEntity)
			Get 
				Return New DataSource2(Of AlertServiceSettingsEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting AnyChangesEntity instances in the database.</summary>
		Public Readonly Property [AnyChanges] As DataSource2(Of AnyChangesEntity)
			Get 
				Return New DataSource2(Of AnyChangesEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting BrandEntity instances in the database.</summary>
		Public Readonly Property [Brand] As DataSource2(Of BrandEntity)
			Get 
				Return New DataSource2(Of BrandEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Brand2DocumentTemplateEntity instances in the database.</summary>
		Public Readonly Property [Brand2DocumentTemplate] As DataSource2(Of Brand2DocumentTemplateEntity)
			Get 
				Return New DataSource2(Of Brand2DocumentTemplateEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Brand2FeatureEntity instances in the database.</summary>
		Public Readonly Property [Brand2Feature] As DataSource2(Of Brand2FeatureEntity)
			Get 
				Return New DataSource2(Of Brand2FeatureEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Brand2StandardMilestoneEntity instances in the database.</summary>
		Public Readonly Property [Brand2StandardMilestone] As DataSource2(Of Brand2StandardMilestoneEntity)
			Get 
				Return New DataSource2(Of Brand2StandardMilestoneEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting BusinessProcessEntity instances in the database.</summary>
		Public Readonly Property [BusinessProcess] As DataSource2(Of BusinessProcessEntity)
			Get 
				Return New DataSource2(Of BusinessProcessEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting CaseEntity instances in the database.</summary>
		Public Readonly Property [Case] As DataSource2(Of CaseEntity)
			Get 
				Return New DataSource2(Of CaseEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2CaseBundleEntity instances in the database.</summary>
		Public Readonly Property [Case2CaseBundle] As DataSource2(Of Case2CaseBundleEntity)
			Get 
				Return New DataSource2(Of Case2CaseBundleEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2ComponentTypeEntity instances in the database.</summary>
		Public Readonly Property [Case2ComponentType] As DataSource2(Of Case2ComponentTypeEntity)
			Get 
				Return New DataSource2(Of Case2ComponentTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2ItemEntity instances in the database.</summary>
		Public Readonly Property [Case2Item] As DataSource2(Of Case2ItemEntity)
			Get 
				Return New DataSource2(Of Case2ItemEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2KPIRatingEntity instances in the database.</summary>
		Public Readonly Property [Case2KPIRating] As DataSource2(Of Case2KPIRatingEntity)
			Get 
				Return New DataSource2(Of Case2KPIRatingEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2LogInfoEntity instances in the database.</summary>
		Public Readonly Property [Case2LogInfo] As DataSource2(Of Case2LogInfoEntity)
			Get 
				Return New DataSource2(Of Case2LogInfoEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2ParticipantEntity instances in the database.</summary>
		Public Readonly Property [Case2Participant] As DataSource2(Of Case2ParticipantEntity)
			Get 
				Return New DataSource2(Of Case2ParticipantEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2PhaseEntity instances in the database.</summary>
		Public Readonly Property [Case2Phase] As DataSource2(Of Case2PhaseEntity)
			Get 
				Return New DataSource2(Of Case2PhaseEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2ReasonCodeEntity instances in the database.</summary>
		Public Readonly Property [Case2ReasonCode] As DataSource2(Of Case2ReasonCodeEntity)
			Get 
				Return New DataSource2(Of Case2ReasonCodeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2SbuEntity instances in the database.</summary>
		Public Readonly Property [Case2Sbu] As DataSource2(Of Case2SbuEntity)
			Get 
				Return New DataSource2(Of Case2SbuEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2ServiceCodeEntity instances in the database.</summary>
		Public Readonly Property [Case2ServiceCode] As DataSource2(Of Case2ServiceCodeEntity)
			Get 
				Return New DataSource2(Of Case2ServiceCodeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2SupplierEntity instances in the database.</summary>
		Public Readonly Property [Case2Supplier] As DataSource2(Of Case2SupplierEntity)
			Get 
				Return New DataSource2(Of Case2SupplierEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2Supplier2StageEntity instances in the database.</summary>
		Public Readonly Property [Case2Supplier2Stage] As DataSource2(Of Case2Supplier2StageEntity)
			Get 
				Return New DataSource2(Of Case2Supplier2StageEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2SystemEntity instances in the database.</summary>
		Public Readonly Property [Case2System] As DataSource2(Of Case2SystemEntity)
			Get 
				Return New DataSource2(Of Case2SystemEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2TurbineMatrixEntity instances in the database.</summary>
		Public Readonly Property [Case2TurbineMatrix] As DataSource2(Of Case2TurbineMatrixEntity)
			Get 
				Return New DataSource2(Of Case2TurbineMatrixEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Case2TurbineMatrix2Case2ItemEntity instances in the database.</summary>
		Public Readonly Property [Case2TurbineMatrix2Case2Item] As DataSource2(Of Case2TurbineMatrix2Case2ItemEntity)
			Get 
				Return New DataSource2(Of Case2TurbineMatrix2Case2ItemEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting CaseBundleEntity instances in the database.</summary>
		Public Readonly Property [CaseBundle] As DataSource2(Of CaseBundleEntity)
			Get 
				Return New DataSource2(Of CaseBundleEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting CaseRelationEntity instances in the database.</summary>
		Public Readonly Property [CaseRelation] As DataSource2(Of CaseRelationEntity)
			Get 
				Return New DataSource2(Of CaseRelationEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting CategoryEntity instances in the database.</summary>
		Public Readonly Property [Category] As DataSource2(Of CategoryEntity)
			Get 
				Return New DataSource2(Of CategoryEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ChangeLogEntity instances in the database.</summary>
		Public Readonly Property [ChangeLog] As DataSource2(Of ChangeLogEntity)
			Get 
				Return New DataSource2(Of ChangeLogEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ChangeTypeEntity instances in the database.</summary>
		Public Readonly Property [ChangeType] As DataSource2(Of ChangeTypeEntity)
			Get 
				Return New DataSource2(Of ChangeTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting CirEntity instances in the database.</summary>
		Public Readonly Property [Cir] As DataSource2(Of CirEntity)
			Get 
				Return New DataSource2(Of CirEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ClaimStatusEntity instances in the database.</summary>
		Public Readonly Property [ClaimStatus] As DataSource2(Of ClaimStatusEntity)
			Get 
				Return New DataSource2(Of ClaimStatusEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ComponentEntity instances in the database.</summary>
		Public Readonly Property [Component] As DataSource2(Of ComponentEntity)
			Get 
				Return New DataSource2(Of ComponentEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ComponentTypeEntity instances in the database.</summary>
		Public Readonly Property [ComponentType] As DataSource2(Of ComponentTypeEntity)
			Get 
				Return New DataSource2(Of ComponentTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ControlEntity instances in the database.</summary>
		Public Readonly Property [Control] As DataSource2(Of ControlEntity)
			Get 
				Return New DataSource2(Of ControlEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting CustomColumnsNameEntity instances in the database.</summary>
		Public Readonly Property [CustomColumnsName] As DataSource2(Of CustomColumnsNameEntity)
			Get 
				Return New DataSource2(Of CustomColumnsNameEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting CustomColumnsValueEntity instances in the database.</summary>
		Public Readonly Property [CustomColumnsValue] As DataSource2(Of CustomColumnsValueEntity)
			Get 
				Return New DataSource2(Of CustomColumnsValueEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting DiscussionEntity instances in the database.</summary>
		Public Readonly Property [Discussion] As DataSource2(Of DiscussionEntity)
			Get 
				Return New DataSource2(Of DiscussionEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting DocumentEntity instances in the database.</summary>
		Public Readonly Property [Document] As DataSource2(Of DocumentEntity)
			Get 
				Return New DataSource2(Of DocumentEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting DocumentBinaryEntity instances in the database.</summary>
		Public Readonly Property [DocumentBinary] As DataSource2(Of DocumentBinaryEntity)
			Get 
				Return New DataSource2(Of DocumentBinaryEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting DocumentClassificationEntity instances in the database.</summary>
		Public Readonly Property [DocumentClassification] As DataSource2(Of DocumentClassificationEntity)
			Get 
				Return New DataSource2(Of DocumentClassificationEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting DocumentStatusEntity instances in the database.</summary>
		Public Readonly Property [DocumentStatus] As DataSource2(Of DocumentStatusEntity)
			Get 
				Return New DataSource2(Of DocumentStatusEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting DocumentTemplateEntity instances in the database.</summary>
		Public Readonly Property [DocumentTemplate] As DataSource2(Of DocumentTemplateEntity)
			Get 
				Return New DataSource2(Of DocumentTemplateEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting DocumentVersionEntity instances in the database.</summary>
		Public Readonly Property [DocumentVersion] As DataSource2(Of DocumentVersionEntity)
			Get 
				Return New DataSource2(Of DocumentVersionEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ErpsystemEntity instances in the database.</summary>
		Public Readonly Property [Erpsystem] As DataSource2(Of ErpsystemEntity)
			Get 
				Return New DataSource2(Of ErpsystemEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting FeatureEntity instances in the database.</summary>
		Public Readonly Property [Feature] As DataSource2(Of FeatureEntity)
			Get 
				Return New DataSource2(Of FeatureEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting FolderEntity instances in the database.</summary>
		Public Readonly Property [Folder] As DataSource2(Of FolderEntity)
			Get 
				Return New DataSource2(Of FolderEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Folder2DocumentEntity instances in the database.</summary>
		Public Readonly Property [Folder2Document] As DataSource2(Of Folder2DocumentEntity)
			Get 
				Return New DataSource2(Of Folder2DocumentEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting FolderTypeEntity instances in the database.</summary>
		Public Readonly Property [FolderType] As DataSource2(Of FolderTypeEntity)
			Get 
				Return New DataSource2(Of FolderTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting HelpEntity instances in the database.</summary>
		Public Readonly Property [Help] As DataSource2(Of HelpEntity)
			Get 
				Return New DataSource2(Of HelpEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting InlineHelpEntity instances in the database.</summary>
		Public Readonly Property [InlineHelp] As DataSource2(Of InlineHelpEntity)
			Get 
				Return New DataSource2(Of InlineHelpEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting InlineHelpTextEntity instances in the database.</summary>
		Public Readonly Property [InlineHelpText] As DataSource2(Of InlineHelpTextEntity)
			Get 
				Return New DataSource2(Of InlineHelpTextEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ItemEntity instances in the database.</summary>
		Public Readonly Property [Item] As DataSource2(Of ItemEntity)
			Get 
				Return New DataSource2(Of ItemEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ItemStatusEntity instances in the database.</summary>
		Public Readonly Property [ItemStatus] As DataSource2(Of ItemStatusEntity)
			Get 
				Return New DataSource2(Of ItemStatusEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ItemSystemMappingEntity instances in the database.</summary>
		Public Readonly Property [ItemSystemMapping] As DataSource2(Of ItemSystemMappingEntity)
			Get 
				Return New DataSource2(Of ItemSystemMappingEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ItemSystemMappingStagingTableEntity instances in the database.</summary>
		Public Readonly Property [ItemSystemMappingStagingTable] As DataSource2(Of ItemSystemMappingStagingTableEntity)
			Get 
				Return New DataSource2(Of ItemSystemMappingStagingTableEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting LanguageEntity instances in the database.</summary>
		Public Readonly Property [Language] As DataSource2(Of LanguageEntity)
			Get 
				Return New DataSource2(Of LanguageEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting LogInfoEntity instances in the database.</summary>
		Public Readonly Property [LogInfo] As DataSource2(Of LogInfoEntity)
			Get 
				Return New DataSource2(Of LogInfoEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting LogInfo2LogTxtEntity instances in the database.</summary>
		Public Readonly Property [LogInfo2LogTxt] As DataSource2(Of LogInfo2LogTxtEntity)
			Get 
				Return New DataSource2(Of LogInfo2LogTxtEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting LogTxtEntity instances in the database.</summary>
		Public Readonly Property [LogTxt] As DataSource2(Of LogTxtEntity)
			Get 
				Return New DataSource2(Of LogTxtEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting MilestoneEntity instances in the database.</summary>
		Public Readonly Property [Milestone] As DataSource2(Of MilestoneEntity)
			Get 
				Return New DataSource2(Of MilestoneEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ModuleEntity instances in the database.</summary>
		Public Readonly Property [Module] As DataSource2(Of ModuleEntity)
			Get 
				Return New DataSource2(Of ModuleEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting NewsEntity instances in the database.</summary>
		Public Readonly Property [News] As DataSource2(Of NewsEntity)
			Get 
				Return New DataSource2(Of NewsEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting News2ParticipantEntity instances in the database.</summary>
		Public Readonly Property [News2Participant] As DataSource2(Of News2ParticipantEntity)
			Get 
				Return New DataSource2(Of News2ParticipantEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting OldCimturbineEntity instances in the database.</summary>
		Public Readonly Property [OldCimturbine] As DataSource2(Of OldCimturbineEntity)
			Get 
				Return New DataSource2(Of OldCimturbineEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ParticipantEntity instances in the database.</summary>
		Public Readonly Property [Participant] As DataSource2(Of ParticipantEntity)
			Get 
				Return New DataSource2(Of ParticipantEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Participant2RoleEntity instances in the database.</summary>
		Public Readonly Property [Participant2Role] As DataSource2(Of Participant2RoleEntity)
			Get 
				Return New DataSource2(Of Participant2RoleEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ParticipantLogEntity instances in the database.</summary>
		Public Readonly Property [ParticipantLog] As DataSource2(Of ParticipantLogEntity)
			Get 
				Return New DataSource2(Of ParticipantLogEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ParticipationTypeEntity instances in the database.</summary>
		Public Readonly Property [ParticipationType] As DataSource2(Of ParticipationTypeEntity)
			Get 
				Return New DataSource2(Of ParticipationTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PayeeEntity instances in the database.</summary>
		Public Readonly Property [Payee] As DataSource2(Of PayeeEntity)
			Get 
				Return New DataSource2(Of PayeeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PbuEntity instances in the database.</summary>
		Public Readonly Property [Pbu] As DataSource2(Of PbuEntity)
			Get 
				Return New DataSource2(Of PbuEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PerformanceActionEntity instances in the database.</summary>
		Public Readonly Property [PerformanceAction] As DataSource2(Of PerformanceActionEntity)
			Get 
				Return New DataSource2(Of PerformanceActionEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PerformanceDataEntity instances in the database.</summary>
		Public Readonly Property [PerformanceData] As DataSource2(Of PerformanceDataEntity)
			Get 
				Return New DataSource2(Of PerformanceDataEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PerformanceUtilitySettingEntity instances in the database.</summary>
		Public Readonly Property [PerformanceUtilitySetting] As DataSource2(Of PerformanceUtilitySettingEntity)
			Get 
				Return New DataSource2(Of PerformanceUtilitySettingEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PermissionEntity instances in the database.</summary>
		Public Readonly Property [Permission] As DataSource2(Of PermissionEntity)
			Get 
				Return New DataSource2(Of PermissionEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PersonalSafetyEntity instances in the database.</summary>
		Public Readonly Property [PersonalSafety] As DataSource2(Of PersonalSafetyEntity)
			Get 
				Return New DataSource2(Of PersonalSafetyEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PhaseEntity instances in the database.</summary>
		Public Readonly Property [Phase] As DataSource2(Of PhaseEntity)
			Get 
				Return New DataSource2(Of PhaseEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Phase2StatusEntity instances in the database.</summary>
		Public Readonly Property [Phase2Status] As DataSource2(Of Phase2StatusEntity)
			Get 
				Return New DataSource2(Of Phase2StatusEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PlatformEntity instances in the database.</summary>
		Public Readonly Property [Platform] As DataSource2(Of PlatformEntity)
			Get 
				Return New DataSource2(Of PlatformEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PopulationlistEntity instances in the database.</summary>
		Public Readonly Property [Populationlist] As DataSource2(Of PopulationlistEntity)
			Get 
				Return New DataSource2(Of PopulationlistEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PopulationlistDocumentEntity instances in the database.</summary>
		Public Readonly Property [PopulationlistDocument] As DataSource2(Of PopulationlistDocumentEntity)
			Get 
				Return New DataSource2(Of PopulationlistDocumentEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PopulationlistItemEntity instances in the database.</summary>
		Public Readonly Property [PopulationlistItem] As DataSource2(Of PopulationlistItemEntity)
			Get 
				Return New DataSource2(Of PopulationlistItemEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting PortfolioEntity instances in the database.</summary>
		Public Readonly Property [Portfolio] As DataSource2(Of PortfolioEntity)
			Get 
				Return New DataSource2(Of PortfolioEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ProjectEntity instances in the database.</summary>
		Public Readonly Property [Project] As DataSource2(Of ProjectEntity)
			Get 
				Return New DataSource2(Of ProjectEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ProjectScopeEntity instances in the database.</summary>
		Public Readonly Property [ProjectScope] As DataSource2(Of ProjectScopeEntity)
			Get 
				Return New DataSource2(Of ProjectScopeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RcEntity instances in the database.</summary>
		Public Readonly Property [Rc] As DataSource2(Of RcEntity)
			Get 
				Return New DataSource2(Of RcEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RccomponentOwnerEntity instances in the database.</summary>
		Public Readonly Property [RccomponentOwner] As DataSource2(Of RccomponentOwnerEntity)
			Get 
				Return New DataSource2(Of RccomponentOwnerEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RcoriginEntity instances in the database.</summary>
		Public Readonly Property [Rcorigin] As DataSource2(Of RcoriginEntity)
			Get 
				Return New DataSource2(Of RcoriginEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RcoriginRelationEntity instances in the database.</summary>
		Public Readonly Property [RcoriginRelation] As DataSource2(Of RcoriginRelationEntity)
			Get 
				Return New DataSource2(Of RcoriginRelationEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RcoriginResponsibleEntity instances in the database.</summary>
		Public Readonly Property [RcoriginResponsible] As DataSource2(Of RcoriginResponsibleEntity)
			Get 
				Return New DataSource2(Of RcoriginResponsibleEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RcoriginUnitEntity instances in the database.</summary>
		Public Readonly Property [RcoriginUnit] As DataSource2(Of RcoriginUnitEntity)
			Get 
				Return New DataSource2(Of RcoriginUnitEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ReasonCodeEntity instances in the database.</summary>
		Public Readonly Property [ReasonCode] As DataSource2(Of ReasonCodeEntity)
			Get 
				Return New DataSource2(Of ReasonCodeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RelatedCaseEntity instances in the database.</summary>
		Public Readonly Property [RelatedCase] As DataSource2(Of RelatedCaseEntity)
			Get 
				Return New DataSource2(Of RelatedCaseEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RelatedCase2CaseRelationEntity instances in the database.</summary>
		Public Readonly Property [RelatedCase2CaseRelation] As DataSource2(Of RelatedCase2CaseRelationEntity)
			Get 
				Return New DataSource2(Of RelatedCase2CaseRelationEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RelatedItemEntity instances in the database.</summary>
		Public Readonly Property [RelatedItem] As DataSource2(Of RelatedItemEntity)
			Get 
				Return New DataSource2(Of RelatedItemEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ReportTypeEntity instances in the database.</summary>
		Public Readonly Property [ReportType] As DataSource2(Of ReportTypeEntity)
			Get 
				Return New DataSource2(Of ReportTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting RoleEntity instances in the database.</summary>
		Public Readonly Property [Role] As DataSource2(Of RoleEntity)
			Get 
				Return New DataSource2(Of RoleEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting Role2PermissionEntity instances in the database.</summary>
		Public Readonly Property [Role2Permission] As DataSource2(Of Role2PermissionEntity)
			Get 
				Return New DataSource2(Of Role2PermissionEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting SbuEntity instances in the database.</summary>
		Public Readonly Property [Sbu] As DataSource2(Of SbuEntity)
			Get 
				Return New DataSource2(Of SbuEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting SbucloneEntity instances in the database.</summary>
		Public Readonly Property [Sbuclone] As DataSource2(Of SbucloneEntity)
			Get 
				Return New DataSource2(Of SbucloneEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting SearchProfileEntity instances in the database.</summary>
		Public Readonly Property [SearchProfile] As DataSource2(Of SearchProfileEntity)
			Get 
				Return New DataSource2(Of SearchProfileEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting SearchProfileDetailEntity instances in the database.</summary>
		Public Readonly Property [SearchProfileDetail] As DataSource2(Of SearchProfileDetailEntity)
			Get 
				Return New DataSource2(Of SearchProfileDetailEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ServiceCodeEntity instances in the database.</summary>
		Public Readonly Property [ServiceCode] As DataSource2(Of ServiceCodeEntity)
			Get 
				Return New DataSource2(Of ServiceCodeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ServiceGroupEntity instances in the database.</summary>
		Public Readonly Property [ServiceGroup] As DataSource2(Of ServiceGroupEntity)
			Get 
				Return New DataSource2(Of ServiceGroupEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting ServiceTypeEntity instances in the database.</summary>
		Public Readonly Property [ServiceType] As DataSource2(Of ServiceTypeEntity)
			Get 
				Return New DataSource2(Of ServiceTypeEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting StageEntity instances in the database.</summary>
		Public Readonly Property [Stage] As DataSource2(Of StageEntity)
			Get 
				Return New DataSource2(Of StageEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting StandardFolderEntity instances in the database.</summary>
		Public Readonly Property [StandardFolder] As DataSource2(Of StandardFolderEntity)
			Get 
				Return New DataSource2(Of StandardFolderEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting StandardMilestoneEntity instances in the database.</summary>
		Public Readonly Property [StandardMilestone] As DataSource2(Of StandardMilestoneEntity)
			Get 
				Return New DataSource2(Of StandardMilestoneEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting StandardTaskEntity instances in the database.</summary>
		Public Readonly Property [StandardTask] As DataSource2(Of StandardTaskEntity)
			Get 
				Return New DataSource2(Of StandardTaskEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting StandardTask2StatusEntity instances in the database.</summary>
		Public Readonly Property [StandardTask2Status] As DataSource2(Of StandardTask2StatusEntity)
			Get 
				Return New DataSource2(Of StandardTask2StatusEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting StateEntity instances in the database.</summary>
		Public Readonly Property [State] As DataSource2(Of StateEntity)
			Get 
				Return New DataSource2(Of StateEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting StatusEntity instances in the database.</summary>
		Public Readonly Property [Status] As DataSource2(Of StatusEntity)
			Get 
				Return New DataSource2(Of StatusEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting SupplierEntity instances in the database.</summary>
		Public Readonly Property [Supplier] As DataSource2(Of SupplierEntity)
			Get 
				Return New DataSource2(Of SupplierEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting SupplierEnvironmentEntity instances in the database.</summary>
		Public Readonly Property [SupplierEnvironment] As DataSource2(Of SupplierEnvironmentEntity)
			Get 
				Return New DataSource2(Of SupplierEnvironmentEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting SystemDescriptionEntity instances in the database.</summary>
		Public Readonly Property [SystemDescription] As DataSource2(Of SystemDescriptionEntity)
			Get 
				Return New DataSource2(Of SystemDescriptionEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TaskEntity instances in the database.</summary>
		Public Readonly Property [Task] As DataSource2(Of TaskEntity)
			Get 
				Return New DataSource2(Of TaskEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TaskMilestoneEntity instances in the database.</summary>
		Public Readonly Property [TaskMilestone] As DataSource2(Of TaskMilestoneEntity)
			Get 
				Return New DataSource2(Of TaskMilestoneEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TimelineEntity instances in the database.</summary>
		Public Readonly Property [Timeline] As DataSource2(Of TimelineEntity)
			Get 
				Return New DataSource2(Of TimelineEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineEntity instances in the database.</summary>
		Public Readonly Property [Turbine] As DataSource2(Of TurbineEntity)
			Get 
				Return New DataSource2(Of TurbineEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineFrequencyEntity instances in the database.</summary>
		Public Readonly Property [TurbineFrequency] As DataSource2(Of TurbineFrequencyEntity)
			Get 
				Return New DataSource2(Of TurbineFrequencyEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineManufacturerEntity instances in the database.</summary>
		Public Readonly Property [TurbineManufacturer] As DataSource2(Of TurbineManufacturerEntity)
			Get 
				Return New DataSource2(Of TurbineManufacturerEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineMarkVersionEntity instances in the database.</summary>
		Public Readonly Property [TurbineMarkVersion] As DataSource2(Of TurbineMarkVersionEntity)
			Get 
				Return New DataSource2(Of TurbineMarkVersionEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineMatrixEntity instances in the database.</summary>
		Public Readonly Property [TurbineMatrix] As DataSource2(Of TurbineMatrixEntity)
			Get 
				Return New DataSource2(Of TurbineMatrixEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineNominelPowerEntity instances in the database.</summary>
		Public Readonly Property [TurbineNominelPower] As DataSource2(Of TurbineNominelPowerEntity)
			Get 
				Return New DataSource2(Of TurbineNominelPowerEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineOldEntity instances in the database.</summary>
		Public Readonly Property [TurbineOld] As DataSource2(Of TurbineOldEntity)
			Get 
				Return New DataSource2(Of TurbineOldEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbinePlacementEntity instances in the database.</summary>
		Public Readonly Property [TurbinePlacement] As DataSource2(Of TurbinePlacementEntity)
			Get 
				Return New DataSource2(Of TurbinePlacementEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbinePowerRegulationEntity instances in the database.</summary>
		Public Readonly Property [TurbinePowerRegulation] As DataSource2(Of TurbinePowerRegulationEntity)
			Get 
				Return New DataSource2(Of TurbinePowerRegulationEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineRotorDiameterEntity instances in the database.</summary>
		Public Readonly Property [TurbineRotorDiameter] As DataSource2(Of TurbineRotorDiameterEntity)
			Get 
				Return New DataSource2(Of TurbineRotorDiameterEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineSmallGeneratorEntity instances in the database.</summary>
		Public Readonly Property [TurbineSmallGenerator] As DataSource2(Of TurbineSmallGeneratorEntity)
			Get 
				Return New DataSource2(Of TurbineSmallGeneratorEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineTemperatureVariantEntity instances in the database.</summary>
		Public Readonly Property [TurbineTemperatureVariant] As DataSource2(Of TurbineTemperatureVariantEntity)
			Get 
				Return New DataSource2(Of TurbineTemperatureVariantEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting TurbineVoltageEntity instances in the database.</summary>
		Public Readonly Property [TurbineVoltage] As DataSource2(Of TurbineVoltageEntity)
			Get 
				Return New DataSource2(Of TurbineVoltageEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
		''' <summary>returns the datasource to use in a Linq query when targeting VisitsEntity instances in the database.</summary>
		Public Readonly Property [Visits] As DataSource2(Of VisitsEntity)
			Get 
				Return New DataSource2(Of VisitsEntity)(_adapterToUse, new ElementCreator(), _customFunctionMappings, _contextToUse) 
			End Get
		End Property
		
 
#Region "Class Property Declarations"
		''' <summary> Gets / sets the IDataAccessAdapter To use For the queries created With this meta data Object.</summary>
		''' <remarks> Be aware that the IDataAccessAdapter Object Set via this Property Is kept alive by the LLBLGenProQuery objects created With this meta data
		''' till they go out of scope.</remarks>
		Public Property AdapterToUse As IDataAccessAdapter
			Get 
				Return _adapterToUse
			End Get
			Set 
				_adapterToUse = value
			End Set
		End Property
		
		''' <summary>Gets Or sets the custom Function mappings To use. These take higher precedence than the ones In the DQE To use</summary>
		Public Property CustomFunctionMappings As FunctionMappingStore 
			Get 
				Return _customFunctionMappings
			End Get
			Set 
				_customFunctionMappings = value
			End Set
		End Property
						
		''' <summary>Gets Or sets the Context instance To use For entity fetches.</summary>
		Public Property ContextToUse As Context
			Get 
				Return _contextToUse
			End Get
			Set 
				_contextToUse = value
			End Set
		End Property
#End Region	
	End Class
End Namespace