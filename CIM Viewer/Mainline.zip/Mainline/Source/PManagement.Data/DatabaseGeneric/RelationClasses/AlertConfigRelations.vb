﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: AlertConfig.</summary>
	Public Class AlertConfigRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the AlertConfigEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.AlertCategoryCriteriaEntityUsingAlertConfigId)
			toReturn.Add(Me.AlertChangeTypeCriteriaEntityUsingAlertConfigId)
			toReturn.Add(Me.AlertConfigCircountEntityUsingAlertConfigId)
			toReturn.Add(Me.AlertReceiverEntityUsingAlertConfigId)
			toReturn.Add(Me.AlertFrequencyEntityUsingAlertFrequencyId)
			toReturn.Add(Me.ParticipantEntityUsingCreatedById)
			toReturn.Add(Me.ParticipantEntityUsingDeletedById)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between AlertConfigEntity and AlertCategoryCriteriaEntity over the 1:n relation they have, using the relation between the fields:
		''' AlertConfig.AlertConfigId - AlertCategoryCriteria.AlertConfigId
		''' </summary>
		Public Overridable ReadOnly Property AlertCategoryCriteriaEntityUsingAlertConfigId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertCategoryCriteria", True)
				relation.AddEntityFieldPair(AlertConfigFields.AlertConfigId, AlertCategoryCriteriaFields.AlertConfigId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertCategoryCriteriaEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between AlertConfigEntity and AlertChangeTypeCriteriaEntity over the 1:n relation they have, using the relation between the fields:
		''' AlertConfig.AlertConfigId - AlertChangeTypeCriteria.AlertConfigId
		''' </summary>
		Public Overridable ReadOnly Property AlertChangeTypeCriteriaEntityUsingAlertConfigId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertChangeTypeCriteria", True)
				relation.AddEntityFieldPair(AlertConfigFields.AlertConfigId, AlertChangeTypeCriteriaFields.AlertConfigId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertChangeTypeCriteriaEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between AlertConfigEntity and AlertConfigCircountEntity over the 1:n relation they have, using the relation between the fields:
		''' AlertConfig.AlertConfigId - AlertConfigCircount.AlertConfigId
		''' </summary>
		Public Overridable ReadOnly Property AlertConfigCircountEntityUsingAlertConfigId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertConfigCircount", True)
				relation.AddEntityFieldPair(AlertConfigFields.AlertConfigId, AlertConfigCircountFields.AlertConfigId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigCircountEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between AlertConfigEntity and AlertReceiverEntity over the 1:n relation they have, using the relation between the fields:
		''' AlertConfig.AlertConfigId - AlertReceiver.AlertConfigId
		''' </summary>
		Public Overridable ReadOnly Property AlertReceiverEntityUsingAlertConfigId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertReceiver", True)
				relation.AddEntityFieldPair(AlertConfigFields.AlertConfigId, AlertReceiverFields.AlertConfigId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertReceiverEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>Returns a new IEntityRelation Object, between AlertConfigEntity and AlertFrequencyEntity over the m:1 relation they have, using the relation between the fields:
		''' AlertConfig.AlertFrequencyId - AlertFrequency.AlertFrequencyId
		''' </summary>
		Public Overridable  ReadOnly Property AlertFrequencyEntityUsingAlertFrequencyId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "AlertFrequency", False)
				relation.AddEntityFieldPair(AlertFrequencyFields.AlertFrequencyId, AlertConfigFields.AlertFrequencyId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertFrequencyEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between AlertConfigEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' AlertConfig.CreatedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Participant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertConfigFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between AlertConfigEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' AlertConfig.DeletedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Participant_", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertConfigFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticAlertConfigRelations
		Friend Shared ReadOnly AlertCategoryCriteriaEntityUsingAlertConfigIdStatic As IEntityRelation = New AlertConfigRelations().AlertCategoryCriteriaEntityUsingAlertConfigId
		Friend Shared ReadOnly AlertChangeTypeCriteriaEntityUsingAlertConfigIdStatic As IEntityRelation = New AlertConfigRelations().AlertChangeTypeCriteriaEntityUsingAlertConfigId
		Friend Shared ReadOnly AlertConfigCircountEntityUsingAlertConfigIdStatic As IEntityRelation = New AlertConfigRelations().AlertConfigCircountEntityUsingAlertConfigId
		Friend Shared ReadOnly AlertReceiverEntityUsingAlertConfigIdStatic As IEntityRelation = New AlertConfigRelations().AlertReceiverEntityUsingAlertConfigId
		Friend Shared ReadOnly AlertFrequencyEntityUsingAlertFrequencyIdStatic As IEntityRelation = New AlertConfigRelations().AlertFrequencyEntityUsingAlertFrequencyId
		Friend Shared ReadOnly ParticipantEntityUsingCreatedByIdStatic As IEntityRelation = New AlertConfigRelations().ParticipantEntityUsingCreatedById
		Friend Shared ReadOnly ParticipantEntityUsingDeletedByIdStatic As IEntityRelation = New AlertConfigRelations().ParticipantEntityUsingDeletedById

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
