﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Brand.</summary>
	Public Class BrandRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the BrandEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.Brand2DocumentTemplateEntityUsingBrandId)
			toReturn.Add(Me.Brand2FeatureEntityUsingBrandId)
			toReturn.Add(Me.Brand2StandardMilestoneEntityUsingBrandId)
			toReturn.Add(Me.CaseEntityUsingBrandId)
			toReturn.Add(Me.InlineHelpEntityUsingBrandId)
			toReturn.Add(Me.PhaseEntityUsingBrandId)
			toReturn.Add(Me.StandardFolderEntityUsingBrandId)
			toReturn.Add(Me.StandardTaskEntityUsingBrandId)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and Brand2DocumentTemplateEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - Brand2DocumentTemplate.BrandId
		''' </summary>
		Public Overridable ReadOnly Property Brand2DocumentTemplateEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Brand2DocumentTemplate", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, Brand2DocumentTemplateFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Brand2DocumentTemplateEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and Brand2FeatureEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - Brand2Feature.BrandId
		''' </summary>
		Public Overridable ReadOnly Property Brand2FeatureEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Brand2Feature", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, Brand2FeatureFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Brand2FeatureEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and Brand2StandardMilestoneEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - Brand2StandardMilestone.BrandId
		''' </summary>
		Public Overridable ReadOnly Property Brand2StandardMilestoneEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Brand2StandardMilestone", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, Brand2StandardMilestoneFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Brand2StandardMilestoneEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - Case.BrandId
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, CaseFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and InlineHelpEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - InlineHelp.BrandId
		''' </summary>
		Public Overridable ReadOnly Property InlineHelpEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "InlineHelp", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, InlineHelpFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("InlineHelpEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and PhaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - Phase.BrandId
		''' </summary>
		Public Overridable ReadOnly Property PhaseEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Phase", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, PhaseFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PhaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and StandardFolderEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - StandardFolder.BrandId
		''' </summary>
		Public Overridable ReadOnly Property StandardFolderEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "StandardFolder", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, StandardFolderFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StandardFolderEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between BrandEntity and StandardTaskEntity over the 1:n relation they have, using the relation between the fields:
		''' Brand.BrandId - StandardTask.BrandId
		''' </summary>
		Public Overridable ReadOnly Property StandardTaskEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "StandardTask", True)
				relation.AddEntityFieldPair(BrandFields.BrandId, StandardTaskFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StandardTaskEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticBrandRelations
		Friend Shared ReadOnly Brand2DocumentTemplateEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().Brand2DocumentTemplateEntityUsingBrandId
		Friend Shared ReadOnly Brand2FeatureEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().Brand2FeatureEntityUsingBrandId
		Friend Shared ReadOnly Brand2StandardMilestoneEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().Brand2StandardMilestoneEntityUsingBrandId
		Friend Shared ReadOnly CaseEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().CaseEntityUsingBrandId
		Friend Shared ReadOnly InlineHelpEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().InlineHelpEntityUsingBrandId
		Friend Shared ReadOnly PhaseEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().PhaseEntityUsingBrandId
		Friend Shared ReadOnly StandardFolderEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().StandardFolderEntityUsingBrandId
		Friend Shared ReadOnly StandardTaskEntityUsingBrandIdStatic As IEntityRelation = New BrandRelations().StandardTaskEntityUsingBrandId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
