﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Case2CaseBundle.</summary>
	Public Class Case2CaseBundleRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the Case2CaseBundleEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.CaseEntityUsingCaseId)
			toReturn.Add(Me.CaseBundleEntityUsingCaseBundleId)
			Return toReturn
		End Function

#Region "Class Property Declarations"



		''' <summary>Returns a new IEntityRelation Object, between Case2CaseBundleEntity and CaseEntity over the m:1 relation they have, using the relation between the fields:
		''' Case2CaseBundle.CaseId - Case.CaseId
		''' </summary>
		Public Overridable  ReadOnly Property CaseEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Case", False)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2CaseBundleFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2CaseBundleEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between Case2CaseBundleEntity and CaseBundleEntity over the m:1 relation they have, using the relation between the fields:
		''' Case2CaseBundle.CaseBundleId - CaseBundle.CaseBundleId
		''' </summary>
		Public Overridable  ReadOnly Property CaseBundleEntityUsingCaseBundleId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "CaseBundle", False)
				relation.AddEntityFieldPair(CaseBundleFields.CaseBundleId, Case2CaseBundleFields.CaseBundleId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseBundleEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2CaseBundleEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticCase2CaseBundleRelations
		Friend Shared ReadOnly CaseEntityUsingCaseIdStatic As IEntityRelation = New Case2CaseBundleRelations().CaseEntityUsingCaseId
		Friend Shared ReadOnly CaseBundleEntityUsingCaseBundleIdStatic As IEntityRelation = New Case2CaseBundleRelations().CaseBundleEntityUsingCaseBundleId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
