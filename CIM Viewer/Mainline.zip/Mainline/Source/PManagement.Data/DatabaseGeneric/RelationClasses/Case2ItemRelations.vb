﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Case2Item.</summary>
	Public Class Case2ItemRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the Case2ItemEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.Case2TurbineMatrix2Case2ItemEntityUsingCase2ItemId)
			toReturn.Add(Me.CaseEntityUsingCaseId)
			toReturn.Add(Me.ItemEntityUsingItemId)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between Case2ItemEntity and Case2TurbineMatrix2Case2ItemEntity over the 1:n relation they have, using the relation between the fields:
		''' Case2Item.Case2ItemId - Case2TurbineMatrix2Case2Item.Case2ItemId
		''' </summary>
		Public Overridable ReadOnly Property Case2TurbineMatrix2Case2ItemEntityUsingCase2ItemId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2TurbineUnitType2Case2Item", True)
				relation.AddEntityFieldPair(Case2ItemFields.Case2ItemId, Case2TurbineMatrix2Case2ItemFields.Case2ItemId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ItemEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2TurbineMatrix2Case2ItemEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>Returns a new IEntityRelation Object, between Case2ItemEntity and CaseEntity over the m:1 relation they have, using the relation between the fields:
		''' Case2Item.CaseId - Case.CaseId
		''' </summary>
		Public Overridable  ReadOnly Property CaseEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Case", False)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2ItemFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ItemEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between Case2ItemEntity and ItemEntity over the m:1 relation they have, using the relation between the fields:
		''' Case2Item.ItemId - Item.ItemId
		''' </summary>
		Public Overridable  ReadOnly Property ItemEntityUsingItemId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Item", False)
				relation.AddEntityFieldPair(ItemFields.ItemId, Case2ItemFields.ItemId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ItemEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ItemEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticCase2ItemRelations
		Friend Shared ReadOnly Case2TurbineMatrix2Case2ItemEntityUsingCase2ItemIdStatic As IEntityRelation = New Case2ItemRelations().Case2TurbineMatrix2Case2ItemEntityUsingCase2ItemId
		Friend Shared ReadOnly CaseEntityUsingCaseIdStatic As IEntityRelation = New Case2ItemRelations().CaseEntityUsingCaseId
		Friend Shared ReadOnly ItemEntityUsingItemIdStatic As IEntityRelation = New Case2ItemRelations().ItemEntityUsingItemId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
