﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Case.</summary>
	Public Class CaseRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the CaseEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.CaseEntityUsingUplink)
			toReturn.Add(Me.Case2CaseBundleEntityUsingCaseId)
			toReturn.Add(Me.Case2ComponentTypeEntityUsingCaseId)
			toReturn.Add(Me.Case2ItemEntityUsingCaseId)
			toReturn.Add(Me.Case2LogInfoEntityUsingCaseId)
			toReturn.Add(Me.Case2ParticipantEntityUsingCaseId)
			toReturn.Add(Me.Case2PhaseEntityUsingCaseId)
			toReturn.Add(Me.Case2ReasonCodeEntityUsingCaseId)
			toReturn.Add(Me.Case2SbuEntityUsingCaseId)
			toReturn.Add(Me.Case2ServiceCodeEntityUsingCaseId)
			toReturn.Add(Me.Case2SupplierEntityUsingCaseId)
			toReturn.Add(Me.Case2SystemEntityUsingCaseId)
			toReturn.Add(Me.Case2TurbineMatrixEntityUsingCaseId)
			toReturn.Add(Me.ChangeLogEntityUsingCaseId)
			toReturn.Add(Me.CirEntityUsingCaseId)
			toReturn.Add(Me.DiscussionEntityUsingCaseId)
			toReturn.Add(Me.FolderEntityUsingCaseId)
			toReturn.Add(Me.MilestoneEntityUsingCaseId)
			toReturn.Add(Me.NewsEntityUsingCaseId)
			toReturn.Add(Me.OldCimturbineEntityUsingCaseId)
			toReturn.Add(Me.PopulationlistEntityUsingCaseId)
			toReturn.Add(Me.RcEntityUsingCaseId)
			toReturn.Add(Me.RelatedCaseEntityUsingCaseId)
			toReturn.Add(Me.RelatedCaseEntityUsingCaseIdRelated)
			toReturn.Add(Me.TimelineEntityUsingCaseId)
			toReturn.Add(Me.VisitsEntityUsingCaseId)
			toReturn.Add(Me.BrandEntityUsingBrandId)
			toReturn.Add(Me.BusinessProcessEntityUsingBusinessProcessId)
			toReturn.Add(Me.CaseEntityUsingCaseIdUplink)
			toReturn.Add(Me.CategoryEntityUsingCategoryId)
			toReturn.Add(Me.ClaimStatusEntityUsingClaimStatusId)
			toReturn.Add(Me.ComponentEntityUsingComponentId)
			toReturn.Add(Me.ParticipantEntityUsingCreatedById)
			toReturn.Add(Me.ParticipantEntityUsingExecutionManagerId)
			toReturn.Add(Me.ParticipantEntityUsingLastEditedById)
			toReturn.Add(Me.ParticipantEntityUsingManagerId)
			toReturn.Add(Me.ParticipantEntityUsingContainmentLeadId)
			toReturn.Add(Me.ParticipantEntityUsingTechnicalSpecialistId)
			toReturn.Add(Me.PbuEntityUsingPbuid)
			toReturn.Add(Me.PersonalSafetyEntityUsingPersonalSafetyId)
			toReturn.Add(Me.PhaseEntityUsingPhaseId)
			toReturn.Add(Me.PlatformEntityUsingPlatform)
			toReturn.Add(Me.PortfolioEntityUsingPortfolioId)
			toReturn.Add(Me.ProjectScopeEntityUsingProjectScopeId)
			toReturn.Add(Me.StandardTaskEntityUsingStandardTaskId)
			toReturn.Add(Me.StatusEntityUsingStatusId)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case.Uplink
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingUplink() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChildCase", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, CaseFields.Uplink)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2CaseBundleEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2CaseBundle.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2CaseBundleEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2CaseBundle", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2CaseBundleFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2CaseBundleEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2ComponentTypeEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2ComponentType.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2ComponentTypeEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2ComponentType", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2ComponentTypeFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ComponentTypeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2ItemEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2Item.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2ItemEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2Item", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2ItemFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ItemEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2LogInfoEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2LogInfo.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2LogInfoEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2LogInfo", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2LogInfoFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2LogInfoEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2ParticipantEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2Participant.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2ParticipantEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2Participant", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2ParticipantFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ParticipantEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2PhaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2Phase.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2PhaseEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2Phase", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2PhaseFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2PhaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2ReasonCodeEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2ReasonCode.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2ReasonCodeEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2ReasonCode", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2ReasonCodeFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ReasonCodeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2SbuEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2Sbu.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2SbuEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2Sbu", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2SbuFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2SbuEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2ServiceCodeEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2ServiceCode.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2ServiceCodeEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2ServiceCode", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2ServiceCodeFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ServiceCodeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2SupplierEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2Supplier.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2SupplierEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2Supplier", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2SupplierFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2SupplierEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2SystemEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2System.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2SystemEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2System", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2SystemFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2SystemEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and Case2TurbineMatrixEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Case2TurbineMatrix.CaseId
		''' </summary>
		Public Overridable ReadOnly Property Case2TurbineMatrixEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2TurbineUnitType", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, Case2TurbineMatrixFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2TurbineMatrixEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ChangeLogEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - ChangeLog.CaseId
		''' </summary>
		Public Overridable ReadOnly Property ChangeLogEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChangeLog", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, ChangeLogFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ChangeLogEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and CirEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Cir.CaseId
		''' </summary>
		Public Overridable ReadOnly Property CirEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Cir", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, CirFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CirEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and DiscussionEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Discussion.CaseId
		''' </summary>
		Public Overridable ReadOnly Property DiscussionEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Discussion", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, DiscussionFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and FolderEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Folder.CaseId
		''' </summary>
		Public Overridable ReadOnly Property FolderEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Folder", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, FolderFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and MilestoneEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Milestone.CaseId
		''' </summary>
		Public Overridable ReadOnly Property MilestoneEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Milestone", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, MilestoneFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("MilestoneEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and NewsEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - News.CaseId
		''' </summary>
		Public Overridable ReadOnly Property NewsEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "News", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, NewsFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("NewsEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and OldCimturbineEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - OldCimturbine.CaseId
		''' </summary>
		Public Overridable ReadOnly Property OldCimturbineEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "OldCimturbine", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, OldCimturbineFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("OldCimturbineEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and PopulationlistEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Populationlist.CaseId
		''' </summary>
		Public Overridable ReadOnly Property PopulationlistEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Populationlist", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, PopulationlistFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PopulationlistEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and RcEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Rc.CaseId
		''' </summary>
		Public Overridable ReadOnly Property RcEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Rc", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, RcFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and RelatedCaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - RelatedCase.CaseId
		''' </summary>
		Public Overridable ReadOnly Property RelatedCaseEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RelatedCase", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, RelatedCaseFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RelatedCaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and RelatedCaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - RelatedCase.CaseIdRelated
		''' </summary>
		Public Overridable ReadOnly Property RelatedCaseEntityUsingCaseIdRelated() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RelatedCase_", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, RelatedCaseFields.CaseIdRelated)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RelatedCaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and TimelineEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Timeline.CaseId
		''' </summary>
		Public Overridable ReadOnly Property TimelineEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Timeline", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, TimelineFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("TimelineEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and VisitsEntity over the 1:n relation they have, using the relation between the fields:
		''' Case.CaseId - Visits.CaseId
		''' </summary>
		Public Overridable ReadOnly Property VisitsEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Visits", True)
				relation.AddEntityFieldPair(CaseFields.CaseId, VisitsFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("VisitsEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and BrandEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.BrandId - Brand.BrandId
		''' </summary>
		Public Overridable  ReadOnly Property BrandEntityUsingBrandId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Brand", False)
				relation.AddEntityFieldPair(BrandFields.BrandId, CaseFields.BrandId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BrandEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and BusinessProcessEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.BusinessProcessId - BusinessProcess.BusinessProcessId
		''' </summary>
		Public Overridable  ReadOnly Property BusinessProcessEntityUsingBusinessProcessId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "BusinessProcess", False)
				relation.AddEntityFieldPair(BusinessProcessFields.BusinessProcessId, CaseFields.BusinessProcessId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("BusinessProcessEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and CaseEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.Uplink - Case.CaseId
		''' </summary>
		Public Overridable  ReadOnly Property CaseEntityUsingCaseIdUplink() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ParentCase", False)
				relation.AddEntityFieldPair(CaseFields.CaseId, CaseFields.Uplink)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and CategoryEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.CategoryId - Category.CategoryId
		''' </summary>
		Public Overridable  ReadOnly Property CategoryEntityUsingCategoryId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Category", False)
				relation.AddEntityFieldPair(CategoryFields.CategoryId, CaseFields.CategoryId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CategoryEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ClaimStatusEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.ClaimStatusId - ClaimStatus.ClaimStatusId
		''' </summary>
		Public Overridable  ReadOnly Property ClaimStatusEntityUsingClaimStatusId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ClaimStatus", False)
				relation.AddEntityFieldPair(ClaimStatusFields.ClaimStatusId, CaseFields.ClaimStatusId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ClaimStatusEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ComponentEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.ComponentId - Component.ComponentId
		''' </summary>
		Public Overridable  ReadOnly Property ComponentEntityUsingComponentId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Component", False)
				relation.AddEntityFieldPair(ComponentFields.ComponentId, CaseFields.ComponentId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ComponentEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.CreatedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "CreatedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.ExecutionManagerId - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingExecutionManagerId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ExecutionManagerParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.ExecutionManagerId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.LastEditedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingLastEditedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "LastEditedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.LastEditedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.ManagerId - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingManagerId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ManagerParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.ManagerId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.ContainmentLeadId - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingContainmentLeadId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Participant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.ContainmentLeadId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.TechnicalSpecialistId - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingTechnicalSpecialistId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "TechnicalSpecialistParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.TechnicalSpecialistId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and PbuEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.Pbuid - Pbu.Pbuid
		''' </summary>
		Public Overridable  ReadOnly Property PbuEntityUsingPbuid() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Pbu", False)
				relation.AddEntityFieldPair(PbuFields.Pbuid, CaseFields.Pbuid)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PbuEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and PersonalSafetyEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.PersonalSafetyId - PersonalSafety.PersonalSafetyId
		''' </summary>
		Public Overridable  ReadOnly Property PersonalSafetyEntityUsingPersonalSafetyId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "PersonalSafety", False)
				relation.AddEntityFieldPair(PersonalSafetyFields.PersonalSafetyId, CaseFields.PersonalSafetyId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PersonalSafetyEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and PhaseEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.PhaseId - Phase.PhaseId
		''' </summary>
		Public Overridable  ReadOnly Property PhaseEntityUsingPhaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Phase", False)
				relation.AddEntityFieldPair(PhaseFields.PhaseId, CaseFields.PhaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PhaseEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and PlatformEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.Platform - Platform.PlatformId
		''' </summary>
		Public Overridable  ReadOnly Property PlatformEntityUsingPlatform() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Platform_", False)
				relation.AddEntityFieldPair(PlatformFields.PlatformId, CaseFields.Platform)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PlatformEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and PortfolioEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.PortfolioId - Portfolio.PortfolioId
		''' </summary>
		Public Overridable  ReadOnly Property PortfolioEntityUsingPortfolioId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Portfolio", False)
				relation.AddEntityFieldPair(PortfolioFields.PortfolioId, CaseFields.PortfolioId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PortfolioEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and ProjectScopeEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.ProjectScopeId - ProjectScope.ProjectScopeId
		''' </summary>
		Public Overridable  ReadOnly Property ProjectScopeEntityUsingProjectScopeId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ProjectScope", False)
				relation.AddEntityFieldPair(ProjectScopeFields.ProjectScopeId, CaseFields.ProjectScopeId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ProjectScopeEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and StandardTaskEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.StandardTaskId - StandardTask.StandardTaskId
		''' </summary>
		Public Overridable  ReadOnly Property StandardTaskEntityUsingStandardTaskId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "StandardTask", False)
				relation.AddEntityFieldPair(StandardTaskFields.StandardTaskId, CaseFields.StandardTaskId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StandardTaskEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CaseEntity and StatusEntity over the m:1 relation they have, using the relation between the fields:
		''' Case.StatusId - Status.StatusId
		''' </summary>
		Public Overridable  ReadOnly Property StatusEntityUsingStatusId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Status", False)
				relation.AddEntityFieldPair(StatusFields.StatusId, CaseFields.StatusId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StatusEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticCaseRelations
		Friend Shared ReadOnly CaseEntityUsingUplinkStatic As IEntityRelation = New CaseRelations().CaseEntityUsingUplink
		Friend Shared ReadOnly Case2CaseBundleEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2CaseBundleEntityUsingCaseId
		Friend Shared ReadOnly Case2ComponentTypeEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2ComponentTypeEntityUsingCaseId
		Friend Shared ReadOnly Case2ItemEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2ItemEntityUsingCaseId
		Friend Shared ReadOnly Case2LogInfoEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2LogInfoEntityUsingCaseId
		Friend Shared ReadOnly Case2ParticipantEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2ParticipantEntityUsingCaseId
		Friend Shared ReadOnly Case2PhaseEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2PhaseEntityUsingCaseId
		Friend Shared ReadOnly Case2ReasonCodeEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2ReasonCodeEntityUsingCaseId
		Friend Shared ReadOnly Case2SbuEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2SbuEntityUsingCaseId
		Friend Shared ReadOnly Case2ServiceCodeEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2ServiceCodeEntityUsingCaseId
		Friend Shared ReadOnly Case2SupplierEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2SupplierEntityUsingCaseId
		Friend Shared ReadOnly Case2SystemEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2SystemEntityUsingCaseId
		Friend Shared ReadOnly Case2TurbineMatrixEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().Case2TurbineMatrixEntityUsingCaseId
		Friend Shared ReadOnly ChangeLogEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().ChangeLogEntityUsingCaseId
		Friend Shared ReadOnly CirEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().CirEntityUsingCaseId
		Friend Shared ReadOnly DiscussionEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().DiscussionEntityUsingCaseId
		Friend Shared ReadOnly FolderEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().FolderEntityUsingCaseId
		Friend Shared ReadOnly MilestoneEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().MilestoneEntityUsingCaseId
		Friend Shared ReadOnly NewsEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().NewsEntityUsingCaseId
		Friend Shared ReadOnly OldCimturbineEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().OldCimturbineEntityUsingCaseId
		Friend Shared ReadOnly PopulationlistEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().PopulationlistEntityUsingCaseId
		Friend Shared ReadOnly RcEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().RcEntityUsingCaseId
		Friend Shared ReadOnly RelatedCaseEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().RelatedCaseEntityUsingCaseId
		Friend Shared ReadOnly RelatedCaseEntityUsingCaseIdRelatedStatic As IEntityRelation = New CaseRelations().RelatedCaseEntityUsingCaseIdRelated
		Friend Shared ReadOnly TimelineEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().TimelineEntityUsingCaseId
		Friend Shared ReadOnly VisitsEntityUsingCaseIdStatic As IEntityRelation = New CaseRelations().VisitsEntityUsingCaseId
		Friend Shared ReadOnly BrandEntityUsingBrandIdStatic As IEntityRelation = New CaseRelations().BrandEntityUsingBrandId
		Friend Shared ReadOnly BusinessProcessEntityUsingBusinessProcessIdStatic As IEntityRelation = New CaseRelations().BusinessProcessEntityUsingBusinessProcessId
		Friend Shared ReadOnly CaseEntityUsingCaseIdUplinkStatic As IEntityRelation = New CaseRelations().CaseEntityUsingCaseIdUplink
		Friend Shared ReadOnly CategoryEntityUsingCategoryIdStatic As IEntityRelation = New CaseRelations().CategoryEntityUsingCategoryId
		Friend Shared ReadOnly ClaimStatusEntityUsingClaimStatusIdStatic As IEntityRelation = New CaseRelations().ClaimStatusEntityUsingClaimStatusId
		Friend Shared ReadOnly ComponentEntityUsingComponentIdStatic As IEntityRelation = New CaseRelations().ComponentEntityUsingComponentId
		Friend Shared ReadOnly ParticipantEntityUsingCreatedByIdStatic As IEntityRelation = New CaseRelations().ParticipantEntityUsingCreatedById
		Friend Shared ReadOnly ParticipantEntityUsingExecutionManagerIdStatic As IEntityRelation = New CaseRelations().ParticipantEntityUsingExecutionManagerId
		Friend Shared ReadOnly ParticipantEntityUsingLastEditedByIdStatic As IEntityRelation = New CaseRelations().ParticipantEntityUsingLastEditedById
		Friend Shared ReadOnly ParticipantEntityUsingManagerIdStatic As IEntityRelation = New CaseRelations().ParticipantEntityUsingManagerId
		Friend Shared ReadOnly ParticipantEntityUsingContainmentLeadIdStatic As IEntityRelation = New CaseRelations().ParticipantEntityUsingContainmentLeadId
		Friend Shared ReadOnly ParticipantEntityUsingTechnicalSpecialistIdStatic As IEntityRelation = New CaseRelations().ParticipantEntityUsingTechnicalSpecialistId
		Friend Shared ReadOnly PbuEntityUsingPbuidStatic As IEntityRelation = New CaseRelations().PbuEntityUsingPbuid
		Friend Shared ReadOnly PersonalSafetyEntityUsingPersonalSafetyIdStatic As IEntityRelation = New CaseRelations().PersonalSafetyEntityUsingPersonalSafetyId
		Friend Shared ReadOnly PhaseEntityUsingPhaseIdStatic As IEntityRelation = New CaseRelations().PhaseEntityUsingPhaseId
		Friend Shared ReadOnly PlatformEntityUsingPlatformStatic As IEntityRelation = New CaseRelations().PlatformEntityUsingPlatform
		Friend Shared ReadOnly PortfolioEntityUsingPortfolioIdStatic As IEntityRelation = New CaseRelations().PortfolioEntityUsingPortfolioId
		Friend Shared ReadOnly ProjectScopeEntityUsingProjectScopeIdStatic As IEntityRelation = New CaseRelations().ProjectScopeEntityUsingProjectScopeId
		Friend Shared ReadOnly StandardTaskEntityUsingStandardTaskIdStatic As IEntityRelation = New CaseRelations().StandardTaskEntityUsingStandardTaskId
		Friend Shared ReadOnly StatusEntityUsingStatusIdStatic As IEntityRelation = New CaseRelations().StatusEntityUsingStatusId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
