﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: CustomColumnsValue.</summary>
	Public Class CustomColumnsValueRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the CustomColumnsValueEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.CustomColumnsNameEntityUsingCustomColumnsNameId)
			toReturn.Add(Me.PopulationlistItemEntityUsingPopulationlistItemId)
			Return toReturn
		End Function

#Region "Class Property Declarations"



		''' <summary>Returns a new IEntityRelation Object, between CustomColumnsValueEntity and CustomColumnsNameEntity over the m:1 relation they have, using the relation between the fields:
		''' CustomColumnsValue.CustomColumnsNameId - CustomColumnsName.CustomColumnsNameId
		''' </summary>
		Public Overridable  ReadOnly Property CustomColumnsNameEntityUsingCustomColumnsNameId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "CustomColumnsName", False)
				relation.AddEntityFieldPair(CustomColumnsNameFields.CustomColumnsNameId, CustomColumnsValueFields.CustomColumnsNameId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CustomColumnsNameEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CustomColumnsValueEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between CustomColumnsValueEntity and PopulationlistItemEntity over the m:1 relation they have, using the relation between the fields:
		''' CustomColumnsValue.PopulationlistItemId - PopulationlistItem.PopulationlistItemId
		''' </summary>
		Public Overridable  ReadOnly Property PopulationlistItemEntityUsingPopulationlistItemId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "PopulationlistItem", False)
				relation.AddEntityFieldPair(PopulationlistItemFields.PopulationlistItemId, CustomColumnsValueFields.PopulationlistItemId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PopulationlistItemEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CustomColumnsValueEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticCustomColumnsValueRelations
		Friend Shared ReadOnly CustomColumnsNameEntityUsingCustomColumnsNameIdStatic As IEntityRelation = New CustomColumnsValueRelations().CustomColumnsNameEntityUsingCustomColumnsNameId
		Friend Shared ReadOnly PopulationlistItemEntityUsingPopulationlistItemIdStatic As IEntityRelation = New CustomColumnsValueRelations().PopulationlistItemEntityUsingPopulationlistItemId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
