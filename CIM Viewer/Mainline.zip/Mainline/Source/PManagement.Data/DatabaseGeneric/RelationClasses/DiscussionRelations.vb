﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Discussion.</summary>
	Public Class DiscussionRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the DiscussionEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.DiscussionEntityUsingReplyToDiscussionId)
			toReturn.Add(Me.CaseEntityUsingCaseId)
			toReturn.Add(Me.DiscussionEntityUsingDiscussionIdReplyToDiscussionId)
			toReturn.Add(Me.ParticipantEntityUsingCreatedById)
			toReturn.Add(Me.ParticipantEntityUsingModifiedById)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between DiscussionEntity and DiscussionEntity over the 1:n relation they have, using the relation between the fields:
		''' Discussion.DiscussionId - Discussion.ReplyToDiscussionId
		''' </summary>
		Public Overridable ReadOnly Property DiscussionEntityUsingReplyToDiscussionId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChildDiscussion", True)
				relation.AddEntityFieldPair(DiscussionFields.DiscussionId, DiscussionFields.ReplyToDiscussionId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>Returns a new IEntityRelation Object, between DiscussionEntity and CaseEntity over the m:1 relation they have, using the relation between the fields:
		''' Discussion.CaseId - Case.CaseId
		''' </summary>
		Public Overridable  ReadOnly Property CaseEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Case", False)
				relation.AddEntityFieldPair(CaseFields.CaseId, DiscussionFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DiscussionEntity and DiscussionEntity over the m:1 relation they have, using the relation between the fields:
		''' Discussion.ReplyToDiscussionId - Discussion.DiscussionId
		''' </summary>
		Public Overridable  ReadOnly Property DiscussionEntityUsingDiscussionIdReplyToDiscussionId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ParentDiscussion", False)
				relation.AddEntityFieldPair(DiscussionFields.DiscussionId, DiscussionFields.ReplyToDiscussionId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DiscussionEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Discussion.CreatedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "CreatedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DiscussionFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DiscussionEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Discussion.ModifiedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingModifiedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ModifiedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DiscussionFields.ModifiedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticDiscussionRelations
		Friend Shared ReadOnly DiscussionEntityUsingReplyToDiscussionIdStatic As IEntityRelation = New DiscussionRelations().DiscussionEntityUsingReplyToDiscussionId
		Friend Shared ReadOnly CaseEntityUsingCaseIdStatic As IEntityRelation = New DiscussionRelations().CaseEntityUsingCaseId
		Friend Shared ReadOnly DiscussionEntityUsingDiscussionIdReplyToDiscussionIdStatic As IEntityRelation = New DiscussionRelations().DiscussionEntityUsingDiscussionIdReplyToDiscussionId
		Friend Shared ReadOnly ParticipantEntityUsingCreatedByIdStatic As IEntityRelation = New DiscussionRelations().ParticipantEntityUsingCreatedById
		Friend Shared ReadOnly ParticipantEntityUsingModifiedByIdStatic As IEntityRelation = New DiscussionRelations().ParticipantEntityUsingModifiedById

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
