﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: DocumentClassification.</summary>
	Public Class DocumentClassificationRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the DocumentClassificationEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.DocumentEntityUsingDocumentClassificationId)
			toReturn.Add(Me.DocumentTemplateEntityUsingDocumentClassificationId)
			toReturn.Add(Me.PopulationlistDocumentEntityUsingDocumentClassificationId)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between DocumentClassificationEntity and DocumentEntity over the 1:n relation they have, using the relation between the fields:
		''' DocumentClassification.DocumentClassificationId - Document.DocumentClassificationId
		''' </summary>
		Public Overridable ReadOnly Property DocumentEntityUsingDocumentClassificationId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Document", True)
				relation.AddEntityFieldPair(DocumentClassificationFields.DocumentClassificationId, DocumentFields.DocumentClassificationId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentClassificationEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DocumentClassificationEntity and DocumentTemplateEntity over the 1:n relation they have, using the relation between the fields:
		''' DocumentClassification.DocumentClassificationId - DocumentTemplate.DocumentClassificationId
		''' </summary>
		Public Overridable ReadOnly Property DocumentTemplateEntityUsingDocumentClassificationId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "DocumentTemplate", True)
				relation.AddEntityFieldPair(DocumentClassificationFields.DocumentClassificationId, DocumentTemplateFields.DocumentClassificationId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentClassificationEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentTemplateEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DocumentClassificationEntity and PopulationlistDocumentEntity over the 1:n relation they have, using the relation between the fields:
		''' DocumentClassification.DocumentClassificationId - PopulationlistDocument.DocumentClassificationId
		''' </summary>
		Public Overridable ReadOnly Property PopulationlistDocumentEntityUsingDocumentClassificationId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "PopulationlistDocument", True)
				relation.AddEntityFieldPair(DocumentClassificationFields.DocumentClassificationId, PopulationlistDocumentFields.DocumentClassificationId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentClassificationEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PopulationlistDocumentEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticDocumentClassificationRelations
		Friend Shared ReadOnly DocumentEntityUsingDocumentClassificationIdStatic As IEntityRelation = New DocumentClassificationRelations().DocumentEntityUsingDocumentClassificationId
		Friend Shared ReadOnly DocumentTemplateEntityUsingDocumentClassificationIdStatic As IEntityRelation = New DocumentClassificationRelations().DocumentTemplateEntityUsingDocumentClassificationId
		Friend Shared ReadOnly PopulationlistDocumentEntityUsingDocumentClassificationIdStatic As IEntityRelation = New DocumentClassificationRelations().PopulationlistDocumentEntityUsingDocumentClassificationId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
