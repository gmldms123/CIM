﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Document.</summary>
	Public Class DocumentRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the DocumentEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.DocumentVersionEntityUsingDocumentId)
			toReturn.Add(Me.Folder2DocumentEntityUsingDocumentId)
			toReturn.Add(Me.DocumentBinaryEntityUsingDocumentBinaryId)
			toReturn.Add(Me.DocumentClassificationEntityUsingDocumentClassificationId)
			toReturn.Add(Me.ParticipantEntityUsingCreatedById)
			toReturn.Add(Me.ParticipantEntityUsingLockedById)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between DocumentEntity and DocumentVersionEntity over the 1:n relation they have, using the relation between the fields:
		''' Document.DocumentId - DocumentVersion.DocumentId
		''' </summary>
		Public Overridable ReadOnly Property DocumentVersionEntityUsingDocumentId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "DocumentVersion", True)
				relation.AddEntityFieldPair(DocumentFields.DocumentId, DocumentVersionFields.DocumentId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentVersionEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DocumentEntity and Folder2DocumentEntity over the 1:n relation they have, using the relation between the fields:
		''' Document.DocumentId - Folder2Document.DocumentId
		''' </summary>
		Public Overridable ReadOnly Property Folder2DocumentEntityUsingDocumentId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Folder2Document", True)
				relation.AddEntityFieldPair(DocumentFields.DocumentId, Folder2DocumentFields.DocumentId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Folder2DocumentEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>Returns a new IEntityRelation Object, between DocumentEntity and DocumentBinaryEntity over the m:1 relation they have, using the relation between the fields:
		''' Document.DocumentBinaryId - DocumentBinary.DocumentBinaryId
		''' </summary>
		Public Overridable  ReadOnly Property DocumentBinaryEntityUsingDocumentBinaryId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "DocumentBinary", False)
				relation.AddEntityFieldPair(DocumentBinaryFields.DocumentBinaryId, DocumentFields.DocumentBinaryId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentBinaryEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DocumentEntity and DocumentClassificationEntity over the m:1 relation they have, using the relation between the fields:
		''' Document.DocumentClassificationId - DocumentClassification.DocumentClassificationId
		''' </summary>
		Public Overridable  ReadOnly Property DocumentClassificationEntityUsingDocumentClassificationId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "DocumentClassification", False)
				relation.AddEntityFieldPair(DocumentClassificationFields.DocumentClassificationId, DocumentFields.DocumentClassificationId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentClassificationEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DocumentEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Document.CreatedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "CreatedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DocumentFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between DocumentEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Document.LockedById - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingLockedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "LockedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DocumentFields.LockedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticDocumentRelations
		Friend Shared ReadOnly DocumentVersionEntityUsingDocumentIdStatic As IEntityRelation = New DocumentRelations().DocumentVersionEntityUsingDocumentId
		Friend Shared ReadOnly Folder2DocumentEntityUsingDocumentIdStatic As IEntityRelation = New DocumentRelations().Folder2DocumentEntityUsingDocumentId
		Friend Shared ReadOnly DocumentBinaryEntityUsingDocumentBinaryIdStatic As IEntityRelation = New DocumentRelations().DocumentBinaryEntityUsingDocumentBinaryId
		Friend Shared ReadOnly DocumentClassificationEntityUsingDocumentClassificationIdStatic As IEntityRelation = New DocumentRelations().DocumentClassificationEntityUsingDocumentClassificationId
		Friend Shared ReadOnly ParticipantEntityUsingCreatedByIdStatic As IEntityRelation = New DocumentRelations().ParticipantEntityUsingCreatedById
		Friend Shared ReadOnly ParticipantEntityUsingLockedByIdStatic As IEntityRelation = New DocumentRelations().ParticipantEntityUsingLockedById

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
