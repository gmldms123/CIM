﻿'///////////////////////////////////////////////////////////////
'// This is generated code. 
'//////////////////////////////////////////////////////////////
'// Code is generated Imports LLBLGen Pro version: 4.0
'// Code is generated on: 
'// Code is generated Imports templates: SD.TemplateBindings.SharedTemplates
'// Templates vendor: Solutions Design.
'//////////////////////////////////////////////////////////////
Imports System
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses

	''' <summary>
	''' Class to define dynamic relations for queries. 
	''' </summary>
	''' <remarks>Dynamic relations are only supported in ansi joins. If you're Imports Oracle on 8i, you can't use Dynamic Relations. In all other cases
	''' you can. In the case of Oracle 9i: specify that you want to use Ansi joins (recommended) by setting the config file setting 'OracleAnsiJoins' to true</remarks>
	<Serializable()> _
	Public Class DynamicRelation 
		Inherits DynamicRelationBase
	
		''' <summary>
		''' Initializes a new instance of the <see cref="DynamicRelation"/> class.
		''' </summary>
		''' <param name="leftOperand">The left operand, which can only be a derived table definition. No join will take place. </param>
		''' <remarks>If a DynamicRelation is created with this CTor, it has to be the only one. It will be ignored if there are more
		''' relations in the relation collection.</remarks>
		Public Sub New(leftOperand As DerivedTableDefinition)
			Me.InitClass(JoinHint.None, String.Empty, String.Empty, Nothing, leftOperand, Nothing)
		End Sub
	
		''' <summary>
		''' Initializes a new instance of the <see cref="DynamicRelation"/> class.
		''' </summary>
		''' <param name="leftOperand">The left operand.</param>
		''' <param name="joinType">Type of the join. If None is specified, Inner is assumed.</param>
		''' <param name="rightOperand">The right operand.</param>
		''' <param name="onClause">The on clause for the join.</param>
		Public Sub New(leftOperand As DerivedTableDefinition, joinType As JoinHint, rightOperand As DerivedTableDefinition, onClause As IPredicate)
			Me.InitClass(joinType, String.Empty, String.Empty, onClause, leftOperand, rightOperand)
		End Sub
	

		''' <summary>
		''' Initializes a new instance of the <see cref="DynamicRelation"/> class.
		''' </summary>
		''' <param name="leftOperand">The left operand.</param>
		''' <param name="joinType">Type of the join. If None is specified, Inner is assumed.</param>
		''' <param name="rightOperand">The right operand which is an entity type.</param>
		''' <param name="aliasRightOperand">The alias of the right operand. If you don't want to / need to alias the right operand (only alias if you have to), specify
		''' string.Empty.</param>
		''' <param name="onClause">The on clause for the join.</param>
		Public Sub New(leftOperand As DerivedTableDefinition, joinType As JoinHint, rightOperand As PManagement.Data.EntityType, aliasRightOperand As String, onClause As IPredicate)
			Me.InitClass(joinType, String.Empty, aliasRightOperand, onClause, leftOperand, GeneralEntityFactory.Create(rightOperand))
		End Sub
	
	
		''' <summary>
		''' Initializes a new instance of the <see cref="DynamicRelation"/> class.
		''' </summary>
		''' <param name="leftOperand">The left operand, which is an entity.</param>
		''' <param name="joinType">Type of the join. If None is specified, Inner is assumed.</param>
		''' <param name="rightOperand">The right operand which is an entity.</param>
		''' <param name="aliasLeftOperand">The alias of the left operand. If you don't want to / need to alias the left operand (only alias if you have to), specify
		''' string.Empty.</param>
		''' <param name="aliasRightOperand">The alias of the right operand. If you don't want to / need to alias the right operand (only alias if you have to), specify
		''' string.Empty.</param>
		''' <param name="onClause">The on clause for the join.</param>
		Public Sub New(leftOperand As PManagement.Data.EntityType, joinType As JoinHint, rightOperand As PManagement.Data.EntityType, aliasLeftOperand As String, aliasRightOperand As String, onClause As IPredicate)
			Me.InitClass(joinType, aliasLeftOperand, aliasRightOperand, onClause, GeneralEntityFactory.Create(leftOperand), GeneralEntityFactory.Create(rightOperand))
		End Sub

	
		''' <summary>
		''' Gets the inheritance provider for inheritance info retrieval for entity operands
		''' </summary>
		''' <returns>The inheritance info provider</returns>
		Protected Overrides Function GetInheritanceProvider() As IInheritanceInfoProvider 
			Return InheritanceInfoProviderSingleton.GetInstance()
		End Function
	End Class
End Namespace