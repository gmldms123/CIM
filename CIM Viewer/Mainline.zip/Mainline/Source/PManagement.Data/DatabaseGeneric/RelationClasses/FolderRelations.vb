﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Folder.</summary>
	Public Class FolderRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the FolderEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.FolderEntityUsingParentFolderId)
			toReturn.Add(Me.Folder2DocumentEntityUsingFolderId)
			toReturn.Add(Me.CaseEntityUsingCaseId)
			toReturn.Add(Me.FolderEntityUsingFolderIdParentFolderId)
			toReturn.Add(Me.FolderTypeEntityUsingFolderTypeId)
			toReturn.Add(Me.ParticipantEntityUsingCreatedBy)
			toReturn.Add(Me.ParticipantEntityUsingLockedBy)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between FolderEntity and FolderEntity over the 1:n relation they have, using the relation between the fields:
		''' Folder.FolderId - Folder.ParentFolderId
		''' </summary>
		Public Overridable ReadOnly Property FolderEntityUsingParentFolderId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChildFolders", True)
				relation.AddEntityFieldPair(FolderFields.FolderId, FolderFields.ParentFolderId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between FolderEntity and Folder2DocumentEntity over the 1:n relation they have, using the relation between the fields:
		''' Folder.FolderId - Folder2Document.FolderId
		''' </summary>
		Public Overridable ReadOnly Property Folder2DocumentEntityUsingFolderId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Folder2Document", True)
				relation.AddEntityFieldPair(FolderFields.FolderId, Folder2DocumentFields.FolderId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Folder2DocumentEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>Returns a new IEntityRelation Object, between FolderEntity and CaseEntity over the m:1 relation they have, using the relation between the fields:
		''' Folder.CaseId - Case.CaseId
		''' </summary>
		Public Overridable  ReadOnly Property CaseEntityUsingCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Case", False)
				relation.AddEntityFieldPair(CaseFields.CaseId, FolderFields.CaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between FolderEntity and FolderEntity over the m:1 relation they have, using the relation between the fields:
		''' Folder.ParentFolderId - Folder.FolderId
		''' </summary>
		Public Overridable  ReadOnly Property FolderEntityUsingFolderIdParentFolderId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "ParentFolder", False)
				relation.AddEntityFieldPair(FolderFields.FolderId, FolderFields.ParentFolderId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between FolderEntity and FolderTypeEntity over the m:1 relation they have, using the relation between the fields:
		''' Folder.FolderTypeId - FolderType.FolderTypeId
		''' </summary>
		Public Overridable  ReadOnly Property FolderTypeEntityUsingFolderTypeId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "FolderType", False)
				relation.AddEntityFieldPair(FolderTypeFields.FolderTypeId, FolderFields.FolderTypeId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderTypeEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between FolderEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Folder.CreatedBy - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingCreatedBy() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "CreatedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, FolderFields.CreatedBy)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between FolderEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Folder.LockedBy - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingLockedBy() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "LockedByParticipant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, FolderFields.LockedBy)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticFolderRelations
		Friend Shared ReadOnly FolderEntityUsingParentFolderIdStatic As IEntityRelation = New FolderRelations().FolderEntityUsingParentFolderId
		Friend Shared ReadOnly Folder2DocumentEntityUsingFolderIdStatic As IEntityRelation = New FolderRelations().Folder2DocumentEntityUsingFolderId
		Friend Shared ReadOnly CaseEntityUsingCaseIdStatic As IEntityRelation = New FolderRelations().CaseEntityUsingCaseId
		Friend Shared ReadOnly FolderEntityUsingFolderIdParentFolderIdStatic As IEntityRelation = New FolderRelations().FolderEntityUsingFolderIdParentFolderId
		Friend Shared ReadOnly FolderTypeEntityUsingFolderTypeIdStatic As IEntityRelation = New FolderRelations().FolderTypeEntityUsingFolderTypeId
		Friend Shared ReadOnly ParticipantEntityUsingCreatedByStatic As IEntityRelation = New FolderRelations().ParticipantEntityUsingCreatedBy
		Friend Shared ReadOnly ParticipantEntityUsingLockedByStatic As IEntityRelation = New FolderRelations().ParticipantEntityUsingLockedBy

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
