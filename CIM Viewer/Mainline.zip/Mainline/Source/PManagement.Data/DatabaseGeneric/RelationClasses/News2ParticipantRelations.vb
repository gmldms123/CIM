﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: News2Participant.</summary>
	Public Class News2ParticipantRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the News2ParticipantEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.NewsEntityUsingNewsId)
			toReturn.Add(Me.ParticipantEntityUsingParticipantId)
			Return toReturn
		End Function

#Region "Class Property Declarations"



		''' <summary>Returns a new IEntityRelation Object, between News2ParticipantEntity and NewsEntity over the m:1 relation they have, using the relation between the fields:
		''' News2Participant.NewsId - News.NewsId
		''' </summary>
		Public Overridable  ReadOnly Property NewsEntityUsingNewsId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "News", False)
				relation.AddEntityFieldPair(NewsFields.NewsId, News2ParticipantFields.NewsId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("NewsEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("News2ParticipantEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between News2ParticipantEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' News2Participant.ParticipantId - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingParticipantId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Participant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, News2ParticipantFields.ParticipantId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("News2ParticipantEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticNews2ParticipantRelations
		Friend Shared ReadOnly NewsEntityUsingNewsIdStatic As IEntityRelation = New News2ParticipantRelations().NewsEntityUsingNewsId
		Friend Shared ReadOnly ParticipantEntityUsingParticipantIdStatic As IEntityRelation = New News2ParticipantRelations().ParticipantEntityUsingParticipantId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
