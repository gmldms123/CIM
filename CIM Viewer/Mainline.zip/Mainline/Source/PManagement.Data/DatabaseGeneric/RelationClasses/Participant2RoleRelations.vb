﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Participant2Role.</summary>
	Public Class Participant2RoleRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the Participant2RoleEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.ParticipantEntityUsingParticipantId)
			toReturn.Add(Me.RoleEntityUsingRoleId)
			Return toReturn
		End Function

#Region "Class Property Declarations"



		''' <summary>Returns a new IEntityRelation Object, between Participant2RoleEntity and ParticipantEntity over the m:1 relation they have, using the relation between the fields:
		''' Participant2Role.ParticipantId - Participant.ParticipantId
		''' </summary>
		Public Overridable  ReadOnly Property ParticipantEntityUsingParticipantId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Participant", False)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, Participant2RoleFields.ParticipantId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Participant2RoleEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between Participant2RoleEntity and RoleEntity over the m:1 relation they have, using the relation between the fields:
		''' Participant2Role.RoleId - Role.RoleId
		''' </summary>
		Public Overridable  ReadOnly Property RoleEntityUsingRoleId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "Role", False)
				relation.AddEntityFieldPair(RoleFields.RoleId, Participant2RoleFields.RoleId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RoleEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Participant2RoleEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticParticipant2RoleRelations
		Friend Shared ReadOnly ParticipantEntityUsingParticipantIdStatic As IEntityRelation = New Participant2RoleRelations().ParticipantEntityUsingParticipantId
		Friend Shared ReadOnly RoleEntityUsingRoleIdStatic As IEntityRelation = New Participant2RoleRelations().RoleEntityUsingRoleId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
