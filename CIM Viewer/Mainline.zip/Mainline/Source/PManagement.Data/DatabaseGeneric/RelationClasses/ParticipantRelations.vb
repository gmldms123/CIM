﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: Participant.</summary>
	Public Class ParticipantRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the ParticipantEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.AlertCategoryEntityUsingCreatedById)
			toReturn.Add(Me.AlertCategoryEntityUsingDeletedById)
			toReturn.Add(Me.AlertCategoryCriteriaEntityUsingCreatedById)
			toReturn.Add(Me.AlertCategoryCriteriaEntityUsingDeletedById)
			toReturn.Add(Me.AlertChangeTypeCriteriaEntityUsingCreatedById)
			toReturn.Add(Me.AlertChangeTypeCriteriaEntityUsingDeletedById)
			toReturn.Add(Me.AlertConfigEntityUsingCreatedById)
			toReturn.Add(Me.AlertConfigEntityUsingDeletedById)
			toReturn.Add(Me.AlertFrequencyEntityUsingCreatedById)
			toReturn.Add(Me.AlertFrequencyEntityUsingDeletedById)
			toReturn.Add(Me.AlertReceiverEntityUsingCreatedById)
			toReturn.Add(Me.AlertReceiverEntityUsingDeletedById)
			toReturn.Add(Me.AlertReceiverTypeEntityUsingCreatedById)
			toReturn.Add(Me.AlertReceiverTypeEntityUsingDeletedById)
			toReturn.Add(Me.AlertServiceSettingsEntityUsingCreatedById)
			toReturn.Add(Me.AlertServiceSettingsEntityUsingDeletedById)
			toReturn.Add(Me.CaseEntityUsingCreatedById)
			toReturn.Add(Me.CaseEntityUsingExecutionManagerId)
			toReturn.Add(Me.CaseEntityUsingLastEditedById)
			toReturn.Add(Me.CaseEntityUsingManagerId)
			toReturn.Add(Me.CaseEntityUsingContainmentLeadId)
			toReturn.Add(Me.CaseEntityUsingTechnicalSpecialistId)
			toReturn.Add(Me.Case2ParticipantEntityUsingParticipantId)
			toReturn.Add(Me.CategoryEntityUsingCreatedById)
			toReturn.Add(Me.CategoryEntityUsingDeletedById)
			toReturn.Add(Me.ChangeLogEntityUsingCreatedById)
			toReturn.Add(Me.ChangeLogEntityUsingDeletedById)
			toReturn.Add(Me.ChangeTypeEntityUsingCreatedById)
			toReturn.Add(Me.ChangeTypeEntityUsingDeletedById)
			toReturn.Add(Me.CirEntityUsingRejectedBy)
			toReturn.Add(Me.CirEntityUsingVerifiedBy)
			toReturn.Add(Me.ComponentEntityUsingCreatedById)
			toReturn.Add(Me.ComponentEntityUsingDeletedById)
			toReturn.Add(Me.DiscussionEntityUsingCreatedById)
			toReturn.Add(Me.DiscussionEntityUsingModifiedById)
			toReturn.Add(Me.DocumentEntityUsingCreatedById)
			toReturn.Add(Me.DocumentEntityUsingLockedById)
			toReturn.Add(Me.FolderEntityUsingCreatedBy)
			toReturn.Add(Me.FolderEntityUsingLockedBy)
			toReturn.Add(Me.MilestoneEntityUsingResponsiblePersonId)
			toReturn.Add(Me.NewsEntityUsingCreatedbyId)
			toReturn.Add(Me.NewsEntityUsingModifiedById)
			toReturn.Add(Me.News2ParticipantEntityUsingParticipantId)
			toReturn.Add(Me.Participant2RoleEntityUsingParticipantId)
			toReturn.Add(Me.ParticipantLogEntityUsingParticipantId)
			toReturn.Add(Me.PersonalSafetyEntityUsingCreatedById)
			toReturn.Add(Me.PersonalSafetyEntityUsingDeletedById)
			toReturn.Add(Me.PhaseEntityUsingCreatedById)
			toReturn.Add(Me.PhaseEntityUsingDeletedById)
			toReturn.Add(Me.PlatformEntityUsingCoordinator)
			toReturn.Add(Me.PopulationlistEntityUsingCreatedById)
			toReturn.Add(Me.PopulationlistDocumentEntityUsingLockedById)
			toReturn.Add(Me.ProjectScopeEntityUsingCreatedById)
			toReturn.Add(Me.ProjectScopeEntityUsingDeletedById)
			toReturn.Add(Me.RcEntityUsingCreatedById)
			toReturn.Add(Me.RcEntityUsingDeletedById)
			toReturn.Add(Me.RccomponentOwnerEntityUsingCreatedById)
			toReturn.Add(Me.RccomponentOwnerEntityUsingDeletedById)
			toReturn.Add(Me.RcoriginEntityUsingCreatedById)
			toReturn.Add(Me.RcoriginEntityUsingDeletedById)
			toReturn.Add(Me.RcoriginRelationEntityUsingCreatedById)
			toReturn.Add(Me.RcoriginRelationEntityUsingDeletedById)
			toReturn.Add(Me.RcoriginResponsibleEntityUsingCreatedById)
			toReturn.Add(Me.RcoriginResponsibleEntityUsingDeletedById)
			toReturn.Add(Me.RcoriginUnitEntityUsingCreatedById)
			toReturn.Add(Me.RcoriginUnitEntityUsingDeletedById)
			toReturn.Add(Me.StandardTaskEntityUsingDeletedById)
			toReturn.Add(Me.StandardTaskEntityUsingCreatedById)
			toReturn.Add(Me.StatusEntityUsingCreatedById)
			toReturn.Add(Me.StatusEntityUsingDeletedById)
			toReturn.Add(Me.TaskEntityUsingResponsiblePersonId)
			toReturn.Add(Me.TaskMilestoneEntityUsingResponsiblePersonId)
			toReturn.Add(Me.TimelineEntityUsingChangedBy)
			toReturn.Add(Me.VisitsEntityUsingCreatedById)
			toReturn.Add(Me.VisitsEntityUsingDeletedById)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertCategoryEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertCategory.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertCategoryEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertCategory", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertCategoryFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertCategoryEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertCategoryEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertCategory.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertCategoryEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertCategory_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertCategoryFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertCategoryEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertCategoryCriteriaEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertCategoryCriteria.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertCategoryCriteriaEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertCategoryCriteria", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertCategoryCriteriaFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertCategoryCriteriaEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertCategoryCriteriaEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertCategoryCriteria.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertCategoryCriteriaEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertCategoryCriteria_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertCategoryCriteriaFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertCategoryCriteriaEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertChangeTypeCriteriaEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertChangeTypeCriteria.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertChangeTypeCriteriaEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertChangeTypeCriteria", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertChangeTypeCriteriaFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertChangeTypeCriteriaEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertChangeTypeCriteriaEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertChangeTypeCriteria.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertChangeTypeCriteriaEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertChangeTypeCriteria_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertChangeTypeCriteriaFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertChangeTypeCriteriaEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertConfigEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertConfig.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertConfigEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertConfig", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertConfigFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertConfigEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertConfig.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertConfigEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertConfig_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertConfigFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertConfigEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertFrequencyEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertFrequency.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertFrequencyEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertFrequency", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertFrequencyFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertFrequencyEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertFrequencyEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertFrequency.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertFrequencyEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertFrequency_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertFrequencyFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertFrequencyEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertReceiverEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertReceiver.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertReceiverEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertReceiver", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertReceiverFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertReceiverEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertReceiverEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertReceiver.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertReceiverEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertReceiver_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertReceiverFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertReceiverEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertReceiverTypeEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertReceiverType.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertReceiverTypeEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertReceiverType", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertReceiverTypeFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertReceiverTypeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertReceiverTypeEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertReceiverType.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertReceiverTypeEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertReceiverType_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertReceiverTypeFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertReceiverTypeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertServiceSettingsEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertServiceSettings.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property AlertServiceSettingsEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertServiceSettings", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertServiceSettingsFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertServiceSettingsEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and AlertServiceSettingsEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - AlertServiceSettings.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property AlertServiceSettingsEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "AlertServiceSettings_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, AlertServiceSettingsFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("AlertServiceSettingsEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Case.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Case.ExecutionManagerId
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingExecutionManagerId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case____", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.ExecutionManagerId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Case.LastEditedById
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingLastEditedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case__", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.LastEditedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Case.ManagerId
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingManagerId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.ManagerId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Case.ContainmentLeadId
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingContainmentLeadId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case_____", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.ContainmentLeadId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Case.TechnicalSpecialistId
		''' </summary>
		Public Overridable ReadOnly Property CaseEntityUsingTechnicalSpecialistId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case___", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CaseFields.TechnicalSpecialistId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and Case2ParticipantEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Case2Participant.ParticipantId
		''' </summary>
		Public Overridable ReadOnly Property Case2ParticipantEntityUsingParticipantId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2Participant", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, Case2ParticipantFields.ParticipantId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ParticipantEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CategoryEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Category.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property CategoryEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Category", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CategoryFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CategoryEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CategoryEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Category.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property CategoryEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Category_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CategoryFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CategoryEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ChangeLogEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - ChangeLog.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property ChangeLogEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChangeLog", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ChangeLogFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ChangeLogEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ChangeLogEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - ChangeLog.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property ChangeLogEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChangeLog_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ChangeLogFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ChangeLogEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ChangeTypeEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - ChangeType.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property ChangeTypeEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChangeType", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ChangeTypeFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ChangeTypeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ChangeTypeEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - ChangeType.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property ChangeTypeEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ChangeType_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ChangeTypeFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ChangeTypeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CirEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Cir.RejectedBy
		''' </summary>
		Public Overridable ReadOnly Property CirEntityUsingRejectedBy() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Cir_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CirFields.RejectedBy)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CirEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and CirEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Cir.VerifiedBy
		''' </summary>
		Public Overridable ReadOnly Property CirEntityUsingVerifiedBy() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Cir", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, CirFields.VerifiedBy)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CirEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ComponentEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Component.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property ComponentEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Component", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ComponentFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ComponentEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ComponentEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Component.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property ComponentEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Component_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ComponentFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ComponentEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and DiscussionEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Discussion.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property DiscussionEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Discussion_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DiscussionFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and DiscussionEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Discussion.ModifiedById
		''' </summary>
		Public Overridable ReadOnly Property DiscussionEntityUsingModifiedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Discussion", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DiscussionFields.ModifiedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DiscussionEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and DocumentEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Document.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property DocumentEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Document", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DocumentFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and DocumentEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Document.LockedById
		''' </summary>
		Public Overridable ReadOnly Property DocumentEntityUsingLockedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Document_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, DocumentFields.LockedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("DocumentEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and FolderEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Folder.CreatedBy
		''' </summary>
		Public Overridable ReadOnly Property FolderEntityUsingCreatedBy() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Folder_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, FolderFields.CreatedBy)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and FolderEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Folder.LockedBy
		''' </summary>
		Public Overridable ReadOnly Property FolderEntityUsingLockedBy() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Folder", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, FolderFields.LockedBy)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("FolderEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and MilestoneEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Milestone.ResponsiblePersonId
		''' </summary>
		Public Overridable ReadOnly Property MilestoneEntityUsingResponsiblePersonId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Milestone", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, MilestoneFields.ResponsiblePersonId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("MilestoneEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and NewsEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - News.CreatedbyId
		''' </summary>
		Public Overridable ReadOnly Property NewsEntityUsingCreatedbyId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "News", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, NewsFields.CreatedbyId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("NewsEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and NewsEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - News.ModifiedById
		''' </summary>
		Public Overridable ReadOnly Property NewsEntityUsingModifiedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "News_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, NewsFields.ModifiedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("NewsEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and News2ParticipantEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - News2Participant.ParticipantId
		''' </summary>
		Public Overridable ReadOnly Property News2ParticipantEntityUsingParticipantId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "News2Participant", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, News2ParticipantFields.ParticipantId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("News2ParticipantEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and Participant2RoleEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Participant2Role.ParticipantId
		''' </summary>
		Public Overridable ReadOnly Property Participant2RoleEntityUsingParticipantId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Participant2Role", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, Participant2RoleFields.ParticipantId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Participant2RoleEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ParticipantLogEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - ParticipantLog.ParticipantId
		''' </summary>
		Public Overridable ReadOnly Property ParticipantLogEntityUsingParticipantId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ParticipantLog", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ParticipantLogFields.ParticipantId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantLogEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and PersonalSafetyEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - PersonalSafety.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property PersonalSafetyEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "PersonalSafety", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, PersonalSafetyFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PersonalSafetyEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and PersonalSafetyEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - PersonalSafety.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property PersonalSafetyEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "PersonalSafety_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, PersonalSafetyFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PersonalSafetyEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and PhaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Phase.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property PhaseEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Phase", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, PhaseFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PhaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and PhaseEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Phase.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property PhaseEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Phase_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, PhaseFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PhaseEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and PlatformEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Platform.Coordinator
		''' </summary>
		Public Overridable ReadOnly Property PlatformEntityUsingCoordinator() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Platform", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, PlatformFields.Coordinator)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PlatformEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and PopulationlistEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Populationlist.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property PopulationlistEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Populationlist", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, PopulationlistFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PopulationlistEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and PopulationlistDocumentEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - PopulationlistDocument.LockedById
		''' </summary>
		Public Overridable ReadOnly Property PopulationlistDocumentEntityUsingLockedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "PopulationlistDocument", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, PopulationlistDocumentFields.LockedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("PopulationlistDocumentEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ProjectScopeEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - ProjectScope.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property ProjectScopeEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ProjectScope", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ProjectScopeFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ProjectScopeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and ProjectScopeEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - ProjectScope.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property ProjectScopeEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "ProjectScope_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, ProjectScopeFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ProjectScopeEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Rc.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property RcEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Rc", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Rc.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property RcEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Rc_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RccomponentOwnerEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RccomponentOwner.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property RccomponentOwnerEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RccomponentOwner", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RccomponentOwnerFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RccomponentOwnerEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RccomponentOwnerEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RccomponentOwner.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property RccomponentOwnerEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RccomponentOwner_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RccomponentOwnerFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RccomponentOwnerEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Rcorigin.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Rcorigin", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Rcorigin.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Rcorigin_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginRelationEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RcoriginRelation.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginRelationEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RcoriginRelation", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginRelationFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginRelationEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginRelationEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RcoriginRelation.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginRelationEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RcoriginRelation_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginRelationFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginRelationEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginResponsibleEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RcoriginResponsible.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginResponsibleEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RcoriginResponsible", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginResponsibleFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginResponsibleEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginResponsibleEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RcoriginResponsible.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginResponsibleEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RcoriginResponsible_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginResponsibleFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginResponsibleEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginUnitEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RcoriginUnit.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginUnitEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RcoriginUnit", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginUnitFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginUnitEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and RcoriginUnitEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - RcoriginUnit.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property RcoriginUnitEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "RcoriginUnit_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, RcoriginUnitFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RcoriginUnitEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and StandardTaskEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - StandardTask.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property StandardTaskEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "StandardTask_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, StandardTaskFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StandardTaskEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and StandardTaskEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - StandardTask.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property StandardTaskEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "StandardTask", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, StandardTaskFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StandardTaskEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and StatusEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Status.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property StatusEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Status", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, StatusFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StatusEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and StatusEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Status.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property StatusEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Status_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, StatusFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("StatusEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and TaskEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Task.ResponsiblePersonId
		''' </summary>
		Public Overridable ReadOnly Property TaskEntityUsingResponsiblePersonId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Task", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, TaskFields.ResponsiblePersonId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("TaskEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and TaskMilestoneEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - TaskMilestone.ResponsiblePersonId
		''' </summary>
		Public Overridable ReadOnly Property TaskMilestoneEntityUsingResponsiblePersonId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "TaskMilestone", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, TaskMilestoneFields.ResponsiblePersonId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("TaskMilestoneEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and TimelineEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Timeline.ChangedBy
		''' </summary>
		Public Overridable ReadOnly Property TimelineEntityUsingChangedBy() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Timeline", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, TimelineFields.ChangedBy)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("TimelineEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and VisitsEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Visits.CreatedById
		''' </summary>
		Public Overridable ReadOnly Property VisitsEntityUsingCreatedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Visits", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, VisitsFields.CreatedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("VisitsEntity", False)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between ParticipantEntity and VisitsEntity over the 1:n relation they have, using the relation between the fields:
		''' Participant.ParticipantId - Visits.DeletedById
		''' </summary>
		Public Overridable ReadOnly Property VisitsEntityUsingDeletedById() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Visits_", True)
				relation.AddEntityFieldPair(ParticipantFields.ParticipantId, VisitsFields.DeletedById)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ParticipantEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("VisitsEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticParticipantRelations
		Friend Shared ReadOnly AlertCategoryEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertCategoryEntityUsingCreatedById
		Friend Shared ReadOnly AlertCategoryEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertCategoryEntityUsingDeletedById
		Friend Shared ReadOnly AlertCategoryCriteriaEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertCategoryCriteriaEntityUsingCreatedById
		Friend Shared ReadOnly AlertCategoryCriteriaEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertCategoryCriteriaEntityUsingDeletedById
		Friend Shared ReadOnly AlertChangeTypeCriteriaEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertChangeTypeCriteriaEntityUsingCreatedById
		Friend Shared ReadOnly AlertChangeTypeCriteriaEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertChangeTypeCriteriaEntityUsingDeletedById
		Friend Shared ReadOnly AlertConfigEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertConfigEntityUsingCreatedById
		Friend Shared ReadOnly AlertConfigEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertConfigEntityUsingDeletedById
		Friend Shared ReadOnly AlertFrequencyEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertFrequencyEntityUsingCreatedById
		Friend Shared ReadOnly AlertFrequencyEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertFrequencyEntityUsingDeletedById
		Friend Shared ReadOnly AlertReceiverEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertReceiverEntityUsingCreatedById
		Friend Shared ReadOnly AlertReceiverEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertReceiverEntityUsingDeletedById
		Friend Shared ReadOnly AlertReceiverTypeEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertReceiverTypeEntityUsingCreatedById
		Friend Shared ReadOnly AlertReceiverTypeEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertReceiverTypeEntityUsingDeletedById
		Friend Shared ReadOnly AlertServiceSettingsEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().AlertServiceSettingsEntityUsingCreatedById
		Friend Shared ReadOnly AlertServiceSettingsEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().AlertServiceSettingsEntityUsingDeletedById
		Friend Shared ReadOnly CaseEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().CaseEntityUsingCreatedById
		Friend Shared ReadOnly CaseEntityUsingExecutionManagerIdStatic As IEntityRelation = New ParticipantRelations().CaseEntityUsingExecutionManagerId
		Friend Shared ReadOnly CaseEntityUsingLastEditedByIdStatic As IEntityRelation = New ParticipantRelations().CaseEntityUsingLastEditedById
		Friend Shared ReadOnly CaseEntityUsingManagerIdStatic As IEntityRelation = New ParticipantRelations().CaseEntityUsingManagerId
		Friend Shared ReadOnly CaseEntityUsingContainmentLeadIdStatic As IEntityRelation = New ParticipantRelations().CaseEntityUsingContainmentLeadId
		Friend Shared ReadOnly CaseEntityUsingTechnicalSpecialistIdStatic As IEntityRelation = New ParticipantRelations().CaseEntityUsingTechnicalSpecialistId
		Friend Shared ReadOnly Case2ParticipantEntityUsingParticipantIdStatic As IEntityRelation = New ParticipantRelations().Case2ParticipantEntityUsingParticipantId
		Friend Shared ReadOnly CategoryEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().CategoryEntityUsingCreatedById
		Friend Shared ReadOnly CategoryEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().CategoryEntityUsingDeletedById
		Friend Shared ReadOnly ChangeLogEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().ChangeLogEntityUsingCreatedById
		Friend Shared ReadOnly ChangeLogEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().ChangeLogEntityUsingDeletedById
		Friend Shared ReadOnly ChangeTypeEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().ChangeTypeEntityUsingCreatedById
		Friend Shared ReadOnly ChangeTypeEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().ChangeTypeEntityUsingDeletedById
		Friend Shared ReadOnly CirEntityUsingRejectedByStatic As IEntityRelation = New ParticipantRelations().CirEntityUsingRejectedBy
		Friend Shared ReadOnly CirEntityUsingVerifiedByStatic As IEntityRelation = New ParticipantRelations().CirEntityUsingVerifiedBy
		Friend Shared ReadOnly ComponentEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().ComponentEntityUsingCreatedById
		Friend Shared ReadOnly ComponentEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().ComponentEntityUsingDeletedById
		Friend Shared ReadOnly DiscussionEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().DiscussionEntityUsingCreatedById
		Friend Shared ReadOnly DiscussionEntityUsingModifiedByIdStatic As IEntityRelation = New ParticipantRelations().DiscussionEntityUsingModifiedById
		Friend Shared ReadOnly DocumentEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().DocumentEntityUsingCreatedById
		Friend Shared ReadOnly DocumentEntityUsingLockedByIdStatic As IEntityRelation = New ParticipantRelations().DocumentEntityUsingLockedById
		Friend Shared ReadOnly FolderEntityUsingCreatedByStatic As IEntityRelation = New ParticipantRelations().FolderEntityUsingCreatedBy
		Friend Shared ReadOnly FolderEntityUsingLockedByStatic As IEntityRelation = New ParticipantRelations().FolderEntityUsingLockedBy
		Friend Shared ReadOnly MilestoneEntityUsingResponsiblePersonIdStatic As IEntityRelation = New ParticipantRelations().MilestoneEntityUsingResponsiblePersonId
		Friend Shared ReadOnly NewsEntityUsingCreatedbyIdStatic As IEntityRelation = New ParticipantRelations().NewsEntityUsingCreatedbyId
		Friend Shared ReadOnly NewsEntityUsingModifiedByIdStatic As IEntityRelation = New ParticipantRelations().NewsEntityUsingModifiedById
		Friend Shared ReadOnly News2ParticipantEntityUsingParticipantIdStatic As IEntityRelation = New ParticipantRelations().News2ParticipantEntityUsingParticipantId
		Friend Shared ReadOnly Participant2RoleEntityUsingParticipantIdStatic As IEntityRelation = New ParticipantRelations().Participant2RoleEntityUsingParticipantId
		Friend Shared ReadOnly ParticipantLogEntityUsingParticipantIdStatic As IEntityRelation = New ParticipantRelations().ParticipantLogEntityUsingParticipantId
		Friend Shared ReadOnly PersonalSafetyEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().PersonalSafetyEntityUsingCreatedById
		Friend Shared ReadOnly PersonalSafetyEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().PersonalSafetyEntityUsingDeletedById
		Friend Shared ReadOnly PhaseEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().PhaseEntityUsingCreatedById
		Friend Shared ReadOnly PhaseEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().PhaseEntityUsingDeletedById
		Friend Shared ReadOnly PlatformEntityUsingCoordinatorStatic As IEntityRelation = New ParticipantRelations().PlatformEntityUsingCoordinator
		Friend Shared ReadOnly PopulationlistEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().PopulationlistEntityUsingCreatedById
		Friend Shared ReadOnly PopulationlistDocumentEntityUsingLockedByIdStatic As IEntityRelation = New ParticipantRelations().PopulationlistDocumentEntityUsingLockedById
		Friend Shared ReadOnly ProjectScopeEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().ProjectScopeEntityUsingCreatedById
		Friend Shared ReadOnly ProjectScopeEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().ProjectScopeEntityUsingDeletedById
		Friend Shared ReadOnly RcEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().RcEntityUsingCreatedById
		Friend Shared ReadOnly RcEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().RcEntityUsingDeletedById
		Friend Shared ReadOnly RccomponentOwnerEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().RccomponentOwnerEntityUsingCreatedById
		Friend Shared ReadOnly RccomponentOwnerEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().RccomponentOwnerEntityUsingDeletedById
		Friend Shared ReadOnly RcoriginEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginEntityUsingCreatedById
		Friend Shared ReadOnly RcoriginEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginEntityUsingDeletedById
		Friend Shared ReadOnly RcoriginRelationEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginRelationEntityUsingCreatedById
		Friend Shared ReadOnly RcoriginRelationEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginRelationEntityUsingDeletedById
		Friend Shared ReadOnly RcoriginResponsibleEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginResponsibleEntityUsingCreatedById
		Friend Shared ReadOnly RcoriginResponsibleEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginResponsibleEntityUsingDeletedById
		Friend Shared ReadOnly RcoriginUnitEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginUnitEntityUsingCreatedById
		Friend Shared ReadOnly RcoriginUnitEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().RcoriginUnitEntityUsingDeletedById
		Friend Shared ReadOnly StandardTaskEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().StandardTaskEntityUsingDeletedById
		Friend Shared ReadOnly StandardTaskEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().StandardTaskEntityUsingCreatedById
		Friend Shared ReadOnly StatusEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().StatusEntityUsingCreatedById
		Friend Shared ReadOnly StatusEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().StatusEntityUsingDeletedById
		Friend Shared ReadOnly TaskEntityUsingResponsiblePersonIdStatic As IEntityRelation = New ParticipantRelations().TaskEntityUsingResponsiblePersonId
		Friend Shared ReadOnly TaskMilestoneEntityUsingResponsiblePersonIdStatic As IEntityRelation = New ParticipantRelations().TaskMilestoneEntityUsingResponsiblePersonId
		Friend Shared ReadOnly TimelineEntityUsingChangedByStatic As IEntityRelation = New ParticipantRelations().TimelineEntityUsingChangedBy
		Friend Shared ReadOnly VisitsEntityUsingCreatedByIdStatic As IEntityRelation = New ParticipantRelations().VisitsEntityUsingCreatedById
		Friend Shared ReadOnly VisitsEntityUsingDeletedByIdStatic As IEntityRelation = New ParticipantRelations().VisitsEntityUsingDeletedById

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
