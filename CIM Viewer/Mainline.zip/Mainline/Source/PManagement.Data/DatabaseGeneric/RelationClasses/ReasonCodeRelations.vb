﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: ReasonCode.</summary>
	Public Class ReasonCodeRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the ReasonCodeEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.Case2ReasonCodeEntityUsingReasonCodeId)
			Return toReturn
		End Function

#Region "Class Property Declarations"

		''' <summary>Returns a new IEntityRelation Object, between ReasonCodeEntity and Case2ReasonCodeEntity over the 1:n relation they have, using the relation between the fields:
		''' ReasonCode.ReasonCodeId - Case2ReasonCode.ReasonCodeId
		''' </summary>
		Public Overridable ReadOnly Property Case2ReasonCodeEntityUsingReasonCodeId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.OneToMany, "Case2ReasonCode", True)
				relation.AddEntityFieldPair(ReasonCodeFields.ReasonCodeId, Case2ReasonCodeFields.ReasonCodeId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("ReasonCodeEntity", True)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("Case2ReasonCodeEntity", False)
				Return relation
			End Get
		End Property


		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticReasonCodeRelations
		Friend Shared ReadOnly Case2ReasonCodeEntityUsingReasonCodeIdStatic As IEntityRelation = New ReasonCodeRelations().Case2ReasonCodeEntityUsingReasonCodeId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
