﻿' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // This is generated code. 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
' // Code is generated using LLBLGen Pro version: 4.0
' // Code is generated on: 
' // Code is generated using templates: SD.TemplateBindings.SharedTemplates
' // Templates vendor: Solutions Design.
' // Templates version: 
' ////////////////////////////////////////////////////////////////////////////////////////////////////////
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports PManagement.Data
Imports PManagement.Data.FactoryClasses
Imports PManagement.Data.HelperClasses
Imports SD.LLBLGen.Pro.ORMSupportClasses

Namespace PManagement.Data.RelationClasses
	''' <summary>Implements the Shared Relations variant for the entity: RelatedCase2CaseRelation.</summary>
	Public Class RelatedCase2CaseRelationRelations
		''' <summary>CTor</summary>
		Public Sub New()
		End Sub

		''' <summary>Gets all relations of the RelatedCase2CaseRelationEntity as a list of IEntityRelation objects.</summary>
		''' <returns>a list of IEntityRelation objects</returns>
		Public Overridable Function GetAllRelations() As List(Of IEntityRelation)
			Dim toReturn As List(Of IEntityRelation)= New List(Of IEntityRelation)()
			toReturn.Add(Me.CaseRelationEntityUsingCaseRelationId)
			toReturn.Add(Me.RelatedCaseEntityUsingRelatedCaseId)
			Return toReturn
		End Function

#Region "Class Property Declarations"



		''' <summary>Returns a new IEntityRelation Object, between RelatedCase2CaseRelationEntity and CaseRelationEntity over the m:1 relation they have, using the relation between the fields:
		''' RelatedCase2CaseRelation.CaseRelationId - CaseRelation.CaseRelationId
		''' </summary>
		Public Overridable  ReadOnly Property CaseRelationEntityUsingCaseRelationId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "CaseRelation", False)
				relation.AddEntityFieldPair(CaseRelationFields.CaseRelationId, RelatedCase2CaseRelationFields.CaseRelationId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("CaseRelationEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RelatedCase2CaseRelationEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>Returns a new IEntityRelation Object, between RelatedCase2CaseRelationEntity and RelatedCaseEntity over the m:1 relation they have, using the relation between the fields:
		''' RelatedCase2CaseRelation.RelatedCaseId - RelatedCase.RelatedCaseId
		''' </summary>
		Public Overridable  ReadOnly Property RelatedCaseEntityUsingRelatedCaseId() As IEntityRelation
			Get
				Dim relation As IEntityRelation = New EntityRelation(SD.LLBLGen.Pro.ORMSupportClasses.RelationType.ManyToOne, "RelatedCase", False)
				relation.AddEntityFieldPair(RelatedCaseFields.RelatedCaseId, RelatedCase2CaseRelationFields.RelatedCaseId)
				relation.InheritanceInfoPkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RelatedCaseEntity", False)
				relation.InheritanceInfoFkSideEntity = InheritanceInfoProviderSingleton.GetInstance().GetInheritanceInfo("RelatedCase2CaseRelationEntity", True)
				Return relation
			End Get
		End Property
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSubTypeRelation(subTypeEntityName As String) As IEntityRelation 
			Return Nothing
		End Function
		''' <summary>stub, not used In this entity, only For TargetPerEntity entities.</summary>
		Public Overridable Function GetSuperTypeRelation() As IEntityRelation 
			Return Nothing
		End Function
#End Region

#Region "Included Code"

#End Region
	End Class
		
	''' <summary>Static Class which Is used For providing relationship instances which are re-used internally For syncing</summary>
	Friend Class StaticRelatedCase2CaseRelationRelations
		Friend Shared ReadOnly CaseRelationEntityUsingCaseRelationIdStatic As IEntityRelation = New RelatedCase2CaseRelationRelations().CaseRelationEntityUsingCaseRelationId
		Friend Shared ReadOnly RelatedCaseEntityUsingRelatedCaseIdStatic As IEntityRelation = New RelatedCase2CaseRelationRelations().RelatedCaseEntityUsingRelatedCaseId

		''' <summary>CTor</summary>
		Shared Sub New()
		End Sub
	End Class
End Namespace
